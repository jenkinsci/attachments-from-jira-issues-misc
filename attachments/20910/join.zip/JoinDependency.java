package join;

import hudson.model.AbstractBuild;
import hudson.model.AbstractProject;
import hudson.model.Action;
import hudson.model.Cause;
import hudson.model.DependencyGraph;
import hudson.model.Result;
import hudson.model.Run;
import hudson.model.TaskListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
* @author wolfs
*/
public class JoinDependency<DEP extends DependencyGraph.Dependency> extends DependencyGraph.Dependency {
    private static final Logger LOGGER = Logger.getLogger(JoinDependency.class.getName());

    private AbstractProject<?,?> splitProject;
    protected DEP splitDependency;
      
    private JoinDependency<?> upstreamDependency;
    private Object lock = new Object();
    private Integer splitBuildId;
    

    JoinDependency(AbstractProject<?, ?> upstream, AbstractProject<?, ?> downstream, AbstractProject<?, ?> splitProject,
    		JoinDependency<?> upstreamDependency) {
        super(upstream, downstream);
        this.splitProject = splitProject;
        this.upstreamDependency = upstreamDependency;
    }

    /**
     * @return true if this JoinDependency and the one passed as argument share a common ancestor split project, i.e.
     * both dependencies where introduces in DependencyGraph from the same job
     */
    public boolean fromSameSplitProject(JoinDependency<?> other) {
        return this.splitProject.equals(other.splitProject);
    }

    @Override
    public boolean shouldTriggerBuild(AbstractBuild build, TaskListener listener, List<Action> actions) {
        AbstractBuild<?,?> splitBuild = getSplitBuild(build);
        if (splitBuild != null) {
            final JoinAction joinAction = splitBuild.getAction(JoinAction.class);
            if(joinAction != null) {
                listener.getLogger().println("Notifying upstream build " + splitBuild + " of job completion");
                boolean joinDownstreamFinished = joinAction.downstreamFinished(splitBuild, build, listener);
                joinDownstreamFinished = joinDownstreamFinished &&
                        conditionIsMet(joinAction.getOverallResult()) &&
                            splitDependency.shouldTriggerBuild(splitBuild, listener, actions);
                return joinDownstreamFinished;
            }
        }
        // does not go in the build log, since this is normal for any downstream project that
        // runs without the join plugin enabled
        LOGGER.log(Level.FINER, "Join notifier cannot find upstream JoinAction: {0}", splitBuild);
        return false;
    }

    private AbstractBuild<?,?> getSplitBuild(AbstractBuild<?,?> build) {
        final List<Cause> causes = build.getCauses();
        AbstractBuild<?,?> splitBuild = null;
        // If there is no intermediate project this will happen
        if (splitProject.getName().equals(build.getProject().getName())) {
            splitBuild = build;
        }
        for (Cause cause : causes) {
            if (cause instanceof JoinAction.JoinCause) {
                continue;
            }
            if (cause instanceof Cause.UpstreamCause) {
                Cause.UpstreamCause uc = (Cause.UpstreamCause) cause;
            	final String upstreamProject = uc.getUpstreamProject();
                
                //Direct link to main project and it's build
                if (splitProject.getName().equals(upstreamProject)) {
                    final Run<?,?> upstreamRun = splitProject.getBuildByNumber(uc.getUpstreamBuild());
                    if (upstreamRun instanceof AbstractBuild<?,?>) {
                        splitBuild = (AbstractBuild<?,?>) upstreamRun;
                        synchronized (this.lock) {
                        	splitBuildId = uc.getUpstreamBuild();
						}
                        break;
                    }
                }
                
                splitBuild = findSplitBuildInDependencyGraph(uc, this.upstreamDependency);  
            }
        }
        return splitBuild;
    }
    
    
    
    private AbstractBuild<?,?> findSplitBuildInDependencyGraph(Cause.UpstreamCause rootCause, JoinDependency<?> upstreamDedendency){
    	AbstractBuild<?,?> splitBuild = null;
        if(upstreamDedendency!=null){
	        //Direct link to upper project and it's build
	        if (upstreamDedendency.getUpstreamProject().getName().equals(rootCause.getUpstreamProject())) {
	        	synchronized (upstreamDependency.lock) {
	        		final Run<?,?> upstreamRun = splitProject.getBuildByNumber(upstreamDependency.splitBuildId);
	        		synchronized (this.lock) {
						this.splitBuildId = upstreamDependency.splitBuildId;
					}
		            if (upstreamRun instanceof AbstractBuild<?,?>) {
		                splitBuild = (AbstractBuild<?,?>) upstreamRun;
		            }
				}
	        }else{
	        	splitBuild = findSplitBuildInDependencyGraph(rootCause,upstreamDedendency.upstreamDependency);
	        }
        }
        return splitBuild;
    }

    protected boolean conditionIsMet(Result overallResult) {
        return true;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        if (!super.equals(obj)) {
            return false;
        }
        final JoinDependency<DEP> other = (JoinDependency<DEP>) obj;
        if (this.splitProject != other.splitProject && (this.splitProject == null || !this.splitProject.equals(other.splitProject))) {
            return false;
        }
        if (this.splitDependency != other.splitDependency && (this.splitDependency == null || !this.splitDependency.equals(other.splitDependency))) {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 79 * hash + super.hashCode();
        hash = 79 * hash + (this.splitProject != null ? this.splitProject.hashCode() : 0);
        hash = 79 * hash + (this.splitDependency != null ? this.splitDependency.hashCode() : 0);
        return hash;
    }



}

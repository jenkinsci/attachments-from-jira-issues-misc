import hudson.console.ModelHyperlinkNote.*

class PrintHandler implements Serializable {

    static def logHandlers = [:]

    static def classArray = [:]
    static def log_backlog = ""
    static def groovyPost = false


    static def colorTable = [:]

    static def className = "PrintHandler"

    static def jenkinsGetBuild
    static def stackHandler
    static def pipelinePrint
    static def jenkins_info
    static def minimize_output = false
    static def ispipeline = false
    static def initState = "implicit"

    static def initClass(classes, info) {
        classArray = classes
        jenkinsGetBuild = classArray.get("JenkinsGetBuild")
        // pipelinePrint = classes.get("PipelinePrint")
        stackHandler = classes.get("StackHandler")
        this.jenkins_info = info
        def url = jenkins_info.get('envMap').get('JENKINS_URL')
        def envpipe = jenkins_info.get('envMap').get('ISPIPELINE')
        if (envpipe) {
            ispipeline = true
        }
        if (url.contains('qa')) {
            setVerbose("off")
        }
        initColors(this.jenkins_info.get('buildManager'))
        printEmphasizeLog("initClass PrintHandler")

    }

    static def remove_colors(str) {
        if (colorTable.get("ANSI_RESET") != "") {
            colorTable.each { ansi, c_str ->
                str = str.replace(c_str, "")
            }
        }
        return str
    }

    static def initColors(buildManager) {
        if (!(buildManager.getClass() =~ /.*[wW]ork.*/)) {
            colorTable.put("ANSI_RESET", "\u001B[0m")
            colorTable.put("ANSI_BLACK", "\u001B[30m")
            colorTable.put("ANSI_RED", "\u001B[31m")
            colorTable.put("ANSI_GREEN", "\u001B[32m")
            colorTable.put("ANSI_YELLOW", "\u001B[33m")
            colorTable.put("ANSI_BLUE", "\u001B[34m")
            colorTable.put("ANSI_PURPLE", "\u001B[35m")
            colorTable.put("ANSI_CYAN", "\u001B[36m")
            colorTable.put("ANSI_WHITE", "\u001B[37m")
            colorTable.put("ANSI_BLACK_BACKGROUND", "\u001B[40m")
            colorTable.put("ANSI_RED_BACKGROUND", "\u001B[41m")
            colorTable.put("ANSI_GREEN_BACKGROUND", "\u001B[42m")
            colorTable.put("ANSI_YELLOW_BACKGROUND", "\u001B[43m")
            colorTable.put("ANSI_BLUE_BACKGROUND", "\u001B[44m")
            colorTable.put("ANSI_PURPLE_BACKGROUND", "\u001B[45m")
            colorTable.put("ANSI_CYAN_BACKGROUND", "\u001B[46m")
            colorTable.put("ANSI_WHITE_BACKGROUND", "\u001B[47m")
        } else {
            colorTable.put("ANSI_RESET", "")
            colorTable.put("ANSI_BLACK", "")
            colorTable.put("ANSI_RED", "")
            colorTable.put("ANSI_GREEN", "")
            colorTable.put("ANSI_YELLOW", "")
            colorTable.put("ANSI_BLUE", "")
            colorTable.put("ANSI_PURPLE", "")
            colorTable.put("ANSI_CYAN", "")
            colorTable.put("ANSI_WHITE", "")
            colorTable.put("ANSI_BLACK_BACKGROUND", "")
            colorTable.put("ANSI_RED_BACKGROUND", "")
            colorTable.put("ANSI_GREEN_BACKGROUND", "")
            colorTable.put("ANSI_YELLOW_BACKGROUND", "")
            colorTable.put("ANSI_BLUE_BACKGROUND", "")
            colorTable.put("ANSI_PURPLE_BACKGROUND", "")
            colorTable.put("ANSI_CYAN_BACKGROUND", "")
            colorTable.put("ANSI_WHITE_BACKGROUND", "")

        }

    }

    static def timeStamp() {
        return new Date().format("yyyy/MM/dd-HH:mm:ss.SS")
    }

    static def logPrint(out_string, logs = ["output"], raw = false) {
        def output
        def stackInfo
        if (stackHandler) {
            stackInfo = sprintf(" %s ", stackHandler.getMethodInfo(8))
        } else {
            stackInfo = ""
        }
        if (!raw && !minimize_output) {
            output = sprintf("%s%s- %s", timeStamp(), stackInfo, out_string)
        } else {
            output = out_string
        }
        if (!logs.any { l -> l == "logger" }) {
            logs.add("logger")
        }
        if (minimize_output) {
            def minimize_logs = []
            logs.each { l ->
                l
                if (l != "output") {
                    minimize_logs.add(l)
                }
            }
            logs = minimize_logs
        }

        if (ispipeline) {
            output = remove_colors(output)
        }
        logs.each { logname ->
            if (pipelinePrint && (logname == "output" || logname == "error")) {
                pipelinePrint.pipelinePrint(output)
            } else {
                def logentry = logHandlers.get(logname)
                def logptr = null
                def use_output = output
                if (logentry) {
                    logptr = logentry.get("fileDescriptor")
                }

                if (logname == "logger") {
                    if (minimize_output && !raw) {
                        use_output = sprintf("%s%s- %s", timeStamp(), stackInfo, out_string)
                    }
                    if (!ispipeline) {
                        use_output = remove_colors(use_output)
                    }
                }
                if (logptr) {
                    logptr.println(use_output)
                    if (log_backlog.size() > 0 && logname == "logger") {
                        logptr.println(log_backlog)
                        log_backlog = ""
                    }
                    logptr.flush()
                } else {
                    if (logname == "logger") {
                        if (initState.size() > 0) {
                            log_backlog = "${log_backlog}\nPrinting Initialized(${initState})"
                            initState = ""
                        }
                        log_backlog = "${log_backlog}\n${use_output}"
                    }
                }
            }
        }
    }

    static def printHref(str,url,logs=["output"]) {
        def output = hudson.console.ModelHyperlinkNote.encodeTo(url,str)
        printConsole(output)
    }

    // Console Functions
    static def printConsoleColor(outstr, clr = "BLUE", info = "") {
        def output
        def color
        if (!clr.startsWith("ANSI_")) {
            color = "ANSI_" + clr
        } else {
            color = clr
        }
        if (info) {
            output = sprintf("%s[%s] - %s%s", colorTable.get(color), info, outstr, colorTable.get("ANSI_RESET"))
        } else {
            output = sprintf("%s%s%s", colorTable.get(color), outstr, colorTable.get("ANSI_RESET"))
        }
        logPrint(output, ["console"])
    }

    static def printConsole(str) {
        logPrint(str, ["console"])
    }

    static def printConsoleRaw(str) {
        logPrint(str, ["console"], true)
    }


    static def printConsoleBlue(outstr) {
        printConsoleColor(outstr, "BLUE", "INFO")

    }

    static def printConsoleYellow(outstr) {
        printConsoleColor(outstr, "YELLOW", "INFO")
    }

    static def printConsolePurple(outstr) {
        printConsoleColor(outstr, "PURPLE", "INFO")
    }

    static def printConsoleRed(outstr) {
        printConsoleColor(outstr, "RED", "INFO")
    }

    static def printConsoleGreen(outstr) {
        printConsoleColor(outstr, "GREEN", "INFO")
    }

    // Emphasize functions


    static def emphasize(str, prechr = ">", postchr = "<", chrcount = 10) {
        return sprintf("%s %s %s", prechr * chrcount, str, postchr * chrcount)
    }

    static def printEmphasizeConsole(str, prechr = ">", postchr = "<", chrcount = 10) {
        def output = emphasize(str, prechr, postchr, chrcount)
        printConsole(output)
    }

    static def printEmphasizeConsoleColor(str, prechr = ">", postchr = "<", chrcount = 10, color = "BLUE") {
        def output = emphasize(str, prechr, postchr, chrcount)
        printConsoleColor(output, color)
    }

    static def printEmphasize(str, prechr = ">", postchr = "<", chrcount = 10, logs = ["output"]) {
        def output = emphasize(str, prechr, postchr, chrcount)
        printRaw(output, logs)
    }

    static def printEmphasizeLog(str, prechr = ">", postchr = "<", chrcount = 10) {
        def output = emphasize(str, prechr, postchr, chrcount)
        printLog(output)
    }

    static def printEmphasizeLogVerbose(str, prechr = ">", postchr = "<", chrcount = 10) {
        def output = emphasize(str, prechr, postchr, chrcount)
        printLog(output)
    }

    static def printEmphasizeColor(str, clr = "BLUE", logs = ["output"]) {
        logPrint(coloredEmphasize(str, clr), logs, true)
    }

    // Drawing functions
    static def drawLine(str, chr = '-') {
        def length = str.size()
        if (length > 0) {
            return chr * length
        } else {
            return ""
        }
    }

    static def drawUnderLine(str, chr = "-") {
        def output
        output = sprintf("%s\n%s", str, drawLine(str, chr))
        return output
    }

    static def drawBox(str, linechr = '-', cornerchr = '+') {
        def output
        def columnchr = "|"
        def topbottomline = cornerchr + drawLine(" ${str} ", linechr) + cornerchr
        def strline = "${columnchr} ${str} ${columnchr}"
        output = sprintf("%s\n%s\n%s", topbottomline, strline, topbottomline)
        return output
    }

    static def coloredBox(str, clr = "BLUE") {
        def output = drawBox(str)
        output = colorOutput(output, clr)
        return output
    }

    static def coloredUnderline(str, clr = "BLUE") {
        def output = drawUnderLine(str)
        output = colorOutput(output, clr)
        return output
    }

    static def coloredEmphasize(str, clr = "BLUE") {
        def output = emphasize(str)
        output = colorOutput(output, clr)
        return output
    }

    static def colorOutput(str, clr = "BLUE") {
        def color
        if (!clr.startsWith("ANSI_")) {
            color = "ANSI_" + clr
        } else {
            color = clr
        }
        return sprintf("%s%s%s", colorTable.get(color), str, colorTable.get("ANSI_RESET"))
    }

    // PrintBox functions
    static def printBox(str, linechr = '-', cornerchr = '+', logs = ["output"]) {
        def output = drawBox(str, linechr, cornerchr)
        printRaw(output, logs)
    }

    static def printBoxLog(str, linechr = '-', cornerchr = '+') {
        def output = drawBox(str, linechr, cornerchr)
        printRaw(output, ["logger"])
    }

    static def printBoxConsole(str, linechr = '-', cornerchr = '+') {
        def output = drawBox(str, linechr, cornerchr)
        printRaw(output, ["console"])
    }

    static def printBoxColor(str, clr = "BLUE", logs = ["output"]) {
        logPrint(coloredBox(str, clr), logs, true)
    }
    // Underline functions

    static def printUnderline(str, chr = "-", logs = ["output"]) {
        def output = drawUnderLine(str, chr)
        printRaw(output, logs)
    }

    static def printUnderlineLog(str, chr = "-") {
        def output = drawUnderLine(str, chr)
        printRaw(output, ["logger"])
    }

    static def printUnderlineConsole(str, chr = "-") {
        def output = drawUnderLine(str, chr)
        printRaw(output, ["console"])
    }

    static def printUnderlineColor(str, clr = "BLUE", logs = ["output"]) {
        logPrint(coloredUnderline(str, clr), logs, true)
    }

    // Raw functions
    static def printRaw(outstr, logs = ["output"]) {
        def output = outstr
        logPrint(output, logs, true)
    }

    static def printRawLog(outstr) {
        def logs = ["logger"]
        def output = outstr
        logPrint(output, logs, true)
    }

    // Log functions
    static def printLog(outstr) {
        def logs = ["logger"]
        def output = sprintf("[%s] - %s", "INFO", outstr)
        logPrint(output, logs)
    }

    static def printLogVerbose(outstr, logs = ["logger"]) {
        def output = sprintf("[%s] - %s", "LOGINFO", outstr)
        logPrint(output, logs)
    }

    static def printLogException(outstr, logs = ["logger"]) {
        def output = sprintf("[%s] - %s", "EXCEPTION", outstr)
        logPrint(output, logs)
    }

    static def printLogWithDebug(outstr) {
        def logs = ["logger"]
        def output = sprintf("[%s] - %s", "DEBUGLOG", outstr)
        logPrint(output, logs)
    }

    // Standard info functions
    static def printInfo(outstr, logs = ["output"]) {
        def output = sprintf("%s[%s] - %s%s", colorTable.get("ANSI_RESET"), "INFO", outstr, colorTable.get("ANSI_RESET"))
        logPrint(output, logs)
    }


    static def printBlueInfo(outstr, logs = ["output"]) {
        def output = sprintf("%s[%s] - %s%s", colorTable.get("ANSI_BLUE"), "INFO", outstr, colorTable.get("ANSI_RESET"))
        logPrint(output, logs)
    }

    static def printYellowInfo(outstr, logs = ["output"]) {
        def output = sprintf("%s[%s] - %s%s", colorTable.get("ANSI_YELLOW"), "INFO", outstr, colorTable.get("ANSI_RESET"))
        logPrint(output, logs)
    }

    static def printPurpleInfo(outstr, logs = ["output"]) {
        def output = sprintf("%s[%s] - %s%s", colorTable.get("ANSI_PURPLE"), "INFO", outstr, colorTable.get("ANSI_RESET"))
        logPrint(output, logs)
    }

    static def printRedInfo(outstr, logs = ["output"]) {
        def output = sprintf("%s[%s] - %s%s", colorTable.get("ANSI_RED"), "INFO", outstr, colorTable.get("ANSI_RESET"))
        logPrint(output, logs)
    }

    static def printGreenInfo(outstr, logs = ["output"]) {
        def output = sprintf("%s[%s] - %s%s", colorTable.get("ANSI_GREEN"), "INFO", outstr, colorTable.get("ANSI_RESET"))
        logPrint(output, logs)
    }

    // Specialty functions
    static def printStackInfo(outstr, logs = ["output"]) {
        def output = sprintf("%s[%s] - %s%s", colorTable.get("ANSI_CYAN"), "STACK_INFO", outstr, colorTable.get("ANSI_RESET"))
        logPrint(output, logs)
    }

    static def printDebug(outstr, logs = ["output"]) {
        if (jenkinsGetBuild.inDebug()) {
            def output = sprintf("%s[%s] - %s%s", colorTable.get("ANSI_PURPLE"), "DEBUG_INFO", outstr, colorTable.get("ANSI_RESET"))
            logPrint(output, logs)
        }
    }


    static def printError(outstr, logs = ["error"]) {
        def output = sprintf("%s[%s] - %s%s", colorTable.get("ANSI_RED"), "ERROR", outstr, colorTable.get("ANSI_RESET"))
        logPrint(output, logs)
    }

    static def printException(outstr, logs = ["error"]) {
        def output = sprintf("%s[%s] - %s%s", colorTable.get("ANSI_RED"), "EXCEPTION", outstr, colorTable.get("ANSI_RESET"))
        logPrint(output, logs)
    }

    static def printSuccess(outstr, logs = ["output"]) {
        def output = sprintf("%s[%s] - %s%s", colorTable.get("ANSI_GREEN"), "SUCCESS", outstr, colorTable.get("ANSI_RESET"))
        logPrint(output, logs)
    }

    static def printWarning(outstr, logs = ["output"]) {
        def output = sprintf("%s[%s] - %s%s", colorTable.get("ANSI_BLACK") + colorTable.get("ANSI_YELLOW_BACKGROUND"), "WARNING", outstr, colorTable.get("ANSI_RESET"))
        logPrint(output, logs)
    }

    static def notify(outstr, logs = ["output"]) {
        def output = sprintf("%s[%s] - %s%s", colorTable.get("ANSI_BLACK") + colorTable.get("ANSI_CYAN_BACKGROUND"), "NOTIFICATION", outstr, colorTable.get("ANSI_RESET"))
        logPrint(output, logs)
    }

    // Init Log  Functions
    static def logInitFileName(logname, String fileName, override = true) {
        def loghandler = logHandlers.get(logname)
        if (loghandler) {
            def loginfostr = ''
            if (override) {
                loginfostr = sprintf("Overriding loghandler %s (filename = %s) with new file %s", logname, loghandler.get("fileName"), fileName)
                def fd = new PrintWriter(fileName)
                logHandlers.get(logname).put("fileName", fileName)
                logHandlers.get(logname).put("fileDescriptor", fd)
            } else {
                loginfostr = sprintf("Can't override log ignoring")
            }
            printWarning(loginfostr)
        } else {
            def fd = new PrintWriter(fileName)
            logHandlers.put(logname, [:])
            logHandlers.get(logname).put("fileName", fileName)
            logHandlers.get(logname).put("fileDescriptor", fd)
        }

    }


    static def logInitFileDescriptor(logname, fileDescriptor, override = true) {
        def loghandler = logHandlers.get(logname)
        if (loghandler) {
            def loginfostr = ''
            if (override) {
                loginfostr = sprintf("Overriding loghandler %s (fd = %s) with new descriptor %s", logname, loghandler.toString(), fileDescriptor.toString())
                logHandlers.get(logname).put("fileName", "NoName")
                logHandlers.get(logname).put("fileDescriptor", fileDescriptor)
            } else {
                loginfostr = sprintf("Can't override log ignoring")
            }
            printWarning(loginfostr)
        } else {
            logHandlers.put(logname, [:])
            logHandlers.get(logname).put("fileName", "NoName")
            logHandlers.get(logname).put("fileDescriptor", fileDescriptor)
        }

    }

    static def setVerbose(status = "on") {
        if (status == "on") {
            minimize_output = false
        } else {
            minimize_output = true
        }
    }

    // Closing functions

    static def closeLogs() {
        printInfo("Closing all logs ....")
        logHandlers.each { log, value ->
            if (log == "output" || log == "error" || log == "console") {
                flushLog(value."fileDescriptor")
            } else {
                closeLog(value."fileDescriptor")
            }
        }
    }

    static def flushLog(fd) {
        if (fd) {
            if (fd.getClass().toString() == "class java.io.PrintWriter") {
                fd.flush()
            } else {
                try {
                    fd.flush()
                } catch (e) {
                    def x = 1
                    // this is to ignore any errors here
                }
            }

        }
    }

    static def getLogFd(logname) {
        def log_info = logHandlers.get(logname)
        if (log_info) {
            return log_info.get("fileDescriptor")
        }
        return null
    }

    static def removeLog(logname) {
        def logFd = getLogFd(logname)
        if (logFd) {
            logFd.delete()
            logHandlers[logname].remove()
        }
    }

    static def closeLog(fd) {
        if (fd) {
            if (fd.getClass().toString() == "class java.io.PrintWriter") {
                fd.flush()
                fd.close()
            } else {
                try {
                    fd.flush()
                    fd.close()
                } catch (e) {
                    def x = 1
                    // this is to ignore any errors here
                }
            }

        }
    }

    // Init functions
    static def printInit() {
        def outlog = jenkins_info.get("output")

        logHandlers.put("output", [:])
        logHandlers.put("error", [:])
        logHandlers.put("console", [:])

        logHandlers.get("output").put("fileName", "stdout")
        logHandlers.get("output").put("fileDescriptor", outlog)

        logHandlers.get("console").put("fileName", "console")
        logHandlers.get("console").put("fileDescriptor", outlog)

        logHandlers.get("error").put("fileName", "error")
        logHandlers.get("error").put("fileDescriptor", outlog)
        initColors("no color")
    }

    static def printInit(stdout, stderr) {

        logHandlers.put("output", [:])
        logHandlers.put("error", [:])
        logHandlers.put("console", [:])

        logHandlers.get("output").put("fileName", "stdout")
        logHandlers.get("output").put("fileDescriptor", stdout)

        logHandlers.get("console").put("fileName", "console")
        logHandlers.get("console").put("fileDescriptor", stdout)

        logHandlers.get("error").put("fileName", "stderr")
        logHandlers.get("error").put("fileDescriptor", stderr)
        initColors("no_color")
        initState = "explicit"
    }

}


class ExceptionHandlerClass implements Serializable {


    static def printHandler

    static def initClass(classes, info) {
        def classArray = classes
        printHandler = classArray.get("PrintHandler")
        printHandler.printEmphasizeLog("initClass ExceptionHandler")
    }

    static def filterout = ['org.codehaus',
                            'RunPython',
                            '$',
                            'groovy.lang',
                            'jenkinsci',
                            'hudson',
                            'sun.',
                            'java.lang']

    static def filter = "yes"


    static def printExceptionStack(e) {
        StackTraceElement[] elements = e.getStackTrace();
        printHandler.printBoxColor("Internal Exception!!!!","RED")
        for (int iterator = 1; iterator <= elements.length; iterator++) {
            def className = elements[iterator - 1].getClassName()
            def method = elements[iterator - 1].getMethodName()
            def printit = true
            if (filter == "yes") {
                filterout.each { f ->
                    //printHandler.printRedInfo("Checking class: ${className} Method: ${method}")
                    if (className.contains(f) || method.contains(f)) {
                        printit = false
                    }
                }
            }
            if (printit) {
                printHandler.printConsoleRaw("[Exception STACK_INFO] Class Name:" + elements[iterator - 1].getClassName() + " Method Name:" + elements[iterator - 1].getMethodName() + " Line Number:" + elements[iterator - 1].getLineNumber());
            }
        }
        printHandler.printBoxColor("End of stack", "RED")
    }

    static def getExceptionStack(e) {
        def stackInfo = []
        StackTraceElement[] elements = e.getStackTrace();
        for (int iterator = 1; iterator <= elements.length; iterator++) {
            def className = elements[iterator - 1].getClassName()
            def method = elements[iterator - 1].getMethodName()
            def printit = true
            if (filter == "yes") {
                filterout.each { f ->
                    //printHandler.printRedInfo("Checking class: ${className} Method: ${method}")
                    if (className.contains(f) || method.contains(f)) {
                        printit = false
                    }
                }
            }
            if (printit) {
                stackInfo.add("[Exception STACK_INFO] Class Name:" + elements[iterator - 1].getClassName() + " Method Name:" + elements[iterator - 1].getMethodName() + " Line Number:" + elements[iterator - 1].getLineNumber())
            }
        }
        return stackInfo
    }


}

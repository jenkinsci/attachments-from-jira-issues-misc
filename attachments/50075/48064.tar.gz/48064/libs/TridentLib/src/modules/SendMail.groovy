import javax.mail.*
import javax.mail.internet.*


class SendMailClass implements Serializable  {


    static def classArray = [:]

    static def printHandler

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get('PrintHandler')
        printHandler.printEmphasizeLog("initClass SendMail")
    }

    def sendMail(host = 'mailhub.lss.emc.com', sender = 'XtremIO QA Jenkins <xtremio-qa-jenkins@emc.com', receivers, subject, text) {

        Properties props = System.getProperties()
        props.put("mail.smtp.host", host)
        Session session = Session.getDefaultInstance(props, null)
        MimeMessage message = new MimeMessage(session)
        message.setFrom(new InternetAddress(sender))

        receivers.split(',').each {
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(it))
        }

        message.setSubject(subject)
        message.setText(text)

        printHandler.printConsole('Sending mail to ' + receivers + '.')
        printHandler.printLog("Subject: ${subject}")
        printHandler.printLog("Content:\n ${text}")
        Transport.send(message)
        printHandler.printInfo('Mail sent.')
    }

}

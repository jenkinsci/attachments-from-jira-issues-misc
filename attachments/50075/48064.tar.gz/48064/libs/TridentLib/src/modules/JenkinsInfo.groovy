class JenkinsInfo implements Serializable {

    static def classArray = [:]

    static def jenkins_info

    static def initClass(classes, info) {
        this.jenkins_info = info
    }

    static def getTmpWorkArea() {
        return jenkins_info.get('workarea')
    }

    static def getWorkSpace() {
        return jenkins_info.get('workspace')
    }

    static def getJenkinsInstance() {
        return jenkins_info.get('j_instance')
    }

    static def getHudsonInstance() {
        return jenkins_info.get('h_instance')
    }

    static def getBuildManager() {
        return jenkins_info.get('buildManager')
    }

    static def getOutput() {
        return jenkins_info.get('output')
    }

    static def getErr() {
        return jenkins_info.get('err')
    }

    static def getBuild() {
        return jenkins_info.get('build')
    }

    static def getBrickname() {
        return jenkins_info.get('brickName')
    }

    static def getParams() {
        return jenkins_info.get('params')
    }

    static def getEnvMap() {
        return jenkins_info.get('envMap')
    }

    static def getLibrarySpace() {
        return jenkins_info.get('library_space')
    }

}

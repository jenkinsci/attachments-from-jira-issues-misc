class XpoolManager implements Serializable {

    static def classArray = [:]

    static def jenkinsHome = ""
    static def groovyHome = ""
    static def groupFile = ""
    static def xpoolGroups = []

    static def xpoolInitialized = false

    static def jenkinsEnv
    static def printHandler
    static def runShell
    static def nativeReplication
    static def jenkins_info
    static def xpoolRest
    static String xpool_command

    static def initClass(classes, info) {
        classArray = classes
        jenkinsEnv = classArray.get("JenkinsEnv")
        printHandler = classArray.get("PrintHandler")
        printHandler.printEmphasizeLog("initClass XpoolManager")
        runShell = classArray.get("RunShell")
        nativeReplication = classArray.get("NativeReplication")
        xpoolRest = classArray.get("XpoolRest")
        xpool_command = jenkinsEnv.getenv('XPOOL_HOME') + "/xpool"
        this.jenkins_info = info
    }


    static def xpoolInit() {
        if (!xpoolInitialized) {
            jenkinsHome = jenkinsEnv.getenv("JENKINS_HOME")
            groovyHome = jenkinsEnv.getenv("TRIDENTLIBHOME") ?: jenkinsEnv.getenv("TRI_GROOVY_HOME")
            if (groovyHome.size() == 0) {
                if (jenkinsEnv.isQA()) {
                    groovyHome = "/root/TridentLib/src"
                } else {
                    groovyHome = "/home/jenkins-dev/TridentLib/src"
                }
            }

            if (jenkinsEnv.isQA()) {
                groupFile = "${groovyHome}/datafiles/qaxpoolGroups.dat"
            } else {
                groupFile = "${groovyHome}/datafiles/xpoolGroups.dat"
            }
            def jenkinsGroups = jenkinsEnv.getenv("GROUP") ?: jenkinsEnv.getenv("XPOOLGROUP")
            if (jenkinsGroups) {
                xpoolGroups = jenkinsGroups.replace('#', '')
            } else {
                xpoolGroups = new File(groupFile).readLines().join(",")
            }
            xpoolInitialized = true
        }
    }


    static def xpoolExtend(String cluster, String message, taggedCluster = "") {
        if (1) {
            return xpoolRest.restInvestigate(cluster)
        } else {
            def cluster_owner = xpoolGetOwner(cluster, taggedCluster)
            def cluster_name = cluster
            if (cluster_owner) {
                if (cluster_owner.equalsIgnoreCase('no_xpool')) {
                    return 'xpoolExtend: Could not find ' + cluster + ' in xpool\nNothing to do'
                }
                def xpool_execute = xpool_command + ' investigation -u ' + cluster_owner
                if (taggedCluster.size() == 0) {
                    xpool_execute += " ${cluster_name}"
                } else {
                    xpool_execute += " -t ${taggedCluster}"
                }
                message = message.replace(" ", "_")
                xpool_execute += " -m ${message}"
                def out_mesg = runShell.runCommand(xpool_execute)

                return out_mesg
            } else {
                return 'xpoolExtend: Could not find owner for ' + cluster + '\nNo extension done'
            }
        }
    }

    static def unTagCluster(cluster) {
        if (nativeReplication) {
            if (nativeReplication.isNative) {
                if (nativeReplication.taggedCluster) {
                    if (1) {
                        return xpoolRest.restUntagCluster(cluster, nativeReplication.taggedCluster)
                    } else {
                        def user = xpoolGetOwner(cluster, "")
                        def command = xpool_command + " remove_tag " + nativeReplication.taggedCluster + " -c " + cluster + " -u " + user
                        def out_mesg = runShell.runCommand(command)
                        return out_mesg
                    }
                }
            }
        }
    }

    static def restoreTags(clusters) {
        if (clusters.size() > 0) {
            if (nativeReplication) {
                if (nativeReplication.isNative) {
                    if (1) {
                        return xpoolRest.restRestoreTags(clusters, nativeReplication.taggedCluster)

                    } else {
                        def tag = nativeReplication.taggedCluster
                        def user = xpoolGetOwner("", tag)
                        printHandler.printConsoleColor("[INFO] Restoring tag ($tag} to clusters " + clusters.join(","))
                        clusters.each { cl ->
                            def command = xpool_command + " add_tag -c ${cl} -u ${user} ${tag}"
                            def out_mesg = runShell.runCommand(command)
                            return out_mesg
                        }
                    }

                }
            }
        }
    }


	static String getrunSshCommand(command, user='jenkins-dev')
	{
		String security_skip='-o ChallengeResponseAuthentication=no -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o GlobalKnownHostsFile=/dev/null'
		String jenkins_host = jenkinsEnv.getenv("JENKINS_URL").split('/')[2].split(':')[0]

                String ssh_command = "/usr/bin/sshpass -p 123456 ssh ${user}@${jenkins_host} ${security_skip} ${command}"

		return ssh_command
	}

    static def xpoolExtendWithUser(String cluster, String message, String cluster_owner, taggedCluster = "") {
        def cluster_name = cluster
        if (1) {
          return  xpoolRest.restInvestigateWithUser(cluster, cluster_owner)
        } else {
            if (cluster_owner) {
                if (cluster_owner.equalsIgnoreCase('no_xpool')) {
                    return 'xpoolExtend: Could not find ' + cluster + ' in xpool\nNothing to do'
                }
                String xpool_execute = getrunSshCommand(xpool_command + " investigation -u  ${cluster_owner}")
                if (taggedCluster.size() == 0) {
                    xpool_execute += " ${cluster_name}"
                } else {
                    xpool_execute += " -t ${taggedCluster}"
                }
                message = message.replace(" ", "_")
                xpool_execute += " -m ${message}"
                def out_mesg = runShell.runCommand(xpool_execute)

                // xpoolUpdateMessage(cluster, message)
                return out_mesg
            } else {
                return 'xpoolExtend: Could not find owner for ' + cluster + '\nNo extension done'
            }
        }
    }

    static def xpoolSearch(fields, str) {
        def options = "-a -p --long "
        for (field in fields) {
            switch (field) {
                case 'jobs':
                     options += "-j"
                    break
                case 'messages':
                     return xpoolRest.getLeaseMessage()
                    break
                case 'url':
                     options += "-u"
                    break
                case 'state':
                     options += "-x"
                    break
                default:
                    printHandler.printBoxLog("Unknown option ${field}")
                    return false
            }
             options += " "
        }
        def command = xpool_command + " list " + options
        def output = runShell.runCommand(command)
        return output =~ str ? true : false

    }
    static def xpoolUpdateMessage(String cluster, String message, taggedCluster = "") {
        def cluster_owner = xpoolGetOwner(cluster)
        def cmd = xpool_command + ' update -u ' + cluster_owner
        if (taggedCluster.size() == 0) {
            cmd += " ${cluster}"
        } else {
            cmd += " -t ${taggedCluster}"
        }
        cmd += ' -m ' + message.replace(' ', "_")
        printHandler.printLog("xpoolUpdateMessage: " + runShell.runCommand(cmd))
    }

    static def xpoolInvestigationStatus(String cluster, taggedCluster = "") {
        return xpoolRest.restInvestigationStatus(cluster)
        def xpool_info
        if (taggedCluster.size() == 0) {
            xpool_info = runShell.runCommand(xpool_command + ' list -a -p -i -c ' + cluster)
        } else {
            def tclusters = nativeReplication.getNativeInfoList()
            tclusters.each { c ->
                def tmp_info = runShell.runCommand(xpool_command + "list -a -p -i -c ${c}")
                xpool_info += "\n" + tmp_info
            }
        }
        printHandler.printLog("xpoolInvestigation Output from command:: ${xpool_info}")
        def cluster_lines = xpool_info.split('\n')
        def status = cluster_lines.any { it.contains('.*investigation') }
        return status
    }

    static def xpoolExtendTime(String cluster, String clusterOwner, String timePhrase, taggedCluster = "") {
        return xpoolRest.restExtendTime(cluster,timePhrase)
        def cluster_info = xpoolGetInfo(cluster, taggedCluster)
        def cluster_owner = clusterOwner
        def cluster_id = cluster_info.split('%%%')[1]
        if (clusterOwner && timePhrase) {
            def xpool_execute = xpool_command + ' extend -u ' + cluster_owner
            if (taggedCluster.size() == 0) {
                xpool_execute += " ${cluster_id}"
            } else {
                xpool_execute += " -t ${taggedCluster}"
            }
            xpool_execute += ' ' + timePhrase
            printHandler.printLog("xpoolExtend Command (with timePhrase) to run: " + xpool_execute)
            return runShell.runCommand(xpool_execute)
        } else {
            return 'xpoolExtendTime time phrase for xpool was not provided please provide non empty time phrase'
        }

    }

    static def xpoolExtend(String cluster, taggedCluster = "") {
        return xpoolRest.restInvestigate(cluster)
        def cluster_owner = xpoolGetOwner(cluster, taggedCluster)
        def cluster_name = cluster
        if (cluster_owner) {
            if (cluster_owner.equalsIgnoreCase('no_xpool')) {
                return 'xpoolExtend: Could not find ' + cluster + ' in xpool\nNothing to do'
            }
            def xpool_execute = xpool_command + ' investigation -u ' + cluster_owner
            if (taggedCluster.size() == 0) {
                xpool_execute += " ${cluster_name}"
            } else {
                xpool_execute += " -t ${taggedCluster}"
            }
            xpool_execute += " 48"
            printHandler.printLog("xpoolExtend: Command to run: " + xpool_execute)
            return runShell.runCommand(xpool_execute)
        } else {
            return 'xpoolExtend: Could not find owner for ' + cluster + '\nNo extension done'
        }
    }

    static def xpoolReleaseOld(String cluster, taggedCluster = "") {
        return xpoolRest.restRelease(cluster)
        def cluster_owner = xpoolGetOwner(cluster, taggedCluster)
        def cluster_name = cluster
        if (cluster_owner) {
            if (cluster_owner.equalsIgnoreCase('no_xpool')) {
                return 'xpoolRelease: Could not find ' + cluster + ' in xpool\nNothing to do'
            }
            def xpool_execute = xpool_command + ' release -s -u ' + cluster_owner
            if (taggedCluster.size() == 0) {
                xpool_execute += " ${cluster_name}"
            } else {
                xpool_execute += " -t ${taggedCluster}"
            }
            def hc = jenkinsEnv.getenv('healthCheck')
            if (hc && hc.contains(cluster)) {
                xpool_execute = xpool_execute.replace('-s', '')
            }
            return runShell.runCommand(xpool_execute)
        } else {
            return 'xpoolRelease: Could not find owner for ' + cluster + '\nNo release done'
        }
    }

    static def xpoolReleaseNative(String cluster) {
       return  xpoolRelease("",cluster)
    }

    static def xpoolReleaseRegular(String cluster) {
        return  xpoolRelease(cluster,"")
    }

    static def xpoolRelease(String cluster, taggedCluster = "") {
        def run_hc = false
        def hc = jenkinsEnv.getenv('healthCheck')
        if (taggedCluster != "") {
            cluster = taggedCluster
        }
        if (hc && hc.contains(cluster)) {
            run_hc = true
        }
        return xpoolRest.restRelease(cluster, run_hc)
    }

    static def xpoolLease(String cluster, taggedCluster = "") {
        def cluster_owner = xpoolGetOwner(cluster, taggedCluster)
        if (cluster_owner) {
            if (cluster_owner.equalsIgnoreCase('no_xpool')) {
                return ('xpoolLease: Could not find ' + cluster + ' in xpool\nNothing to do')
            }
        } else {
            cluster_owner = 'jenkins-dev'
        }
        def xpool_execute = xpool_command + ' lease -u ' + cluster_owner + ' -c ' + cluster + ' 24'
        println xpool_execute
        return runShell.runCommand(xpool_execute)
    }

    static def cluster_entry = [:]

    static def xpoolEntry(String cluster, taggedCluster = "") {
        def c = cluster_entry.get(cluster)
        if (c) {
            return c
        }
        xpoolInit()
        if (taggedCluster.size() > 0) {
            cluster = nativeReplication.getNativeInfoList()[0]
        }
        if (cluster == "" && taggedCluster.size() > 0) {
            cluster = taggedCluster.split("-x")[0]
        }
        def xpool_info = runShell.runCommand(xpool_command + ' list -a -p -c ' + cluster)
        def cluster_lines = xpool_info.split('\n')
        def cluster_line = cluster_lines.find { it.contains(cluster) }
        cluster_entry.put(cluster, cluster_line)
        return cluster_line
    }
/*
    static def xpoolClusterID(String cluster, taggedCluster = "") {
        def cluster_line = xpoolEntry(cluster, taggedCluster)
        if (cluster_line) {
            return cluster_line.split(' ')[0]
        } else {
            return "no_xpool"
        }
    }
*/
    static def cluster_get_info = [:]

    static def xpoolGetInfo(String cluster, taggedCluster = "") {

        def c = cluster_get_info.get(cluster)
        if (c) {
            return c
        }
        def owner = "no_xpool"
        def id = "no_xpool"
        def cluster_line = xpoolEntry(cluster, taggedCluster)
        if (cluster_line) {
            owner = "jenkins-dev"
            id = cluster_line.split(' ')[0]
        }
        def return_info = owner + '%%%' + id
        cluster_get_info.put(cluster, return_info)
        return return_info
    }

    static def cluster_owner = [:]


    static def xpoolGetOwnerNative(String cluster,use_cache = true)
    {
        return xpoolGetOwner("", cluster, use_cache)
    }

    static def xpoolGetOwnerRegular(String cluster, use_cache = true)
    {
        return xpoolGetOwner(cluster,"", use_cache)
    }
    static def xpoolGetOwner(String cluster, taggedCluster = "",use_cache = true) {
       /* def c = cluster_owner.get(cluster)

        if (use_cache && c) {
            return c
        }
        def owner
        def cluster_line = xpoolEntry(cluster, taggedCluster)
        printHandler.printLog("xpoolGetOwner: Cluster line -> " + cluster_line)
        if (cluster_line) {
            def line = cluster_line.replaceAll(/\s+/, ' ')
            def fields = line.split(' ')
            def owner_field = fields[2].split(':')
            if (owner_field.size() > 1) {
                owner = owner_field[1]
            } else {
                owner = 'jenkins-dev'
            }
        } else {
            owner = 'no_xpool'
        }
        cluster_owner.put(cluster, owner)
        return owner
   */
        if (taggedCluster) {
            cluster = taggedCluster
        }
        printHandler.printInfo("==================== XpoolGetOwner ============================")
        xpoolRest.restPrintBrickInfo(cluster)
        printHandler.printInfo("================================================================")
        return xpoolRest.restGetOwner(cluster, use_cache)
    }

}

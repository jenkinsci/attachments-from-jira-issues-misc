import hudson.model.*

class JenkinsPageUpdate implements Serializable {


    static def classArray = [:]
    static def printHandler
    static def logHandler
    static def j_info
    static def jenkinsEnv
    static def exceptionHandler

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get("PrintHandler")
        printHandler.printEmphasizeLog("initClass JenkinsPageUpdate")
        exceptionHandler = classArray.get("ExceptionHandler")
        logHandler = classArray.get("LogHandler")
        jenkinsEnv = classArray.get("JenkinsEnv")
        j_info = info
    }

    static def setSummaryMsg(jenkins_msg, manager) {
        if (jenkins_msg.size() > 0) {
            printHandler.printLog("Create Summary")
            def today = new Date()
            def str = "<h1>${today}:<br><br>${jenkins_msg}</h1>"
            // manager.createSummary("warning.gif").appendText("<h1>${today}:\n${jenkins_msg}</h1>", false, false, false, "red")
            createMsg(str, manager, "warning.gif", "red")
        }
    }

    static def setSummaryMsg_archived(jenkins_msg, manager) {
        if (jenkins_msg.size() > 0) {
            printHandler.printLog("Create Summary")
            def today = new Date()
            def str = "<h1>Build_Artifacts_URL:<br><br>${jenkins_msg}</h1>"
            createMsg(str, manager, "folder.gif", "blue")
        }
    }


    static def createMsg(msg, manager, gif, color = "red") {
        if (jenkinsEnv.getenv("ISPIPELINE")!= null) {
            printHandler.printBox("Cannot set messages in PipeLine")
            if (msg) {
                printHandler.printEmphasize("Message was: "+ msg)
            }
        }  else {
            if (msg) {
                printHandler.printLog("Creating message color ${color}, gif ${gif}, message ${msg} ")
                manager.createSummary(gif).appendText(msg, false, false, false, color)
            }
        }
    }


    static def setPic(manager) {
        def buildUrl = manager.envVars['BUILD_URL']
        def jenkinsUrl = manager.envVars['JENKINS_URL']
        def home = manager.envVars['JENKINS_HOME']
        def buildNumber = manager.envVars['BUILD_NUMBER']
        def pic = ""
        if (jenkinsEnv.getenv("ISPIPELINE")) {
            printHandler.printBoxLog("setPic function does not work in the pipeline environment")
            return
        }

        if (manager.logContains(".*Creating performance charts.*")) {
            printHandler.printLog("Setting GUI chart started")
            def dir = logHandler.getArchivePath()
            if (!dir.endsWith('/archive') && !dir.endsWith('/archive/')) {
                dir += '/archive'
            }
            printHandler.printLog("Dir = " + dir)
            try {
                new File(dir).eachFile() { file ->
                    printHandler.printLog("file = " + file)
                    if (file =~ "([^\\s]+(\\.(?i)(jpg|png|gif|bmp)))") {
                        pic = file.toString()
                    }
                }
                printHandler.printLog("pic = " + pic)
                pic = buildUrl + "/artifact/" + pic.split("/archive/")[-1]
                if (pic != '') {
                    printHandler.printLog("<img src=" + pic)
                    manager.createSummary("warning.gif").appendText("<img src='$pic' style='width:504px;height:428px;'>", false, false, false, "None")
                } else {
                    printHandler.printError("pic not found")
                }
            }
            catch (e) {
                printHandler.printError("CAN'T FIND GUI PIC - TRY TO ARCHIVE BEFORE GROOVING.")
            }
            printHandler.printLog("GUI chart ended")

        }
    }

    static def setML(manager) {
        def path = logHandler.getArchivePath()
        try {
            printHandler.printLog("ML integration started - path ${path}")
            def MLpath = ''
            def dir = "${path}"
            new File(dir).eachFileMatch(~/.*Dup.*html/) { file ->
                MLpath = file.getAbsolutePath()
            }
            if (MLpath) {
                printHandler.printLog(MLpath)
                String output = new File(MLpath).text
                manager.createSummary("network.gif").appendText(output, false, false, false, "")
            } else {
                printHandler.printLog("No file of ML found")
            }
        } catch (e) {
            printHandler.printError("Error in ML integration " + e)
            if (exceptionHandler) {
                exceptionHandler.printExceptionStack(e)
            }
        }
        printHandler.printLog("ML integration Ended")
    }

    static def setQC(manager) {
        printHandler.printLog("Check if log contains QCReporter")
        if (manager.logContains(".*reported test.*")) {
            printHandler.printLog("Started setQC")
            def logtext
            if (!jenkinsEnv.getenv('ISPIPELINE')) {
                logtext = manager.build.logFile.text
            } else {
                logtext = j_info.get('buildManager').log
            }
            logtext.eachLine { line ->
                if (line.contains("[QCReporter] reported test")) {
                    def key = "QCLINK"
                    def value = line.split("run:")[-1]
                    printHandler.printLog("QC found link " + value)
                    try {
                        printHandler.printLog("Creating New ENV: " + key + " = " + value)
                        def pa = new ParametersAction([new StringParameterValue(key, value)])
                        Thread.currentThread().executable.addAction(pa)
                    } catch (e) {
                        printHandler.printError("Error Creating New ENV: " + e)
                        if (exceptionHandler) {
                            exceptionHandler.printExceptionStack(e)
                        }
                    }
                }
            }
        }
    }
}


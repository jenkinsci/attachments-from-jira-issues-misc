import org.codehaus.groovy.runtime.StackTraceUtils

class DebugHandler implements Serializable {
    static def classArray = [:]

    static def jenkinsEnv
    static def printHandler
    static def jenkins_info

    static def initClass(classes, info) {
        classArray = classes
        jenkinsEnv = classArray.get("JenkinsEnv")
        printHandler = classArray.get("PrintHandler")
        printHandler.printEmphasizeLog("initClass DebugHandler")
        this.jenkins_info = info
    }


    def printCurrentMethod() {
        if (jenkinsEnv.getenv('STACKTRACE') == 'true') {
            def marker = new Throwable()
            def stackinfo = StackTraceUtils.sanitize(marker).stackTrace[2]
            printHandler.printStackInfo("${stackinfo.methodName}(): ${stackinfo.fileName}:${stackinfo.lineNumber}")
        }
    }
}


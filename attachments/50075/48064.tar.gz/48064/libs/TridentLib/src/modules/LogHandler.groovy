class LogHandler implements Serializable {

    static def archivePath = ""
    static def logFilePath = ""


    static def classArray = [:]
    static def printHandler
    static def jenkinsEnv
    static def jenkins_info

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get("PrintHandler")
        jenkinsEnv = classArray.get("JenkinsEnv")
        jenkins_info = info
    }


    static def getArchivePath() {

        def build = jenkins_info.get('build')

        if (archivePath == "") {
            try {
                archivePath = build.getArtifactsDir()
            } catch (Exception e) {
                archivePath = jenkins_info.get('buildManager').getArtifactsDir()
            }

        }
        return archivePath.toString()
    }

    static def getLogFilePath() {
        return logFilePath
    }

    static def createLogFile(appName) {
        def path = getArchivePath()
        def groovylog = ""
        def now = (new Date()).format("yyyy-MM-dd_HH:mm:ss.SS", TimeZone.getTimeZone('Asia/Jerusalem'))
        if (!path.endsWith('/archive') && !path.endsWith('/archive/')) {
            path += '/archive'
        }
        printHandler.printInfo("Current Archive is: ${path}")

        if (appName == "" || appName == null) {
            appName = "groovy"
        }
        groovylog = "${path}/${appName}_log_${now}.txt"
        File Dir = new File(path)
        if (!Dir.exists()) {
            printHandler.printInfo(now + " create archive directory needed")
            Dir.mkdir()
            printHandler.printInfo(now + " create archive directory ended")
        }
        logFilePath = groovylog
        printHandler.logInitFileName("logger", groovylog)
        printHandler.printBlueInfo("******************** GROOVY LOG FILE ********************")
        printHandler.printLog("log file directory: " + path)
        def artifactPath = jenkinsEnv.getenv("BUILD_URL")
        if (artifactPath == null) {
            def envMap = jenkins_info.get('envMap')
            artifactPath = envMap.get('BUILD_URL')
        }
        printHandler.printLog("CreatePath ended")
        printHandler.printLog("groovy log file created in Build Artifacts directory: " + groovylog)
        printHandler.printConsole("[LOG_INFO] - groovy log file link: " + artifactPath + "/artifact/${appName}_log_" + now + ".txt")
    }

}

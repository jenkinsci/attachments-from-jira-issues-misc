import hudson.*
import hudson.model.*
import hudson.tasks.*
import jenkins.*
import jenkins.model.*

class LoadClass implements Serializable {
    static def className
    static def loadClasses = []
    static def printHandler
    static def jenkins_info
    static def exceptionHandler

    static def initClass(classes, info) {
        printHandler = classes.get('PrintHandler')
        printHandler.printEmphasizeLog("initClass LoadClass")
        exceptionHandler = classArray.get("ExceptionHandler")
        jenkins_info = info
    }

    static def LoadClass(info, String classfile) {
        def output = info.get('output')
        return loadSpecific(classfile, output)
    }

    static def LoadClass(info, classes) {
        def output = info.get('output')
        def classArray = [:]

        for (cf in classess) {
            def carr = cf.split(':')
            def filename = carr[0]
            def key = carr[1]
            def size = 1
            if (carr.size() == 3) {
                size = carr[2]
            }
            if (filename.startsWith('/')) {
                groovyFileName = filename
            } else {
                if (!filename.endsWith('.groovy')) {
                    filename = filename + '.groovy'
                }
                groovyFileName = "${groovyHome}/${filename}.groovy"
            }

            if (!classArray.get(key)) {
                classArray.put(key, [])
            }
            try {
                def obj_array = []
                1.upto(size, {
                    def obj = loadSpecific(groovyFileName, output)
                    obj_array.add(obj)
                }
                )
                classArray.get(key).put(obj_array)
            } catch (Exception e) {
                output.println("Error Loading file ${size} times(s)...." + e.toString())
            }
        }
        return classArray
    }

    static def loadSpecific(classFile, output) {
        def File groovyFile
        def Class groovyClass
        def GroovyObject groovyObject
        def groovyFileName = classFile

        groovyFile = new File(groovyFileName)
        def now = getNow()

        try {
            def clazzLoader = Jenkins.getInstance().getPluginManager().uberClassLoader
            groovyClass = new GroovyClassLoader(clazzLoader).parseClass(groovyFile);
            groovyObject = groovyClass.newInstance()

        } catch (Exception e) {
            output.println("Error here !!!! " + e.toString())
            if (exceptionHandler) {
                exceptionHandler.printExceptionStack(e)
            }
        }
        return groovyObject
    }

    static def loadClass(classFiles

    static def loadClasses(classFiles, info) {
        def output = info.get('output')


        def groovyHome

        groovyHome = library_space

        for (cf in classFiles) {
            def groovyFileName = "${groovyHome}/${cf}.groovy"
            def module_index
            if (cf =~ /apps/) {
                module_index = cf.split('/')[-3] + '.' + cf.split('/')[-1]
            } else {
                module_index = cf.split("/")[-1]
            }
            try {
                def obj = loadSpecific(groovyFileName, output)
                loadClasses.put(module_index, obj)

            } catch (Exception e) {
                output.println("Error Loading file ...." + e.toString())
            }
        }


        def phandler = loadClasses.get("PrintHandler")
        phandler.printInit(output, err)
        def class_info = info


        for (c_entry in loadClasses) {
            def c_name = c_entry.key
            def cobj = loadClasses.get(c_name)
            phandler.printInfo("initializing ${c_name} ...")
            def now = getNow()
            initModules.add("${now} [LOADING_INFO] Initializing ${c_name}")
            cobj.initClass(loadClasses, class_info)
        }

        def moreinfo = [:]

        moreinfo.put("WORKSPACE", workspace)
        moreinfo.put('TRI_GROOVY_HOME', groovyHome)
        moreinfo.put('TRIDENTLIBHOME', groovyHome)
        moreinfo.put('TRIGROOVYHOME', groovyHome)
        moreinfo.put('APPS_HOME', groovyHome + "/apps")
        moreinfo.put('PYTHON_HOME', groovyHome + "/python")

        def jenv = loadClasses.get("JenkinsEnv")
        if (envMap) {
            jenv.setenv(envMap)
        }
        jenv.setenv(moreinfo)


        return loadClasses
    }

    static def runMethod(loadClasses, runClasses, info) {
        def defaultClasses = ["modules/PrintHandler", "modules/JenkinsEnv", "modules/LogHandler", "modules/RunShell", "modules/WorkUtils",
                              "modules/JenkinsPageUpdate"]

        loadClasses = loadClasses.trim()
        def lClasses = loadClasses.split(',')
        def rClasses = runClasses.split(',')

        def classes = []
        def uniquelist = []
        classes.addAll(defaultClasses)
        classes.addAll(lClasses)

        for (c in classes) {
            def found = false
            for (u in uniquelist) {
                if (c == u) {
                    found = true
                }
            }
            if (!found) {
                uniquelist.add(c)
            }
        }

        def jenkins_info = info

        def myclasses = classLoader(uniquelist, jenkins_info)
        def phandler = myclasses.get("PrintHandler")
        def workutils = myclasses.get("WorkUtils")
        def nanoTime = System.nanoTime().toString()
        def logHandler = myclasses.get('LogHandler')
        phandler.printInfo("Before create logfile")
        logHandler.createLogFile()
        phandler.printInfo("After createlogfile")


        def tmp_work_area = workutils.createTmpWorkArea(null, nanoTime)
        jenkins_info.put('workarea', tmp_work_area)

       def status = 0
        for (cl in rClasses) {
            def p = myclasses.get(cl)
            try {
                phandler.printRawLog("Executing class: " + cl + "Class: " + p.getClass())
                status += p.internalMain(jenkins_info)
            } catch (Exception e) {
                phandler.printWarning("COULD NOT Execute cl!!!!  " + cl + " - " + e.toString())
                if (exceptionHandler) {
                   exceptionHandler.printExceptionStack(e)
                   status += 1
                }
            }
        }
        workutils.removeTmpWorkArea(tmp_work_area)
        return status
    }
}

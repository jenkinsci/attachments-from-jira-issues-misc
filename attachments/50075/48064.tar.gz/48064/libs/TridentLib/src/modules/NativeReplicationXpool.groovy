class NativeReplicationXpool implements Serializable {

    static def classArray = [:]

    static def printHandler
    static def xpoolManager
    static def jenkinsEnv
    static def nativeReplication
    static def QAReuse
    static def jenkins_info
    static def dummyKey = "ZZZZZZZZZXXX"

    static def cluster_actions = [:]
    // this has to be defined now otherwise you can't access the sub dictionary with get

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get("PrintHandler")
        printHandler.printEmphasizeLog("initClass NativeReplicationXpool")
        xpoolManager = classArray.get("XpoolManager")
        nativeReplication = classArray.get("NativeReplication")
        jenkinsEnv = classArray.get("JenkinsEnv")
        QAReuse = classArray.get("ErrorHandler.QAReuse")
        jenkins_info = info

    }

    static def nativeExtend(slave_name, message, ur_run_owner = "", time = "") {
        def cluster_data = cluster_actions.get(slave_name)
        printHandler.printInfo("NativeReplicationExtend  ${slave_name} ${message}")
        if (cluster_data) {
            if (cluster_data.get('action') != 'extend') {
                printHandler.printWarning("${slave_name} was already processed with " + cluster_data.get("action") + " Ignoring extend request")
                return
            }
        }
        def cluster_info = ['action': 'extend', 'message': message, 'owner': ur_run_owner, 'duration': 'eod']
        if (!cluster_actions.get(slave_name)) {
            cluster_actions.put(slave_name, [:])
        }
        cluster_actions.put(slave_name, cluster_info)

    }


    static def nativeRelease(slave_name, message) {
        def cluster_data = cluster_actions.get(slave_name)
        printHandler.printInfo("NativeReplicationRelease: Registering  ${slave_name} ${message}")
        if (cluster_data) {
            if (cluster_data.get('action') != 'free') {
                printHandler.printWarning("${slave_name} was already processed with " + cluster_data.get("action") + " Ignoring release request")
                return
            }
        }
        def cluster_info = ['action': 'release', 'message': message]
        if (!cluster_actions.get(slave_name)) {
            cluster_actions.put(slave_name, [:])
        }
        cluster_actions.put(slave_name, cluster_info)
    }

    static def performActions(manager) {
        def first_action = ""
        def same_actions = true
        def message = ""
        def cluster_tag = nativeReplication.taggedCluster
        if (!nativeReplication.isNative || cluster_actions.size() == 0) {
            printHandler.printLog("No actions to perform for native replication...")
            return
        }
        printHandler.printConsole(printHandler.emphasize("Proccessing native application xpool actions ....."))

        def first_key = cluster_actions.keySet()[0]
        def first_item = cluster_actions.get(first_key)
        first_action = first_item.get('action')

        cluster_actions.each { key, item ->
            if (first_action != item.get('action')) {
                same_actions = false
            }
            message += " " + item.get('message')
        }

        if (same_actions) {
            printHandler.printConsoleColor("[INFO] - Proccessing tagged cluster ${cluster_tag} ... ")
            if (first_action == 'extend') {
                printHandler.printConsoleColor("[INFO] - Proccessing extension for all clusters ....")
                def counter = 1
                cluster_actions.each { cluster_name, info ->
                    def c_mesg = info.get("message")
                    printHandler.printLog(" Proccesing ${cluster_name}")
                    xpoolManager.unTagCluster(cluster_name)
                    def c_string = counter.toString()
                    printHandler.printConsoleColor("[INFO] - ${c_string}. Extending cluster ${cluster_name} with message ${c_mesg}")
                    counter += 1
                    xpoolManager.xpoolExtend(cluster_name, c_mesg)
                }
                xpoolManager.restoreTags(cluster_actions.keySet())
            } else {
                if (jenkinsEnv.isQA()) {
                    if (!QAReuse.QAReuse(manager)) {
                        def specificCluster = manager.envVars['CLUSTER_NAME']
                        if (!(specificCluster && specificCluster.trim() != "" && specificCluster.toUpperCase() != "NONE")) {
                            // printHandler.printInfo("Reuse not functioning - releasing ....")
                            printHandler.printConsole("[INFO] - Performing Release for (no Reuse) " + cluster_tag)
                            printHandler.printLog(xpoolManager.xpoolRelease("",  cluster_tag))
                        }
                    }
// Note we will need to support here ReUse of devlab here
                } else {
                    printHandler.printConsoleColor("[INFO] - Performing Release for  " + cluster_tag)
                    printHandler.printLog(xpoolManager.xpoolRelease("", message, cluster_tag))
                }
            }
        } else {
            def release_candidates = []
            printHandler.printConsole(printHandler.emphasize("Processing each cluster separately ...", '%', '%', 20))
            cluster_actions.each { cluster_name, info ->
                printHandler.printConsole("    Proccessing ${cluster_name}")
                def action = info.get("action")
                def c_mesg = info.get("message")
                if (action == "extend") {
                    printHandler.printLog("Removing tag ${cluster_tag} from cluster ${cluster_name}")
                    xpoolManager.unTagCluster(cluster_name)
                    printHandler.printConsoleColor("[INFO] - Extending cluster ${cluster_name} with message ${c_mesg}")
                    xpoolManager.xpoolExtend(cluster_name, c_mesg)
                } else {
                    printHandler.printLog("Adding ${cluster_name} to release list")
                    release_candidates.add(cluster_name)
                }
            }
            if (release_candidates.size() > 0) {
                printHandler.printConsoleColor("[INFO] - Releasing through cluster tag the following cluster(s): " + release_candidates.join(", "))
                xpoolManager.xpoolRelease("", "", cluster_tag)
            }
        }
    }
}

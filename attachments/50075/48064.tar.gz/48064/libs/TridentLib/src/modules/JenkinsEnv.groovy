import hudson.*
import hudson.model.*
import jenkins.*
import jenkins.model.*

class JenkinsEnv implements Serializable {

    static def classArray = [:]
    static def printHandler
    static def jenkins_info
    static def envVars
    static def exceptionHandler
    static def SemaphoreLoad = ['count':0]

    static def initClass(classes, info) {
        classArray = classes
        this.printHandler = classArray.get("PrintHandler")
        printHandler.printEmphasizeLog("initClass JenkinsEnv")
        this.exceptionHandler = classArray.get("ExceptionHandler")
        this.jenkins_info = info
        this.envVars = jenkins_info.get('envMap')
        if (envVars == null) {
            envVars = [:]
        }
    }

    static def initializeEnv() {
        if(SemaphoreLoad.get('count') == 0) {
            try {
                printHandler.printBoxLog("Starting Env Load ...")
                printHandler.printBoxLog("Loading System Environment Variables")
                loadSystemEnv()
                printHandler.printBoxLog("Loading Global Properties Variables")
                getJenkinsGlobalProperties()
                printHandler.printBoxLog("Loading build parameters")
                loadParams()
                printHandler.printEmphasizeLog("Updating semaphore ...")
              //  printHandler.printBoxLog("Current semaphore count ..." + SemaphoreLoad.get('count'))
                SemaphoreLoad.put('count', SemaphoreLoad.get('count') + 1)

            } catch (e) {
                printHandler.printLog("Initialize env failed - " + e.toString())
                if (exceptionHandler) {
                    exceptionHandler.printExceptionStack(e)
                }
            }
            SemaphoreLoad.put('count', SemaphoreLoad.get('count') + 1)
            printHandler.printBoxLog("Env initialization Ended")
        }
    }

    static def loadParams() { // This always overrides environment
        def params = jenkins_info.get('params')
        for (p in params) {
            try {
                printHandler.printLog("LOAD PARAMS: " + p)
                if (p && p.key && p.value) {
                    envVars.put(p.key, p.value)
                }
            } catch(e) {
                printHandler.printEmphasizeLog("load params - we had an error here")
            }
        }
    }

    static def loadSystemEnv() {
        def envproc = "env".execute()
        def sout = new StringBuffer()
        def serr = new StringBuffer()
        envproc.consumeProcessOutput(sout, serr)
        envproc.waitForProcessOutput()
        def envout = sout.toString().split('\n')
        for (e in envout) {
            def p = e.split('=')
            if (p.size() == 2) {
                def var = p[0].trim()
                def val = p[1].trim()
                printHandler.printLog("SYSTEM VARIABLES: " + p)
                if (!envVars.get(var)) {
                    envVars.put(var, val)
                }
            }
        }
    }

    static def getJenkinsGlobalProperties() {
        def props
        try {
            props = jenkins_info.get('j_instance').getGlobalNodeProperties()
        } catch (e) {
            props = Jenkins.getInstance().getGlobalNodeProperties()
        } catch (f) {
            props = jenkins_info.get('build').getEnvironment(jenkins_info.get('buildManager').listener)
        }

        printHandler.printBoxLog("We got the following props ..." + props)
        def propList = props.getAll(hudson.slaves.EnvironmentVariablesNodeProperty.class)
        if (propList && propList.size() > 0) {
            def vars = propList.get(0).getEnvVars()
            vars.each { k, v ->
                if (!envVars.get(k)) {
                    printHandler.printLog("GLOBAL VARIABLES: ${k} = ${v}")
                    envVars.put(k, v)
                }
            }
        }
    }

    static def isQA()
    {
        def url = getenv('JENKINS_URL')
        return url.contains('qa')
    }
    static def getenv(str) {
        initializeEnv()
        return envVars.get(str)
    }

    static def setenv(var, val) {
        initializeEnv()
        envVars.put(var, val)
    }

    static def setenv(map) {
        initializeEnv()
        envVars = envVars + map
    }

    static def putenv(var, val) {

        initializeEnv()
        envVars.put(var, val)
    }

    static def putenv(map) {
        initializeEnv()

        printHandler.printLog("PUTENV map is " + map)
        envVars = envVars + map
    }

    static def printenv() {
        initializeEnv()

        printHandler.printBlueInfo("Environment variables:")
        envVars.each { k, v ->
            printHandler.printGreenInfo(sprintf("\t%s=%s", k, v))
        }
    }

    static def printenvToLog() {

        initializeEnv()

        printHandler.printRawLog("Environment variables:\n-------------------------")
        envVars.each { k, v ->
            printHandler.printRawLog(sprintf("\t%s=%s", k, v))
        }
        printHandler.printRawLog("-------------------------")
    }

    static def getAllEnv() {
        initializeEnv()

        return envVars
    }

    static def String[] getShellEnv() {
        initializeEnv()
        return envVars.collect { k, v -> "$k=$v" }
    }

}

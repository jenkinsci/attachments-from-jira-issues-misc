import java.util.regex.Pattern

class LogSearch implements Serializable  {

    static def classArray = [:]

    static def jenkins_info
    static def readLog = null
    static def jenkinsEnv
    static def printHandler
    static def logHandler
    static def ispipeline = false
    static def expTable = [:]
    static def searchCount = 0
    static def cacheHits = 0

    static def initClass(classes, info) {
        this.jenkins_info = info
        def classArray = classes
        jenkinsEnv = classArray.get("JenkinsEnv")
        logHandler = classArray.get("LogHandler")
        printHandler = classArray.get("PrintHandler")
        printHandler.printEmphasizeLog("initClass LogSearch")

    }


    static def initializeReader() {
        if (jenkinsEnv.getenv("ISPIPELINE")) {
            ispipeline = true
        }

        if (!readLog) {
            printHandler.printBoxLog("Starting initializeReader method - " + printHandler.timeStamp())
            if (ispipeline) {
                def escChar = 033.asType(char).toString()
                def log = jenkins_info.("buildManager").log
                printHandler.printBoxLog("Log before Parse is: " + (log.length() / 1024).intValue().toString() + "K")
                def logArray = log.split('\n')
                printHandler.printBoxLog("Amount of lines in log = " + logArray.size().toString())
                logArray.size().times() {
                    def logLine = logArray[it]
                    def size = logLine.size()
                    def hasSpace  = logLine =~ /\s/ ? true : false
                    def hasEscape = logLine.contains(escChar)
                    if (!hasSpace && hasEscape) {
                        logArray[it] = ""
                    } else {
                        if (hasSpace && (hasEscape || size > 100)) {
                            def cutOff = ' '
                            def cutLen = 1
                            if (hasEscape) {
                                cutOff = '=='
                                cutLen = 2
                            }
                            logArray[it] = logArray[it].substring(logArray[it].indexOf(cutOff) + cutLen)
                        }
                    }
                }
                readLog = logArray.join("\n")
                // The following code was added since in a pipeline there might be more than one call
                // to the ErrorHandler and we must start reading the log from only the new output
                def  cursize = readLog.size()
                printHandler.printBoxLog("Log after Parse is: " + (readLog.length() / 1024).intValue().toString() + "K")
                def String logSizeFile = logHandler.getArchivePath() + "/" + "errHandler.curlogSize"
                def pastReadFile = new File(logSizeFile)
                if (pastReadFile.exists()) {
                    def skipSize = Integer.parseUnsignedInt(pastReadFile.text.trim())
                    printHandler.printBoxLog("Skipping " + skipSize + " already processed bytes in the log")
                    readLog = readLog.substring(skipSize + 1)
                    pastReadFile.delete()
                }
                pastReadFile = new File(logSizeFile)
                pastReadFile.write(Integer.toString(cursize))


            } else {
                readLog = jenkins_info.get("buildManager")
            }
            printHandler.printBoxLog("initializeReader method completed - " + printHandler.timeStamp())
        }
        // printHandler.printBoxLog("Allowed methods for current log")
        //  readLog.metaClass.methods*.name.sort().unique().each {printHandler.printRawLog("\t" + it)}
    }


    static String cleanTextContent(String text) {
        // strips off all non-ASCII characters
        text = text.replaceAll("[^\\x00-\\x7F]", "");

        // erases all the ASCII control characters
        text = text.replaceAll("[\\p{Cntrl}&&[^\r\n\t]]", "");

        // removes non-printable characters from Unicode
        text = text.replaceAll("\\p{C}", "");

        return text.trim();
    }

    static clear_consecutive_wildcards(exp) {
        if (exp.getClass() =~ /String/) {
            def pattern = "\\.\\*"
            exp = '.*' + exp.split(pattern).grep().join('.*') + '.*'
        }
        return exp
    }

    static def searchLog(exp) {
        initializeReader()
        def ind
        if (!exp.getClass() =~ /String/) {
            ind = exp.toString()
        } else {
            ind = exp
        }
        def exp_found = expTable.get(ind)
        searchCount += 1
        if (!exp_found) {
            expTable.put(ind, [:])
            expTable.get(ind).put('found', false)
            expTable.get(ind).put('string', '')
        } else {
            def status = exp_found.get('found')
            cacheHits += 1
            printHandler.printBoxLog("Returning previous found string! for ${exp} found status:" + status.toString())
            return (exp_found.get('string'))
        }
         if (ispipeline) {
            def found = ""
            def pattern_exp = Pattern.compile(exp, Pattern.MULTILINE)
            printHandler.printUnderlineLog("Starting Search for ${exp} at - " + printHandler.timeStamp() + "...")
            found = readLog.find(pattern_exp)
            printHandler.printUnderlineLog("Search Complete for ${exp} at - " + printHandler.timeStamp())

            def is_found = found != null && found.size() > 0
            expTable.get(ind).put('found', is_found)
            expTable.get(ind).put('string', found)
            return (found)
        } else {
            def return_val = null
            def matcher = readLog.getLogMatcher(exp)
            printHandler.printEmphasizeLogVerbose("searchLog: matcher - " + matcher + " exp - " + exp)
            if (matcher != null) {
                def group_string = matcher.group()
                printHandler.printEmphasizeLogVerbose(" in matcher: group_string - ${group_string}")
                if (group_string.size() > 0) {
                    group_string = cleanTextContent(group_string)
                }
                return_val = group_string
            }
            expTable.get(ind).put('found', return_val != null && return_val.size() > 0)
            expTable.get(ind).put('string', return_val)
            return return_val
        }
    }

    static def printSearchStatstics() {
        printHandler.printEmphasizeLog("Search Statistics")
        def outstat = sprintf("Total Searches: %d Cache Hits: %d", searchCount, cacheHits)
        printHandler.printBoxLog(outstat)
     }

    static def logContains(exp) {
        initializeReader()
        def found = searchLog(exp)
        if (found) {
            return found.size() > 0
        } else {
            return false
        }
    }
}



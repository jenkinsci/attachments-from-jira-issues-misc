class JenkinsGetBuild implements Serializable  {

    static def classArray = [:]

    static def debugMode = false

    static def debugHandler
    static def jenkinsEnv
    static def printHandler
    static def jenkins_info

    static def initClass(classes, info) {
        classArray = classes
        debugHandler = classArray.get("DebugHandler")
        jenkinsEnv = classArray.get("JenkinsEnv")
        printHandler = classArray.get("PrintHandler")
        printHandler.printEmphasizeLog("initClass JenkinsGetBuild")
        this.jenkins_info = info
    }


    static def getBuild(String job, String number, setDebugMode = true) {

        def return_val = null
        debugMode = setDebugMode

        printHandler.printLogWithDebug("Job is " + job)
        printHandler.printLogWithDebug("Build Number is " + number)


        def project = jenkins_info.get('j_instance').getItem(job)
        if (!project) {
            project = jenkins_info.get('j_instance').getItemByFullName(job)
        }

        printHandler.printLogWithDebug("PROJECT = " + project)

        if (project) {
            def bnum = number.toInteger()
            def String first_build = project.builds[-1]
            def String last_build = project.builds[0]
            printHandler.printLogWithDebug("last_build is " + last_build)
            printHandler.printLogWithDebug("first_build is " + first_build)
            if (last_build.find('#')) {
                last_build = last_build.split('#')[1].trim()
            }
            if (first_build.find('#')) {
                first_build = first_build.split('#')[1].trim()
            }
            def high_num = last_build.find((/\d+/)).toInteger()
            def low_num = first_build.find((/\d+/)).toInteger()

            if (bnum >= low_num && bnum <= high_num) {
                def build_list = project.builds[0..-1]
                def listnumbers = []
                build_list.each { it ->
                    String tmpstr = it
                    if (tmpstr.find('#')) {
                        tmpstr = tmpstr.split('#')[1].trim()
                    }
                    listnumbers.add(tmpstr.find((/\d+/)))
                }
                def ind = listnumbers.indexOf(number)
                printHandler.printLogWithDebug("Index Found is " + ind)
                return_val = build_list[ind]
            }
        }
        printHandler.printLogWithDebug("returning " + return_val)
        return return_val
    }

    static def getBuild(manager) {
        def build
        if (jenkinsEnv.getenv("ErrorHandler_DEBUG")) {
            debugMode = true
        }
        try {
            build = manager.build
        } catch (Exception e) {
            build = jenkins_info.get('build')
        }
        return build
    }

    static def inDebug() {
        return debugMode
    }


}


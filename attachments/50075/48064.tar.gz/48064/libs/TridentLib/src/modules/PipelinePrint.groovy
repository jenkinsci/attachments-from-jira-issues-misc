class PipelinePrint implements Serializable {
    static def classArray = [:]

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get("PrintHandler")
        printHandler.printEmphasizeLog("initClass PipelinePrint")
        jenkinsEnv = classArray.get("JenkinsEnv")
        exceptionHandler = classArray.get("ExceptionHandler")
        this.jenkins_info = info
    }

    static def pipelinePrint(str) {
        println str
    }
}

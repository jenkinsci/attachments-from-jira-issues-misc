class NodeHandlerClass implements Serializable {

    static def classArray = [:]

    static def slaveList = [:]


    static def printHandler
    static exceptionHandler
    static def jenkins_info
    static def j_instance

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get("PrintHandler")
        exceptionHandler = classArray.get("ExceptionHandler")
        printHandler.printEmphasizeLog("initClass NodeHandler")
        this.jenkins_info = info
        j_instance = info.get('j_instance')
    }


    static def getNode(slaveName) {

        def slave = slaveList.get(slaveName)
        if (slave) {
            return slave.get('node')
        }
        return null
    }

    static def getComputer(slaveName) {
        def slave = slaveList.get(slaveName)
        if (slave) {
            return slave.get('computer')
        }
        return null
    }

    static def getLabels(slaveName) {
        initSlaveFromName(slaveName)
        def computer = getComputer(slaveName)
        def labels = []
        computer.getAssignedLabels().each {
            labels.add(it.toString())
        }
        return labels
    }

    static def setLabels(slaveName, labels) {
        initSlaveFromName(slaveName)
        def labels_to_set = ""
        if (labels instanceof String) {
            labels_to_set = labels
        } else {
            labels_to_set = labels.join(" ")
        }
        def node = getNode(slaveName)
        if (labels_to_set != "") {
            node.setLabelString(labels_to_set)
            node.save()
        }
    }

    static def initSlaveFromBuild(build) {
        def slave = build.getBuiltOn()
        def slaveName = slave.getDisplayName()

        if (!slaveList.get(slaveName)) {
            def slave_info = [:]
            slave_info.put('node', slave)
            if (slave) {
                slave_info.put('computer', slave.toComputer())
            }
            slaveList.put(slaveName, slave_info)
        }
        return slaveName
    }

    static def initSlaveFromName(slaveName) {

        if (!slaveList.get(slaveName)) {
            def computer = null
            def node = j_instance.getNode(slaveName)
            if (node) {
                computer = node.toComputer()
            }
            def slave_info = [:]
            slave_info.put('node', node)
            slave_info.put('computer', computer)
            slaveList.put(slaveName, slave_info)
        }
    }


    static def nodeOffline(slaveName, mesg) {
        def computer = getComputer(slaveName)
        def info_mesg = "nodeOffline - setting ${slaveName} offline with message: ${mesg}"
        def error_mesg = "nodeOffline - ${slaveName} computer not initialized"
        printHandler.printLog(info_mesg)
        if (computer) {
            setComputerOffline(computer, mesg)
        } else {
            printHandler.printLog(error_mesg)
        }
    }


    static def killBuild(b) {
       if (b.isBuilding()){
             printHandler.printInfo ("Trying to kill " +  b.getDisplayName() + "...")
             b.doStop()
             b.doKill()
             b.finish(
                hudson.model.Result.ABORTED,
                new java.io.IOException("Aborting build " + b.getSearchName())
            )
        }
    }  


    static def killJobs(nodeName) {
        def jobs = hudson.model.Hudson.instance.items
        jobs.each { job ->

            try {
                job.builds.each { build ->
                         if (build.isBuilding() && build.builtOnStr == nodeName) {
                                  killBuild(build)
                         }
                }
                } catch (e) {
                     def x = 1 // nothing really to do here ignore it
                }
        }
    }

    static def nodeRemove(slaveName) {
        initSlaveFromName(slaveName)
        def computer = getComputer(slaveName)
        if (computer) {
            def node = getNode(slaveName)
            printHandler.printGreenInfo("Removing ${slaveName} if needed ...")
            if (computer.countBusy() > 0) {
                killJobs(slaveName)
            }
                try {
                    try {

                        def wsDir = node.workspaceRoot
                        def subdirs = wsDir.list()
                        if (subdirs.size() > 0) {
                            printHandler.printUnderline(printHandler.emphasize("Removing recursively workspace for ${slaveName}"))
                            printHandler.printGreenInfo("Removing workspace: ${wsDir} sub-directories:")
                            for (s in subdirs) {
                                printHandler.printGreenInfo("   ${s}")
                                s.deleteRecursize()
                            }
                        }
                    } catch (Exception d) {
                        printHandler.printInfo("Error removing workspace for ${slaveName}")
//                    exceptionHandler.printExceptionStack(d)
                    }

                    printHandler.printGreenInfo("   Setting ${slaveName} offline ...")
                    computer.setTemporarilyOffline(true, null)
                    printHandler.printPurpleInfo("  Removing slave ...")
                    nodeOffline(slaveName, "Before node removal")

                    computer.doDoDelete()
                } catch (Exception e) {
                    printHandler.printError("Could not remove ${slaveName}")
                    exceptionHandler.printExceptionStack(e)
                }
        } else {
            printHandler.printPurpleInfo("Slave ${slaveName} already removed")
        }
    }
    static def safeNodeRemove(slaveName) {
        initSlaveFromName(slaveName)
        def computer = getComputer(slaveName)
        if (computer) {
            def node = getNode(slaveName)
            printHandler.printGreenInfo("Removing ${slaveName} if needed ...")
            if (computer.countBusy() > 0) {
                printHandler.printRedInfo("Not removing ${slaveName} because jobs are running")
            } else {
                try {
                    try {

                        def wsDir = node.workspaceRoot
                        def subdirs = wsDir.list()
                        if (subdirs.size() > 0) {
                            printHandler.printUnderline(printHandler.emphasize("Removing recursively workspace for ${slaveName}"))
                            printHandler.printGreenInfo("Removing workspace: ${wsDir} sub-directories:")
                            for (s in subdirs) {
                                printHandler.printGreenInfo("   ${s}")
                                s.deleteRecursize()
                            }
                        }
                    } catch (Exception d) {
                        printHandler.printInfo("Error removing workspace for ${slaveName}")
//                    exceptionHandler.printExceptionStack(d)
                    }

                    printHandler.printGreenInfo("   Setting ${slaveName} offline ...")
                    computer.setTemporarilyOffline(true, null)
                    printHandler.printPurpleInfo("  Removing slave ...")
                    nodeOffline(slaveName, "Before node removal")

                    computer.doDoDelete()
                } catch (Exception e) {
                    printHandler.printError("Could not remove ${slaveName}")
                    exceptionHandler.printExceptionStack(e)
                }
            }
        } else {
            printHandler.printPurpleInfo("Slave ${slaveName} already removed")
        }
    }

    static def nodeOnline(slaveName, mesg) {
        def computer = getComputer(slaveName)

        def info_mesg = "nodeOnline - setting ${slaveName} online with message: ${mesg}"
        def error_mesg = "nodeOffline - ${slaveName} computer not initialized"

        printHandler.printLog(info_mesg)
        if (computer) {
            setComputerOnline(computer, mesg)
        } else {
            printHandler.printLog(error_mesg)
        }

    }

    static def clearUniqueIDs(slaveName) {
        def originalLabels = getLabels(slaveName)
        printHandler.printInfo ("Clearing Unique ID's from label of ${slaveName}")
        printHandler.printInfo("ORIGINAL LABELS: " + originalLabels.join(","))
        def newLabels = []
        originalLabels.each { l->
            if (!l.startsWith("uID_")) {
                newLabels.add(l)
            }
        }
        printHandler.printRaw("SETTING NEW LABELS: " + newLabels.join(","))
        setLabels(slaveName, newLabels.join(" "))
        printHandler.printInfo("LABELS AFTER CHANGE")
        printHandler.printInfo(getLabels(slaveName))
    }

    static def isBusy(slaveName) {
        initSlaveFromName(slaveName)
        def computer = getComputer(slaveName)
        return computer.countBusy() > 0

    }

    static def setComputerOffline(computer, mesg) {
        computer.cliOffline(mesg)
    }

    static def setComputerOnline(computer, mesg) {
        computer.cliOnline(mesg)
    }

    static def isSlaveOffline(slaveName) {
        def computer = getComputer(slaveName)
        if (computer) {
            return computer.isOffline() || computer.isTemporarilyOffline()
        } else {
            printHandler.printLog("isSlaveOffline - ${slaveName} computer not initialized")
            return true
        }
    }

    static def isSlaveOnline(slaveName) {
        def computer = getComputer(slaveName)
        if (computer) {
            return computer.isOnline()
        } else {
            printHandler.printLog("isSlaveOnline - ${slaveName} computer not initialized")
            return false
        }
    }

    static def isSlaveIdle(slaveName) {
        def computer = getComputer(slaveName)
        if (computer) {
            return computer.isIdle()
        } else {
            printHandler.printLog("isSlaveIdle - ${slaveName} computer not initialized")
            return false
        }
    }
}

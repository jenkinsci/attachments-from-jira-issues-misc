// a wrapper closure around executing a string                                  
// can take either a string or a list of strings (for arguments with spaces)    
// prints all output, complains and halts on error                              
class RunShell implements Serializable {
    static def classArray = [:]
    static def printHandler
    static def jenkinsEnv
    static def jenkins_info
    static def exceptionHandler
    static String[] fullEnv
    static String[] sparseEnv
    static def runEnvSet = false

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get("PrintHandler")
        printHandler.printEmphasizeLog("initClass RunShell")
        jenkinsEnv = classArray.get("JenkinsEnv")
        exceptionHandler = classArray.get("ExceptionHandler")
        this.jenkins_info = info
    }

    static def setRunEnv() {
        if (!runEnvSet && jenkinsEnv) {
            fullEnv = jenkinsEnv.getShellEnv()
            sparseEnv = cleanEnv()
            runEnvSet = true
        }

    }

    static def printIt(str) {
        if (printHandler) {
            printHandler.printBox('RunShell: ' + str)
        } else {
            println('RunShell: ' + str)
        }
    }

    static def setEnvironment() {
        jenkinsEnv.getAllEnv().each { k, v ->
            System.setProperty(k, v)
        }
    }

    static String[] cleanEnv() {
        def newenv = []
        def envlist = [/JENKINS_URL=/, /BUILD_NUMBER=/, /BUILD_URL=/]
        for (l in fullEnv) {
            if (!envlist.any { e -> l =~ e }) {
                newenv.add(l)
            }
        }
        return newenv
    }

    static def runList(list) {
        def errorStream = new StringBuffer()
        def outputStream = new StringBuffer()
        def proc
        //  setEnvironment()
        try {
            printIt("Before execute of " + list.join(" "))

            proc = list.execute()


            try {
                printIt("Waiting for process to output ...")
                proc.waitForProcessOutput(outputStream, errorStream)
            } catch (Exception out) {
                printIt("Error in waiting for output! " + out.toString())
            }
            // proc.in.eachLine { line -> output += '\n' + line }
            //  proc.out.close()
            try {
                printIt("Waiting for process to finish executing ...")
                proc.waitFor()
                printIt("Process execution completed...")

                if (proc.exitValue()) {
                    printIt("gave the following error: ")
                    printIt(errorStream)
                    outputStream = outputStream + "\n" + list.join(" ") + ' Failed!!!!'
                }
            } catch (Exception exe) {
                printIt("Error in waiting for process to end! " + exe.toString())
            }
        } catch (Exception e) {
            printIt("We got this " + e.toString())
            if (exceptionHandler) {
                exceptionHandler.printExceptionStack(e)
            }
        }
        if (proc) {
            proc.destroyForcibly()
            proc.waitFor()
        }
        return outputStream.toString()
    }

    static def runCommand = { strList ->
        assert (strList instanceof String ||
                (strList instanceof List && strList.each { it instanceof String }))

        def outputStream = new StringBuffer()
        def errorStream = new StringBuffer()
        setRunEnv()
        def environ = fullEnv
        def proc
        //  setEnvironment()
        try {
            printIt("Before execute of ${strList}")
            if (jenkinsEnv) {
                proc = strList.execute(environ, null)
            } else {
                proc = strList.execute()
            }

            try {
                printIt("Waiting for process to output ...")
                proc.waitForProcessOutput(outputStream, errorStream)
            } catch (Exception out) {
                printIt("Error in waiting for output! " + out.toString())
            }
            // proc.in.eachLine { line -> output += '\n' + line }
            //  proc.out.close()
            try {
                printIt("Waiting for process to finish executing ...")
                proc.waitFor()
                printIt("Process execution completed...")

                if (proc.exitValue()) {
                    printIt("gave the following error: ")
                    printIt(errorStream)
                    outputStream = outputStream + "\n" + strList + ' Failed!!!!'
                }
            } catch (Exception exe) {
                printIt("Error in waiting for process to end! " + exe.toString())
            }
        } catch (Exception e) {
            printIt("We got this " + e.toString())
            if (exceptionHandler) {
                exceptionHandler.printExceptionStack(e)
            }
        }
        if (proc) {
            proc.destroyForcibly()
            proc.waitFor()
        }
        return outputStream.toString()
    }


}

import org.codehaus.groovy.runtime.StackTraceUtils

class StackHandlerClass implements Serializable  {


    static def initClass(classes, info) {
        def classArray = classes
    }

    static def getMethodInfo(stackNumber = 4) {
        def marker = new Throwable()
        def stacker = StackTraceUtils.sanitize(marker).stackTrace[stackNumber]
        return sprintf("%s %s", stacker.toString(), stacker.methodName)
    }
}

import groovy.json.JsonOutput
import groovy.json.JsonSlurper

class XpoolRest implements Serializable {

    static def classArray = [:]
    static def releasedClusters = [:]

    static def jenkinsEnv
    static def printHandler
    static def runShell
    static def exceptionHandler
    static String xpool_url
    static def slurper = new JsonSlurper()
    static def clustersInfo = [:]
    static def allClusterData = [:]
    static def jenkins_info

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get("PrintHandler")
        printHandler.printEmphasizeLog("initClass XpoolRest")
        exceptionHandler = classArray.get("ExceptionHandler")
        jenkinsEnv = classArray.get("JenkinsEnv")
        runShell = classArray.get("RunShell")
        xpool_url = getXpoolUrl(jenkinsEnv.getenv('XPOOL_CLIENT'))
        this.jenkins_info = info
    }

    static def getXpoolUrl(exe = 'prd') {
        switch (exe) {
            case 'stg':
                xpool_url = "http://xpool-stg.xiodrm.lab.emc.com"
                break
            case 'dev':
                xpool_url = "http://xpool-dev.xiodrm.lab.emc.com"
                break
            default:
                xpool_url = "http://xpool.xiodrm.lab.emc.com"
                break
        }
        return xpool_url
    }

    static def restGetAllBricks(use_cache = true) {
        def restCommand = "curl -X GET " + xpool_url + "/o/list/"
        if (allClusterData.size() == 0) {
            def output = runShell.runCommand(restCommand)
            def info = slurper.parseText(output)
            info.each { brick_info ->

            }
        }
    }

    static def restPrintBrickInfo(brick, use_cache = false) {
        def binfo = restGetBrickInfo(brick, use_cache)
        printHandler.printRaw(JsonOutput.prettyPrint(JsonOutput.toJson(binfo)))

    }

    static def restGetBrickInfo(brick, use_cache = false) {
        def cinfo = clustersInfo.get(brick)

        if (cinfo && use_cache) {
            printHandler.printInfo("restGetBrickInfo using cache for ${brick}")
            return cinfo
        }
        def restCommand = "curl -X GET " + xpool_url + "/o/list/?name=" + brick
        if (brick.contains("-TAG"))
        {
            printHandler.printInfo("Handling FEDERATION brick ${brick}")
            restCommand = "curl -X GET " + xpool_url + "/o/list/?xpool_tag=" + brick
        }
        /*
            optional parameters:
            user (-u) -  user=<username>
            appliance name (-c) -  name=<appliance_name>
            available appliances only (-x) -  available=true
            show only appliances in investigation (-i) -  investigation=true
         */
        def output = runShell.runCommand(restCommand)
        try {
            def info = slurper.parseText(output)
            clustersInfo.put(brick, info[0])
            return clustersInfo.get(brick)
        } catch (Exception e) {
            exceptionHandler.printExceptionStack(e)
            printHandler.printError("restGetBrickInfo - Returning null")
            return null

        }
    }


    static def restGetOwner(brick, use_cache = true) {
        def info = restGetBrickInfo(brick, use_cache)
        if (!info) {
            printHandler.printWarning("restGetOwner- failed")
            return null
        }
        def lessee = 'cyc_user'
        try {
            lessee = info.get('lessee')
            if (!lessee) {
                lessee = 'cyc_user'
            }
        } catch (Exception e) {
            printHandler.printWarning("restGetOwner - lessee not returned in REST returning default - " + lessee)

        }
        return lessee
    }

    static def restInvestigate(cluster, taggedCluster = "", use_cache = true) {
        def owner = restGetOwner(cluster, use_cache)

        def curl_command = ["curl", "-d"]

        def curl_json = sprintf('{"user":"%s","activator":"%s","name":"%s"}', owner, owner, cluster)
        if (cluster.contains("-TAG")) curl_json = sprintf('{"user":"%s","activator":"%s","name":"%s"}', owner, owner, cluster)
        def curl_action = ["-X", "POST"]
        def curl_type = ["-H", "Content-Type:application/json"]
        def curl_url = sprintf("%s/o/11/investigation/", xpool_url)

        curl_command += curl_json
        curl_command += curl_type
        curl_command += curl_action
        curl_command += curl_url

        def output = runShell.runList(curl_command)
        def data = slurper.parseText(output)
        def investigation = data.get('is_investigation')

        return "XpoolRest.restInvestigate:\nInvestigation Status: " + investigation

    }

    static def restInvestigateWithUser(String cluster, String cluster_owner, taggedCluster = "", use_cache = true) {
        def owner = restGetOwner(cluster, use_cache)

        def curl_command = ["curl", "-d"]

        def curl_json = sprintf('{"user":"%s","activator":"%s","name":"%s"}', cluster_owner, owner, cluster)
        if (cluster.contains("-TAG")) curl_json = sprintf('{"user":"%s","activator":"%s","xpool_tag":"%s"}', cluster_owner, owner, cluster)
        def curl_action = ["-X", "POST"]
        def curl_type = ["-H", "Content-Type:application/json"]
        def curl_url = sprintf("%s/o/11/investigation/", xpool_url)

        curl_command += curl_json
        curl_command += curl_type
        curl_command += curl_action
        curl_command += curl_url

        def output = runShell.runList(curl_command)
        def data = slurper.parseText(output)
        def return_info = sprintf("XpoolRest.restInvestigateWithUser(%s,%s):\nInvestigation Status: %s\nUser: %s", cluster, cluster_owner,
                                    data.get('is_investigation'), data.get('lessee'))
        return return_info

    }

    static def restInvestigationStatus(String cluster, taggedCluster = "") {
        def info = restGetBrickInfo(cluster,false)
        return info.get('is_investigation')
    }

    static def getLeaseMessages() {

    }

    static def getLeaseMessage(cluster) {
        def brick_info = restGetBrickInfo(cluster)
        return brick_info.get("lease_msg")

    }

    static def restLease() {
        /*Lease:


        curl - d '{"user":"<user>", "ttl":<seconds>}' - H
        "Content-Type: application/json" - X
        POST http://xpool.xiodrm.lab.emc.com/o/lease/

        more optional parameters:
        labels(-l) labels: < lable1, label2 ... >
        groups(-g) - groups: < group1, group2.. >
                appliances
        name(-c) - name: < appliance_name >
        */
        printHandler.printWarning("XpoolRest.restLease - not implemented yet")
        return ""
    }

    static def restUntagCluster(cluster, tag) {
        def owner = restGetOwner(cluster)

        def curl_command = ["curl", "-d"]

        def curl_json = sprintf('{"name":"%s","activator":"%s","cluster":"%s"}', tag, owner, cluster)
        def curl_action = ["-X", "POST"]
        def curl_type = ["-H", "Content-Type:application/json"]
        def curl_url = sprintf("%s/o/remove_xpool_tag/", xpool_url)

        curl_command += curl_json
        curl_command += curl_type
        curl_command += curl_action
        curl_command += curl_url

        def output = runShell.runList(curl_command)
        def info_str = sprintf("XpoolRest.restUntagCluster - Cluster: %s\nResult:\n%s", cluster, output)
        return info_str
    }

    static def restRestoreTags(clusters, tag) {
        def output = ""

        clusters.each { c ->

            def owner = restGetOwner(c)

            def curl_command = ["curl", "-d"]

            def curl_json = sprintf('{"name":"%s","activator":"%s","cluster":"%s"}', tag, owner, c)
            def curl_action = ["-X", "POST"]
            def curl_type = ["-H", "Content-Type:application/json"]
            def curl_url = sprintf("%s/o/add_xpool_tag/", xpool_url)

            curl_command += curl_json
            curl_command += curl_type
            curl_command += curl_action
            curl_command += curl_url

            output = output + runShell.runList(curl_command)
        }
        def info_str = sprintf("XpoolRest.restRestoreTags - Clusters: %s Tag: %s\nResult:\n%s", clusters.join(","), tag, output)
        return info_str
    }

    static def getTimeInSeconds(String timePhrase) {
        int howMany
        if (timePhrase == "eod") {
            Calendar c = Calendar.getInstance();
            c.add(Calendar.DAY_OF_MONTH, 1);
            c.set(Calendar.HOUR_OF_DAY, 19);
            c.set(Calendar.MINUTE, 30);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
            howMany = (c.getTimeInMillis() - System.currentTimeMillis()) / 1000

        } else {
            howMany = timePhrase.toInteger() * 60 & 60
        }
        return howMany

    }

    static def restExtendTime(String cluster, String timePhrase, taggedCluster = "") {
        def owner = restGetOwner(cluster, false)

        def curl_command = ["curl", "-d"]

        def curl_json = sprintf('{"name":"%s","user":"%s","ttl":%s}', cluster, owner, timePhrase)
        if (cluster.contains("-TAG")) curl_json = sprintf('{"name":"%s","user":"%s","ttl":%s}', cluster, owner, timePhrase)
        def curl_action = ["-X", "POST"]
        def curl_type = ["-H", "Content-Type:application/json"]
        def curl_url = sprintf("%s/o/extend/", xpool_url)

        curl_command += curl_json
        curl_command += curl_type
        curl_command += curl_action
        curl_command += curl_url

        def output = runShell.runList(curl_command)
        def info_str = sprintf("XpoolRest.restExtendTime - Cluster: %s Owner: %s TTL: %s \nResult:\n%s", cluster, owner, timePhrase, output)
        return info_str
    }

    static def restRelease(String cluster, hc = "") {
        def skip_option = ',"skip_hc":"true"' //if skip_hc:true hippo will be skipped
        def report_uid = ""
        def info_str = ""
        def owner = restGetOwner(cluster)
        def auto_users = ['jenkins-dev','qa_leaser','cyc_user']
        if (!jenkinsEnv.isQA() && !auto_users.any{u -> u == owner}) {
            printHandler.printBox("Not releasing appliance of private lease of ${owner}")
            return ("No release done for specific user ${owner}")
        }
        def env_hc = jenkinsEnv.getenv('healthCheck')
        if (env_hc) {
            printHandler.printLog("restRelease - hc retrieved from environment -  ${env_hc}")
            hc = env_hc
        }
        if (hc && hc.contains(cluster)) {
            skip_option = ""
        }
        if (releasedClusters.get('cluster') != null) {
            releasedClusters.put('cluster',null)
            return ('Cluster already released.')
        }  else {
            releasedClusters.put('cluster','1')

            def uid = getXpoolUrl(jenkinsEnv.getenv('UNIQUE_ID'))
            if (uid) report_uid = ',"report_uid":"' + uid + '"'

            def curl_command = ["curl", "-d"]

            def curl_json = sprintf('{"names":["%s"],"user":"%s"%s%s}', cluster, owner, skip_option, report_uid)
            if (cluster.contains("-TAG")) curl_json = sprintf('{"xpool_tag":"%s","user":"%s"%s%s}', cluster, owner, skip_option, report_uid)
            def curl_action = ["-X", "POST"]
            def curl_type = ["-H", "Content-Type:application/json"]
            def curl_url = sprintf("%s/o/release/", xpool_url)

            curl_command += curl_json
            curl_command += curl_type
            curl_command += curl_action
            curl_command += curl_url

            def output = runShell.runList(curl_command)
            if (restGetOwner(cluster, false) != owner) {
                info_str = sprintf("XpoolRest.restRelease - Cluster :%s released", cluster)
            } else {
                info_str = sprintf("XpoolRest.restRelease - Error during release!!!\nCluster: %s Owner: %s\nResult:\n%s", cluster, owner, output)
            }
        }
        return info_str
    }
}

/*
static def unTagCluster(cluster) {
static def restoreTags(clusters) {

static def xpoolSearch(fields, str) {
static def xpoolUpdateMessage(String cluster, String message, taggedCluster = "") {
static def xpoolExtendTime(String cluster, String clusterOwner, String timePhrase, taggedCluster = "") {
static def xpoolExtend(String cluster, taggedCluster = "") {
static def xpoolRelease(String cluster, taggedCluster = "") {
static def xpoolReleaseNative(String cluster) {
static def xpoolReleaseRegular(String cluster) {
static def xpoolRelease(String cluster, String message, taggedCluster = "") {
static def xpoolLease(String cluster, taggedCluster = "") {
static def xpoolEntry(String cluster, taggedCluster = "") {
static def xpoolClusterID(String cluster, taggedCluster = "") {
static def xpoolGetInfo(String cluster, taggedCluster = "") {
static def xpoolGetOwnerNative(String cluster,use_cache = true)
static def xpoolGetOwnerRegular(String cluster, use_cache = true)






Extend:








release
curl -d '{"names":[<appliance_name>], "user":"jenkins-dev"}' -H "Content-Type: application/json" -X POST http://xpool.xiodrm.lab.emc.com/o/release/

if you want to skip hippo (-s) add skip_hc : true to the parameters.
}*/

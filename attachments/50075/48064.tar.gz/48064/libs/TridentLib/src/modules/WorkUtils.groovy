class WorkUtils implements Serializable {

    static def classArray = [:]
    static def printHandler
    static def DossierChecked
    static def DossierExists

    static def jenkins_info
    static def exceptionHandler

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get("PrintHandler")
        printHandler.printEmphasizeLog("initClass WorkUtils")
        exceptionHandler = classArray.get("ExceptionHandler")
        DossierChecked = false
        DossierExists = false
        this.jenkins_info = info
    }

    static def checkDossierExists(build_dir) {
        def status = false
        def archive_dir = build_dir + '/archive'
        printHandler.printBlueInfo("Dossier Exist: " + DossierChecked.toString() + " Archive: " + archive_dir)
        if (DossierChecked) {
            return DossierExists
        }
        try {

            def workdir = new File(archive_dir)
            def filelist = []

            workdir.eachFile { f ->
                def outstr = sprintf("Checking file %s", f)
                filelist.add(f)
                if (f =~ /.*xbrick.*bz2/ || f =~ /.*vxms.*bz2/ || f =~ /.*xbrick.*tar.*/ || f =~ /.*vxms.*tar.*/) {
                    status = true
                    printHandler.printBlueInfo("Found zip file: " + f + " status: " + status.toString())
                }
            }
            printHandler.printBlueInfo("Files found in archive:\n\t")
            printHandler.printBlueInfo(filelist.join("\n\t") + "\n")
        } catch (Exception e) {
            DossierExists = false
            DossierChecked = true
            if (!e.toString() =~ /java.io.FileNotFoundException/) {
                printHandler.printError('Caught exception ' + e.toString())
                if (exceptionHandler) {
                    exceptionHandler.printExceptionStack(e)
                }
            } else {
                printHandler.printWarning("No archive to process")
            }
            return false
        }
        DossierChecked = true
        DossierExists = status
        return status
    }

    static def createTmpWorkArea(workspace, tmp_string) {
        if (workspace) {
            def area_workspace = new File(workspace)
            if (area_workspace.exists() && area_workspace.isDirectory()) {
                return workspace
            }
        }
        def area_workspace_name = "/tmp/" + tmp_string
        def area_workspace = new File(area_workspace_name)
        try {
            area_workspace.mkdirs()
        } catch (Exception e) {
            printHandler.printError("Can't create working space " + area_workspace_name + " - " + e.toString())
            if (exceptionHandler) {
                exceptionHandler.printExceptionStack(e)
            }
            return ""
        }
        return area_workspace_name
    }

    static def removeTmpWorkArea(workspace) {
        if (workspace =~ /^\/tmp\//) {
            def area_workspace = new File(workspace)
            try {
                area_workspace.deleteDir()
            } catch (Exception e) {
                printHandler.printError("Can't remove tmp directory: " + workspace + "- " + e.toString())
                if (exceptionHandler) {
                    exceptionHandler.printExceptionStack(e)
                }
            }
        }
    }
}

class NativeReplication implements Serializable {


    static def jenkinsEnv
    static def isNative = false

    static def taggedCluster = ""
    static def initialized = false

    static def initClass(classes, info) {
        def classArray = classes
        jenkinsEnv = classArray.get("JenkinsEnv")
    }

    static def initiateNative()
    {
        if (!initialized) {
            taggedCluster = jenkinsEnv.getenv('USER_TAGS')
            if (taggedCluster) {
                isNative = taggedCluster.size() > 0
            }
            initialized = true
        }
    }

    static def getNativeInfoString() {
        initiateNative()
        if (!taggedCluster) {
            return ""
        } else {
            isNative = true
            return taggedCluster.replace('-TAG', '').replace('-x', '_x').split('_').join(",")
        }

    }

    static def getNativeInfoList() {
        initiateNative()
        if (!taggedCluster) {
            return [""]
        } else {
            isNative = true
            return taggedCluster.replace('-TAG', '').replace('-x', '_x').split('_')
        }
    }


}
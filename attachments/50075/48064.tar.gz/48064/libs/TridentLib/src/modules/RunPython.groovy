class RunPython implements Serializable {
    static def classArray = [:]
    static def printHandler
    static def jenkinsEnv
    static def runShell
    static def jenkins_info
    static def library_space
    static def pythonPathString
    static def appdir

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get("PrintHandler")
        printHandler.printEmphasizeLog("initClass RunPython")
        jenkinsEnv = classArray.get("JenkinsEnv")
        runShell = classArray.get("RunShell")
    }

    static def runPythonScript(str) {
        def library_space = jenkinsEnv.getenv('library_space')
        def appdir = jenkinsEnv.getenv('APP_DIR')
        def String command = str
        printHandler.printRedInfo("COMMAND IS: " + command)
        return runShell.runCommand(command)
    }
}

import hudson.model.*
import jenkins.model.*

def jenkins = jenkins.model.Jenkins.instance
def killNode = build.buildVariableResolver.resolve("killNode")
def Mynode = ''
def jenkinsNodes = jenkins.nodes

if (killNode =~ "slave") {
    return false
}
for (node in jenkinsNodes) {
    if (node.nodeName == killNode) {
        Mynode = node
        break;
    }
}

comp = Mynode.toComputer()

while (comp.countBusy() > 0) {
//sleep(120000)
    Thread.sleep(120000)
}

hudson.model.Hudson.instance.removeNode(jenkins.model.Jenkins.instance.getNode(build.buildVariableResolver.resolve("killNode")))


import jenkins.model.*
import hudson.model.*
import java.security.*
import java.util.Random

public class Actions {

    String trigger(String name, String label, String ClusterName, String XPOOL_HOME,binding){

        def XPOOL_GROUP = ""
        try{
        XPOOL_GROUP = binding.getVariables().get("XPOOL_GROUP")
        }catch(e){
        XPOOL_GROUP = "rnddevlab"
        }

        if ( XPOOL_GROUP == "" || XPOOL_GROUP == null || XPOOL_GROUP == "null" || XPOOL_GROUP == "Null" || XPOOL_GROUP.length() < 2 ){
         XPOOL_GROUP = "rnddevlab"
        }

        def nodeName = name + "/" +  System.nanoTime()
	def url = "http://jenkins-rnd:8080/job/"+nodeName
	def job = hudson.model.Hudson.instance.getJob("lease_and_create_node")
	def param = new hudson.model.StringParameterValue('NAME', nodeName)
	def param2 = new hudson.model.StringParameterValue('EXECUTORS', "1")
	def param3 = new hudson.model.StringParameterValue('LBL', label)
	def param4 = new hudson.model.StringParameterValue('url', url)
	def param5 = new hudson.model.StringParameterValue('CLUSTER_NAME', ClusterName)
	def param6 = new hudson.model.StringParameterValue('XPOOL_PATH', XPOOL_HOME)
        def param7 = new hudson.model.StringParameterValue('XPOOL_GROUP', XPOOL_GROUP)
	def paramsAction = new hudson.model.ParametersAction(param,param2, param3, param4, param5, param6,param7)
	def cause = new hudson.model.Cause.UserIdCause()
	def causeAction = new hudson.model.CauseAction(cause)
	hudson.model.Hudson.instance.queue.schedule(job, 0, causeAction, paramsAction)
	return nodeName
    }
}


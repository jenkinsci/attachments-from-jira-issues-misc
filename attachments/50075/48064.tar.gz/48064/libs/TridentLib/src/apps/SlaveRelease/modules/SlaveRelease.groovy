import jenkins.model.*

class SlaveRelease {


        static def classArray = [:]
        static def printHandler
        static def nodeHandler
        static def xpoolRest
        static def jenkins_info
        static def jenkinsEnv
        static def j_instance


        static def initClass(classes, info) {
            classArray = classes
            printHandler = classArray.get('PrintHandler')
            jenkinsEnv = classArray.get('JenkinsEnv')
            nodeHandler = classArray.get('NodeHandler')
            xpoolRest = classArray.get('XpoolRest')
            this.jenkins_info = info
            j_instance = info.get('j_instance')
            printHandler.printEmphasizeLog("initClass SlaveRelease")
        }

        static def internalMain(jenkins_info) {
             try {
                 def slaveName = jenkins_info.get('brickName')
                 if (slaveName) {
                    printHandler.printBox("Releasing and removing ${slaveName}")
                    def is_specific = jenkinsEnv.getenv('SPECIFIC_APPLIANCE') == slaveName
                    if (! is_specific) {
                        printHandler.printUnderline("Release ${slaveName}  ...")
                        xpoolRest.restRelease(slaveName)
                    } else {
                        printHandler.printBox("No release for ${slaveName} as it is a specific lease request")
                    }
                    printHandler.printUnderline("Removal of ${slaveName} from Jenkins Database...")
                    nodeHandler.nodeRemove(slaveName)
                    printHandler.printBox("Release/remove of ${slaveName} completed")
                    return 0
                 } else {
                    printHandler.printBox("SlaveRelease no brick requested")
                    return 1
                }
             }
             catch(Exception e) {
                printHandler.printError("Failed to execute - " + e.toString())
                return 1
             }

    }
}

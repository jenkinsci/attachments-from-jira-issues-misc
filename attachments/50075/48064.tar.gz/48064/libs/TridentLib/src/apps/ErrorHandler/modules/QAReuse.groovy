class QAReUseClass {

    static def classArray = [:]

    static def printHandler
    static def nodeHandler
    static def jenkinsEnv
    static def jenkins_info
    static def j_instance

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get("PrintHandler")
        nodeHandler = classArray.get("NodeHandler")
        jenkinsEnv = classArray.get("JenkinsEnv")
        jenkins_info = info
        j_instance = jenkins_info.get('j_instance')
        printHandler.printEmphasizeLog("initClass QAReuse")
    }

    static def QAReuse(manager) {
        def status = false
        def specificCluster = manager.envVars['CLUSTER_NAME']

        if (specificCluster && specificCluster.trim() != "" && specificCluster.toUpperCase() != "NONE") {
            printHandler.printEmphasizeConsoleColor("[NOTE] - Not executing reuse because we have a specific cluster (${specificCluster})"," >","",5)
            return status
        }

        def WORKSPACE = manager.envVars['WORKSPACE']
        def XBRICK = manager.envVars['XBRICK']
        if (manager.envVars['USER_TAGS']) {
            XBRICK = manager.envVars['USER_TAGS']
        }

        if (XBRICK != null) {

            printHandler.printInfo("Checking possibility for reuse of - ${XBRICK}")
            def nName = manager.envVars['NODE_NAME']
            def q = j_instance.queue
            for (item in q.items) {
                printHandler.printLog("[INFO]		looping Jenkins queue")
                try {
                    def Dname = item.getAssignedLabel().getDisplayName()
                    if (Dname == nName) {
                        try {
                            dbReport(manager)
                        } catch (e) {
                            printHandler.printLog("ERROR in dbReport continuing anyway ...")
                        }
                        printHandler.printLog("found queue entry: " + item.toString())
                        printHandler.printConsoleColor("[INFO] -  Found jobs in Queue - Passing $XBRICK to next job", "GREEN")
                        def slave = manager.build.getBuiltOn()
                        def cmd = "def proc = \"/home/jenkins/PassClusterParams.sh $nName $WORKSPACE\".execute(); proc.waitFor(); println proc.in.text;"
                        def output = hudson.util.RemotingDiagnostics.executeGroovy(cmd, slave.getChannel())
                        printHandler.printLog(output)
                        status = true
                        return true

                    }
                } catch (e) {
                    printHandler.printError("error in getting item LBL. continue to next one")
                    printHandler.printLog(e)
                }
                if (status) {
                    return status
                }
            }
        }
        return status
    }

    def createNewENV(String key, String value) {
        try {
            printHandler.printLog("Creating New ENV: " + key + " = " + value)
            def pa = ParametersAction([StringParameterValue(key, value)])
            Thread.currentThread().executable.addAction(pa)
        } catch (e) {
            printHandler.printLog("[WARN]      " + e)
        }
    }

    static def dbReport(manager) {
        printHandler.printLog("DBCONN.py FAILS returning ....")
        return
        try {
            def JENKINS_GIT = manager.envVars['HomeJenkins']
            def JenkinsRunsInfo = JENKINS_GIT + "/dbconn.py"
            def url = jenkinsEnv.getenv('JENKINS_URL')
            def buildRes = jenkins_info.get('buildResult')
            printHandler.printLog("[INFO]    Reporting to DB")
            def now = (System.currentTimeMillis()).toString()
            /* try {
                 createNewENV("TestEnded", now)
             } catch (e) {
                 printHandler.printLog("[WARN]      " + e)
             }*/
            def params
            if (manager.logContains(".*Aborted by.*") || manager.logContains(".*Build was aborted.*")) {
                params = "${url} {'runStatus':'Aborted','testEnded':'${now}'}"
            } else {
                params = "${url} {'runStatus':'${buildRes}','testEnded':'${now}'}"
            }
            def output = ""
            def proc = "${JenkinsRunsInfo} ${params}".execute()
            proc.in.eachLine { line -> output += '\n' + line }
            proc.out.close()
            proc.waitFor()
            if (proc.exitValue()) {
                printHandler.printLog("[ERROR]   ${proc.getErrorStream()}")
            } else {
                printHandler.printLog("[info]   Reported successfully to DB")
            }
        }
        catch (e) {
            printHandler.printLog(e)
        }

    }
}

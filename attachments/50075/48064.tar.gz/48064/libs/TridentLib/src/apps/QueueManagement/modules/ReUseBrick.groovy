import hudson.*
import hudson.model.*
import hudson.plugins.sshslaves.*
import hudson.slaves.*
import jenkins.*
import jenkins.model.*

class reUseBrickClass {

    static def classArray = [:]
    static def idString = "Job_UniqueID"
    static def setString = "TS_Id"
    static def countString = "TS_Executors"
    static def xpoolString = "TS_XpoolLabel"

    static def searchVars = [/.*TS_Executors=/, /.*TS_Id=/, /.*TS_XpoolLabel=/, /.*Job_UniqueID=/]

    static def printHandler
    static def jenkinsEnv
    static def queueHandler
    static def xpoolInfo
    static def setCheckLabels
    static def xpoolRelease
    static def xpoolExtend
    static def workUtils
    static def jenkins_info
    static def exceptionHandler

    static def initClass(classes, info) {
        def classArray = classes
        printHandler = classArray.get('PrintHandler')
        jenkinsEnv = classArray.get('JenkinsEnv')
        exceptionHandler = classArray.get("ExceptionHandler")
        queueHandler = classArray.get('QueueManagement.QueueHandler')
        xpoolInfo = classArray.get('QueueManagement.XpoolInfo')
        setCheckLabels = classArray.get("QueueManagement.SetCheckLabels")
        workUtils = classArray.get("WorkUtils")
        xpoolExtend = classArray.get("QueueManagement.XpoolExtend")
        xpoolRelease = classArray.get('QueueManagement.XpoolRelease')
        this.jenkins_info = info
        printHandler.printEmphasizeLog("initClass ReUseBrick")
    }


    static def internalMain(jenkins_info) {
        def build = this.jenkins_info.get('build')
        def workspace
        def ts_id
        def job_id
        def max_allowed
        try {
            ts_id = build.buildVariableResolver.resolve("TS_Id")
            job_id = build.buildVariableResolver.resolve("Job_UniqueID")
            max_allowed = build.buildVariableResolver.resolve("TS_Executors")
        } catch (Exception e) {
            def params = jenkins_info.get('params')
            ts_id = params.get('TS_Id')
            job_id = params.get('Job_UniqueID')
            max_allowed = params.get('TS_Executors')

        }
        def tmp_work_name = sprintf("%s_%s", ts_id, job_id)

        def cur_work_area = jenkins_info.get('work_area')
        workspace = workUtils.createTmpWorkArea(cur_work_area, tmp_work_name)
        printHandler.printBlueInfo("Running reUseBrick ....")
        if (reUseBrick(ts_id, max_allowed, workspace)) {
            printHandler.printBlueInfo("Running setCheckLabels ....")
            setCheckLabels.setCheckLabels(workspace)
        }
        printHandler.printBlueInfo("Running xpoolRelease ....")
        xpoolRelease.xpool_release(workspace)
        printHandler.printBlueInfo("Cleaning up workspace ....")
        workUtils.removeTmpWorkArea(workspace)
        return 0
    }


    static def reUseBrick(ts_id, max_allowed, workspace) {

        printHandler.printInfo("Starting reUseBrick: testID =  " + ts_id + " workspace = " + workspace)
        if (ts_id) {
            def brick
            def brick_labels
            brick = jenkins_info.get('brickName')

            brick_labels = xpoolInfo.xpool_info(brick, workspace)
            brick_labels = brick_labels.replace(';', ' ').replace(',', ' ').split(/\s+/).join(' ')
            def queueList = queueHandler.getQueueInfo(ts_id, brick, brick_labels)
            def running_build_list = queueHandler.getRunningBuilds(ts_id)
            printHandler.printPurpleInfo("getRunningBuilds returned: " + running_build_list)
            def running_build_count = 0
            if (running_build_list.size() > 0) {
                running_build_count = running_build_list.get(ts_id)
            }
            if (queueList.size() > 0) {
                //    printHandler.printRedInfo(queueList)
                def q_entry = queueList.get(ts_id)

                def check_count = max_allowed.toInteger() - running_build_count
                printHandler.printPurpleInfo("MAX Allowed " + max_allowed + " RUNNING COUNT " + running_build_count + " CHECK COUNT " + check_count)
                def test_entry = getReuseEntry(q_entry, brick_labels, check_count)
                if (test_entry.get(idString)) {
                    def info = sprintf("Reusing brick %s for test with following labels %s_%s", brick, ts_id, test_entry.get(idString))
                    printHandler.printBox(info)
                    extendBrick(brick, workspace)
                    printCollectorFile(brick, ts_id, test_entry.get(idString), workspace)
                    return true
                } else {
                    def info = sprintf("There are no tests found that match in test set %s that match the right criteria of %s", ts_id, brick)
                    printHandler.printPurpleInfo(printHandler.emphasize(info,">","<",2))
                    printHandler.printPurpleInfo(printHandler.emphasize("Brick ${brick} will be released"," >","",4))
                }
            } else {
                def info = sprintf("brick %s will be released no matching tests for reuse", brick)
                printHandler.printBox(info)
                printReleaseFile(brick, workspace)
                return false
            }
        }
        return false
    }

    static def printCollectorFile(brick, ts_id, id, workspace) {
        try {
            def collectorFile = "${workspace}/collector.dat"
            def collectorFilefd = new PrintWriter(collectorFile)
            printHandler.printBox("Creating and writing info to " + collectorFile)
            printHandler.logInitFileDescriptor("collectorFile", collectorFilefd)
            def outstring = sprintf("%s:-:%s:-:%s", brick, ts_id, id)
            printHandler.printRaw(outstring, ["collectorFile"])
            printHandler.printRaw(printHandler.emphasize("Output is : " + outstring," >","",2))
        } catch (Exception e) {
            printHandler.Error("Problem writing Collector file" + e.toString())
            if (exceptionHandler) {
                exceptionHandler.printExceptionStack(e)
            }

        }

    }

    static def printReleaseFile(brick, workspace) {
        def releaseFile = "${workspace}/releaseList.dat"
        def releaseFileFd = new PrintWriter(releaseFile)
        printHandler.printBox("Creating and writing info to " + releaseFile)
        printHandler.logInitFileDescriptor("releaseFile", releaseFileFd)
        def outstring = sprintf("%s", brick)
        printHandler.printRaw(outstring, ["releaseFile"])

    }


    static def extendBrick(brick, workspace) {
        def extendFile = "${workspace}/extendFile.dat"
        def extendFileFd = new PrintWriter(extendFile)
        printHandler.printBox("Creating and writing info to " + extendFile)
        printHandler.logInitFileDescriptor("extendFile", extendFileFd)
        def outstring = sprintf("%s", brick)
        printHandler.printRaw(outstring, ["extendFile"])
        xpoolExtend.xpool_extend(workspace)
    }

    static def getTestClusters(test_label, cluster_types) {
        def clist = []
        def outlist = []

        // first get any mention of a cluster_type even a negative one (@)
        test_label.split(/\s+/).each { t_label ->
            def c_label = t_label.trim()
            if (c_label =~ /^@/) {
                c_label = c_label.replace('@', '')
            }
            if (cluster_types.any { it == c_label }) {
                clist.add(t_label)
            }
        }

        // build a complete list including the parsing of the negative options
        clist.each { l ->
            if (l.charAt(0) != '@') {
                outlist.add(l)
            } else {
                def neg = l.replace('@', '')
                cluster_types.each {
                    if (it != neg) {
                        outlist.add(it)
                    }
                }
            }
        }
        // return a sorted unique list of each possible cluster type requested
        return outlist.sort().unique()
    }


    static def matchLabels(test_label, brick_label) {
        def cluster_types = ['single', 'dual', 'triple', 'quad', 'penta', 'six', 'septet', 'octa']
        def brick_type

// force matching case before any processing
        test_label = test_label.toString().toLowerCase().replace(',', ' ')
        brick_label = brick_label.toLowerCase()
        def b_list = brick_label.split(/\s+/)
// first we check for matching cluster types
        // get brick type first
        b_list.each { ctype ->
            if (cluster_types.any { it == ctype }) {
                brick_type = ctype
            }
        }

        def test_clusters = getTestClusters(test_label, cluster_types)
        if (!test_clusters.any { it == brick_type }) {
            return false
        }
// Now we check all the rest of the -l option against the brick information
        // remove mention of cluster types from test_label
        cluster_types.each {
            test_label = test_label.replace(it, '').replace('@' + it, '')
        }
        test_label.split(/\s+/).each {
            t_label ->
                def neg = false
                def matched
                if (t_label =~ /^@/) {
                    neg = true
                    t_label = t_label.replace('@', '')
                }
                matched = b_list.any { it == t_label }
                if (matched && neg) {
                    return false
                } else {
                    if (!matched) {
                        return false
                    }
                }
        }
        return true // Found all  test label request in brick label
    }


    static def getReuseEntry(queueList, brick_label, count) {
        def testList = queueList.get('testList')
        def returnInfo = [:]
        def get_label = false
        printHandler.printBox("Starting getReuseEntry ...")
        printHandler.printLog("Current size of queue entries " + testList.size())
        printHandler.printLog("Checking maximum_slaves " + count + " queue entries")
        testList.each { t ->
            if (!returnInfo.size() && count >= 0) { // Make sure we take only the first test that matches
                def test_label = ""
                t.get(xpoolString).split(' ').each { opt ->
                    opt = opt.trim()
                    if (get_label) {
                        test_label = opt
                        get_label = false
                    }
                    if (opt =~ /^-l/) {
                        if (opt.size() > 2) {
                            test_label = opt.replace('-l', '')
                        } else {
                            get_label = true
                        }
                    }
                }
                if (matchLabels(test_label, brick_label)) {
                    returnInfo.put(setString, t.get(setString))
                    returnInfo.put(idString, t.get(idString))
                }
            }
            count = count - 1
        }
        return returnInfo
    }

}

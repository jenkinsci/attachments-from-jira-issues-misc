import com.cloudbees.hudson.plugins.modeling.impl.jobTemplate.InstanceFromJobTemplate
import hudson.*
import hudson.model.*
import jenkins.*
import jenkins.model.*

class QueueHandler {

    static def idString = "Job_UniqueID"
    static def setString = "TS_Id"
    static def countString = "TS_Executors"
    static def xpoolString = "TS_XpoolLabel"
    static def clusterName = "CLUSTER_NAME"

    static def xpoolUser = "XPOOL_USER"
    static def xpoolLabelRegex = "xpoolLabelRegex"

    static
    def searchVars = [/.*TS_Executors=/, /.*TS_Id=/, /.*TS_XpoolLabel=/, /.*Job_UniqueID=/, /.*CLUSTER_NAME/, /.*XPOOL_USER/, /.*xpoolLabelRegex/]
    static def buildSearch = [idString, setString, countString, xpoolString, clusterName, xpoolUser, xpoolLabelRegex]
    static def optionalValues = [clusterName, xpoolUser, xpoolLabelRegex]
    static def classArray = [:]
    static def printHandler
    static def jenkinsEnv
    static def jenkinsGetBuild
    static def jenkins_info
    static def j_instance
    static def queue_pointer
    static def exceptionHandler

    static def first_called = false

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get('PrintHandler')
        jenkinsEnv = classArray.get('JenkinsEnv')
        jenkinsGetBuild = classArray.get('JenkinsGetBuild')
        exceptionHandler = classArray.get("ExceptionHandler")
        this.jenkins_info = info
        printHandler.printEmphasizeLog("initClass QueueHandler")
        j_instance = info.get('j_instance')
        queue_pointer = j_instance.queue
    }

    static def get_queue_pointer() {
        return queue_pointer
    }

    static def getBrickName(b) {
        def brickname = "UNKNOWN"
        //   printHandler.printRedInfo("Handling build of type " + b.getClass())
        if (b) {
            try {
                def brick = b.getBuiltOnStr()

                if (brick) {
                    brickname = brick
                    //            printHandler.printBlueInfo("BRICK IS " + brickname)
                } else {
                    brick = b.getBuildOn()
                    brickname = brick.toString()
                }
            }
            catch (Exception e) {
                try {
                    def executor = b.getExecutor()
                    if (executor) {
                        brickname = b.getExecutor().getDisplayName()
                    }
                } catch (Exception f) {
                    printHandler.printLog("Problem getting brick name for build")
                }

            }
        }
        //    printHandler.printPurpleInfo ("getBrickName returning - " + brickname)
        return brickname
    }


    static def getRunningBuilds(testSetID = "") {

        def testSets = [:]
        if (testSetID) {
            printHandler.printRedInfo("getRunningBuilds testSetID is:" + testSetID)
        }
        try {
            j_instance.instance.getAllItems(hudson.model.Job).findAll {
                it.getBuilds().getLastBuild() && it.getBuilds().getLastBuild().isBuilding()
            }.each {
                it ->
                    def job_builds = it.getBuilds()
                    job_builds.each { b ->
                        if (b.isBuilding()) {
                            def brickname = getBrickName(b)
                            if (brickname.startsWith("xbrick")) {
                                try {
                                    b.getActions(ParametersAction).findAll { it.getParameter(setString) }.each { act ->
                                        def ts_ID = act.getParameter(setString).getValue().split('=')[0]
                                        def xpoolLabel = act.getParameter(xpoolString).getValue().split('=')[0]
                                        def unique_id = act.getParameter(idString).getValue().split('=')[0]
                                        if ((testSetID && ts_ID.equals(testSetID)) || testSetID == "") {
                                            if (testSets.get(ts_ID)) {
                                                def tcount = testSets.get(ts_ID) + 1
                                                testSets.put(ts_ID, tcount)
                                            } else {
                                                testSets.put(ts_ID, 1)
                                            }
                                        }
                                    }
                                } catch (Exception e) {
                                    printHandler.printLog("Error reading " + b.toString())
                                }
                            }
                        }
                    }
            }
        } catch (Exception e) {
            printHandler.printException("getRunningBuilds caught: " + e.toString())
            if (exceptionHandler) {
                exceptionHandler.printExceptionStack(e)
            }
        }
        return testSets
    }

    static def getQueueEntryInfo(q_entry_string) {
        def line = []
        def m_string = q_entry_string =~ /runId=[^,]*,/
        //       printHandler.printRedInfo(" getQueueEntryInfo Got string " +  q_entry_string)
        if (m_string.count) {
            def m = m_string[0]
            //        printHandler.printGreenInfo("We got m " + m)
            m = m.replace('runId=', '').replace(',', '').replace('#', '/')
            def buildName
            if (m.split('/').size() > 2) {
                buildName = m.split('/')[0..-2].join('/')
            } else {
                buildName = m.split('/')[-2]
            }
            def buildNum = m.split('/')[-1]
            //   printHandler.notify("Trying to get info for " + buildName + "/" + buildNum)
            def buildInfo = jenkinsGetBuild.getBuild(buildName, buildNum, false)

            def actions = []
            if (buildInfo) {
                actions = buildInfo.getActions(ParametersAction)
            }
            for (a in actions) {
                for (b in buildSearch) {
                    def param = a.getParameter(b)
                    if (param) {
                        def value = param.getValue()
                        def name = param.getName()
                        line.add(sprintf("%s=%s", name.trim(), value.trim()))
                    }
                }
            }
        }
        return line
    }

    static def label_parse_vars(label,tmpmap)
    {
        def found = label =~ /(\$\{\w+\})/
        def matches = [:]
        found.each { matches.put(it[0], 1) }
        matches.each { k, v ->
            def val = k
            def var = val.replace("\$", "").replace("{", "").replace("}", "")
            def var_value = jenkinsEnv.getenv(var)
            if (!var_value) {
                var_value = tmpmap.get(var)
            }
            if (!var_value) {
                var_value = "BAD_VALUE: ${var}"
            }
             label = label.replace(val, var_value)
        }
        return label

    }
    static def getXpoolLabelBase(jobname,tmpmap) {
        String TS_XpoolLabel_Base = ""
        def job = j_instance.getItemByFullName(jobname)
        if (!first_called) {
            printHandler.printLogVerbose("Getting xpoolBase for jobname ${jobname}")
        }
        if (job) {
            InstanceFromJobTemplate instFromTempl = InstanceFromJobTemplate.from(job)
            if (instFromTempl != null) {
                TS_XpoolLabel_Base = instFromTempl.TS_XpoolLabel_Base ?: ""
                if (!first_called) {
                    printHandler.printLogVerbose("Accessed Attribute TS_XpoolLabel_Base value: ${TS_XpoolLabel_Base}")
                }
            }
        }
        def found = TS_XpoolLabel_Base =~ /(\$\{\w+\})/
        def matches = [:]
        found.each { matches.put(it[0], 1) }
        matches.each { k, v ->
            def val = k
            def var = val.replace("\$", "").replace("{", "").replace("}", "")
            def orig_var = val
            def var_value = jenkinsEnv.getenv(var)
            if (!var_value) {
                var_value = tmpmap.get(var)
            }
            if (!var_value) {
                var_value = "BAD_VALUE: ${orig_var}"
            }
            TS_XpoolLabel_Base = TS_XpoolLabel_Base.replace(val, var_value)
        }
        return TS_XpoolLabel_Base
    }

    static def getDefaultUser() {
        if (jenkinsEnv.isQA()) {
            return "qa_leaser"
        } else {
            return "jenkins-dev"
        }
    }

    static def getQueueEntriesbyLabel(label) {
        def entryList = []
        def q = j_instance.queue
        q.getItems().findAll { it.getAssignedLabel() =~ /label/ }.each {
            entryList.add(it)
        }
        return entryList
    }

    static def getQueueInfo(tsetId = '', brick = '', brick_label = '', tsList = []) {
        def q = j_instance.queue
        def setList = [:]
        def sortedSetList = [:]
        printHandler.printLog(printHandler.emphasize("getQueueInfo - start"))
        //printHandler.printPurpleInfo("getQueueInfo tsList size = " + tsList.size())
        //printHandler.printPurpleInfo(tsList)
        try {
            q.getItems().each {
                def jobName
                def itString = it.toString()
                if (itString =~ /.*runId=/) {
                    jobName = it.toString().split(/runId=/)[1].split(/#/)[0]
                } else {
                    jobName = itString.split(/[\[\]]/)[1]
                }

                //printHandler.printLogVerbose("getQueueInfo - Current Item: " + it.toString() + "\nJOBNAME is:${jobName}")
                if (it) {
                    def list = []

                    def line = it.getParams().split(/\n/)
                    if (line.size() <= 1) {
                        line = getQueueEntryInfo(it.toString())
                        //printHandler.printBoxLog("IT = " + it.toString())
                    }
                    //printHandler.printUnderlineLog("THIS IS LINE: ${line}")
                    line.sort().each { l ->
                        def newval = []
                        if (searchVars.any { s -> l =~ s }) {
                            def varval = l.split('=')
                            if (varval instanceof String) {
                                newval.add(varval)
                                newval.add('')
                            } else if (varval.size() == 1) {
                                newval.add(varval[0])
                                newval.add('')
                            } else {
                                newval = varval
                            }
                            list.add(newval)
                        }
                    }
                    def tID
                    def tmpmap = [:]
                    def missing_list = []

                    list.each { l -> tmpmap.put(l[0], l[1]) }


                    def xpoolRequest = tmpmap.get(xpoolString)
                    def xpoolBaseLabel = getXpoolLabelBase(jobName, tmpmap)

                    if (xpoolRequest == null) {
                        xpoolRequest = ''
                    }

                    if (xpoolBaseLabel == null) {
                        xpoolBaseLabel = ''
                    }
              if (xpoolRequest.isEmpty()) {
                        tmpmap.put(xpoolString, xpoolBaseLabel.trim())
                    } else if (!xpoolBaseLabel.isEmpty()) {
                        tmpmap.put(xpoolString, sprintf("%s,%s", xpoolBaseLabel, xpoolRequest.trim()))
                    } // if neither of the above ifs are true we are left with the original value
                    def parsed_label = label_parse_vars(tmpmap.get(xpoolString), tmpmap)
                    tmpmap.put(xpoolString, parsed_label)
                    buildSearch.each {
                        if (!tmpmap.get(it) && !optionalValues.any { o -> o == it }) {
                            missing_list.add(it)
                        }
                    }
                    if (missing_list.size()) {
                        printHandler.printLogVerbose("Skipping ${jobName} because it is missing the following variables: " + missing_list.join(" "))
                    } else {
                        def juid = tmpmap.get(idString)
                        if (!juid.matches("[0-9]+")) {
                            printHandler.printBoxColor("Skipping ${jobName} because Job_UniqueID value can only be numeric digits: ${juid}", "RED")
                            missing_list.add("Job_UniqueId")
                        }
                    }
                    def process = true
                    if (tmpmap.size() && missing_list.size() == 0) {
                        tID = tmpmap.get(setString)
                        if (tsetId) {
                            process = tsetId == tID
                        } else {
                            if (tsList.size() > 0) {
                                //  printHandler.printLogVerbose("tsList size " + tsList.size())
                                if (!first_called) {
                                    printHandler.printLogVerbose("tID is ${tID}")
                                    printHandler.printLogVerbose("uID is " + tmpmap.get(idString))
                                    printHandler.printLogVerbose("clusterName is" + tmpmap.get(clusterName))
                                }
                                def uID = tmpmap.get(idString)
                                process = tsList.any { tID == it.split(':')[0] && uID == it.split(':')[1] }
                                if (!first_called) {
                                    tsList.each {
                                        printHandler.printLogVerbose("\t ${it}")
                                        printHandler.printLogVerbose("\t " + it.split(':')[0] + " - " + it.split(':')[1])
                                    }
                                    printHandler.printLogVerbose("continue processing state: ${process}")
                                }
                            }
                        }
                        if (process && tmpmap.get(xpoolString)) {
                            if (!setList.get(tID)) {
                                setList.put(tID, [:])
                                setList.get(tID).put(countString, tmpmap.get(countString))
                                if (tsetId) {
                                    setList.get(tID).put(xpoolString, tmpmap.get(xpoolString))
                                }
                                setList.get(tID).put('testList', [])
                            }

                            tmpmap.put('testName', it.toString().split(/\[|\]/)[1])

                            setList.get(tID).get('testList').add(tmpmap)
                        }
                    }
                }
            }

            setList.each { k, v ->
                def tmpv = v.get('testList')
                def sorted
                try {
                    sorted = tmpv.sort({ a, b -> Float.valueOf(a.get(idString)) <=> Float.valueOf(b.get(idString)) })
                } catch (e) {
                    printHandler.printBoxColor("Error in sorting UniqueID(s) using non-sorted order!", "RED")
                    sorted = tmpv

                }
                sortedSetList.put(k, [:])
                sortedSetList.get(k).put(countString, v.get(countString))
                sortedSetList.get(k).put('testList', [])
                sortedSetList.get(k).put('testList', sorted)
            }
        } catch (Exception e) {
            printHandler.printException("problem in Queue Access " + e.toString())
            if (exceptionHandler) {
                exceptionHandler.printExceptionStack(e)
            }
            throw new RuntimeException("[(Queue reader ERROR]" + e.getMessage())
        }

        printHandler.printEmphasizeLog("getQueueInfo - finished returning Test Set list current count = " + sortedSetList.size())
        first_called = true
        return sortedSetList

    }

    static def printDataFile(queueList) {
        //File temp = File.createTempFile("temp",".scrap")
        try {
            def build = jenkins_info.get('buildManager')
            def workspace = jenkins_info.get('workarea')
            def requestFileFd = new PrintWriter("${workspace}/request_file.dat")
            printHandler.logInitFileDescriptor("requestFile", requestFileFd)

            printHandler.printInfo("[INFO] Printing Data File if neccessary ...")
            def request_count = 0
            queueList.each { test_id, test_info ->
                def tests = test_info.get('testList')
                def testSet_string = sprintf('%s:-:%s', test_id, test_info.get(countString).toString())
                tests.each { test ->
                    def xString = ""
                    def cName = test.get(clusterName)
                    if (cName && !cName.isEmpty()) {
                        xString = "CLUSTER_NAME=${cName}"
                    } else {
                        xString = test.get(xpoolString)
                    }
                    def xuser = test.get(xpoolUser)

                    if (!xuser || xuser.isEmpty()) {
                        // printHandler.printUnderline("no user defined in queue, using default user")
                        xuser = getDefaultUser()
                    }
                    if (xuser != getDefaultUser()) {
                        printHandler.printEmphasize("XpoolUser is ${xuser}")
                    }

                    request_count += 1
                    def test_string = sprintf('%s:-:%s:-:%s:-:%s', test.get(idString), xString, test.get('testName'), xuser)
                    def out_string = sprintf('%s:-:%s', testSet_string, test_string)
                    printHandler.printRaw(out_string, ["requestFile"])
                    printHandler.printInfo(sprintf("\t%s", out_string))
                }
                requestFileFd.flush()
                printHandler.printUnderline("Total requests in queue: " + request_count.toString())
                return true
            }
        } catch (Exception e) {
            printHandler.printException("Problem writing file" + e.toString())
            if (exceptionHandler) {
                exceptionHandler.printExceptionStack(e)
            }
            return false
        }
    }


    static def internalMain(jenkins_info) {
        try {

            def runningTestSets = [:]
            def printQueue = [:]
            printHandler.setVerbose("on")

            printHandler.printInfo("[INFO] Starting Queue Reader .....")


            def queueList = getQueueInfo()
            if (queueList.size() > 0) {
                runningTestSets = getRunningBuilds()
            }

            def qsize = queueList.size()
            def rsize

            if (qsize) {
                rsize = runningTestSets.size()
            } else {
                printHandler.printInfo("[INFO] Nothing in queue to process exiting ....")
                return 0
            }

            if (qsize > 0 && rsize == 0) {
                printQueue = queueList
            } else {
                printHandler.printInfo("[INFO] Checking the queue requests against running builds ...")
                runningTestSets.each { k, v ->
                    def q_info = queueList.get(k)
                    printHandler.printInfo("\tTestSet: " + k + " currently running " + v)
                    if (q_info) {
                        def threshold = q_info.get(countString).toInteger()
                        printHandler.printInfo(sprintf("\t\tQueue Threshold: %d", threshold))
                        if (threshold > v) {
                            printHandler.printInfo("\t\t\tAdding info to process")
                            printQueue.put(k, q_info)
                        } else {
                            printHandler.printInfo("[INFO] - testSet " + k + " has " + v + " builds running, threshold = " + threshold + " Not Added")
                        }
                    } else {
                        printHandler.printInfo("\t\t No more requests in queue")
                    }
                }
                printHandler.printInfo("[INFO] Proccessing rest of Queue without running builds ...")
                queueList.each { k, v ->
                    if (!runningTestSets.get(k)) {
                        printHandler.printInfo("[INFO] Adding to queue " + k + " (no running builds)")
                        printQueue.put(k, v)
                    }
                }
            }

            if (printQueue.size() > 0) {
                return printDataFile(printQueue)
            } else {
                printHandler.printInfo("[INFO] Currently all thresholds are in use or there is nothing in the queue")
                return 0
            }
        } catch (Exception e) {
            printHandler.printException("Exception is: " + e.toString())
            return 1
        }
        return 0
    }
}



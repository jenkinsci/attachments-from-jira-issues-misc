import hudson.*
import hudson.model.*
import hudson.plugins.sshslaves.*
import hudson.plugins.sshslaves.verifiers.*
import hudson.slaves.*
import hudson.slaves.EnvironmentVariablesNodeProperty.Entry
import jenkins.*
import jenkins.model.*

class setCheckLabelsClass {
    static def printHandler
    static def jenkinsEnv
    static def jenkins_info
    static def getHostForNode
    static def exceptionHandler
    static def queueHandler
    static def xpoolUpdate
    static def jenkinsPageUpdate

    static def slaveHostsList = ["BALINS","JNODES"] // This is used in getJnode and CreateSlaveInjenkins

    static def initClass(classes, info) {
        def classArray = classes
        printHandler = classArray.get('PrintHandler')
        jenkinsEnv = classArray.get('JenkinsEnv')
        getHostForNode = classArray.get('QueueManagement.GetHostForNode')
        queueHandler = classArray.get('QueueManagement.QueueHandler')
        xpoolUpdate = classArray.get('QueueManagement.XpoolUpdate')
        exceptionHandler = classArray.get("ExceptionHandler")
        jenkinsPageUpdate = classArray.get("JenkinsPageUpdate")
        printHandler.printEmphasizeLog("initClass SetCheckLabels")
        this.jenkins_info = info
    }

    static def setNodeOnline(node, node_name) {

        printHandler.printInfo("Setting Node ${node_name} Online if needed ...")
        if (node.getComputer().isOffline() || node.getComputer().isTemporarilyOffline()) {
            node.getComputer().setTemporarilyOffline(true)
            sleep(1000)
            node.getComputer().setTemporarilyOffline(false)
            node.getComputer().connect(true)
            node.getComputer().cliOnline()
        } else {
            printHandler.printInfo("${node_name} is already online - no processing.")
        }
    }

    static def internalMain(jenkins_info) {
        return setCheckLabels(jenkins_info.get('workarea'))
    }

    static def getCurrentBuildOnNode(node, node_name, slave_label) {
        def ts_id = slave_label.split('_')[0]
        def unique_id = slave_label.split('_')[1]
        def computer = node.getComputer()
        def build_name = ""
        printHandler.printBoxLog("Checking Node ${node_name} for build with ${slave_label}")
        computer.getBuilds().limit(5).each {
            build ->
                try {
                    build.getActions(ParametersAction).findAll {
                        it.getParameter("TS_Id")
                    }.each { act ->
                        if (build_name == "") {
                            printHandler.printLog("Checking Build: " + build.toString())
                            try {
                                def act_ts_id = act.getParameter("TS_Id").getValue()
                                def act_unique_id = act.getParameter("Job_UniqueID").getValue()
                                printHandler.printLog(" TS_Id - ${act_ts_id}, UniqueId - ${act_unique_id}")
                                if (act_ts_id == ts_id && act_unique_id == unique_id) {
                                    build_name = build.toString().replace('#', '/ ').replace(' ', ' ')
                                }
                            } catch (Exception action) {
                                printHandler.printLog("Skipping build " + build.toString() + " because of " + action.toString())
                            }
                        }
                    }
                } catch (Exception b) {
                    printHandler.printLog("Skipping build " + build.toString() + "because on getActions " + b.toString())
                }
        }
        printHandler.printBoxLog("${node_name}, ${slave_label}, return build: ${build_name}")
        return build_name
    }

    static def oldgetCurrentBuildOnNode(node, node_name, slave_label) {


        def isUsable = node.getComputer().isAcceptingTasks()
        def isIdle = node.getComputer().isIdle()

        def build = null

        printHandler.printLog('Checking node ' + node_name)
        printHandler.printLog("isUsable state for ${node_name}: " + isUsable)
        printHandler.printLog("isIdle state for ${node_name}:" + isUsable)

        if (isUsable) {
            def computer = node.getComputer()
            def builds = computer.getBuilds()
            if (builds && !isIdle) {
                build = builds.getLastBuild().toString().replace('#', '/ ').replace(' ', ' ')
            }
            def executor = null
            def executors = computer.getExecutors()
            if (executors) {
                executors.each { e ->
                    def executable = e.getCurrentExecutable()
                    if (executable && !executor) {
                        executable.each {
                            executor = it.toString()
                        }

                    }
                }
            }
            if (executor) {
                def buildString = null
                if (executor =~ /runId=/) {
                    buildString = executor.split(/runId=/)[1].split(/,/)[0].replace('/', '/job/').replace('#', '/')
                } else {
                    buildString = executor.replace('#', '/ ').replace(' ', ' ')
                }
                build = buildString
            }
        }
        return build
    }

    static def isQueueOccupied(nodeList) {
        def list = []
        printHandler.printInfo("Checking occupation of Queue ...")
        nodeList.each { nodename, n_entry ->
            //   printHandler.printBlueInfo("NODENAME: ${nodename}")
            //     printHandler.printBlueInfo(n_entry)
            def tsId = n_entry.get('tsetID')
            def uId = n_entry.get('uniqueID')
            list.add(sprintf("%s:%s", tsId, uId))
        }


        def foundlist = queueHandler.getQueueInfo('', '', '', list)
        //printHandler.printBox("Current count still in queue - " + foundlist.size().toString())

        return foundlist.size() > 0
    }

    static def setCheckLabels(workspace) {

        def infoFile = sprintf("%s/%s", workspace, "collector.dat")
        def infolines
        def status = 0

        printHandler.printInfo("Executing setCheckLabels() ....")
        printHandler.printRedInfo("File name is " + infoFile)
        try {
            infolines = new File(infoFile).readLines()
        } catch (FileNotFoundException exception) {
            printHandler.notify("No file to process!!!")
            return 0
        } catch (Exception e) {
            printHandler.printError("setCheckLabels Unknown Error" + e.toString())
            if (exceptionHandler) {
                exceptionHandler.printExceptionStack(e)
            }
            return 1
        }


        def xpoolReleaseFile = sprintf('%s/%s', workspace, "releaseList.dat")
        def summaryFile = sprintf('%s/%s', workspace, "nodeSummaries.dat")

        def outfd = null
        def failedlist = [:]
        def nodenames = [:]

        infolines.each { infoLine ->
            def tmp_list = infoLine.split(':-:')
            def nodename = tmp_list[0]
            def testset = tmp_list[1]
            def uniqueid = tmp_list[2]
            def username = tmp_list[3]
            nodenames.put(nodename, [:])
            nodenames.get(nodename).put('slave_label', testset + '_' + uniqueid)
            nodenames.get(nodename).put('username', username)
        }

        def try_count = 0
        def sleep_time_string = jenkinsEnv.getenv("Check_Sleep_Time") ?: "10"
        def sleep_time = sleep_time_string.toInteger()
        def max_try_count_string = jenkinsEnv.getenv("Check_Count") ?: "30"
        def max_try_count = max_try_count_string.toInteger()
        def buildCount = 0
        def delay_time_str = jenkinsEnv.getenv("DELAY_TIME") ?: "0"
        def delay_time = delay_time_str.toInteger()
        def online_list = [:]
        try {
            printHandler.printBox("Setting nodes online if needed ...")
            def instance = jenkins_info.get('j_instance')
            nodenames.each { nodename, n_info ->
                def node = instance.getNode(nodename)
                if (!node) {
                    createSlaveInJenkins(nodename, workspace)
                    node = instance.getNode(nodename)
                }
                setNodeOnline(node, nodename)
                online_list.put(nodename, node)
            }
            online_list.each { name, node ->
                nodenames.get(name).put('node', node)
            }
        } catch (Exception o) {
            printHandler.printError("Could not set nodes online exiting!!!" + o.toString())
            if (exceptionHandler) {
                exceptionHandler.printExceptionStack(o)
            }
            return 1
        }


        if (delay_time) {
            printHandler.printBox("Sleeping ${delay_time} seconds after online process")
            sleep(delay_time * 1000)
        }

        def currentBuildingClusters = [:]
        def nodeList = [:]
        def nodeListSize = 0
        def threads = []
        def nodesToProcessCount = nodenames.size()
        def threadCount = 0
        def labels_set = 0
        printHandler.printBoxColor("Start of Slave Labeling with threads...", "GREEN")
        try {
            nodenames.each { node_name, node_info ->

                def thread = new Thread({
                    def slave_label = node_info.get('slave_label')
                    def node = node_info.get('node')
                    threadCount += 1
                    def threadString = "Thread No. " + threadCount.toString()
                    printHandler.printGreenInfo("${threadString} Processing ${node_name}:")
                    printHandler.printInfo("${threadString}   node_name   = " + node_name)
                    printHandler.printInfo("${threadString}   slave_label = " + slave_label)

                    // These are set first for use below whether we can get a node or not
                    def nodeStruct = [:]

                    nodeStruct.put('build', '')

                    if (node) {

                        def current_label = node.getLabelString()
                        nodeStruct.put('slave_label', slave_label)
                        nodeStruct.put('node', node)
                        nodeStruct.put('current_label', current_label)
                        nodeStruct.put('tsetID', slave_label.split('_')[0])
                        nodeStruct.put('uniqueID', slave_label.split('_')[1])
                        nodeStruct.put('username', node_info.get('username'))

                        def newlabel = [current_label, slave_label].sort().join(' ')
                        def qp = queueHandler.get_queue_pointer()

                        printHandler.printBox("${threadString} - waiting for lock to set label ...")
                        qp._withLock({
                            printHandler.printInfo("${threadString} Adding label " + slave_label + " to node " + node_name)
                            node.setLabelString(newlabel)
                            printHandler.printInfo("${threadString} - Saving node after labelling ...")
                            node.save()
                            printHandler.printInfo("${threadString} - Node Saved.")
                            labels_set += 1
                            printHandler.printGreenInfo("${threadString} amount of labels set ${labels_set}/${nodesToProcessCount}")
                            printHandler.printInfo("${threadString} Modified Label " + node.getLabelString())
                            printHandler.printBlueInfo("${threadString} Checking if build started after 2 seconds ...")
                            sleep(2000)
                            def build = getCurrentBuildOnNode(node, node_name, nodeStruct.get('slave_label'))
                            if (build) {
                                nodeStruct.put('build', build)
                                currentBuildingClusters.put(node_name, build)
                                printHandler.printGreenInfo("${threadString} Restoring label for ${node_name} because ${build} (taken first round)")
                                node.setLabelString(current_label)
                                node.save()
                                buildCount += 1
                            }
                        })
                        printHandler.printBox("${threadString} - label set and lock released")

                    }
                    nodeList.put(node_name, nodeStruct)
                }
                )
                thread.start()
                threads.add(thread)
            }
            threads.each { it.join() }
            printHandler.printBoxColor("Threads completed", "GREEN")
            nodeListSize = nodeList.size()
            def pre_sleep = nodeListSize * 3
            printHandler.printBlueInfo("Current Node List Size " + nodeListSize)
            printHandler.printUnderline("Waiting ${pre_sleep} seconds before checking queue ....")
            sleep(pre_sleep * 1000)
            printHandler.printEmphasizeColor("Executing Maintain Call", "PURPLE")
            def qpointer = queueHandler.get_queue_pointer()
            qpointer.maintain()
            printHandler.printEmphasizeColor("Maintain Call completed", "PURPLE")
            def queueOccupied = true
            def queueOccupiedCount = 0
            def queueOccupiedMax = 5
            // printHandler.printUnderline("Calling Queue Maintain before querying queue ....")
            //  q_pointer.maintain()
            while ((try_count++ < max_try_count) && (buildCount < nodeListSize) && queueOccupied) {
                printHandler.printInfo("Sleeping ${sleep_time} seconds ....")

                sleep(sleep_time * 1000)

                printHandler.printBlueInfo("Checking/Status of nodes that might have been taken try ${try_count}/${max_try_count} current build found count ${buildCount}/${nodeListSize}")
                nodeList.each { node_name, n_entry ->
                    if (n_entry['build'] != '') {
                        currentBuildingClusters.put(node_name, n_entry['build'])
                        def current_label = n_entry['current_label']
                        def node = n_entry['node']
                        if (node && node.getLabelString() != current_label) {
                            printHandler.printGreenInfo("restoring label ${current_label} to ${node_name} build found!")
                            node.setLabelString(current_label)
                            printHandler.printGreenInfo("Saving node after relabelling ...")
                            node.save()
                            printHandler.printGreenInfo("Node Saved.")

                        }
                    } else {
                        def node = n_entry['node']
                        if (node) {
                            def build = getCurrentBuildOnNode(node, node_name, n_entry['slave_label'])
                            if (build) {
                                nodeList[node_name].put('build', build)
                                printHandler.printInfo("slave ${node_name} Build Info - " + nodeList[node_name]['build'])
                                def current_label = n_entry['current_label']
                                currentBuildingClusters.put(node_name, n_entry['build'])
                                buildCount = buildCount + 1
                                printHandler.printBlueInfo("restoring label ${current_label} from ${node_name} because it was taken  by a build ...")
                                node.setLabelString(current_label)
                                printHandler.printBlueInfo("Saving node after relabelling ...")
                                node.save()
                                printHandler.printBlueInfo("Node Saved.")

                            }
                        }
                    }
                }
                if (currentBuildingClusters.size() > 0) {
                    printHandler.printBox("List of clusters taken")
                    currentBuildingClusters.each { node, build ->
                        printHandler.printRaw("\t${node} -> ${build}")
                    }
                    printHandler.printUnderline("Current total: " + currentBuildingClusters.size().toString())
                } /*else {
                    def q_pointer = queueHandler.get_queue_pointer()
                    printHandler.printBoxColor("Maintaining queue and checking current queue occupation ...", "PURPLE")
                    q_pointer.maintain()
                }*/
                queueOccupied = isQueueOccupied(nodeList)
                if (!queueOccupied && queueOccupiedCount < queueOccupiedMax) {
                    printHandler.printBlueInfo("Queue is empty - still checking nodes " + queueOccupiedMax - queueOccupiedCount + " times ...")
                    queueOccupied = true
                }
                queueOccupiedCount += 1
            }

            printHandler.printInfo('Summary of requests:')
            def summaryfd = null
            nodeList.each { name, n_entry ->
                def node = n_entry['node']
                def cur_build = n_entry['build']
                def current_label = n_entry['current_label']
                def username = n_entry['username']
                printHandler.printInfo(name + ',' + cur_build)

                if (!cur_build) {
                    status = 1
                    if (node) {
                        printHandler.printPurpleInfo("after processing resetting label to ${current_label} from ${name} (not taken or completed build)  ...")
                        node.setLabelString(current_label)
                        printHandler.printPurpleInfo("Saving node after setting label")
                        node.save()
                        printHandler.printPurpleInfo("Node Saved.")
                    }

                    if (!outfd) {
                        printHandler.printBlueInfo(sprintf("Preparing/writing to %s", xpoolReleaseFile))
                        outfd = new PrintWriter(xpoolReleaseFile)
                        printHandler.logInitFileDescriptor("releaseFile", outfd)
                    }
                    failedlist.put(name, 1)
                    if (outfd) {
                        printHandler.printBlueInfo(sprintf("Adding %s (%s) to %s", name, username, xpoolReleaseFile))
                        def line = "${name}:-:${username}"
                        printHandler.printRaw(line, ["releaseFile"])
                    }
                } else {
                    if (!summaryfd) {
                        printHandler.printBlueInfo(sprintf("Preparing and writing to %s", summaryFile))
                        summaryfd = new PrintWriter(summaryFile)
                        printHandler.logInitFileDescriptor("summaryFile", summaryfd)
                    }
                    xpoolUpdate.xpool_update(name, jenkinsEnv.getenv("JENKINS_URL") + "job/" + cur_build.replace(' ', ''), username)
                    if (summaryfd) {
                        def info = sprintf("%s:-:%s:-:%s", name, cur_build, username)
                        printHandler.printBlueInfo(sprintf("Updating " + summaryFile + " with " + info))
                        printHandler.printRaw(info, ["summaryFile"])
                    }

                }
            }
            printHandler.printBox("Summary of run: Requests processed: " + nodeList.size().toString() + " Failures: " + failedlist.size().toString())
        } catch (Exception e) {
            nodeList.each { node_name, n_entry ->
                printHandler.printError("IN EXCEPTION " + e.toString())
                def node = n_entry['node']
                def m_label = n_entry['current_label']
                if (node) {
                    printHandler.printError("resetting label to ${m_label} for ${node_name} groovy exception!!!! " + e.toString() + " ... ")
                    node.setLabelString(m_label)
                    printHandler.printRedInfo("Saving node after label set")
                    node.save()
                    printHandler.printRedInfo("Node saved.")
                }
                if (n_entry.get('build') == '') {
                    if (!outfd) {
                        printHandler.printBlueInfo(sprintf("Preparing and writing to %s (no build found)", xpoolReleaseFile))
                        outfd = new PrintWriter(xpoolReleaseFile)
                        printHandler.logInitFileDescriptor("releaseFile", outfd)
                    }

                    if (outfd && failedlist.get(node_name)) {
                        def rel_out = sprintf("%s:-:%s", node_name, username)
                        printHandler.printRaw(node_name, ["releaseFile"])
                    }
                }
            }
        }
        checkFiles(xpoolReleaseFile, summaryFile)
        return status

    }

    static def checkFiles(releaseFile, summaryFile) {
        def notified = false
        def manager = jenkins_info.get('buildManager')
        def sfd = new File(summaryFile)
        if (sfd.exists()) {
            def str = "Nodes taken: <br>" + sfd.readLines().join("<br>") + "<br>"
            jenkinsPageUpdate.createMsg(str, manager, "green.gif", "blue")
            notified = true
        }
        def rfd = new File(releaseFile)
        if (rfd.exists()) {
            def str = "Nodes requested to be released: <br>" + rfd.readLines().join("<br>") + "<br>"
            jenkinsPageUpdate.createMsg(str, manager, "red.gif", "red")
            notified = true
        }
        if (!notified) {
            def str = "No nodes proccessed"
            jenkinsPageUpdate.createMsg(str, manager, "info.gif", "green")

        }
    }

    static def inQueue(label) {

        def instance = jenkins_info.get('j_instance')
        def q = instance.queue
        def searchVars = [/.*TS_Id=/, /Job_UniqueID=/]
        def found = false

        try {
            q.getItems().each {
                if (it && found == false) {

                    def line = it.getParams().split(/\n/)
                    def list = []
                    line.sort().each { l ->
                        if (searchVars.any { s -> l =~ s }) {
                            list.add(l.split('='))
                        }
                    }

                    def tID
                    def tmpmap = [:]

                    list.each { l -> tmpmap.put(l[0], l[1]) }
                    if (tmpmap.size()) {
                        tID = tmpmap.get('TS_Id')
                        uID = tmpmap.get('Job_UniqueID')
                        if (sprintf("%s_%s", tID, uID) == label) {
                            found = true
                        }
                    }
                }
            }


        } catch (Exception e) {
            printHandler.printError("Problem checking in Queue Access " + e.toString())
            if (exceptionHandler) {
                exceptionHandler.printExceptionStack(e)
            }
            throw new RuntimeException("[(Queue check ERROR]" + e.getMessage())
        }
        return found
    }


    static def getUserCredentials(description='tridentbuild_user') {
        def cred_user = description
        def return_creds = ''
        def creds = com.cloudbees.plugins.credentials.CredentialsProvider.lookupCredentials(
                    com.cloudbees.plugins.credentials.common.StandardUsernameCredentials.class,
                    jenkins_info.get('j_instance'),
                    null,
                    null
        );
        creds.each { c ->
                if (c.description == cred_user) {
                    return_creds = c.id
                }
            }
        return return_creds
    }

    static def getJnode(xbrick_label, host_name = "") {

        def envVars = jenkinsEnv.getAllEnv()
        def envString
        def list_choice = [:]

        host_name = host_name == "" ? "JNODES" : host_name

        def sites = ['DRM','HPK']

        // slaveHostsList is defined at top of class because it is shared
        // Create a list pointer based on each hostname and site name to add more site
        for (slave_host in slaveHostsList) {
            list_choice.put(slave_host,[])
            for (site in sites) {
                list_choice.get(slave_host).add(slave_host + '_TO_USE_' + site)
            }
        }

        //list_choice.put("BALINS",['BALINS_TO_USE_DRM', 'BALINS_TO_USE_HPK'])
       // list_choice.put("JNODES", ['JNODES_TO_USE_DRM', 'JNODES_TO_USE_HPK'])

         def slave_index = sites.indexOf('DRM') // default value for slave using indexOf in case more sites are added

        // Note right now we only have to indexes drm and hpk but in case we have more the current default is drm

        if (xbrick_label =~ /.*[Dd][Rr][mM].*/) {
           slave_index = sites.indexOf('DRM')
        } else if (xbrick_label =~ /.*[Hh][Pp][Kk].*/) {
            slave_index = sites.indexOf('HPK')
        }

        envString = list_choice.get(host_name)[slave_index]

        def jnodeList = []
        def jlist = envVars.get(envString)
        if (jlist) {
            jnodeList = jlist.split(',')
        }
        def worknode = getHostForNode.get_host_by_weight(jnodeList)

        if (!worknode) {
            Random random = new Random()
            worknode = jnodeList[random.nextInt(jnodeList.size()**1)]
        }
        return worknode
    }

    static def createSlaveInJenkins(xbrick, workspace, host_name = "", description = "") {

        def worknode =  host_name



        printHandler.printBlueInfo(printHandler.emphasize("Creating node $xbrick in Jenkins ...."))

        try {
            def xbrickfile = new File(sprintf("%s/%s.dat", workspace, xbrick))
            def brick_info = [:]


            xbrickfile.eachLine { line ->
                if (line.contains('=')) {
                    def value
                    def l_info = line.split('=')
                    def key = l_info[0]
                    if (l_info.size() == 2) {
                        value = l_info[1].trim()
                    } else {
                        value = "-EMPTY-"
                    }
                    brick_info.put(key, value)
                }
            }


          //  brick_info.put('LGS', brick_info.get('LGS').toLowerCase())
          //  brick_info.put('IPMIS', brick_info.get('NODES').replaceAll('-n', '-i'))
            def lbls = brick_info.get('tags').replaceAll(';', ' ').replaceAll(',', ' ')
            // slaveHostsList is defined at the beginning of the class and also used in getJnode
            if (host_name == "" || slaveHostsList.any{it == host_name}) {
                worknode = getJnode(lbls, host_name)
            }

            if (!worknode) {
                throw new RuntimeException("Couldn't get work node!")

            }

            printHandler.printBox("Using ${worknode} as slave host")

            def List<Entry> env = new ArrayList<Entry>()
            brick_info.each { k, v ->
                env.add(new Entry(k, v))
            }

            def EnvironmentVariablesNodeProperty envPro = new EnvironmentVariablesNodeProperty(env)

            def jenkins_url = jenkinsEnv.getenv('JENKINS_URL')
            if (!jenkins_url) {
                jenkins_url = jenkins_info.get('h_instance').getRootUrl()
            }

            printHandler.printBox("Create slave in jenkins...")
            def remote_fs = jenkins_url.split("://")[-1]
            if (remote_fs.contains(".")) {
                remote_fs = remote_fs.split("\\.")[0]
            } else {
                remote_fs = remote_fs.split(":")[0]
            }

            def userCreds = getUserCredentials(description)
            if (userCreds == '') {
                userCreds = null
            }

            SshHostKeyVerificationStrategy hostKeyVerificationStrategy = new NonVerifyingKeyVerificationStrategy()
            def Slave slave = new DumbSlave(
                    xbrick, "Automatic Creation",
                    "/var/" + remote_fs + "/" + xbrick,
                    "1",
                    Node.Mode.NORMAL,
                    xbrick + " " + lbls,
                    new SSHLauncher(worknode, 22, userCreds,
                            "-Xmx512m -Xms256m",
                            null,
                            null,
                            null,
                            null,
                            null,
                            null,
                            hostKeyVerificationStrategy),
                    //new com.cloudbees.jenkins.plugins.nodesplus.ManualLaunchOnlyRetentionStrategy(),
                    new RetentionStrategy.Always(),
                    new LinkedList()
            )

            slave.getNodeProperties().add(envPro)
            jenkins_info.get('j_instance').addNode(slave)
            //def created_node = jenkins_info.get('j_instance').getNode(xbrick)
            //setNodeOnline(created_node, xbrick)
        } catch (Exception e) {
            printHandler.printError("Error in create brick " + xbrick + "\n\t" + e.toString())
            if (exceptionHandler) {
                exceptionHandler.printExceptionStack(e)
            }
            throw new RuntimeException("[Create Brick Error]" + e.getMessage())

        }

    }

}

import jenkins.model.*


class CreateBrickMainClass {
     def runMethod(info) {

        def library_space = info.get('library_space')
        def output = info.get('output')
        def err = info.get('err')

        info.put('j_instance',Jenkins.getInstance())

        def instance = info.get('j_instance')
        def groovyHome = library_space

        def envMap = info.get('envMap')
        def appdir = "apps/CreateBrick"


// All you need to change are the lines till the next comment


         def lClasses = "apps/CreateBrick/modules/CreateBrick"
         lClasses += ",apps/QueueManagement/modules/SetCheckLabels"
         lClasses += ",apps/CreateBrick/modules/SwitchLauncher"

         def rClasses = "CreateBrick.CreateBrick"

        def appFilePath = new File(CreateBrickMainClass.class.getProtectionDomain().getCodeSource().getLocation().getPath()).toString()
        def appDir = appFilePath.substring(0,appFilePath.lastIndexOf('/'))
        envMap.put('APP_DIR',appDir)
        envMap.put('library_space',library_space)
       // envMap.put('work_area',info.get('workarea'))
        def pythonPathString = sprintf("PYTHONPATH=%s/python:%s/python:%s",appdir,library_space,'${PYTHONPATH}')
        envMap.put('PYTHONPATH',pythonPathString)

        info.put('envMap',envMap)
        info.put('appName',appdir.split('/')[-1])
// Only the lines above have to be changed to run a process

        def loadFile = sprintf("%s/%s", groovyHome, "interfaces/DynamicClassMethod.groovy")


        def File groovyFile
        def Class groovyClass
        def GroovyObject groovyObject
        def groovyFileName = loadFile

        output.println("Loading ${groovyFileName} ...")
        groovyFile = new File(groovyFileName);


        def clazzLoader = Jenkins.getInstance().getPluginManager().uberClassLoader
        groovyClass = new GroovyClassLoader(clazzLoader).parseClass(groovyFile);

        groovyObject = groovyClass.newInstance()
        return groovyObject.runMethod(lClasses,rClasses,info)
    }
}

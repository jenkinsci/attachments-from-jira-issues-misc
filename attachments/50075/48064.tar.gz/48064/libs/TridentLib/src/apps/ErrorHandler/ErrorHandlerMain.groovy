import jenkins.model.*

class ErrorHandlerMainClass {
    def runMethod(info) {

        def buildManager = info.get('buildManager')
        def h_instance = info.get('h_instance')
        def library_space = info.get('library_space')
        def workspace = info.get('workspace')
        def brickName = info.get('brickName')
        def params = info.get('params')
        def output = info.get('output')
        def err = info.get('err')
        if (output == null) {
            output = buildManager.listener.logger
            err = output
            info.put('output', output)
            info.put('err', err)
        }

        def work_area = info.get('workarea')

        info.put('j_instance', Jenkins.getInstance())


        def instance

        def groovyHome = library_space

        if (!instance) {
            try {
                instance = Jenkins.getInstance()
            } catch (Exception e) {
                output.println("instance try no. 1 failed! " + e.toString())
                try {
                    instance = Hudson.instance
                } catch (Exception d) {
                    output.println("instance try no. 2 failed! " + d.toString())
                }
            }

        }
        if (!instance) {
            output.println("STILL NO INSTANCE !!!!")
            throw new RuntimeException("INSTANCE IS STILL NULL!")

        }


        def envMap = info.get('envMap')
        def appsDir = "${groovyHome}/apps"
        def classFile = "${appsDir}/ErrorHandler/datafiles/classList.dat"



        def lClasses_array = []
        try {
            new File(classFile).each {
                lClasses_array.add(it)
            }
        }
        catch (Exception f) {
            output.println("Could not access classList.dat!!! " + f.toString())
        }

// All you need to change are the lines till the next comment

        def lClasses = lClasses_array.join(",")
        def rClasses = "ErrorHandler.PatternHandler"
        if (envMap.get('EXECUTOR_NUMBER') == '-1' && envMap.get('JENKINS_URL').contains("qa")) {
            output.println("Master job ErrorHandler will not run - running MatrixMonitorAndClean  instead ...")
            lClasses = "apps/ErrorHandler/modules/MatrixMonitorAndClean"
          //  lClasses += "apps/SlaveMonitor/modules/SlaveMonitor,apps/QueueManagement/modules/QueueHandler,modules/NodeHandler"
            rClasses = "ErrorHandler.MatrixMonitorAndClean"
        }

// Only the lines above have to be changed to run a process

        def loadFile = sprintf("%s/%s", groovyHome, "interfaces/DynamicClassMethod.groovy")
        info.put('appName','ErrorHandler')


        def File groovyFile
        def Class groovyClass
        def GroovyObject groovyObject
        def groovyFileName = loadFile

        //output.println("Loading ${groovyFileName}")
        groovyFile = new File(groovyFileName);

        def clazzLoader = Jenkins.getInstance().getPluginManager().uberClassLoader
        groovyClass = new GroovyClassLoader(clazzLoader).parseClass(groovyFile);

        groovyObject = groovyClass.newInstance()
        return groovyObject.runMethod(lClasses, rClasses, info)
    }
}

import jenkins.model.*


class ReUseMain {
    def runMethod(info) {
        def output
        def err
        def buildManager = info.get('buildManager')
        def h_instance = info.get('h_instance')
        if (info.get('output') == null) {
            output = buildManager.listener.logger
            err = output
            info.put('output', output)
            info.put('err', err)
        } else {
            output = info.get('output')
            err = info.get('err')
        }


        def library_space = info.get('library_space')
        def workspace = info.get('workarea')
        def brickName = info.get('brickName')
        def params = info.get('params')

        info.put('j_instance', Jenkins.getInstance())


        def instance
        def groovyHome = library_space

        if (!instance) {
            try {
                instance = Jenkins.getInstance()
            } catch (Exception e) {
                output.println("instance try no. 1 failed! " + e.toString())
                try {
                    instance = Hudson.instance
                } catch (Exception d) {
                    output.println("instance try no. 2 failed! " + d.toString())
                }
            }

        }
        if (!instance) {
            output.println("STILL NO INSTANCE !!!!")
            throw new RuntimeException("INSTANCE IS STILL NULL!")

        }


        def QDIR = "apps/QueueManagement"
        def envMap = info.get('envMap')
        envMap.put('QUEUE_HOME', "${groovyHome}/${QDIR}")
        info.put('envMap', envMap)
// All you need to change are the lines till the next comment

        def lClasses = "modules/RunShell,modules/WorkUtils,modules/JenkinsGetBuild,modules/DebugHandler,"
        lClasses += "${QDIR}/modules/QueueHandler,${QDIR}/modules/ReUseBrick,${QDIR}/modules/SetCheckLabels,"
        lClasses += "${QDIR}/modules/GetHostForNode,${QDIR}/modules/XpoolInfo,${QDIR}/modules/XpoolRelease,${QDIR}/modules/XpoolExtend"

        def rClasses = "ReUseBrick"
        info.put('appName',rClasses)

// Only the lines above have to be changed to run a process

        def loadFile = sprintf("%s/%s", groovyHome, "interfaces/DynamicClassMethod.groovy")


        def File groovyFile
        def Class groovyClass
        def GroovyObject groovyObject
        def groovyFileName = loadFile

        output.println("Loading ${groovyFileName}")
        groovyFile = new File(groovyFileName);


        def clazzLoader = Jenkins.getInstance().getPluginManager().uberClassLoader
        groovyClass = new GroovyClassLoader(clazzLoader).parseClass(groovyFile);

        groovyObject = groovyClass.newInstance()
        return groovyObject.runMethod(lClasses, rClasses, info)
    }
}

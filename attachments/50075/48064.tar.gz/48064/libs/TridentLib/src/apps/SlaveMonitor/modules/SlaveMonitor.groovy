class SlaveMonitorClass {


    static def classArray = [:]
    static def printHandler
    static def queueHandler
    static def jenkins_info
    static def j_instance


    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get('PrintHandler')
        queueHandler = classArray.get('QueueManagement.QueueHandler')
        this.jenkins_info = info
        j_instance = info.get('j_instance')
        printHandler.printEmphasizeLog("initClass SlaveMonitor")
    }

    static def internalMain(jenkins_info) {
        def info = [:]
        def all_info = [:]
        def startTime = printHandler.timeStamp()
        printHandler.setVerbose("on")
        info = getSlavesInfo()
        all_info = processHosts(info.get('hosts_info'), info.get('jslaves_info'))
        all_info.put('startTime', startTime)
        all_info.put('hosts_totals', info.get('hosts_totals'))
        removeIdles(info.get('remove_slaves'))
        printInfo(all_info)
        return 0
    }
    static def slaveBaseLabels = [/.*cute-slave-Auto.*/, /.*cute-slave-drm.*/,
                                  /.*jnode-phy.*/, /.*jnode-auto.*/,
                                  /.*Auto.*/, /.*Afif.*/, /.*cute-slave.*/]

    static checkSlave(hName, labelString) {
        def correctName = (hName =~ /.*jnode.*/ || hName =~ /.*jenkins.*/)
        def correctLabel = slaveBaseLabels.any { labelString =~ it }
        // printHandler.printPurpleInfo("CHECKSLAVE: hName = ${hName} label = ${labelString}")
        //   printHandler.printGreenInfo("CHECKSLAVE: correctName = ${correctName} correctLabel = ${correctLabel}")
        return correctName && correctLabel
    }

    static def getSlavesInfo() {
        def hosts = [:]
        def hosts_totals = [:]
        def jslaves = [:]
        def remove_slaves = []
        // First get all the cute-slave-Auto first
        for (slave in j_instance.slaves.findAll {
            checkSlave(it.computer.hostName, it.getLabelString())
        }.sort { it.computer.hostName }) {
            def host = slave.computer.hostName
            def host_dict = ['slave_count': 0, 'total_executors': 0, 'slaves': [], 'total_idles': 0, 'total_busy': 0]
            hosts.put(host, host_dict)
        }
        hosts_totals.put('total_slaves', 0)
        hosts_totals.put('total_executors', 0)
        hosts_totals.put('total_busy', 0)
        hosts_totals.put('total_idles', 0)
        //    hosts.each { k, v ->
        //         printHandler.printRedInfo("HOST:" + k)
        //     }

        // We only will process slaves attached to the host list created above

        j_instance.slaves.sort { it.computer.hostName }.each { slave ->

            def host = slave.computer.hostName
            def h = hosts.get(host)
            def addr = InetAddress.getAllByName(host)
            def jslave = addr.toString()
            def slaveName = slave.computer.getDisplayName()
            //    printHandler.printPurpleInfo(printHandler.emphasize("Before processing - ${slaveName}","(",")",5))
// Don't process the main hosts just sub hosts on each

            if (h && !hosts.any { k, v -> k.startsWith(slaveName) }) {
                def slave_count = h.get('slave_count') + 1
                def is_idle = (!slave.computer.isOffline() && (slave.computer.countBusy() == 0))
                //        printHandler.printGreenInfo("Proccessing Slave " + slave + "Slave Name:" + slaveName)
                //        printHandler.printInfo(printHandler.emphasize("ISOFFLINE = " + slave.computer.isOffline()))
                //         printHandler.printInfo(printHandler.emphasize("COUNTBUSY = " + slave.computer.countBusy().toString()))
                //         printHandler.printRedInfo("IS IDLE = " + is_idle)
                def add_slave = true
                if (is_idle) {
                    def q_entries = queueHandler.getQueueEntriesbyLabel(slaveName)
                    if (q_entries.size() > 0) {
                        printHandler.printInfo("${slaveName} is idle but still has entries in queue")
                    } else {
                        def descInfo = slave.getNodeDescription()
                        if (descInfo =~ /.*Automatic Creation.*/ || descInfo =~ /.*Created by .*SYSTEM.*/) {
                            printHandler.printInfo("Adding idles ${slaveName} to removal list   ")
                            add_slave = false
                            remove_slaves.add(slave)
                        } else {
                            printHandler.printInfo("${slaveName} is idle but was not automatically created")
                        }
                    }

                }
                if (add_slave) {
                    def executor_count = slave.computer.getNumExecutors()
                    def busy_count = slave.computer.countBusy()
                    def idles = executor_count - busy_count
                    def total_executors = h.get('total_executors') + executor_count
                    def total_idles = h.get('total_idles') + idles
                    def total_busy = h.get('total_busy') + busy_count
                    def slave_info = ['name': jslave, 'executors': executor_count, 'busy_count': busy_count, 'idles': idles]

                    // Per host information
                    hosts.get(host).put('slave_count', slave_count)
                    hosts.get(host).put('total_executors', total_executors)
                    hosts.get(host).put('total_idles', total_idles)
                    hosts.get(host).put('total_busy', total_busy)
                    hosts.get(host).get('slaves').add(slave_info)

                    // Global information
                    hosts_totals.put('total_executors', hosts_totals.get('total_executors') + executor_count)
                    hosts_totals.put('total_busy', hosts_totals.get('total_busy') + busy_count)
                    hosts_totals.put('total_slaves', hosts_totals.get('total_slaves') + 1)
                    hosts_totals.put('total_idles', hosts_totals.get('total_idles') + idles)
                    jslaves.put(jslave, executor_count)
                }
            }
        }
        return ['hosts_info': hosts, 'hosts_totals': hosts_totals, 'jslaves_info': jslaves, 'remove_slaves': remove_slaves]
    }

    static def removeIdles(slaves) {
        if (slaves.size() > 0) {
            printHandler.printRedInfo("Removing idle slaves found")
        }
        for (slave in slaves) {
            def slaveName = slave.computer.getDisplayName()
            printHandler.printRedInfo(' Shutting down node and deleting: ' + slaveName + ' ....')
            slave.getComputer().setTemporarilyOffline(true, null);
            slave.getComputer().doDoDelete();
        }
    }

    static def processHosts(hosts, jslaves_info) {
        def minimum_slaves = 20000
        def maximum_slaves = -1
        def maximum_executors = -1
        def minimum_executors = 20000
        def max_slave_hosts = []
        def min_slave_hosts = []
        def max_execs_hosts = []
        def min_execs_hosts = []
        def min_execs_per_slave = 20000
        def max_execs_per_slave = -1
        def max_slave_execs = []
        def min_slave_execs = []

        hosts.each { k, v ->
            def slave_count = v.get('slave_count')
            def executor_count = v.get('total_executors')
            if (slave_count < minimum_slaves) {
                minimum_slaves = slave_count
            }
            if (slave_count > maximum_slaves) {
                maximum_slaves = slave_count
            }
            if (executor_count < minimum_executors) {
                minimum_executors = executor_count
            }
            if (executor_count > maximum_executors) {
                maximum_executors = executor_count
            }
        }

        hosts.each { k, v ->
            def slave_count = v.get('slave_count')
            def executor_count = v.get('total_executors')
            if (minimum_slaves != maximum_slaves) {
                if (slave_count == minimum_slaves) {
                    min_slave_hosts.add(k)
                }

                if (slave_count == maximum_slaves) {
                    max_slave_hosts.add(k)
                }
            }
            if (minimum_executors != maximum_executors) {
                if (executor_count == minimum_executors) {
                    min_execs_hosts.add(k)
                }
                if (executor_count == maximum_executors) {
                    max_execs_hosts.add(k)
                }
            }
        }

        jslaves_info.each { k, v ->
            if (v < min_execs_per_slave) {
                min_execs_per_slave = v
            }
            if (v > max_execs_per_slave) {
                max_execs_per_slave = v
            }
        }
        jslaves_info.each { k, v ->
            if (v == max_execs_per_slave) {
                max_slave_execs.add(k)
            }
            if (v == min_execs_per_slave) {
                min_slave_execs.add(k)
            }
        }


        def ret_info = [:]
        ret_info.put('hosts_info', hosts)
        ret_info.put('jslaves_info', jslaves_info)
        ret_info.put('max_slave_count', maximum_slaves)
        ret_info.put('min_slave_count', minimum_slaves)
        ret_info.put('max_exec_count', maximum_executors)
        ret_info.put('min_exec_count', minimum_executors)
        ret_info.put('max_slaves', max_slave_hosts)
        ret_info.put('min_slaves', min_slave_hosts)
        ret_info.put('max_execs', max_execs_hosts)
        ret_info.put('min_execs', min_execs_hosts)
        ret_info.put('max_execs_per_slave', max_execs_per_slave)
        ret_info.put('min_execs_per_slave', min_execs_per_slave)
        ret_info.put('max_slave_execs', max_slave_execs)
        ret_info.put('min_slaves_execs', min_slave_execs)

        return ret_info
    }


    static def printInfo(info) {

        def hosts = info.get('hosts_info')
        def hosts_totals = info.get('hosts_totals')

        def host_amount = hosts.size()
        def slave_count = hosts_totals.get('total_slaves')
        def executor_count = hosts_totals.get('total_executors')
        def busy_count = hosts_totals.get('total_busy')
        def aver_string
        def slave_average
        def executor_average
        def total_weight_average


        printHandler.printRaw(" ")
        printHandler.printInfo('---------------- Totals -----------------------\n\n')


        printHandler.printInfo("Amount of hosts processed: " + host_amount)
        printHandler.printInfo('Total Slaves found: ' + slave_count)
        printHandler.printInfo('Total Executors found: ' + executor_count)
        printHandler.printInfo('Total Idle Executors found: ' + hosts_totals.get('total_idles'))
        printHandler.printInfo('Total Busy Executors found: ' + hosts_totals.get('total_busy'))
        slave_average = slave_count / host_amount
        executor_average = busy_count / host_amount
        total_weight_average = slave_average + (5 * executor_average)
        aver_string = sprintf('Average Slaves per Host: %3.2f', slave_average)
        printHandler.printInfo(aver_string)
        aver_string = sprintf('Average Busy Executors per Host: %3.2f', executor_average)
        printHandler.printInfo(aver_string)
        aver_string = sprintf('Average Total Weight per Host: %3.2f', total_weight_average)
        printHandler.printInfo(aver_string)
        printHandler.printRaw(" ")
        printHandler.printInfo('--------------- Per Host ------------------------\n\n')

        hosts.each {
            k, v ->
                def total_busy = v.get('total_busy')
                def s_count = v.get('slave_count')
                def weight = s_count + (5 * total_busy)
                def outstr = sprintf('%s Slaves: %d, Executors %d, (Busy: %d + Idles: %d), Weight %d',     \
                          k,
                        s_count,
                        v.get('total_executors'),
                        total_busy,
                        v.get('total_idles'),
                        weight)


                def e_count = v.get('total_executors')
                if (total_weight_average < weight) {
                    printHandler.notify(outstr)
                } else if (s_count > slave_average && e_count > executor_average) {
                    printHandler.printRedInfo(outstr)
                } else if (s_count > slave_average) {
                    printHandler.printYellowInfo(outstr)
                } else if (e_count > executor_average) {
                    printHandler.printPurpleInfo(outstr)
                } else {
                    printHandler.printBlueInfo(outstr)
                }
                printHandler.printRaw(" ")
        }
    }
}

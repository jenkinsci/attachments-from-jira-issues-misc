class AddOnFuncs {

    static def classArray = [:]

    static def jenkinsEnv
    static def printHandler

    static def initClass(classes, info) {
        classArray = classes

        jenkinsEnv = classArray.get("JenkinsEnv")
        printHandler = classArray.get("PrintHandler")
        printHandler.printEmphasizeLog("initClass AddOnFuncs")
    }

    /**
     * this method intended to get p_arg of type list with environement variable name and its expected value.
     *
     **/
    static def checkEnvVarForValue(p_arg) {

        if (p_arg.size() == 2) {

            def envValue = jenkinsEnv.getenv(p_arg[0])

            if (envValue == p_arg[1]) {
                printHandler.printLog("got expected environment variable value " + p_arg[0] + "=" + envValue)
                return true
            } else {
                printHandler.printLog("got unexpected environment variable value " + p_arg[0] + "= [" + envValue + "] expecting [" + p_arg[1] + "]")
            }
        } else {
            printHandler.printError("expecting for 2  args but got: " + p_arg.size())
        }

        return false
    }

}

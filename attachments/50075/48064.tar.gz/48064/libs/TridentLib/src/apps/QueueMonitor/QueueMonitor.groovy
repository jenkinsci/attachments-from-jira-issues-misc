
import com.cloudbees.groovy.cps.NonCPS
import com.cloudbees.hudson.plugins.modeling.impl.jobTemplate.InstanceFromJobTemplate
import com.cloudbees.jenkins.plugins.workflow.*
import hudson.model.*
import jenkins.model.*
import org.jenkinsci.plugins.workflow.actions.LabelAction
import org.jenkinsci.plugins.workflow.actions.WorkspaceAction
import org.jenkinsci.plugins.workflow.cps.nodes.StepNode
import org.jenkinsci.plugins.workflow.graph.FlowGraphWalker
import org.jenkinsci.plugins.workflow.graph.FlowNode
import org.jenkinsci.plugins.workflow.job.*
import org.jenkinsci.plugins.workflow.support.steps.*

class QueueMonitor {

    static int monitorLap = 5000 // milliseconds
    static Set jobParams = ["TS_Id", "Job_UniqueID", "label", "TS_XpoolLabel", "TS_Executors", "label", "TS_Reuse"]
    static String PL_TEMPLATE = "QC_TestTemplate"
    private PrintStream logger
    private boolean verbosed = false
    private Jenkins jenkins
    private Queue queue
    private Map testRuns
    private Map exCount
    private String tsId

    public static enum Status {
        NONE, WAITING, RUNNING, COMPLETED;
    }

    QueueMonitor(PrintStream logger, boolean verbosed = false, String tsId = null) {
        this.tsId = tsId
        this.logger = logger
        this.verbosed = verbosed
        this.jenkins = Jenkins.getInstance()
        this.queue = jenkins.queue
        this.testRuns = [:]
        this.exCount = [:]
    }

    void setVerbose(boolean verbosed) {
        this.verbosed = verbosed
    }

    void verbose(String msg) {
        if (this.verbosed) {
            this.putInfo("DEBUG: $msg")
        }
    }

    void putInfo(String msg) {
        this.logger.println(msg)
    }

    @NonCPS
    Map sorted() {
        return this.testRuns.sort { a, b ->
            a.value["TS_Id"] <=> b.value["TS_Id"] ?: a.value["Job_UniqueID"] <=> b.value["Job_UniqueID"] }
    }

    void report() {
        int count = 0
        String curTS = ""
        this.putInfo((new Date()).format("*** HH:mm:ss ") + "*"*93)
        this.putInfo(String.format("  %-14s : %-14s : %-14s : %-8s : %-9s : %-8s : %s",
                "Job_UniqueID",
                "label",
                "TS_XpoolLabel",
                "TS_Reuse",
                "Status",
                "Node",
                "Started"
        ))
        this.putInfo("*"*106)
        for (r in this.sorted()) {
            if (!r.value.TS_Id.equals(curTS)) {
                this.putInfo(String.format("TS_Id: %s, TS_Executors: %s", r.value.TS_Id, r.value.TS_Executors) +
                        overBooked(r.value, this.exCount.get(r.value.TS_Id, 0)))
                curTS = r.value.TS_Id
            }
            this.putInfo(String.format("  %-14s : %-14s : %-14s : %-8s : %-9s : %-8s : %s",
                    r.value.Job_UniqueID,
                    r.value.label,
                    r.value.TS_XpoolLabel,
                    reuse(r.value["TS_Reuse"]),
                    r.value["Status"].toString(),
                    r.value.get("Node", ""),
                    r.value.get("Started", null) ? r.value.Started.format("YYYY-MM-dd HH:mm:ss") : ""
            ))
        }
        this.putInfo("")
    }

    void runMonitor(int maxNum) {
        int counter = 1
        while (true) {
            this.setData()
            this.report()
            if (++counter > maxNum) break
            sleep(monitorLap)
        }
    }

    void setData() {
        this.testRuns = this.getPendingJobs() << getRunningJobs() << this.getCompletedJobs()
        this.exCount = [:]
        for (r in this.testRuns) {
            this.exCount[r.value.TS_Id] =
                    r.value.Status == Status.RUNNING ? exCount.get(r.value.TS_Id, 0) + 1 : exCount.get(r.value.TS_Id, 0)
        }
    }

    Map getPendingJobs() {
        // putInfo("Reading queue")
        Map m = [:]
        for (item in this.queue.items) {
            def task = item.task
            if (task.getClass().getName().contains(ExecutorStepExecution.getName())) {
                def run = task.runForDisplay()
                ParametersAction pa = run.getAction(ParametersAction.class)
                Map params = getParams(pa.getParameters())
                if (params.keySet().containsAll(jobParams)) {
                    if (!this.tsId || this.tsId == params.TS_Id) {
                        m[task.name] = params
                        m[task.name]["Status"] = Status.WAITING
                    }
                }
            }
        }
        // this.putInfo(m.toString())
        return m
    }

    Map getRunningJobs() {
        // putInfo("Retrieving running jobs")
        Map m = [:]
        for (Computer comp in this.jenkins.getComputers()) {
            for (Executor executor in comp.getExecutors()) {
                def executable = executor.getCurrentExecutable()
                if (executor.isBusy()
                        && comp.getName()
                        && executable.getClass().getName().contains(ExecutorStepExecution.getName())) {
                    def run = executable.getParent().runForDisplay()
                    ParametersAction pa = run.getAction(ParametersAction.class)
                    Map params = getParams(pa.getParameters())
                    if (params.keySet().containsAll(jobParams)) {
                        if (!this.tsId || this.tsId == params.TS_Id) {
                            m[params["name"]] = params
                            m[params["name"]]["Status"] = Status.RUNNING
                            m[params["name"]]["Node"] = comp.getDisplayName()
                            m[params["name"]]["Started"] = run.getTime()
                        }
                    }
                }
            }
        }
        // this.putInfo(m.toString())
        return m
    }

    Map getCompletedJobs() {
        // putInfo("Reading completed jobs")
        Map m = [:]
        InstanceFromJobTemplate instFromTempl = null
        for (WorkflowJob pipeline : jenkins.getAllItems(WorkflowJob.class)) {
            for (Job job : pipeline.getAllJobs()) {
                instFromTempl = InstanceFromJobTemplate.from(job)
                if (instFromTempl != null && instFromTempl.model.name == PL_TEMPLATE) {
                    for (Build build in job.getBuilds()) {
                        // putInfo(">>> ${job.name} ${build.number}")
                        if (build.isBuilding()) continue
                        ParametersAction pa = build.getAction(ParametersAction.class)
                        List<ParameterValue> paramValues = pa.getParameters()
                        Map params = getParams(paramValues)
                        String name = "${job.name}#${build.number}"
                        if (params.keySet().containsAll(jobParams)) {
                            if (!this.tsId || this.tsId == params.TS_Id) {
                                m[name] = params
                                m[name]["Status"] = build.isBuilding() ? Status.RUNNING : Status.COMPLETED
                                m[name]["Node"] = getDeployNode(build)
                                m[name]["Started"] = build.getTime()
                            }
                        }
                    }
                }
            }
        }
        return m
    }

    @NonCPS
    static String getDeployNode(WorkflowRun build) {
        // putInfo("Build number: ${build.number}, ${build.getClass()}")
        FlowGraphWalker walker = new FlowGraphWalker(build.getExecution())
        def nodes = walker.toList().sort { a, b -> a.getId().toInteger() <=> b.getId().toInteger() }
        String nodeName = null
        for (FlowNode n in nodes) {
            // putInfo("${n.getId()}")
            if (n instanceof StepNode) {
                def wsAction = n.getAction(WorkspaceAction)
                def lbAction = n.getAction(LabelAction)
                if (wsAction && wsAction.getNode()) {
                    nodeName = wsAction.getNode()
                } else if (lbAction) {
                    if (lbAction.getDisplayName() =~ /Deploy.*/ && nodeName) {
                        break
                    }
                    nodeName = null
                }
            }
        }
        return nodeName
    }

    Map getTestData() {
        String uid = (new Date()).format("HHmmssSSS")
        return [
                "pipeline_1#1" : [
                        "TS_Id" : "5555",
                        "Job_UniqueID" : uid,
                        "TS_Executors" : 2,
                        "label" : "5555_${uid}",
                        "TS_XpoolLabel" : "single",
                        "Running" : true
                ]
        ]
    }

    Map getParams(String taskString) {
        def params = [:]
        def matcher = taskString =~ /.*runId=([^#]+)#(\d+).*/
        if(matcher.matches()) {
            String name = matcher.group(1)
            int num = matcher.group(2).toInteger()
            try {
                params["name"] = name + "#" + num
                def run = this.jenkins.getItem(name).getBuildByNumber(num)
                def action = run.getAction(ParametersAction)
                for (pname in jobParams) {
                    def p = action.getParameter(pname)
                    if (p) {
                        params[pname] = p.getValue()
                    }
                }
                params["Started"] = run.timestamp.getTime()
            } catch (e) {
                // verbose("ERROR: " + e)
            }
        }
        return params
    }

    Map getParams(List<ParameterValue> paramValues) {
        def params = [:]
        for (ParameterValue p in paramValues) {
            params[p.name] = p.value
        }
        return params
    }

    static String reuse(String r) {
        return r.equals("true") ? "reuse" : ""
    }

    static String overBooked(Map p, int exCounter) {
        return  exCounter > p.TS_Executors.toInteger() ? ", Overbooking: ${exCounter} executors running" : ", Ok"
    }

    static void main(String[] args) {
        PrintStream logger = new PrintStream(System.out)
        QueueMonitor qmonitor = new QueueMonitor(logger, true, null)
        qmonitor.report()
    }

}

def defaultHome
if (manager.envVars['JENKINS_URL'].contains("qa")) {
    defaultHome = "/root/TridentLib/src"
} else {
    defaultHome = "/home/jenkins-dev/TridentLib/src"
}
def groovyHome = manager.envVars['DEBUGTRIDENTGROOVY'] ?: defaultHome
def interfaceDir = "${groovyHome}/interfaces"
def appDir = "${groovyHome}/apps/SlaveMonitor"


def groovyHomes = ['TRIDENTLIBHOME', 'TRIGROOVYHOME', 'TRI_GROOVY_HOME']

groovyHomes.each { k ->
    if (manager.envVars['DEBUGTRIDENTGROOVY'] || !manager.envVars[k]) {
        manager.envVars[k] = groovyHome

    }
}

def obj = evaluate(new File("${interfaceDir}/PostGroovyWrapper.groovy"))
obj.runMethod("${appDir}/SlaveMonitorMain.groovy", manager, groovyHome)

import jenkins.model.*

class SlaveDisconnectClass {


    static def classArray = [:]
    static def printHandler
    static def jenkins_info
    static def jenkinsEnv
    static def j_instance


    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get('PrintHandler')
        jenkinsEnv = classArray.get('JenkinsEnv')
        this.jenkins_info = info
        j_instance = info.get('j_instance')
        printHandler.printEmphasizeLog("initClass SlaveDisconnect")
    }

    static def internalMain(jenkins_info) {

        def startMinute = jenkinsEnv.getenv('DISCONNECT_START')
        def startMinuteInt = 20
        def interval = jenkinsEnv.getenv('DISCONNECT_INTERVAL')
        def intervalInt = 5

        if (startMinute) {
            startMinuteInt = startMinute.toInteger()
        }

        if (interval) {
            intervalInt = interval.toInteger()
        }
        def endMinuteInt = startMinuteInt + intervalInt


        Calendar localCalendar = Calendar.getInstance(TimeZone.getDefault());
        int currentMINUTE = localCalendar.get(Calendar.MINUTE);
        printHandler.printInfo (printHandler.emphasize("Slave Disconnect Process ...."))
        if((currentMINUTE > startMinuteInt) && (currentMINUTE < endMinuteInt)) {

            for (slave in j_instance.slaves) {

                // Make sure slave is online
                if (!slave.getComputer().isOffline() && !slave.name.contains("jslave")) {
                    //Make sure that the slave busy executor number is 0.
                    if (slave.getComputer().countBusy() == 0 && slave.getNodeDescription() == "Automatic Creation") {
                        printHandler.printInfo("***********************************")
                        printHandler.printInfo('----> Disconnecting xbrick node  ' + slave.name);
                        slave.getComputer().setTemporarilyOffline(true, null);
                        slave.getComputer().doDoDisconnect();
                        printHandler.printInfo("***********************************")
                    }
                }

            }
        } else {
            printHandler.printInfo(printHandler.emphasize("Scanning is only performed every hour be the minutes " + startMinuteInt + " and " + endMinuteInt))
            return 0
        }
        return 0
    }
}

class XpoolCollector {

    static def classArray = [:]

    static def jenkinsEnv
    static def runShell
    static def printHandler
    static def jenkins_info
    static def workspace


    static def initClass(classes, info) {
        classArray = classes
        jenkinsEnv = classArray.get('JenkinsEnv')
        runShell = classArray.get('RunShell')
        printHandler = classArray.get('PrintHandler')
        this.jenkins_info = info
        printHandler.printEmphasizeLog("initClass XpoolCollector")
        this.workspace = info.get('workarea')
    }


    static def internalMain(jenkins_info) {
        if (!this.workspace) {
            this.workspace = jenkins_info.get('workarea')
        }
        def python_command = "xpoolCollector.py"
        def python_script = sprintf("%s/python/%s %s %s", jenkinsEnv.getenv("QUEUE_HOME"), python_command, workspace, jenkinsEnv.getenv("TRI_GROOVY_HOME"))
        def output = runShell.runCommand(python_script)
        if (output) {
            output.split('\n').each { it ->
                printHandler.printRaw(it)
            }
        }
        return 0
    }
}

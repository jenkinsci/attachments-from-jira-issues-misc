class XpoolInfo {

    static def classArray = [:]

    static def jenkinsEnv
    static def runShell
    static def printHandler
    static def jenkins_info
    static def exceptionHandler

    static def initClass(classes, info) {
        classArray = classes
        jenkinsEnv = classArray.get('JenkinsEnv')
        runShell = classArray.get('RunShell')
        exceptionHandler = classArray.get("ExceptionHandler")
        printHandler = classArray.get('PrintHandler')
        printHandler.printEmphasizeLog("initClass XpoolInfo")
        this.jenkins_info = info
    }

    static def xpool_info(brick, workspace) {
        def python_command = "xpoolInfo.py"

        def labels = ''
        def labelFile = sprintf("%s/%s", workspace, 'label.dat')
        printHandler.printConsole("[INFO] XpoolInfo: getting Info about brick: " + brick)
        def python_script = sprintf("%s/python/%s %s %s %s", jenkinsEnv.getenv("QUEUE_HOME"), python_command, workspace, brick, jenkinsEnv.getenv("TRI_GROOVY_HOME"))
        def output
        try {
            output = runShell.runCommand(python_script)
        } catch (Exception e) {
            printHandler.printLog("xpoolInfo - caught exception " + e.toString())
            if (exceptionHandler) {
                exceptionHandler.printExceptionStack(e)
            }
        }
        printHandler.printLog(printHandler.emphasize('xpool_info','-','-'))
        if (output) {
            output.split('\n').each { it ->
                printHandler.printLog(it)
            }
            // Note: when calling this script a file called label.dat will be created in the workspace it is used in post groovy to check reuse of the brick
        }

        try {
            def infolines = new File(labelFile).readLines()
            labels = infolines[0]
            return labels
        } catch (FileNotFoundException exception) {
            printHandler.printLog("xpoolInfo - no label.dat file found")
        } catch (Exception e) {
            printHandler.printError("xpoolInfo Unknown Error" + e.toString())
            if (exceptionHandler) {
                exceptionHandler.printExceptionStack(e)
            }
        }
        return labels
    }
}

import groovy.json.JsonSlurper
class JobDeploymentClass {


    static def classArray = [:]
    static def printHandler
    static def jenkinsEnv
    static def sendMail
    static def j_info
    static def queueJobs = [:]

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get('PrintHandler')
        jenkinsEnv = classArray.get('JenkinsEnv')
        sendMail = classArray.get("SendMail")
        j_info = info
    }

    static def internalMain(jenkins_info) {
        printHandler.setVerbose("on")
        printHandler.printInfo("Starting Automatic Job Deployment")
        def jfile = jenkinsEnv.getenv("JOBLISTFILE") ?: "/tmp/joblist.json"
        loadAndDeployJobs(jfile)
        printHandler.printInfo("Automatic Job Deployment Finished")
        return 0
    }

    static def loadFile(filename) {
        def file = new File(filename)
        if (!file.exists() || !file.canRead()) {
            printHandler.printBox("Cannot access ${filename} for reading!!!")
            return null
        } else {
            return file
        }
    }

    static def loadAndDeployJobs(fileName) {
        def object = loadFile(fileName)
        if (!object) {
            sendMail.SendMail('mailhub.lss.emc.com', 'XtremIO QA Jenkins <xtremio-qa-jenkins@emc.com>',
                    "ilan.yosef@emc.com",
                    "Auto Job Deployment Notification",
                    "No jobs created because ${fileName} did not exist")
        } else {
            def data = object.getText()
            def jsonSlurper = new JsonSlurper()
            def jobs = jsonSlurper.parseText(data)
            printHandler.printUnderline("Trying to deploy " + jobs.size().toString() + "job(s)")
            jobs.size().times() {
                deployJob(jobs[it])
            }
        }
    }

    static def getJobForQueue(jobName)
    {
        def job = queueJobs.get(jobName)
        if (!job) {
            job = jenkins.model.Jenkins.instance.getAllItems(hudson.model.Job).findAll{it.getFullName().equals(jobName)}[0]
            queueJobs.put(jobName,job)
        }
        return job
    }
    static def deployJob(job_info) {
        def jobName = job_info.get("JOB_NAME")
        def params = []
        printHandler.printBox("Queueing ${jobName} with parameter(s):")
        def paramList = []
        job_info.each { entry, value ->
            if (entry != "JOB_NAME") {
                params.add(new hudson.model.StringParameterValue(entry, value))
                printHandler.printRaw("\t ${entry} = ${value}")
                paramList.add("${entry}=${value}")
            }
        }
        params.add(new hudson.model.StringParameterValue("AUTODEPLOYMENT", "TRUE"))
        def paramsAction = new hudson.model.ParametersAction(params)
        def cause = new hudson.model.Cause.UserIdCause()
        def causeAction = new hudson.model.CauseAction(cause)
        def job = getJobForQueue(jobName)
        //schedule job with quietPeriod=10 to allow jenkins to clean duplicates from queue
        hudson.model.Hudson.instance.queue.schedule(job, 10, causeAction, paramsAction)
        printHandler.printBox("${jobName} sent to Queue")
        sendMail.sendMail('mailhub.lss.emc.com', 'XtremIO QA Jenkins <xtremio-qa-jenkins@emc.com>',
                "ilan.yosef@emc.com",
                "Auto Job Deployment Notification ${job}",
                "Job ${job} enqueued with the following:\n\t" + paramList.join("\n\t") + "\n")
    }
}

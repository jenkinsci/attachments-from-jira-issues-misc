import groovy.json.JsonSlurper 
class CreateBrickClass {


    static def classArray = [:]
    static def printHandler
    static def jenkinsEnv
    static def slurper = new JsonSlurper()

    static def setCheckLabels
    static def switchLauncher
    static def nodeHandler
    static def xpoolManager

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get('PrintHandler')
        jenkinsEnv = classArray.get('JenkinsEnv')
        setCheckLabels = classArray.get("QueueManagement.SetCheckLabels")
        switchLauncher = classArray.get("CreateBrick.SwitchLauncher")
        nodeHandler = classArray.get("NodeHandler")
        xpoolManager = classArray.get("XpoolManager")

    }

    static def createWorkFile(workdir,xbrick,info) {
        def workingFile = sprintf("%s/%s.dat", workdir, xbrick)
        def fd = new PrintWriter(workingFile)
        printHandler.printUnderline("Writing info to file " + workingFile)
        printHandler.logInitFileDescriptor("brickFile", fd)
        info.each { fname, fvalue ->
            printHandler.printRaw(sprintf("%s=%s\n", fname, fvalue), ["output","brickFile"])
        }
        printHandler.closeLog(printHandler.getLogFd("brickFile"))
        return workingFile
    }

    static def checkForInfoField() {
        def nodeInfo = jenkinsEnv.getenv("NODEINFO")
        def info = [:]
        if (nodeInfo) {
            printHandler.printInfo("Processing NODEINFO " + nodeInfo)
            try {
                def values = slurper.parseText(nodeInfo)
                printHandler.printInfo(values)
                values.each { k, v ->
                    if (v.size() == 0) {
                        v = "None"
                    }
                    printHandler.printInfo("KEY " + k + " VALUE " + v)
                    jenkinsEnv.putenv(k, v)
                    if (k != "uniqueID") {
                        info.put(k, v)
                    }
                }
            } catch (Exception e) {
                printHandler.printConsole("Error parsing NODEINFO " + e.toString())
                return null
            }
        }
        return info
    }

    static def internalMain(jenkins_info) {
        def nodeInfo = checkForInfoField()
        try {
            printHandler.printEmphasizeConsole("NodeInfo is: " + nodeInfo)
            if (nodeInfo && nodeInfo.size() > 0) {
                printHandler.printInfo("CreateBrick")
                def instance = jenkins_info.get('j_instance')
                def uID = "uID_"
                def xbrick = jenkinsEnv.getenv('XBRICK')
                if (xbrick.size() == 0) {
                    xbrick = jenkinsEnv.getenv('xbrick')
                }
                def host_name = jenkinsEnv.getenv('host_name')
                if (!host_name) {
                    host_name = ""
                }
                def description = jenkinsEnv.getenv('description')
                if (!description) {
                    description = "tridentbuild_user"
                }

                def node = instance.getNode(xbrick)
                def workspace = jenkins_info.get('workarea')

                if (node) {
                    printHandler.printBox("Removing existing node ${xbrick} before recreating")
                    nodeHandler.nodeRemove(xbrick)
                }


                def brickFile = createWorkFile(workspace, xbrick, nodeInfo)
                setCheckLabels.createSlaveInJenkins(xbrick, workspace, host_name, description)
                new File(brickFile).delete()
                node = jenkins_info['j_instance'].getNode(xbrick)

                uID = sprintf("%s%s", uID, jenkinsEnv.getenv("uniqueID"))

                def current_label = node.getLabelString()
                def new_label = current_label + " " + uID
                node.setLabelString(new_label)
                node.save()
                setCheckLabels.setNodeOnline(node, xbrick)
                printHandler.printBox("Checking if node is online")
                printHandler.printInfo("Waiting 5 seconds to check ...")
                sleep(5 * 1000)
                def sleepTime = 10
                def sleepCount = 20
                def sleepCounter = 1
                while (sleepCounter <= sleepCount) {
                    if (node.getComputer().isOnline()) {
                        printHandler.printBox("Node is online")
                        return 0
                    }
                    printHandler.printInfo("Sleeping " + sleepTime + " Seconds - try no. " + sleepCounter)
                    sleep(sleepTime * 1000)
                    sleepCounter += 1
                }
                printHandler.printBox("Node is not online -  releasing " + xbrick + " and removing it from Jenkins Database")
                xpoolManager.xpoolRelease(xbrick)
                nodeHandler.nodeRemove(xbrick)
                return 1

            } else {
                printHandler.printError("Error in data received nothing to do ....")
                return 1
            }
        } catch (Exception e) {
            printHandler.printException ("An exception occurred " + e.toString())
            return 1
        }
    }
}

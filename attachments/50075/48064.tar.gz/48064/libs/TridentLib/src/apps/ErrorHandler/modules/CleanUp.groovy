class CleanUp {
    static def classArray = [:]

    static def cycleHandler
    static def jenkinsEnv
    static def printHandler
    static def runShell
    static def jenkins_info
    static def updateJenkins
    static def nodeHandler
    static def nativeReplication
    static def xpoolManager
    static def sendMail
    static def j_instance

    static def initClass(classes, info) {
        classArray = classes
        cycleHandler = classArray.get("ErrorHandler.CycleHandler")
        jenkinsEnv = classArray.get("JenkinsEnv")
        printHandler = classArray.get("PrintHandler")
        runShell = classArray.get("RunShell")
        nodeHandler = classArray.get("NodeHandler")
        updateJenkins = classArray.get("JenkinsPageUpdate")
        nativeReplication = classArray.get("NativeReplication")
        xpoolManager = classArray.get("XpoolManager")
        sendMail = classArray.get("SendMail")
        this.jenkins_info = info
        j_instance = jenkins_info.get('j_instance')
        printHandler.printEmphasizeLog("initClass CleanUp")

    }

    static def cleanupProcess(manager, jenkins_msg, slave_name, is_extended) {

        def clusters = []
        def native_clusters = nativeReplication.getNativeInfoString()
        if (native_clusters != "" ) {
            printHandler.printLog("Under native cluster environment, clusters: ${native_clusters}")
        }
        if (!slave_name) {
            printHandler.printLog("No cleanup to do no slave name to work with")
            return 0
        }

        if (!is_extended && (slave_name.startsWith('xbrick') || native_clusters) ) {

            if (!native_clusters) {
                def b = null
                for (n in ['XBRICK','xbrick','NODE_NAME','node_name']) {
                    if (b == null || !b) {
                        b = manager.envVars[n]
                        if (b == null || !b) {
                            b = jenkinsEnv.getenv(n)
                        }
                    }
                }
                clusters.add(b)
             } else {
                clusters.addAll(native_clusters.split(','))
            }

            printHandler.printLog("Processing clusters: " + clusters.join(","))

            def history_clusters = []
            if (native_clusters) {
                history_clusters.addAll(native_clusters.split(','))
            } else {
                history_clusters.addAll(clusters)
            }

            history_clusters.each {
                c_name ->
                if (!jenkinsEnv.getenv('ISPIPELINE')) {
                    printHandler.printHref("Cluster history: ${c_name}", "http://devlab-srv:8000/history#/${c_name}")
                } else {
                    printHandler.printConsoleColor('Cluster history: ' + ('http://devlab-srv:8000/history#/' + c_name).toURL(), "PURPLE")
                }
            }

            if ((manager.envVars['JENKINS_URL'].contains("qa") || manager.envVars['JENKINS_URL'].
                    startsWith("http://jenkins-rnd-upgrade")) && !jenkinsEnv.getenv('ISPIPELINE') ) {
                printHandler.printConsole("Setting extra build page info .....")
                updateJenkins.setSummaryMsg(jenkins_msg, manager)
                updateJenkins.setPic(manager)
                updateJenkins.setML(manager)
                updateJenkins.setQC(manager)
            }

            if (!jenkinsEnv.getenv("JENKINS_URL").contains("qa")) {
                printHandler.printInfo("Executing CycleHandler")
                cycleHandler.run(manager)
                if (!jenkinsEnv.getenv('ISPIPELINE')) {
                    def slaveLabel = nodeHandler.getNode(slave_name).getLabelString()
                    if (jenkins_info.get('buildResult')== hudson.model.Result.UNSTABLE && (slaveLabel.contains("Gen2") || slaveLabel.contains("Gen3"))) {
                        def leaseCmd = xpoolManager.xpool_command() + ' lease -u xtools -q -m "Unstable_X1_cluster_on_investigation" -c ' + slave_name + ' 48'
                        printHandler.printConsoleColor(leaseCmd)
                        runShell.runCommand(leaseCmd)
                        def sender = jenkinsEnv.getenv("JENKINS_URL").split("//")[1].split(":")[0].split(/\./)[0] + "@dell.com"
                        sendMail.sendMail('mailhub.lss.emc.com', sender, 'ronen.peer@dell.com', slave_name + ' is unstable, requires investigation', 'Please check cluster failure')
                    }
                }
            }

        }
    }
}

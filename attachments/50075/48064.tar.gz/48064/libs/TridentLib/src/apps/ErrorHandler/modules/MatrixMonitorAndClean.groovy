class MatrixMonitorAndClean {
    static def classArray = [:]

    static def jenkinsEnv
    static def printHandler
    static def runShell
    static def jenkins_info
    static def updateJenkins
    static def slaveMonitor
    static def sessionInfo
    static def j_instance
    static def manager

    static def initClass(classes, info) {
        classArray = classes
        jenkinsEnv = classArray.get("JenkinsEnv")
        printHandler = classArray.get("PrintHandler")
        slaveMonitor = classArray.get("SlaveMonitor.SlaveMonitor")
        sessionInfo = classArray.get("ErrorHandler.SessionInfo")
        updateJenkins = classArray.get("JenkinsPageUpdate")
        this.jenkins_info = info
        j_instance = jenkins_info.get('j_instance')
        manager = jenkins_info.get('buildManager')
        printHandler.printEmphasizeLog("initClass MatrixMonitorAndClean")

    }

    static def internalMain(info) {
        matrixMonitor()
    }

    static def matrixMonitor() {
        def url = manager.envVars['BUILD_URL']
        def hurl = manager.envVars['JENKINS_URL']
        def workspace = manager.envVars['WORKSPACE']
        def groovyHome = jenkinsEnv.getenv("TRIDENTLIBHOME") ?: jenkinsEnv.getenv("TRIGROOVYHOME")
        if (groovyHome.size() == 0) {
            if (jenkinsEnv.getenv("JENKINS_URL").contains("qa")) {
                groovyHome = "/root/TridentLib/src"
            } else {
                groovyHome = "/home/jenkins-dev/TridentLib/src"
            }
        }
        def runs = manager.build.getExactRuns()
        def done = false
        printHandler.printConsole("Checking if Matrix children are still running, sleeping 10 seconds ...")
        while (!done) {
            sleep(10000)
            done = true
            for (run in runs) {
                if (run.isBuilding()) {
                    printHandler.printConsole("Matrix children still running, sleeping 10 seconds ...")
                    done = false
                    break
                }
            }
        }
        try {
            printHandler.printConsole("Preparing Matrix Summary Info ....")
            def command = "${groovyHome}/apps/ErrorHandler/python/matrixInfo.py ${url} ${hurl}"
            printHandler.printLog ("Matrix command string is: ${command}")
            def proc = command.execute()
            def output = ""
            proc.waitFor()
            proc.in.eachLine { line -> output += '\n' + line }
            output = output.trim()
            proc.out.close()
            if (proc.exitValue()) {
                printHandler.printConsole("${proc.getErrorStream()}")
                printHandler.printLog(("${proc.getErrorStream()}"))
            } else {
                printHandler.printLog("Python output:\n${output}")
               // manager.createSummary("network.gif").appendText(output, false, false, false, "")
                updateJenkins.createMsg(output,manager,"network.gif","blue")
                new File("/${workspace}/report.HTML").withWriter { it << output }
            }
        } catch (e) {
            printHandler.printError("error in creating report.html")
            return 1
        }
        printHandler.printConsole("Executing Slave Monitor ....")
        slaveMonitor.internalMain()
        printHandler.printConsole("Processing finished.")
        return 0
    }
}

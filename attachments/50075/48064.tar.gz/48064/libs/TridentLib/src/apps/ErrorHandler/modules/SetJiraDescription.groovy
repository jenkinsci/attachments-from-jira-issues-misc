class SetJiraDescription {

    static def classArray = [:]
    static def printHandler
    static def jenkins_info

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get("PrintHandler")
        printHandler.printEmphasizeLog("initClass SetJiraDescription")
        this.jenkins_info = info
    }

    static def setJiraUrls(output, build_url) {
        printHandler.printLog("[INFO] -- Preparing jira Urls for " + build_url)
        def job = hudson.model.Hudson.instance.getJob("setJiraUrls")
        def params = []
        def param = new hudson.model.StringParameterValue('ConsoleUrl', "${build_url}/console")
        params[0] = param
        def paramsAction = new hudson.model.ParametersAction(params)
        def cause = new hudson.model.Cause.UserIdCause()
        def causeAction = new hudson.model.CauseAction(cause)
        hudson.model.Hudson.instance.queue.schedule(job, 0, causeAction, paramsAction)
    }
}

import hudson.plugins.sshslaves.*
import hudson.plugins.sshslaves.verifiers.*
import hudson.slaves.*

class SwitchLauncher  {
    static def classArray = [:]
    static def printHandler

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get('PrintHandler')
    }

    static def switchLauncher(slavename, host) {

        def slave = hudson.model.Hudson.instance.getSlave(slavename)
        def launcher = slave.getLauncher()

        if (launcher.getHost() == host) {
            printHandler.printInfo(sprintf("%s's host already set", slavename))
            return true
        }
        printHandler.printInfo(sprintf("Changing %s's host to %s ....", slavename, host))
        def jdkinstaller = new hudson.tools.JDKInstaller("dummy", true)

        def newlauncher = new SSHLauncher(
                host,
                (int) 22,
                launcher.getCredentialsId(),
                launcher.getJvmOptions(),
                launcher.getJavaPath(),
                jdkinstaller,
                launcher.getPrefixStartSlaveCmd(),
                launcher.getSuffixStartSlaveCmd(),
                launcher.getRetryWaitTime(),
                launcher.getMaxNumRetries(),
                launcher.getRetryWaitTime(),
                launcher.getSshHostKeyVerificationStrategy()
        )
        def computer = slave.getComputer()
        computer.cliOffline("Trying to change host ...")
        slave.setLauncher(newlauncher)
        computer.cliOnline()
        computer.connect(true)
        return true
    }
}
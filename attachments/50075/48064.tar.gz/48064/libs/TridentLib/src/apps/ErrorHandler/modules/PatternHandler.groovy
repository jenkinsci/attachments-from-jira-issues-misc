class PatternHandler {

    static def classArray = [:]
    static def fArray = [:]
    enum TriggType {
        PATTERN, FUNCTION
    }
    static def totalPatterns = 0
    static def cleanUp
    static def debugHandler
    static def DynamicFuncClassHolder
    static def jenkinsEnv
    static def jenkinsGetBuild
    static def jenkins_info
    static def logHandler
    static def logSearch
    static def nativeReplication
    static def nativeReplicationXpool
    static def nodeHandler
    static def printHandler
    static def QAReuse
    static def reUseApi
    static def sessionInfo
    static def switchFuncs
    static def trackingCluster
    static def updateJenkins
    static def xpoolManager

    static def initClass(classes, info) {
        this.jenkins_info = info
        classArray = classes
        fArray = classes
        cleanUp = classArray.get("ErrorHandler.CleanUp")
        debugHandler = classArray.get("DebugHandler")
        jenkinsEnv = classArray.get("JenkinsEnv")
        jenkinsGetBuild = classArray.get("JenkinsGetBuild")
        printHandler = classArray.get("PrintHandler")
        sessionInfo = classArray.get("ErrorHandler.SessionInfo")
        switchFuncs = classArray.get("ErrorHandler.SwitchFuncs")
        trackingCluster = classArray.get("ErrorHandler.TrackingCluster")
        reUseApi = classArray.get('QueueManagement.ReUseBrick')
        xpoolManager = classArray.get("XpoolManager")
        nativeReplication = classArray.get("NativeReplication")
        nativeReplicationXpool = classArray.get("NativeReplicationXpool")
        QAReuse = classArray.get("ErrorHandler.QAReuse")
        updateJenkins = classArray.get("JenkinsPageUpdate")
        logSearch = classArray.get("LogSearch")
        logHandler = classArray.get("LogHandler")
        nodeHandler = classArray.get("NodeHandler")
        printHandler.printEmphasizeLog("initClass PatternHandler")


    }

    static class topicDict {
        def String topic
        def int line_no
        def patterns = []
        def actions = []
    }

    static discernSlave(){
        printHandler.printBoxLog("Discerning slave name ...")
        if (! sessionInfo.getJenkinsEntry("slave_name")) {
            jenkinsEnv.putenv("slave_name", jenkins_info.get("brickName"))
            printHandler.printBoxLog('brickName = ' + jenkinsEnv.getenv("slave_name"))
            if (!jenkinsEnv.getenv ("slave_name")) {
                jenkinsEnv.putenv("slave_name", jenkinsEnv.getenv("CLUSTER_NAME"))
                printHandler.printBoxLog('CLUSTER_NAME = ' + jenkinsEnv.getenv("slave_name"))
            }

            if (!jenkinsEnv.getenv ("slave_name")) {
                jenkinsEnv.putenv("slave_name", jenkinsEnv.getenv("NODE_NAME"))
                printHandler.printBoxLog('NODENAME = ' + jenkinsEnv.getenv("slave_name"))
            }

            if (!jenkinsEnv.getenv ("slave_name")) {
                jenkinsEnv.putenv("slave_name", jenkinsEnv.getenv("XBRICK"))
                printHandler.printBoxLog('XBRICK = ' + jenkinsEnv.getenv("slave_name"))
            }
            if (!jenkinsEnv.getenv ("slave_name")) {
                jenkinsEnv.putenv("slave_name", jenkinsEnv.getenv("xbrick"))
                printHandler.printBoxLog('xbrick = ' + jenkinsEnv.getenv("slave_name"))
            }
            if (jenkinsEnv.getenv("slave_name") == "master") {
                jenkinsEnv.putenv("slave_name",null)
            }
            sessionInfo.setJenkinsEntry("slave_name", jenkinsEnv.getenv("slave_name"))
            printHandler.printBoxLog("SLAVENAME is " + sessionInfo.getJenkinsEntry('slave_name'))
        }

    }
    static def String[] loadPatternFile(filename) {
        def groovyHome = jenkinsEnv.getenv("TRIDENTLIBHOME") ?: jenkinsEnv.getenv("TRI_GROOVY_HOME")
        if (groovyHome.size() == 0) {
            if (jenkinsEnv.getenv("JENKINS_URL").contains("qa")) {
                groovyHome = "/root/TridentLib/src"
            } else {
                groovyHome = "/home/jenkins-dev/TridentLib/src"
            }
        }
        def String dataFilesDir = "${groovyHome}/apps/ErrorHandler/datafiles"
        def pattern_file = dataFilesDir + "/" + filename
        if (filename.startsWith("/") || filename.startsWith(".")) {
            pattern_file = filename
        }
        File file = new File(pattern_file)
        printHandler.printLog(printHandler.emphasize("Loading pattern file: " + pattern_file, " >", "< ", 4))
        def lines = file.readLines()
        return lines
    }

    static def processLog(tDict, brickname, found = false, actionFound = false) {

        def cur_topic
        def cur_actions = []

        def topics = tDict["topics"]
        def cur_pattern = ""
        def topic_idx
        def pattern_findings = []
        def curbrickname = "" // this was added for EXPANSIVE_SEARCH
        def patterns_searched = 0

        for (topic_idx = 0; topic_idx < topics.size(); topic_idx++) {
            def t = topics[topic_idx]
            if (!found) {
                printHandler.printLogVerbose("Processing log for topic: " + t.topic + "($brickname)")
                cur_topic = t
                t.patterns.each { pfd ->
                    patterns_searched += 1
                    if (patterns_searched % 100 == 0) {
                        def counter = patterns_searched.toString()
                        printHandler.printInfo("Number of patterns searched: ${counter} ")
                    }
                    if (!found) {
                        if (pfd['type'] == TriggType.PATTERN) {
                            def p = pfd['data']
                            printHandler.printLog("Checking Pattern: " + p)
                            //   printHandler.printLog("CURRENT FINDINGS")
                            if (t.topic == "EXPANSIVE_SEARCH" || t.topic.endsWith('_ES')) {
                                curbrickname = ""
                            } else {
                                curbrickname = brickname
                            }
                            if (jenkinsEnv.getenv("ISPIPELINE")) {
                                pattern_findings = expressionInLogPipeline(p, curbrickname)
                            } else {
                                pattern_findings = expressionInLog(p, curbrickname)
                            }
                            pattern_findings.each {
                                it.each { k, v ->
                                    printHandler.printDebug("Key is: " + k + "Value is: " + v)
                                }
                            }
                            def is_deadbeef = pattern_findings.any { f -> f.get("match") =~ /DEADBEEF/ }
                            found = !is_deadbeef
                            cur_pattern = p
                        } else if (pfd['type'] == TriggType.FUNCTION) {
                            def func = pfd['data']
                            def functionCommandList = func.split(',')
                            if (functionCommandList.size() >= 2 && functionCommandList[0].trim() != functionCommandList[1].trim()) {
                                DynamicFuncClassHolder = fArray.get(functionCommandList[0])

                                if (functionCommandList.size() > 2) {
                                    printHandler.printDebug("Function detected case more than 2")
                                    found = DynamicFuncClassHolder."${functionCommandList[1]}"(functionCommandList[(2..functionCommandList.size() - 1)])
                                } else {
                                    printHandler.printDebug("Function detected case less than 2")
                                    found = DynamicFuncClassHolder."${functionCommandList[1]}"()
                                }

                                if (found) {
                                    def Funcfinding = [:]
                                    Funcfinding.put("pattern", functionCommandList[1])
                                    Funcfinding.put("match", "${functionCommandList[1]}(${functionCommandList[(2..functionCommandList.size() - 1)]})")
                                    pattern_findings.add(Funcfinding)
                                }
                            }
                        }
                    }
                }

                def actobj = [:]
                def afound = ""
                def pfound = ""
                def summary_string = "pattern trigger: "
                if (found) {
                    printHandler.printBox("Processing found action:", "=", "+", ["logger"])
                    pattern_findings.each { f ->
                        pfound += "Pattern: " + f.get("pattern") + " Match: " + f.get("match") + "\n\t"
                        summary_string += f.get("match") + " , "
                    }
                    summary_string += "\naction trigger: "
                    printHandler.printLog("Error Handling was triggered by: " + pfound)
                }

                cur_topic.actions.each { a ->
                    if (!actionFound && found) {
                        printHandler.printLog("	Checking action pattern: " + a.get("pattern"))
                        if (a.get("pattern").trim() != ".*") {
                            def findings
                            if (jenkinsEnv.getenv("ISPIPELINE")) {
                                findings = expressionInLogPipeline(a.get("pattern"), curbrickname)
                            } else {
                                findings = expressionInLog(a.get("pattern"), curbrickname)
                            }
                            def is_deadbeef = findings.any { f -> f.get("match") =~ /DEADBEEF/ }
                            printHandler.printDebug("	\nChecking action pattern: " + a.get("pattern") + " AND DEADBEEF IS: " + is_deadbeef)
                            if (!is_deadbeef) {
                                findings.each { f ->
                                    afound += "Pattern: " + f.get("pattern") + " Match: " + f.get("match")
                                    summary_string += f.get("match") + " , "
                                }
                            }
                        } else {
                            afound += "Pattern: .* + Match: .*"
                            summary_string += ".* , "
                        }

                        if (afound) {
                            printHandler.printLog("		Action Pattern is: " + afound)
                            a.put("pattern_found", cur_pattern)
                            a.put("string_found", summary_string)
                            actobj.put(cur_topic.topic, a)
                            cur_actions.add(actobj)
                            if (a.get("exit") == "yes") {
                                actionFound = true
                                found = true
                            } else {
                                found = false
                            }
                        }
                    } // if !action_found
                } // cur_topics.actions.each
            } // !found
        } // for topic_idx
        return (cur_actions)
    } // processLog


    static def createActionObject(action) {

        def actobj = [:]
        def fields = action.split("::")
        fields.each { f ->
            def String[] subfields = f.split("->")
            def String field = subfields[0].trim()
            def String value = subfields[1].trim()
            actobj.put(field, value)
        }
        actobj.put("pattern_found", "")
        actobj.put("string_found", "")
        return actobj
    }

    static def checkTopicObject(cur_obj) {
        def message_header = "Topic " + cur_obj.topic + " Start line: " + cur_obj.line_no + " "
        def message = ""
        if (cur_obj.patterns.size() == 0) {
            message = message_header + "Has no patterns or functions"
        } else if (cur_obj.actions.size() == 0) {
            message = message_header + "Has no actions"
        } else {
            def all_errors = []
            cur_obj.actions.each { act ->
                def errors = switchFuncs.checkActions(act.get("actions"))
                if (errors.size() > 0) {
                    def err_string = errors.join(",")
                    all_errors.add("action pattern " + act.get("pattern") + " invalid functions " + err_string)
                }
            }
            if (all_errors.size() > 0) {
                message = message_header + "Invalid functions!!!\n" + all_errors.join("\n")
            }
        }
        return (message)
    }

    static def createTopicObject(topic, start_line, lines) {
        def function = /^Function::.+/
        def pattern = /^Pattern::.+/
        def actions = /^Actions::\s*pattern\s*->\s*\S+.*::\s*jenkinsinfo\s*->\s*\S+.*::\s*actions\s*->\s*\S+\s*::\s*exit\s*->\s*\S+\s*::\s*nodeinfo\s*->\s*\S+.*/

        def cur_obj = new topicDict()

        cur_obj.topic = topic
        cur_obj.patterns = []
        cur_obj.actions = []
        cur_obj.line_no = start_line

        def relative_line = 0
        def lines_count = lines.size()

        printHandler.printDebug("Loading info for topic: " + topic)

        while (relative_line < lines_count) {
            def l = lines[relative_line]

            if (l.matches(function)) {
                def f = l.split('::')[1].trim()
                cur_obj.patterns.add(['type': TriggType.FUNCTION, 'data': f])
                printHandler.printLog("added function [ " + f + " ]")
            } else if (l.matches(pattern)) {
                def p = l.split("::")[1].trim()
                cur_obj.patterns.add(['type': TriggType.PATTERN, 'data': p])
                printHandler.printLog("added pattern [ " + p + " ]")

            } else if (l.matches(actions)) {

                def a = l.replace("Actions::", "")
                def aobj = createActionObject(a)
                cur_obj.actions.add(aobj)

            } else if (l.matches(/^\s*$/) || l.matches(/\s*\/\/.*/)) {
                printHandler.printDebug("Empty line or comment line " + l)
                def x = 1

            } else {
                printHandler.printError("Error on " + (start_line + relative_line) + " >> " + l)
                return (null)
            }
            relative_line++
        }
        totalPatterns += cur_obj.patterns.size() + cur_obj.actions.size()
        return (cur_obj)
    }


    static def parsePatterns(String file) {

        def topic_pattern = /^\[\S+\]/
        def topic_end = /^\[END\]/

        def lines = loadPatternFile(file)
        def line_no = 0
        def line_count = lines.size()

        def topics = []
        def message = ""

        while (line_no < line_count) {

            def l = lines[line_no]

            if (l.matches(topic_pattern) && !l.matches(topic_end)) {
                def start_line = line_no
                def topic = l.replace("]", "").replace("[", "")
                def topic_lines = []

                line_no++
                l = lines[line_no]

                while (!l.matches(topic_end) && line_no < line_count) {
                    topic_lines.add(l)
                    l = lines[line_no++]
                }

                if (line_no == line_count && !l.matches(topic_end)) {
                    printHandler.printError("Error topic " + topic + " (line no. " + start_line + ")Does not have a [END]")
                    return ([])
                } else {
                    def topic_obj = createTopicObject(topic, start_line, topic_lines)
                    if (!topic_obj) {
                        return ([])
                    }
                    message = checkTopicObject(topic_obj)
                    if (message.length()) {
                        printHandler.printError("Error!!!! " + message)
                        throw new RuntimeException("Error: " + message)
                        return ([])
                    }
                    topics.add(topic_obj)
                }
            }
            line_no++
        }
        return (topics)
    }

    static String cleanTextContent(String text) {
        // strips off all non-ASCII characters
        text = text.replaceAll("[^\\x00-\\x7F]", "")

        // erases all the ASCII control characters
        text = text.replaceAll("[\\p{Cntrl}&&[^\r\n\t]]", "")

        // removes non-printable characters from Unicode
        text = text.replaceAll("\\p{C}", "")

        return text.trim();
    }

    static def expressionInLogPipeline(expression, brickname) {
        def exprList = expression.split("&&")
        def search_string = ""
        def found_string = ""
        def findings = []

        exprList.each { it ->
            it = it.trim()
            def is_neg = (it.indexOf("!") == 0)
            if (is_neg) {
                search_string = it.substring(1)
            } else {
                search_string = it
            }
            found_string = ""
            printHandler.printLog("expressionInLogPipeline() Search string:" + search_string)

            found_string = logSearch.searchLog(search_string)
            if (found_string && brickname) {
                if (brickname) {
                    printHandler.printUnderlineLog("Searching again for string ${search_string} with ${brickname} ")
                    search_string = ".*${brickname}${search_string}"
                    found_string = logSearch.searchLog(search_string)
                }
            }
            def finding = [:]
            finding.put("pattern", search_string)
            if (found_string && is_neg) {
                found_string = "DEADBEEF"
            } else {
                if (!found_string) {
                    if (is_neg) {
                        found_string = "Pattern Negative Found"
                    } else {
                        found_string = "DEADBEEF"
                    }
                }
            }
            printHandler.printDebug("Search string match: " + found_string)
            finding.put("match", found_string)
            findings.add(finding)

        }
        return findings
    }


    static def expressionInLog(expression, brickname) {

        def exprList = expression.split("&&")
        def search_string = ""
        def found_string
        def findings = []
        def manager = sessionInfo.getJenkinsEntry("manager")
        def brickexp
        if (brickname) {
            brickexp = ".*${brickname}"
        }
        //    printHandler.printLog ("ExpressionInLog - expression ${expression} - brickname ${brickname}")
        exprList.each { it ->
            it = it.trim()

            def is_neg = (it.indexOf("!") == 0)
            //printHandler.printLog("it = ${it} -> is_neg is ${is_neg}")
            if (is_neg) {
                search_string = it.substring(1)
            } else {
                search_string = it
            }
            //  search_string = search_string.replace('.*', '')
            //  search_string = ".*${search_string}"

            printHandler.printLog("expressionInLog() Search string:" + search_string)
            def search_exp = /${search_string}/
            found_string = logSearch.searchLog(search_exp)
            if (found_string) {
                printHandler.printLog("Search Match found:" + found_string)
                if (found_string.size() > 0) {
                    def found_out = found_string.substring(found_string.indexOf(' ') + 1)
                    if (brickname) {
                        printHandler.printLog("Checking match for ${brickexp} and ${found_out} ")
                        def bricksearch = /${brickexp}${search_string}/
                        found_string = logSearch.searchLog(bricksearch)
                    }
                }
            }

            def finding = [:]
            finding.put("pattern", search_string)
            def orig_string = found_string
            if (found_string && is_neg) {
                found_string = "DEADBEEF"
            } else {
                if (!found_string) {
                    if (is_neg) {
                        found_string = "Pattern Negative Found"
                    } else {
                        found_string = "DEADBEEF"
                    }
                }
            }
            printHandler.printEmphasize("Found String is: ${orig_string} finding value: ${found_string} is_neg: ${is_neg}", ">", "<", 2, ["logger"])
            finding.put("match", found_string)
            findings.add(finding)

        }
        return findings
    }

    static def processSuccess(manager, slave_name, native_brick, actions = "") {
        if (actions == "") {
            printHandler.printLog("No action items found build seems successful - performing release procedure(s) ....")
        } else {
            printHandler.printBoxLog("Only action(s) with 'no exit' option performed, continuing to release ...")
            printHandler.printUnderlineLog("Actions already performed: ${actions}")
        }
        if (jenkinsGetBuild.inDebug()) {
            printHandler.printLog("this was a debug run so no action(s) will be taken")
        } else {
            if (manager.envVars['JENKINS_URL'].contains("qa")) {
                processSuccessQa(manager, slave_name, native_brick, actions)
            } else {
                processSuccessDevLab(manager, slave_name, native_brick, actions)
            }
        }
    }

    static def processSuccessDevLab(manager, slave_name, native_brick, actions) {
        printHandler.printBox("no actionable patterns found leaving cluster as is")
    }

    static def processSuccessQa(manager, slave_name, native_brick, actions) {
        trackingCluster.TrackingClusterProcess(manager, slave_name)
        printHandler.printBox("processSuccessQA - SLAVE NAME ${slave_name}, NATIVE ${native_brick} actions ${actions}")
        def sCluster = manager.envVars['CLUSTER_NAME'] ?: manager.envVars['SPECIFIC_APPLIANCE']
        if (sCluster && sCluster.trim() != "" && sCluster.toUpperCase() != "NONE") {
            def b = native_brick ?: slave_name
            printHandler.printConsoleColor(printHandler.emphasize("Not performing release or reUse check for specific cluster ${b}", '-', '-', 5))
        } else {
            def buildOwner = jenkinsEnv.getenv('BUILD_USER_ID')
            def brickOwner
            def procbrick
            if (native_brick == "") {
                procbrick = slave_name
            } else {
                procbrick = nativeReplication.taggedCluster
            }

            if (native_brick != "") {
                brickOwner = xpoolManager.xpoolGetOwner("", procbrick, false)
            } else {
                brickOwner = xpoolManager.xpoolGetOwner(procbrick, "", false)
            }
            printHandler.printBoxLog("brickOwner = ${brickOwner}, buildOwner = ${buildOwner}")
            if (brickOwner != buildOwner) {
                printHandler.printBoxConsole("Not releasing ${procbrick} because xpool owner (${brickOwner}) is different from build owner (${buildOwner})")
            } else {
                if (native_brick != "") {
                    printHandler.printConsoleColor("QA - No patterns found for this run will release native clusters if needed", "GREEN")
                    nativeReplicationXpool.nativeRelease(native_brick, "No patterns found")
                } else {
                    if (actions != "" || !QAReuse.QAReuse(manager)) {
                        printHandler.printConsoleColor("Performing Release for (no Reuse) " + slave_name)
                        printHandler.printConsoleColor(xpoolManager.xpoolRelease(slave_name))
                    }
                }
            }
        }
    }

    static def getBricksFromLog(manager) {
        def log = manager.build.getLog()
        def flist = []
        log.findAll("xbrick.*-TAG|xbrickdrm[0-9-]+|xbrick[0-9-]+").each { m ->
            if (m.endsWith('-TAG')) {
                flist.add(m)
            } else {
                if (!m.trim().endsWith("-") && m.split("-").size() < 3) {
                    flist.add(m)
                }
            }
        }
        return flist.toSet()
    }

    static def internalMain(info) {

        def manager = info.get('buildManager')
        def set_msg = ""
        def buildResult = info.get('buildResult')

        def returnValue = 0

        sessionInfo.setJenkinsManagerInfo(manager)
        printHandler.printInit()
        if (jenkinsEnv.getenv("VERBOSEPRINT") == "true") {
            printHandler.setVerbose("on")
        }


        // Must come after printHandler initialization

        def current_build
        def groovyHome = jenkinsEnv.getenv("TRIDENTLIBHOME") ?: jenkinsEnv.getenv("TRI_GROOVY_HOME")
        if (groovyHome.size() == 0) {
            if (jenkinsEnv.getenv("JENKINS_URL").contains("qa")) {
                groovyHome = "/root/TridentLib/src"
            } else {
                groovyHome = "/home/jenkins-dev/TridentLib/src"
            }
        }
        def dataFilesDir = "${groovyHome}/apps/ErrorHandler/datafiles"
        def pFile
        if (!jenkinsEnv.getenv("JENKINS_URL").contains("qa")) {
            pFile = "tri_patterns.txt"
        } else {
            pFile = "tri_qapatterns.txt"
        }
        def patternsFile = jenkinsEnv.getenv("TRI_PATTERNS_FILE") ?: "${dataFilesDir}/${pFile}"


        if (!(manager instanceof String || manager instanceof GString)) {

            def jobName = jenkinsEnv.getenv("ErrorHandler_jobName")
            def choice = jenkinsEnv.getenv("ErrorHandler_Choice")
            def build_number = jenkinsEnv.getenv("ErrorHandler_BuildNo")

            if (choice && build_number && jobName) {
                current_build = jenkinsGetBuild.getBuild(jobName, build_number)
                printHandler.printBlueInfo("Proccessing log of job ${jobName} current_build number ${build_number}")
            } else {
                current_build = jenkinsGetBuild.getBuild(manager)
            }

            sessionInfo.setJenkinsBuildInfo(current_build)
            printHandler.printDebug(sessionInfo.getJenkinsBuildInfo())

            def sCluster = manager.envVars['CLUSTER_NAME']

            def storge_server = "http://dossier-drm.xiodrm.lab.emc.com"
            def JENKINS_Master = InetAddress.localHost.hostName
            def BUILD_NUMBER = manager.envVars['BUILD_NUMBER']
            def JOB_BASE_NAME = manager.envVars['JOB_BASE_NAME']
            def JOB_NAME = manager.envVars['JOB_NAME']
            def archive_path = logHandler.getArchivePath()
            def build_artifacts_link
            if (archive_path.find("axis-")) {
                def JOB_PATH_FOLDER = JOB_NAME - JOB_BASE_NAME
                build_artifacts_link = "${storge_server}/${JENKINS_Master}/jobs/${JOB_PATH_FOLDER}builds/${BUILD_NUMBER}/${JOB_BASE_NAME}"

            } else {
                build_artifacts_link = "${storge_server}/${JENKINS_Master}/jobs/${JOB_NAME}/builds/${BUILD_NUMBER}"
            }

            if (JENKINS_Master.startsWith("jenkins-rnd")) {
                updateJenkins.setSummaryMsg_archived("<a href=\"${build_artifacts_link}\" target=\"_blank\">Check The Build Artifacts Here</a>", manager)
            }

            printHandler.printConsole("[INFO] - Build status before processing - " + buildResult)

            if (sCluster && sCluster.trim() != "" && sCluster.toUpperCase() != "NONE") {
                //printHandler.printConsoleColor(printHandler.emphasize("SPECIFIC CLUSTER (${sCluster}) - no proccesing for extend,release or reuse"), "BLUE")
                printHandler.printBox("SPECIFIC CLUSTER (${sCluster}) - no proccessing for extend,release or reuse", "=", "+", ["console"])
                updateJenkins.setSummaryMsg("${sCluster} is a specific cluster - No Processing Done", manager)
                return 0
            }
            discernSlave()

            printHandler.printBoxLog("SLAVE NAME BEFORE CHECK.... " + sessionInfo.getJenkinsEntry("slave_name"))
            if (sessionInfo.getJenkinsEntry("slave_name") == null) {
                if (buildResult == hudson.model.Result.ABORTED) {
                    printHandler.printConsoleColor("[ERROR_INFO] - Status ABORTED and No XBrick variable found, trying to discern from log ....", "RED")
                    def cluster_list = getBricksFromLog(manager)
                    if (cluster_list.size() == 0) {
                        printHandler.printConsoleColor(printHandler.emphasize("[ERROR_INFO] Status ABORTED no xbrick found in log"), "RED")
                        updateJenkins.setSummaryMsg("After ABORT - No xbrick variable defined in the environment or log-  No Processing Done", manager)
                    } else {
                        def is_tag = ""

                        printHandler.printLog("List of clusters found:")
                        for (c in cluster_list) {
                            printHandler.printLog("${c}")
                        }

                        for (c in cluster_list) {
                            if (c.endsWith("-TAG")) {
                                is_tag = c
                            }
                        }

                        if (is_tag.size() > 0) {
                            printHandler.printConsole("[INFO] - Build Aborted Releasing tagged cluster ${is_tag}")
                            printHandler.printConsole(xpoolManager.xpoolRelease("", "", is_tag))
                        } else {
                            cluster_list.each { r_c ->
                                printHandler.printConsole("[INFO] - Build Aborted Released cluster ${r_c}")
                                printHandler.printConsole(xpoolManager.xpoolRelease(r_c, "", ""))

                            }
                        }
                        updateJenkins.setSummaryMsg("Build Aborted clusters released", manager)
                    }
                    return 1
                }
            }

            if (!jenkinsGetBuild.inDebug()) {
                def slave_name = sessionInfo.getJenkinsEntry("slave_name")
                if (slave_name) {
                    if (xpoolManager.xpoolInvestigationStatus(slave_name) == true) {
                        printHandler.printError("Error handling cancelled because " + slave_name + " is already under investigation")
                        return 0
                    }
                }
            }
        } else {
            printHandler.printError("Can only be run under a jenkins post current_build environment")
            return 9999
        }


        printHandler.printConsole("[INFO] - Parsing patterns file: ${patternsFile}")
        def native_bricks = nativeReplication.getNativeInfoList()

        def topics = parsePatterns(patternsFile)
        if (topics.size() == 0) {
            throw new RuntimeException("Problems in parsing ${patternsFile}")
        }

        printHandler.printConsole("[INFO] - ErrorHandler -  Checking log for info ...")
        printHandler.printBoxLog("Max amount of patterns to search - " + totalPatterns.toString())
        def tDict = ["topics": topics]
        def slave_name = sessionInfo.getJenkinsEntry("slave_name")
        native_bricks.each { native_brick ->
            if (native_brick) {
                printHandler.printConsole("[INFO] - Processing cluster ${native_brick} ...")
            }
            def actions_performed = ""
            def action_items = processLog(tDict, native_brick)
            logSearch.printSearchStatstics()
            def action_count = 0
            if (action_items.size()) {
                action_items.each { action ->
                    def a_keys = new ArrayList(action.keySet())
                    def topic = a_keys[0].toString()
                    def act = action.get(topic)
                    def acts = act.get("actions")
                    def jenkins_msg = act.get("jenkinsinfo")
                    if (act.get("exit") == "no") {
                        actions_performed = acts
                        action_count += 1
                    }
                    if (native_brick) {
                        set_msg += "${native_brick} - ${jenkins_msg} \n"
                    } else {
                        set_msg += jenkins_msg + " "
                    }
                    def pattern_info = "Error Category: " + topic + " Jenkins Message: " + jenkins_msg + " Pattern: "
                    pattern_info += act.get("pattern_found") + " / " + act.get("pattern")
                    def offline_info = act.get("nodeinfo")
                    sessionInfo.setSwitchInfo(acts, pattern_info, jenkins_msg, act.get("string_found"), offline_info)
                    if (!jenkinsGetBuild.inDebug()) {
                       returnValue =  switchFuncs.runSwitch(sessionInfo.getJenkinsInfo(), sessionInfo.getSwitchInfo(), native_brick)
                    } else {
                        switchFuncs.runDebug(sessionInfo.getJenkinsInfo(), sessionInfo.getSwitchInfo(), native_brick)
                    }
                }
                // this check it to see if only actions were without exit and no procedure was done for cluster
                if (actions_performed != "" && action_count == action_items.size()) {
                    def extents = jenkinsEnv.getenv("EXTENDED")
                    if (! extents ) {
                        printHandler.printBox("No Extents found")
                        processSuccess(manager, slave_name, native_brick, actions_performed)
                    } else {
                        printHandler.printBox("Handling extents ${extents}")
                        def extend_array = extents.split(":")
                        if (!extend_array.grep(slave_name) && extend_array.grep(native_brick)) {
                            processSuccess(manager, slave_name, native_brick, actions_performed)
                        }
                    }
                }
            } else {
                // this is when no actions were found at all
                printHandler.printBox("processSuccess - ${slave_name}, ${native_brick}")
                processSuccess(manager, slave_name, native_brick, "")
            }
        }

        // Cleanup no matter what
        if (!jenkinsGetBuild.inDebug()) {
            nativeReplicationXpool.performActions(manager)
            cleanUp.cleanupProcess(manager, set_msg, slave_name, switchFuncs.is_extended)
        }
        nodeHandler.nodeRemove(slave_name)
        printHandler.printConsole(printHandler.emphasize("Proccesing finished."))
        return returnValue
    }

}

import hudson.*
import hudson.model.*
import jenkins.*
import jenkins.model.*

class GetHostForNodeClass {

    static def classArray = [:]
    static def printHandler
    static def jenkinsEnv
    static def jenkinsGetBuild
    static def jenkins_info
    static def j_instance


    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get('PrintHandler')
        jenkinsEnv = classArray.get('JenkinsEnv')
        jenkinsGetBuild = classArray.get('JenkinsGetBuild')
        this.jenkins_info = info
        j_instance = info.get('j_instance')
        printHandler.printEmphasizeLog("initClass GetHostForNode")
    }


    def getQueueEntriesbyLabel(label) {
        def entryList = []
        def q = j_instance.queue
        q.getItems().findAll { it.getAssignedLabel() =~ /label/ || it.getWhy() =~ /label/ }.each {
            entryList.add(it)
        }
        return entryList
    }

    def getSlavesInfo(list = []) {
        def j_instance = Jenkins.instance
        def hosts = [:]
        def jslaves = [:]

        // First get all the cute-slave-Auto first
        def hostNames = [/.*jnode.*/, /.*jenkins-slave.*/, /.*jslave[0-9].*/, /.*jsandbox[0-9].*/,/.*arwen.*/,/.*balin.*/]
        def labels = [/.*cute-slave-Auto.*/, /.*slave-container.*/]

        def hName
        def label_string = ""
        for (slave in j_instance.slaves.findAll {
            try {
                if (it.computer) {
                    hName = it.computer.hostName
                } else {
                    hName = "XXXXnoneXXXX"
                }
            } catch (Exception e) {
                hName = "XXXXnoneXXXX"
            }
            try {
                label_string = it.getLabelString()
            } catch (Exception e) {
                label_string = 'No_LABEL'
            }
            (hostNames.any { h -> hName =~ h } || labels.any { l -> label_string =~ l })
        }.sort { st -> try {st.computer.hostName } catch (Exception e) {'XXXnoneXXX'}}) {
            if (list.size() == 0 || (list.size() > 0 && list.any { name -> slave.computer != null && slave.computer.hostName != null && slave.computer.hostName.startsWith(name) })) {

                def host = slave.computer.hostName
                def host_dict = ['slave_count': 0, 'total_executors': 0, 'slaves': [], 'total_idles': 0, 'total_busy': 0]
                //          printHandler.notify("FOUND HOST: ${host}")
                hosts.put(host, host_dict)
            }
        } // Note: this concludes both the findALL and sort

        // We only will process slaves attached to the host list created above
        printHandler.printBoxLog("Processing listed hosts .....")
        j_instance.slaves.sort { try {it.computer.hostName} catch(Exception e) {'None'}}.each { slave ->

            def host = "Unknown"
            def h = ""
            def addr
            def jslave
            def slaveName = ""
            def skip_process = false

            try {
                host = slave.computer.hostName
                h = hosts.get(host)
                addr = InetAddress.getAllByName(host)
                jslave = addr.toString()
                slaveName = slave.computer.getDisplayName()
            } catch (e) {
                printHandler.printLogException("Skipping process for ${host} because of " + e.toString())
                skip_process = true
            }

            //Don't process the main hosts just sub hosts on each
            if (! skip_process) {
                try {
                    if (!(h.size() == 0) && !(slaveName.size() == 0) && !hosts.any { k, v -> (k && k.startsWith(slaveName)) }) {
                        def slave_count = h.get('slave_count') + 1
                        def is_idle = (!slave.computer.isOffline() && (slave.computer.countBusy() == 0))
                        def q_entries = getQueueEntriesbyLabel(slaveName)
                        def executor_count = slave.computer.getNumExecutors()
                        def busy_count = slave.computer.countBusy()
                        def idles = executor_count - busy_count
                        def total_executors = h.get('total_executors') + executor_count
                        def total_idles = h.get('total_idles') + idles
                        def total_busy = h.get('total_busy') + busy_count
                        def slave_info = ['name': jslave, 'executors': executor_count, 'busy_count': busy_count, 'idles': idles]

                        // Per host information
                        hosts.get(host).put('slave_count', slave_count)
                        hosts.get(host).put('total_executors', total_executors)
                        hosts.get(host).put('total_idles', total_idles)
                        hosts.get(host).put('total_busy', total_busy)
                        hosts.get(host).get('slaves').add(slave_info)

                    } // h && shost
                } catch (e) {
                    printHandler.printLogException("skipped host - ${h} and slave - ${slaveName} " + e.toString())
                }
            }
        } // j_instance.slaves.sort ...
        printHandler.printBoxLog("getSlavesInfoList finished.")
        return hosts
    }


    def get_host_by_weight(node_list = []) {
        def hosts = getSlavesInfo(node_list)
        def least_weight = Integer.MAX_VALUE
        def useHosts = []

        hosts.each { k, v ->
            def total_busy = v.get('total_busy')
            def s_count = v.get('slave_count')
            def weight = s_count + (5 * total_busy)

            if (weight <= least_weight) {
                printHandler.printLog("\tget_host_by_weight - HOST: ${k}\n\tbusy: ${total_busy}, slaves: ${s_count}, weight: ${weight} least_weight: ${least_weight} ADDED")
                least_weight = weight
                def host_weight = ["host": k, "weight": weight]
                useHosts.add(host_weight)
            }
        }

        // get all hosts with the least weight then randomly choose one (if more than one)

        def host
//    printHandler.notify("USEHOSTS_SIZE: " + useHosts.size().toString())

        if (useHosts.size() > 0) {
            least_weight = useHosts[-1].get("weight") // Last in array must be the lowest weight
            useHosts = useHosts.findAll { it.get("weight") == least_weight }
            printHandler.printLogVerbose("Hosts to choose from :")
            useHosts.each { printHandler.printLogVerbose("\t" + it) }
            if (useHosts.size() == 1) {
                host = useHosts[0].get("host")
            } else {
                Random random = new Random()
                host = useHosts[random.nextInt(useHosts.size()**1)].get("host")
            }
            return host
        } else {
            def hostlist = hosts.keySet()
            if (hostlist.size() > 0) {
                printHandler.printLog("Hosts: " + hostlist.join("\n"))
                Random random = new Random()
                host = hostlist[random.nextInt(hostlist.size()**1)]

            }
        }
        if (host) {
            host += '.'
            return host.split(/\./)[0]
        }

        return null
    }

}

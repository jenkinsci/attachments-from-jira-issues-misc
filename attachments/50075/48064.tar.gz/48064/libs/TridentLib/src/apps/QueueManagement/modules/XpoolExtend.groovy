class XpoolExtend {

    static def classArray = [:]

    static def jenkinsEnv
    static def runShell
    static def printHandler
    static def jenkins_info

    static def initClass(classes, info) {
        classArray = classes
        jenkinsEnv = classArray.get('JenkinsEnv')
        runShell = classArray.get('RunShell')
        printHandler = classArray.get('PrintHandler')
        this.jenkins_info = info
        printHandler.printEmphasizeLog("initClass XpoolExtend")
    }

    static def internalMain(jenkins_info) {
        xpool_extend()
    }

    static def xpool_extend(workspace = "") {
        if (!workspace) {
            this.workspace = jenkins_info.get('workarea')
        }
        def python_command = "xpoolExtend.py"
        def python_script = sprintf("%s/python/%s %s %s", jenkinsEnv.getenv("QUEUE_HOME"), python_command, workspace, jenkinsEnv.getenv("TRI_GROOVY_HOME"))
        def output = runShell.runCommand(python_script)
        printHandler.printConsole("Executing xpool_extend")
        printHandler.printLog(printHandler.emphasize('xpool_extend','-','-'))
        if (output) {
            output.split('\n').each { it ->
                printHandler.printLog(it)
            }
        }
        return 0
    }
}

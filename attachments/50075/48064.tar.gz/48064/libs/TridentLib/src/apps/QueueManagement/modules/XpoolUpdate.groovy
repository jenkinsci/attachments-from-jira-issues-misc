class XpoolUpdate {

    static def classArray = [:]

    static def jenkinsEnv
    static def runShell
    static def printHandler
    static def jenkins_info

    static def initClass(classes, info) {
        classArray = classes
        jenkinsEnv = classArray.get('JenkinsEnv')
        runShell = classArray.get('RunShell')
        printHandler = classArray.get('PrintHandler')
        printHandler.printEmphasizeLog("initClass XpoolUpdate")
        this.jenkins_info = info
    }


    static def xpool_update(cluster = "", message = "", username="") {
        def python_command = "xpoolUpdate.py"
        def python_script = sprintf("%s/python/%s %s %s %s %s", jenkinsEnv.getenv("QUEUE_HOME"), python_command, jenkinsEnv.getenv("TRI_GROOVY_HOME"), cluster, message, username)
        def output = runShell.runCommand(python_script)
        printHandler.printConsole("Executing xpool_update for cluster: ${cluster}")
        printHandler.printLog(printHandler.emphasize('xpool_update','-','-'))
        if (output) {
            output.split('\n').each { it ->
                printHandler.printLog(it)
            }
        }
    }
}

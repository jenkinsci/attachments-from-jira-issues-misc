class SwitchFuncs {

    static def is_extended = false
    static def ur_extended = false
    static def ur_extend_on_failure = false

    static def jenkinsEnv
    static def printHandler
    static def nodeHandler
    static def runShell
    static def setJiraDescription
    static def jenkinsPageUpdate
    static def trackingCluster
    static def cycleHandler
    static def workUtils
    static def xpoolManager
    static def jenkins_info
    static def exceptionHandler
    static def reUseApi
    static def QAReuse
    static def nativeReplication
    static def nativeReplicationXpool
    static def classArray = [:]
    static def traceEnvEntry = "TRACE_NODES"

    // This list is essential as now the ErrorHandler can parse a log and do actions which do not pertain to slaves/nodes 
    // if a call is to one of these functions during a run without a slave/node they will be skipped automatically
    // When adding a new slave/node function please update this list

    static def nodeSlaveFuncList = [
            "AutoExtendURSlaveOnCorruption",
            "extendURSlave",
            "removeSplitted",
            "splittedSlave",
            "dummyFunction",
            "releaseSlave",
            "checkIfTraced",
            "checkSetTrace",
            "releaseSlaveHealthCheck",
            "extendSlave",
            "setExtendedInEnv",
            "extendForceSlave",
            "extendAll",
            "nodeOffline"
        ]


    static def initClass(classes, info) {
        classArray = classes
        jenkinsEnv = classArray.get("JenkinsEnv")
        printHandler = classArray.get("PrintHandler")
        nodeHandler = classArray.get("NodeHandler")
        exceptionHandler = classArray.get("ExceptionHandler")
        runShell = classArray.get("RunShell")
        setJiraDescription = classArray.get("ErrorHandler.SetJiraDescription")
        jenkinsPageUpdate = classArray.get("JenkinsPageUpdate")
        trackingCluster = classArray.get("ErrorHandler.TrackingCluster")
        cycleHandler = classArray.get("ErrorHandler.CycleHandler")
        workUtils = classArray.get("WorkUtils")
        xpoolManager = classArray.get("XpoolManager")
        reUseApi = classArray.get('QueueManagement.ReUseBrick')
        QAReuse = classArray.get('ErrorHandler.QAReuse')
        nativeReplication = classArray.get('NativeReplication')
        nativeReplicationXpool = classArray.get('NativeReplicationXpool')
        this.jenkins_info = info
        printHandler.printEmphasizeLog("initClass SwitchFuncs")
    }

    static def checkActions(action) {
        def actions = action.split(',')
        def actname
        def errors = []
        actions.each { act ->
            if (act =~ /(\S+)/) {
                def actarr = act.split(/[()]/)
                actname = actarr[0].trim()
            } else {
                actname = act
            }
            if (!SwitchFuncs.class.metaClass.methods*.name.any { it == actname }) {
                errors.add(actname)
            }
        }
        return errors
    }

    static def runDebug(jenkinsSessionInfo, switchInfo, native_slave = "") {

        def actions = switchInfo.get('acts').split(',')
        def pattern_info = switchInfo.get('pattern_info')
        def string_found = switchInfo.get('string_found')
        def offline_info = switchInfo.get('offline_info')
        def slave_name = jenkinsSessionInfo.get('slave_name')
        def output_template = 'Cluster %s would be proccessed: \n\tpattern: %s\n\tmatched string:%s\n\toffline message:%s\nActions:'
        def output_info = sprintf(output_template, slave_name, pattern_info, string_found, offline_info)
        printHandler.printDebug(output_info)

        actions.each { act ->
            if (SwitchFuncs.class.metaClass.methods*.name.any { it == act }) {
                printHandler.printDebug("    " + act)
            } else {
                printHandler.printError("   Action " + act + ' is not defined' + ' in switchFuncs.groovy')
            }
        }
    }
    static def doAction(actname,slavename)
    {
        printHandler.printBoxLog("doAction  - action is ${actname} and slavename is ${slavename}")
        if (slavename) {
            return true
        }
        return !(nodeSlaveFuncList.any{actname == it})
    }

    static def runSwitch(jenkinsSessionInfo, switchInfo, native_slave = "") {
        def projectName = jenkinsSessionInfo.get("projectName")
        def buildNumber = jenkinsSessionInfo.get("buildNumber")
        def buildNumberStr = jenkinsSessionInfo.get("buildNumberStr")
        def slave_name = jenkinsSessionInfo.get('slave_name')
        def manager = jenkinsSessionInfo.get('manager')
        def sysInfo = jenkinsSessionInfo.get('sysInfo')

        def actions = switchInfo.get('acts').split(',')
        def pattern_info = switchInfo.get('pattern_info')
        def jenkins_msg = switchInfo.get('jenkins_msg')
        def string_found = switchInfo.get('string_found')
        def offline_info = switchInfo.get('offline_info')

        def buildEnv = jenkinsSessionInfo.get("buildENV")
        def buildOwner = buildEnv.get("BUILD_USER_ID")
        def jenkinsUrl = buildEnv.get('JENKINS_URL')
        def buildUrl = buildEnv.get("BUILD_URL")
        def ur_run_owner = buildEnv.get("triggered_by_user")
        def triggered_by_dingo = buildEnv.get("TRIGGERED_BY_DINGO")
        def deployNumber = buildEnv.get("deployNumber")
        def jenkinsHome = buildEnv.get("JENKINS_HOME")

        def buildDir = buildUrl.replace(jenkinsUrl, jenkinsHome + '/').replace('/job/', '/jobs/').replace("/${buildNumberStr}/", "/builds/${buildNumber}")
        if (native_slave != "") {
            slave_name = native_slave
        }
        def node = nodeHandler.getNode(slave_name)
        def slaveLabel = ""
        if (node) {
            slaveLabel = node.getLabelString()
        }

        def returnValue = 0
        def tmp_message = "UR_detected_data_corruption_please_investigate_link:_${buildUrl}"
     //   def message = "${buildUrl} -  ${offline_info}"
        def message = offline_info.replace(' ','_')


        def all_args = [:]

        all_args['buildDir'] = buildDir
        all_args['buildNumber'] = buildNumber
        all_args['buildUrl'] = buildUrl
        all_args['jenkinsUrl'] = jenkinsUrl
        all_args['manager'] = manager
        all_args['message'] = message
        all_args['offline_info'] = offline_info
        all_args['jenkins_msg'] = jenkins_msg
        all_args['projectName'] = projectName
        all_args['slaveLabel'] = slaveLabel
        all_args['slave_name'] = slave_name
        all_args['tmp_message'] = tmp_message
        all_args['ur_owner'] = ur_run_owner
        all_args['triggered_by_dingo'] = triggered_by_dingo
        all_args['deployNumber'] = deployNumber
        all_args['buildEnv'] = buildEnv
        all_args['sysInfo'] = sysInfo
        all_args['buildOwner'] = buildOwner



        def output_template = 'Processing cluster for  %s\n\tpattern: %s\n\tmatched string: %s\n\toffline message: %s'
        def output_info = sprintf(output_template, slave_name, pattern_info, string_found, offline_info)
        printHandler.printLog(output_info)
        def actname = ""
        def params = ""
        printHandler.printBoxConsole("[INFO] - Performing the following action(s) " + actions + " on cluster " + slave_name)
        actions.each { act ->
            printHandler.printLog("   Trying to perform " + act)
            try {
                // if the action is a parameterized function we expect it to return an integer variable
                if (act =~ /\(\S+\)/) {
                    printHandler.printEmphasizeLog("Performing parameter action")
                    def actarr = act.split(/[()]/)

                    actname = actarr[0].trim()
                    params = actarr[1].trim()
                    printHandler.printBoxLog("Paramterized action - action = ${actname} params = ${params}")
                    all_args['func_params'] = params
                    if (doAction (actname, slave_name)) {
                        def action_method = this.invokeMethod(actname, all_args)
                        returnValue = Eval.me("method", action_method, "method")
                    } else {
                        printHandler.notify("Not executing ${act} - no slave/node defined")
                    }

                } else {
                    printHandler.printBoxLog("Action = ${act}")
                    actname = act.trim()
                    if (doAction(actname, slave_name)) {
                        def action_method = this.invokeMethod(actname, all_args)
                        Eval.me("method", action_method, "method")
                    } else {
                        printHandler.notify("Not executing ${act} - no slave/node defined")
                    }
                }

            } catch (e) {
                printHandler.printError("Failed to perform actions ${act}, reason: " + e.toString())
                if (exceptionHandler) {
                    exceptionHandler.printExceptionStack(e)
                    returnValue = 999
                }
            }
        }
        return returnValue

    }

    static def returnFuncsParms(j_info) {
        def parms = j_info.get('func_params').split('-')
        def val = parms[0].toInteger()
        def infostring = parms[1]
        printHandler.printInfo ("returnFuncParms: ${infostring} = ${val}")
        return val
    }
    static def returnValueToCaller(j_info) {
        def String param = j_info.get('func_params')
        return param.toInteger()
    }
    static def returnEnvValToCaller(j_info) {
        def envvar = j_info.get('func_params')
        def val = jenkinsEnv.getenv(envvar)
        if (val) {
            printHandler.printBoxLog("returnEnvValtoCaller variable is: ${envvar} value is: ${val}")
            return val.toInteger()
        } else {
            return 0
        }
    }

    static def nodeOffline(j_info) {
        def slavename = j_info.get('slave_name')
        def jenkins_msg = j_info.get('jenkins_msg')
        def message = j_info.get('offline_info')
        def buildDir = j_info.get('buildDir')

        printHandler.printLog("ur extended status is " + ur_extended)

        if (!ur_extended) {
            if (workUtils.checkDossierExists(buildDir)) {
                printHandler.printLog('Not taking node off line since dossier exists')
            } else {
                nodeHandler.nodeOffline(slavename, jenkins_msg)
            }
        } else {
            printHandler.printLog('skipping [nodeOffline] the slave was already extended by ur_user')
        }
    }

    static def extendAll(j_info) {

        def slave_name = j_info.get('slave_name')
        if (checkIfTraced("extendAll", slave_name)) {
            return
        }

        def message = j_info.get('message')
        if (!nativeReplication.isNative) {
            extendForceSlave(j_info)

        } else {
            def cluster_list = nativeReplication.getNativeInfoList()
            cluster_list.each { cl ->
                setExtendedInEnv(cl)
                nativeReplicationXpool.nativeExtend(cl, message)
            }
        }

    }
    static def extendForceSlave(j_info) {
        def manager = j_info.get('manager')
        def slave_name = j_info.get('slave_name')
        def triggered_by_dingo = j_info.get("triggered_by_dingo")
        def message = j_info.get('message')
        jenkinsPageUpdate.setPic(manager)

        if (triggered_by_dingo == "yes"){
            j_info.put('dingo_message', 'Dingo:Cluster_Reserved_Due_To_Data_Corruption')
            extendURSlave(j_info)
            return
        }
        if (checkIfTraced("extendSlaveForce", slave_name)) {
            return
        }


        if (!is_extended && !ur_extended) {
            if (ur_extend_on_failure) {
                printHandler.printLog("skipping [extendForceSlave] extending the slave for  UR User Slave: " + slave_name)
                extendURSlave(j_info)
            } else {
                setExtendedInEnv(slave_name)
                trackingCluster.TrackingClusterProcess(manager, slave_name)
                if (!nativeReplication.isNative) {
                    printHandler.printLog("Performing Extend for " + slave_name)
                    printHandler.printLog(xpoolManager.xpoolExtend(slave_name, message))
                } else {
                    nativeReplicationXpool.nativeExtend(slave_name, message)
                }
            }
        }
    }

    static def setExtendedInEnv(xbrick)
    {
        def cur_value = jenkinsEnv.getenv("EXTENDED") ?: ""
        if (cur_value) {
            if (!cur_value.contains(xbrick)) {
                jenkinsEnv.putenv("EXTENDED", "${cur_value}:${xbrick}")
            }
        } else {
            jenkinsEnv.putenv("EXTENDED",xbrick)
        }

    }

    static def extendSlave(j_info) {
        def manager = j_info.get('manager')
        def slave_name = j_info.get('slave_name')
        def message = j_info.get('offline_info')
        def buildDir = j_info.get('buildDir')
        jenkinsPageUpdate.setPic(manager)


        if (checkIfTraced("extendSlave", slave_name)) {
            return
        }

        if (!is_extended && !ur_extended) {
            if (ur_extend_on_failure) {
                printHandler.printLog("skipping [extendSlave] extending the slave for  UR User Slave: " + slave_name)
                extendURSlave(j_info)
            } else {
                trackingCluster.TrackingClusterProcess(manager, slave_name)
                if (workUtils.checkDossierExists(buildDir)) {
                    printHandler.printLog("Not extending ${slave_name} because dossier exists")
                    printHandler.printLog("Calling releaseSlave instead ...")
                    releaseSlave(j_info)
                    is_extended = false
                } else {
                    is_extended = true
                    setExtendedInEnv(slave_name)
                    if (!nativeReplication.isNative) {
                        printHandler.printLog("Performing Extend for " + slave_name)
                        printHandler.printLog(xpoolManager.xpoolExtend(slave_name, message))

                    } else {
                        nativeReplicationXpool.nativeExtend(slave_name, message)
                    }
                }
            }
        }
    }


    static def setJiraUrls(j_info) {
        def buildUrl = j_info.get('buildUrl')
        printHandler.printLog("Skipping setJiraUrls until all issues are finalized ...")
        //setJiraDescription.setJiraUrls(buildUrl)

    }
    static def releaseSlaveHealthCheck(j_info) {
        def hc = jenkinsEnv.getenv("healthCheck")
        if (!hc) {
            jenkinsEnv.putenv("healthCheck", j_info.get('slave_name'))
        } else {
            jenkinsEnv.putenv("healthCheck", hc + ":" + j_info.get('slave_name'))
        }
        releaseSlave(j_info)
    }


    static def checkSetTrace(j_info) {
        def message_string = "missing_traces"
        if (!xpoolManager.xpoolSearch(["messages"], message_string)) {
            printHandler.printUnderlineLog("checkSetTrace - Extending current slave(s) with ${message_string} ")
            j_info.put('message',message_string)
            extendAll(j_info)
            if (nativeReplication.isNative) {
                def slave_string = nativeReplication.taggedCluster + ":" + nativeReplication.getNativeInfoString().replace(",",":")
                jenkinsEnv.putenv(traceEnvEntry, slave_string)
             } else {
                jenkinsEnv.putenv(traceEnvEntry, j_info.get("slave_name"))
            }
        }
    }

    static def checkIfTraced(func_name, slave_name) {
        def traceBricks = jenkinsEnv.getenv(traceEnvEntry)
        printHandler.printBoxLog("checkIfTraced = ${func_name}, ${slave_name}")
        if (traceBricks) {
            def traceArray = traceBricks.split(':')
            def checkBricks = []
            if (nativeReplication.isNative) {
                checkBricks.add(nativeReplication.taggedCluster)
                for (b in nativeReplication.getNativeInfoString().split(",")) {
                    checkBricks.add(b)
                }
            } else {
                checkBricks.add(slave_name)
            }
            if (traceArray == checkBricks) {
                printHandler.printBoxLog("checkIfTraced - ${func_name} no action because bricks are extended because of missing trace")
                return true
            } else {
                return false
            }

        } else {
          return false
        }

    }
    static def releaseSlave(j_info) {
        def manager = j_info.get('manager')
        def slave_name = j_info.get('slave_name')
        def message = j_info.get('offline_info')
        def s_info = j_info.get('sysInfo')
        def buildOwner = j_info.get('buildOwner')
        def buildEnv = jenkinsEnv.getAllEnv()
        jenkinsPageUpdate.setPic(manager)
        trackingCluster.TrackingClusterProcess(manager, slave_name)
        def isQA = manager.envVars['JENKINS_URL'].contains("qa")
        def ts_id = ""
        def max_allowed = "0"
        def ts_reuse = 'false'
        if (buildEnv) {
            ts_id = buildEnv.get('TS_Id')
            max_allowed = buildEnv.get('TS_Executors')
            ts_reuse = buildEnv.get('TS_Reuse')
        }

        def trackCluster = jenkinsEnv.getenv("Tracking")
        if (trackCluster) {
            return
        }

        if (checkIfTraced("releaseSlave", slave_name)) {
            return
        }
        if (!isQA) {
            // QueueManager handling for reuse (reuse function also releases the slave if not needed
            if (ts_reuse == 'true' && ts_id != null && max_allowed != null) {
                def workarea = s_info.get('workarea')
                reUseApi.ReUseBrick(ts_id, max_allowed, workarea)
            } else {
                if (ur_extend_on_failure) {
                    printHandler.printLog("skipping release, extending the slave for UR User Slave: " + slave_name)
                    extendURSlave(j_info)
                } else {
                    if (!nativeReplication.isNative) {
                        printHandler.printLog("Performing Release for " + slave_name)
                        printHandler.printLog(xpoolManager.xpoolRelease(slave_name, message))
                    } else {
                        nativeReplicationXpool.nativeRelease(slave_name, message)
                    }
                }
            }
        } else { // QA Handling
            def brickOwner
            if (nativeReplication.isNative) {
                brickOwner = xpoolManager.xpoolGetOwner("", nativeReplication.taggedCluster, false)
            } else {
                brickOwner = xpoolManager.xpoolGetOwner(slave_name, "", false)
            }
            printHandler.printBoxLog("brickOwner = ${brickOwner}, buildOwner = ${buildOwner}")

            if (brickOwner != buildOwner && brickOwner != "qa_leaser"  && brickOwner != "jenkins-dev" && brickOwner != "cyc_user") {
                printHandler.printBoxConsole("Not releasing ${slave_name} because xpool owner (${brickOwner}) is different from build owner (${buildOwner})")
            } else {
                if (!nativeReplication.isNative) {
                    printHandler.printLog("Trying to perform reuse ...")
                    // if (!QAReuse.QAReuse(manager)) {
                    printHandler.printInfo("Reuse is not functioning - performing release ...")
                    printHandler.printLog("Performing Release for " + slave_name)
                    printHandler.printLog(xpoolManager.xpoolRelease(slave_name, message))
                    //}
                } else {
                    nativeReplicationXpool.nativeRelease(slave_name, message)
                }
            }
        }
    }

    static def dummyFunction(j_info) {
        def message = j_info.get('offline_info')
        def slave_name = j_info.get('slave_name')
        printHandler.printLog("Performing Nothing for " + slave_name)
        printHandler.printLog("Dummy function slave: " + slave_name + " message: " + message)
    }

    static def splittedSlave(j_info) {
        def slave_name = j_info.get('slave_name')
        def node = nodeHandler.getNode(slave_name)
        def label = node.getLabelString()
        printHandler.printLog("Setting splitted label for: " + slave_name)
        node.setLabelString(label + " " + "splitted")
    }

    static def removeSplitted(j_info) {

        def slave_name = j_info.get('slave_name')
        def node = nodeHandler.getNode(slave_name)
        def label = node.getLabelString()

        printHandler.printLog('Removing splitted label from: ' + slave_name)
        label.replaceAll("splitted", "")
        node.setLabelString(label)

    }

    static def setSummary(j_info) {
        def manager = j_info.get('manager')
        def message = j_info.get('offline_info')
        manager.createSummary("warning.gif").appendText(message, false, false, false, 'red')
    }

    static def setFailure(j_info) {
        if (!jenkinsEnv.getenv('ISPIPELINE')) {
            def manager = j_info.get('manager')
            manager.buildFailure()
        } else {
            def sysinfo = j_info.get('sysInfo')
            def build = sysinfo.get('build')
            build.result = hudson.model.Result.FAILURE
        }
    }

    static def setUnstable(j_info) {
        if (!jenkinsEnv.getenv('ISPIPELINE')) {
            def manager = j_info.get('manager')
            try {
                manager.buildUnstable()
                manager.build.setResult(hudson.model.Result.UNSTABLE)

            } catch (e) {
                printHandler.printLog("was some kind of problem with setUnstable " + e.toString())
                if (exceptionHandler) {
                    exceptionHandler.printExceptionStack(e)
                }
            }
        } else {
            jenkinsEnv.putenv("DEPLOY_RESULT", "UNSTABLE")
            printHandler.printBoxLog("Not setting jenkins unstable in pipeline environment ....")
            printHandler.printBoxLog("Setting unstable for tracking cluster in pipeline environment ....")
            def sysinfo = j_info.get('sysInfo')
          //  def build = sysinfo.get('build')
            def manager = j_info.get('manager')
            def deployNumber = j_info.get('deployNumber')
           // build.result = hudson.model.Result.UNSTABLE
            cycleHandler.handleDeployFailurePipeline(manager, deployNumber)
        }
    }

    static def setReserveClusterAnyway(j_info) {
        def manager = j_info.get('manager')
        printHandler.printLog("activated setReserveClusterAnyway method")
        ur_extended = true
    }

    static def setReserveClusterOnFailure(j_info) {
        def manager = j_info.get('manager')
        printHandler.printLog("activated setReserveClusterOnFailure method")
        ur_extend_on_failure = true
    }

    static def extendURSlave(j_info) {
        def manager = j_info.get('manager')
        if (nativeReplication.isNative) {
            printHandler.printLog("extendURSlave is not needed in native replication ignoring")
            return
        }

        if (!ur_extended && !is_extended) {
            printHandler.printLog("activated extendURSlave method")

            def slave_name = j_info.get('slave_name')
            def buildDir = j_info.get('buildDir')
            def message = j_info.get('offline_info')
            def buildUrl = j_info.get("buildUrl")
            def ur_owner = j_info.get("ur_owner")
            def dingo_message = j_info.get("dingo_message")
            if (checkIfTraced("extendURSlave", slave_name)) {
                return
            }
            if (!ur_owner) {
                ur_owner = 'jenkins-dev'
            }
            setExtendedInEnv(slave_name)
            message = "Dingo:Cluster_Reserved_please_investigate_link:_${buildUrl}"
            if (dingo_message) {
                message = dingo_message+"_please_investigate_link:_${buildUrl}"
            }
            trackingCluster.TrackingClusterProcess(manager, slave_name)
            printHandler.printLog("Performing Extend for " + slave_name)
            printHandler.printLog(xpoolManager.xpoolExtendWithUser(slave_name, message, ur_owner))
            printHandler.printLog(xpoolManager.xpoolExtendTime(slave_name, ur_owner, 'eod'))

            is_extended = true
            ur_extended = true
        }
    }

    static def AutoExtendURSlaveOnCorruption(j_info) {
        def manager = j_info.get('manager')
        def slave_name = j_info.get('slave_name')
        def message = j_info.get('offline_info')
        if (nativeReplication.isNative) {
            printHandler.printLog("AutoExtendURSlaveOnCorruption is not needed in native replication ignoring")
            return
        }
        if (checkIfTraced("AutoExtendURSlaveOnCorruption", slave_name)) {
            return
        }
        setSummary("warning.gif").appendText("<h1>DataCorruption detected please investigate it</h1>", false, false, false, "red")
        def buildUrl = j_info.get("buildUrl")
        def ur_run_owner = j_info.get("ur_run_owner")
        if (!ur_run_owner) {
            ur_run_owner = 'jenkins-dev'
        }
        def buildDir = j_info.get('buildDir')
        trackingCluster.TrackingClusterProcess(manager, slave_name)
        if (workUtils.checkDossierExists(buildDir)) {
            printHandler.printLog("Not extending ${slave_name} because dossier exists")
            printHandler.printLog("Calling releaseSlave instead ...")
            releaseSlave(j_info)
            is_extended = false
        } else {
            setExtendedInEnv(slave_name)
            message = "UR_detected_data_corruption_please_investigate_link:_${buildUrl}"
            printHandler.printLog("Performing Extend for " + slave_name)
            printHandler.printLog(xpoolManager.xpoolExtendWithUser(slave_name, message, ur_run_owner, message))
            printHandler.printLog(xpoolManager.xpoolExtendTime(slave_name, ur_run_owner, 'eod'))
            is_extended = true
        }

    }
}

class CreateBrickMethodsClass {


    static def classArray = [:]
    static def printHandler
    
static def setCheckLabels


    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get('PrintHandler')
	setCheckLabels = classArray.get("QueueManagement.SetCheckLabels")
    }

    // Add methods here as needed
    static def example_method() {
        printHandler.printInfo("CreateBrick")
    }
}

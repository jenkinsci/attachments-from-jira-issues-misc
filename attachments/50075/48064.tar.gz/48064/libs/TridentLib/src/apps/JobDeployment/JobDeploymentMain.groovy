import jenkins.model.*

class JobDeployentMainClass {
    def runMethod(info) {

        def buildManager = info.get('buildManager')
        def h_instance = info.get('h_instance')
        def library_space = info.get('library_space')
        def workspace = info.get('workspace')
        def brickName = info.get('brickName')
        def params = info.get('params')
        def output = info.get('output')
        def err = info.get('err')
        if (output == null) {
            output = buildManager.listener.logger
            err = output
            info.put('output', output)
            info.put('err', err)
        }

        def work_area = info.get('workarea')

        info.put('j_instance', Jenkins.getInstance())


        def instance

        def groovyHome = library_space

        if (!instance) {
            try {
                instance = Jenkins.getInstance()
            } catch (Exception e) {
                output.println("instance try no. 1 failed! " + e.toString())
                try {
                    instance = Hudson.instance
                } catch (Exception d) {
                    output.println("instance try no. 2 failed! " + d.toString())
                }
            }

        }
        if (!instance) {
            output.println("STILL NO INSTANCE !!!!")
            throw new RuntimeException("INSTANCE IS STILL NULL!")

        }


        def envMap = info.get('envMap')
        def appsDir = "${groovyHome}/apps"




// All you need to change are the lines till the next comment

        def lClasses = "apps/JobDeployment/modules/JobDeployment,modules/SendMail"
        def rClasses = "JobDeployment.JobDeployment"

// Only the lines above have to be changed to run a process

        def loadFile = sprintf("%s/%s", groovyHome, "interfaces/DynamicClassMethod.groovy")


        def File groovyFile
        def Class groovyClass
        def GroovyObject groovyObject
        def groovyFileName = loadFile
        info.put('appName','JobDeployment')

        //output.println("Loading ${groovyFileName}")
        groovyFile = new File(groovyFileName);

        def clazzLoader = Jenkins.getInstance().getPluginManager().uberClassLoader
        groovyClass = new GroovyClassLoader(clazzLoader).parseClass(groovyFile);

        groovyObject = groovyClass.newInstance()
        return groovyObject.runMethod(lClasses, rClasses, info)
    }
}

import hudson.model.*

class CycleHandler {

    static def classArray = [:]
    static def output

    static def jenkins_info
    static def sessionInfo
    static def jenkinsEnv
    static def logSearch

    static def initClass(classes, info) {
        classArray = classes
        this.jenkins_info = info
        output = jenkins_info.get('output')
        sessionInfo = classArray.get("ErrorHandler.SessionInfo")
        jenkinsEnv = classArray.get("JenkinsEnv")
        logSearch = classArray.get("LogSearch")
    }
    static def handleDeployFailurePipeline(manager, deployNumber) {
        def brick = jenkins_info.get('brickName')
        def pa = new ParametersAction([new StringParameterValue("deployFailed_"+deployNumber,brick)])
        jenkins_info.get('build').rawBuild.addAction(pa)

    }

    static def run(manager) {
        def cyclesList = []
        def di = "no"
        def du = "no"
        def cyclesNum = "0"
        def logLines = []

        def logtext = sessionInfo.getJenkinsEntry("logtext")
        if (logSearch.logContains(".*HA cycle.*")) {
            output.println("hacomb part")
            def counter = 0
            logLines = logtext.split("\n")
            logLines.each() {
                if (it.contains("HA cycle")) {
                    counter++;
                }
            }
            cyclesNum = counter.toString()
        }

        if (logSearch.logContains(".*volspider]\\s*Cycle.*")) {
            def counter = 0
            output.println("volspider part")
            logLines = logtext.split("\n")
            logLines.each()
                    {
                        if (it.contains("Cycle"))
                            counter++;
                    }
            cyclesNum = counter.toString()
        }



        if (logSearch.logContains(".*DATA_CORRUPTION.*")) {
            di = "yes"
        }

        if (logSearch.logContains(".*service loss found.*")) {
            du = "yes"
        }
        if (!jenkinsEnv.getenv('ISPIPELINE')) {
            def pa = new ParametersAction([new StringParameterValue("cycles", cyclesNum)])
            Thread.currentThread().executable.addAction(pa)
            pa = new ParametersAction([new StringParameterValue("corruption", di)])
            Thread.currentThread().executable.addAction(pa)
            pa = new ParametersAction([new StringParameterValue("serviceLoss", du)])
            Thread.currentThread().executable.addAction(pa)
        } else {
            def pa = new ParametersAction([new StringParameterValue("cycles", cyclesNum)])
            jenkins_info.get('build').rawBuild.addAction(pa)
            pa = new ParametersAction([new StringParameterValue("corruption", di)])
            jenkins_info.get('build').rawBuild.addAction(pa)
            pa = new ParametersAction([new StringParameterValue("serviceLoss", du)])
            jenkins_info.get('build').rawBuild.addAction(pa)
        }
    }
}

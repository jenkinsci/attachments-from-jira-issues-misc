import jenkins.model.*

class SlaveMonitorMainClass {
    def runMethod(info) {

        def buildManager = info.get('buildManager')
        def h_instance = info.get('h_instance')
        def library_space = info.get('library_space')
        def workspace = info.get('workspace')
        def brickName = info.get('brickName')
        def params = info.get('params')
        def output = info.get('output')
        def err = info.get('err')

        info.put('j_instance', Jenkins.getInstance())

        def instance = info.get('j_instance')
        def groovyHome = library_space

        def appdir = "apps"

        def slaveMonitorDir = "${appdir}/SlaveMonitor"
        def queueManagerDir = "${appdir}/QueueManagement"

// All you need to change are the lines till the next comment

        def GDIR = groovyHome
        def SDIR = slaveMonitorDir
        def QDIR = queueManagerDir
        def IDIR = "${GDIR}/interfaces"

        def lClasses = "${SDIR}/modules/SlaveMonitor,${QDIR}/modules/QueueHandler"

        def rClasses = "SlaveMonitor.SlaveMonitor"
        info.put('appName',"SlaveMonitor")

        // if you need special environment or params here is the place to put it (QUEUE_HOME is needed in this case)

        // def envMap = info.get('envMap')
        //    envMap.put('QUEUE_HOME',"${groovyHome}/${QDIR}")
        //   info.put('envMap',envMap)

// Only the lines above have to be changed to run a process

        def loadFile = sprintf("%s", "${IDIR}/DynamicClassMethod.groovy")


        def File groovyFile
        def Class groovyClass
        def GroovyObject groovyObject
        def groovyFileName = loadFile

        output.println("Loading ${groovyFileName} ...")
        groovyFile = new File(groovyFileName);


        def clazzLoader = Jenkins.getInstance().getPluginManager().uberClassLoader
        groovyClass = new GroovyClassLoader(clazzLoader).parseClass(groovyFile);

        groovyObject = groovyClass.newInstance()
        return groovyObject.runMethod(lClasses, rClasses, info)
    }
}

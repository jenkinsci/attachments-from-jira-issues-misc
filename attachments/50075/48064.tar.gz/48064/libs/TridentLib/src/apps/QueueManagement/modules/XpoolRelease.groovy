class XpoolRelease {

    static def classArray = [:]

    static def jenkinsEnv
    static def runShell
    static def printHandler
    static def nodeHandler
    static def jenkins_info
    static def jenkinsPageUpdate

    static def initClass(classes, info) {
        classArray = classes
        jenkinsEnv = classArray.get('JenkinsEnv')
        runShell = classArray.get('RunShell')
        printHandler = classArray.get('PrintHandler')
        nodeHandler = classArray.get("NodeHandler")
        jenkinsPageUpdate = classArray.get("JenkinsPageUpdate")
        printHandler.printEmphasizeLog("initClass XpoolRelease")
        this.jenkins_info = info
    }

    static def internalMain(jenkins_info) {
        xpool_release(jenkins_info.get('workarea'))
        return 0
    }

    static def removeNodes(releaseFile)
    {
        printHandler.printBox("Removing released node(s) from jenkins ...")
        def xbrickLines = new File(releaseFile).readLines()
        for (line in xbrickLines) {
            def xbrick = line.split(':-:')[0]
            nodeHandler.nodeRemove(xbrick)
        }
    }

    static def check_again(releaseFile)
    {
        def release_lines = [:]
        new File(releaseFile).readLines().each{
            line ->
                printHandler.printUnderline("Processing ${line} ...")
                def xbrick = line.split(':-:')[0]
                def user = line.split(':-:')[1]
                if (!nodeHandler.isBusy(xbrick)) {
                    release_lines.put(xbrick, user)
                } else {
                    printHandler.printGreenInfo("Xbrick ${xbrick} - user ${user} will not be released because it is busy")
                }
        }

        if (release_lines.size() > 0) {
            printHandler.printPurpleInfo("The following bricks will be release from xpool:")
            release_lines.each {x, u ->
                printHandler.printPurpleInfo("  ${x} - ${u}")
            }
            new File(releaseFile).delete()
            printHandler.logInitFileName("releaseFile",releaseFile, true)
            printHandler.printLog("Rewriting new release file - ${releaseFile}")
            release_lines.each {xbrick, user ->
                printHandler.printRaw("${xbrick}:-:${user}",["releaseFile"])
            }
        } else {
            new File(releaseFile).delete()
        }
    }

    static def xpool_release(workspace = "") {
        if (!workspace) {
            workspace = jenkins_info.get('workarea')
        }
        def manager = jenkins_info.get('buildManager')
        def releaseFile = sprintf("%s/%s", workspace,"releaseList.dat")
        if (!new File(releaseFile).exists()) {
            printHandler.printBoxLog("xpool_release no release file nothing to do")
        } else {
            check_again(releaseFile)
            if (!new File(releaseFile).exists()) {
                jenkinsPageUpdate.createMsg("Not releasing nodes because they were taken by builds",manager,"green.gif", "blue")
                printHandler.printBoxLog("xpool release empty after checking for running build(s)  nothing to do")
            } else {
                def rfd = new File(releaseFile)
                def str = "Releasing nodes: <br>" + rfd.readLines().join("<br>") + "<br>"
                jenkinsPageUpdate.createMsg(str, manager, "red.gif", "red")
                def python_command = "xpoolRelease.py"
                def python_script = sprintf("%s/python/%s %s %s", jenkinsEnv.getenv("QUEUE_HOME"), python_command, workspace, jenkinsEnv.getenv("TRI_GROOVY_HOME"))
                printHandler.printConsole("Executing xpool_release")
                printHandler.printLog(printHandler.emphasize('xpool_release', '-', '-'))
                def output = runShell.runCommand(python_script)
                if (output) {
                    output.split('\n').each { it ->
                        printHandler.printInfo(it)
                    }
                }
                removeNodes(releaseFile)
            }
        }

    }
}

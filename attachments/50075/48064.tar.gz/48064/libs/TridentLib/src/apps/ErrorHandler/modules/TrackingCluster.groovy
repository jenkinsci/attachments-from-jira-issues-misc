class TrackingCluster {
    static def classArray = [:]

    static def jenkinsEnv
    static def printHandler
    static def runShell
    static def jenkins_info
    static def logHandler

    static def initClass(classes, info) {
        classArray = classes
        jenkinsEnv = classArray.get("JenkinsEnv")
        printHandler = classArray.get("PrintHandler")
        runShell = classArray.get("RunShell")
        printHandler.printEmphasizeLog("initClass TrackingCluster")
        logHandler = classArray.get("LogHandler")
        this.jenkins_info = info
    }

    static def TrackingClusterProcess(manager, slave_name) {

        def url = manager.envVars['BUILD_URL']
        def tracking_cluster = manager.envVars['RUN_GROOVY_TRACKER']
        def groovyHome = jenkinsEnv.getenv("TRI_GROOVY_HOME") ?: "/home/jenkins-dev/TridentLib/src"
        def Bstat

        if (1) {
            printHandler.printBox("TrackingClusterProcess not supported")
        } else {
            // DEPLOY_RESULT populate only on UNSTABLE status in pipeline environment
            if (jenkinsEnv.getenv('DEPLOY_RESULT')) {
                Bstat = jenkinsEnv.getenv('DEPLOY_RESULT')
                printHandler.printLog("update unstable status...")
            } else {
                Bstat = jenkins_info.get('build').getResult()
            }

            printHandler.printLog("Updating Clusters DB")
            def output = ""
            def command = ""
            if (jenkinsEnv.getenv("ISPIPELINE")) {
                def archive = logHandler.getArchivePath()
                command = ["${groovyHome}/apps/ErrorHandler/python/reportDevLabPipe.py", url, archive, Bstat]
            } else {
                command = ["${groovyHome}/apps/ErrorHandler/python/reportDevLab.py", url, Bstat]
            }

            output = runShell.runCommand(command)

            printHandler.printBoxLog("Output of reportDevLab")
            printHandler.printRawLog(output)

            printHandler.printBoxLog("Clusters DB Updated")

            try {
                if (tracking_cluster.equals("yes")) {
                    printHandler.printLog("Tracking cluster jobs")
                    def trackerCmd = ["${groovyHome}/apps/ErrorHandler/python/singleClusterTrackerDb.py", slave_name, '3', '8', 'xtools', 'roip']
                    output = runShell.runCommand(trackerCmd)
                    printHandler.printBoxLog("Output of singleClusterTrackerDb")
                    printHandler.printRawLog(output)
                    if (output.contains("Cluster extended by tracker")) {
                        jenkinsEnv.putenv("Tracking", slave_name + " Extended by Tracker")
                        printHandler.printLog("Cluster extended by tracker")
                    }
                    printHandler.printBoxLog("Tracked cluster jobs complete")
                }
            } catch (e) {
                printHandler.printBoxLog("Error during tracking cluster " + e.toString())
            }
        }
    }
}

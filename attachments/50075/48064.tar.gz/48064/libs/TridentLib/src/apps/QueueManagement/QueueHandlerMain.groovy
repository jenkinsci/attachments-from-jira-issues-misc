import jenkins.model.*

class QueueHandlerMainClass {
    def runMethod(info) {

        def buildManager = info.get('buildManager')
        def h_instance = info.get('h_instance')
        def library_space = info.get('library_space')
        def workspace = info.get('workarea')
        def brickName = info.get('brickName')
        def params = info.get('params')
        def output = info.get('output')
        def err = info.get('err')
        if (output == null) {
            output = buildManager.listener.logger
            err = output
            info.put('output', output)
            info.put('err', err)
        }
        info.put('j_instance', Jenkins.getInstance())

        def instance = info.get('j_instance')
        def groovyHome = library_space

        def envMap = info.get('envMap')
        def appdir = "apps"

// All you need to change are the lines till the next comment

        def QDIR = "${appdir}/QueueManagement"
        def SDIR = "${appdir}/SlaveDisconnect"
        def QueuePackage = "QueueManagement"
        def SlavePackage = "SlaveDisconnect"
        envMap.put('QUEUE_HOME', "${groovyHome}/${QDIR}")
        info.put('envMap', envMap)
        info.put('appName','QueueHandler')

        def lClasses = "${QDIR}/modules/QueueHandler,${QDIR}/modules/SetCheckLabels,${QDIR}/modules/XpoolRelease,${QDIR}/modules/XpoolCollector,"
        lClasses += "${QDIR}/modules/GetHostForNode,modules/NodeHandler,modules/RunShell,modules/JenkinsGetBuild,modules/DebugHandler"
        lClasses += ",${QDIR}/modules/XpoolUpdate,${SDIR}/modules/SlaveDisconnect"
        //def rClasses = "${QueuePackage}.QueueHandler,${QueuePackage}.XpoolCollector,${QueuePackage}.SetCheckLabels,${QueuePackage}.XpoolRelease,${SlavePackage}.SlaveDisconnect"
        def rClasses = "${QueuePackage}.QueueHandler,${QueuePackage}.XpoolCollector,${QueuePackage}.SetCheckLabels,${QueuePackage}.XpoolRelease"

// Only the lines above have to be changed to run a process

        def loadFile = sprintf("%s/%s", groovyHome, "interfaces/DynamicClassMethod.groovy")


        def File groovyFile
        def Class groovyClass
        def GroovyObject groovyObject
        def groovyFileName = loadFile

        output.println("Loading ${groovyFileName} ...")
        groovyFile = new File(groovyFileName);


        def clazzLoader = Jenkins.getInstance().getPluginManager().uberClassLoader
        groovyClass = new GroovyClassLoader(clazzLoader).parseClass(groovyFile);

        groovyObject = groovyClass.newInstance()
        return groovyObject.runMethod(lClasses, rClasses, info)
    }
}

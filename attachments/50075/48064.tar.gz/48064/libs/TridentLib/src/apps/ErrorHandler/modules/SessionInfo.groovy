class SessionInfo {

    static def classArray = [:]
    static def sessionInfo = ['jenkinsInfo': [:], 'SwitchInfo': [:]]

    static def printHandler
    static def nodeHandler
    static def jenkins_info
    static def jenkinsEnv

    static def initClass(classes, info) {
        classArray = classes
        printHandler = classArray.get("PrintHandler")
        nodeHandler = classArray.get("NodeHandler")
        jenkinsEnv = classArray.get('JenkinsEnv')
        printHandler.printEmphasizeLog("initClass SessionInfo")
        jenkins_info = info
        setJenkinsEntry("sysInfo", jenkins_info)
    }

    static setJenkinsEntry(key, value) {
        sessionInfo.get('jenkinsInfo').put(key, value)
    }

    static def getJenkinsEntry(key) {
        return sessionInfo.get('jenkinsInfo').get(key)
    }


    static setSwitchEntry(key, value) {
        sessionInfo.get('SwitchInfo').put(key, value)
    }


    static def getSwitchEntry(key) {
        return sessionInfo.get('SwitchInfo').get(key)
    }

    static def setJenkinsManagerInfo(manager) {
        if (manager) {
            setJenkinsEntry("manager", manager)
            setJenkinsEntry("output", getJenkinsEntry("manager").listener.logger)
            setJenkinsEntry("error", getJenkinsEntry("output"))
        } else {
            setJenkinsEntry("manager", null)
            setJenkinsEntry("output", System.out)
            setJenkinsEntry("error", System.err)
        }

    }

    static def setJenkinsBuildInfo(build) {
        if (!jenkinsEnv.getenv('ISPIPELINE')) {
            printHandler.printLog("Not a pipeline")
            setJenkinsEntry("logtext", build.logFile.text)
            setJenkinsEntry("projectName", build.project.getDisplayName())
            setJenkinsEntry("buildNumber", build.getNumber())
            setJenkinsEntry("buildNumberStr", getJenkinsEntry("buildNumber").toString())
            setJenkinsEntry("buildENV", build.getEnvironment())
        } else {
            printHandler.printLog("IN PIPELINE Processing")
            setJenkinsEntry("logtext", jenkins_info.get('buildManager').log)
            def eMap = jenkins_info.get('envMap')
            setJenkinsEntry("projectName", eMap.get('JOB_NAME'))
            setJenkinsEntry("buildNumber", eMap.get('BUILD_NUMBER').replace('#', '').trim().toInteger())
            setJenkinsEntry("buildNumberStr", getJenkinsEntry("buildNumber").toString())
            setJenkinsEntry("buildENV", jenkins_info.get('envMap'))
        }



        def slaveName
        try {
            slaveName = nodeHandler.initSlaveFromBuild(build)
        } catch (Exception e) {
            slaveName = jenkins_info.get('brickName')
        }
        if (slaveName == null) {
            slaveName = 'NotFound'
        }
        setJenkinsEntry("slave_name", slaveName)
        if (getJenkinsEntry("slave_name") =~ /jnode.*/ || !getJenkinsEntry("slave_name").startsWith('xbrick')) {
            def env = getJenkinsEntry("buildENV")
            def variables = ['CLUSTER_NAME', 'XBRICK', 'NODENAME', 'USER_TAGS', 'xbrick']
            def slave_name = null
            variables.each { v ->
                if (!slave_name) {
                    def temp_name = env.get(v)
                    if (temp_name != 'None' && temp_name != null) {
                        slave_name = temp_name
                        nodeHandler.initSlaveFromName(slave_name)
                    }
                }
            }
            setJenkinsEntry("slave_name", slave_name)
        }
    }

    static def getJenkinsBuildInfo() {
        def template = "Slave Name: %s\nEnvironment:\n%s"
        def envString = "\n"
        getJenkinsEntry("buildENV").each { k, v ->
            envString = sprintf('%s\t%s=%s\n', envString, k, v)
        }
        return sprintf(template, getJenkinsEntry("slave_name"), envString)
    }

    static def getbuildEnv(key) {
        return getJenkinsEntry("buildENV").get(key)
    }

    static def setSwitchInfo(acts, pattern_info, jenkins_msg, string_found, offline_info) {
        setSwitchEntry("acts", acts)
        setSwitchEntry("pattern_info", pattern_info)
        setSwitchEntry("jenkins_msg", jenkins_msg)
        setSwitchEntry("string_found", string_found)
        setSwitchEntry("offline_info", offline_info)
    }

    static def getSessionInfo() {
        return sessionInfo
    }

    static def getJenkinsInfo() {
        return sessionInfo.get('jenkinsInfo')
    }


    static def getSwitchInfo() {
        return sessionInfo.get('SwitchInfo')
    }
}

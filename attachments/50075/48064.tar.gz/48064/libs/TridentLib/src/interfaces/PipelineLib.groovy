import hudson.*
import hudson.model.*

class PipelineLib implements Serializable {

    static def loadPipelineLibs(j_info, classToRun) {
        try {

            def obj = classToRun
            def info = [:]
            def envMap = [:]
            // def bManager = currentBuild.getRawBuild()

            info.put('buildManager', j_info.get('bManager'))
            info.put('output', null) // this is resolved in "obj.runMethod()"
            info.put('err', null) // this is resolved in the "obj.runMethod()"
            info.put('h_instance', j_info.get('h_instance'))
            // Jenkins.getInstance() can't be called here it is set in the call to runMethod of the class
            //  info.put('j_instance',Jenkins.getInstance())
            info.put('library_space', j_info.get('library_space'))
            info.put('build', j_info.get('build'))
            info.put('buildResult', info.get('build').result)
            info.put('workspace', j_info.get('cluster_workspace'))
            info.put('brickName', j_info.get('brickName'))
            info.put('params', j_info.get('params'))
            envMap = j_info.get('envMap')
            envMap.put('ISPIPELINE', 'true')
            info.put('envMap', envMap)

           return obj.loadLib(info)

        } catch (e) {
            println("ERROR " + e.toString())
            return "ERROR " + e.toString()
        }
    }

    static def get_cluster_workspace() {
        def workspace = new File('.').getAbsolutePath()
        return (workspace)
    }
}

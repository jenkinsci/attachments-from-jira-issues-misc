import hudson.*
import hudson.model.*
import hudson.tasks.*
import jenkins.*
import jenkins.model.*

class DynamicClassMethod {
    static def className
    static def initModulesInfo = []
    static def implicitList = []
    static def exceptionHandler

    static def getNow() {
        def now = new Date().format("yyyy/MM/dd-HH:mm:ss.SS")
        return now
    }

    static def loadSpecific(classFile, output) {
        def File groovyFile
        def Class groovyClass
        def GroovyObject groovyObject
        def groovyFileName = classFile

        groovyFile = new File(groovyFileName)
        def now = getNow()
        initModulesInfo.add("${now} [LOADING_INFO] Loading ${groovyFileName}")

        try {
            def clazzLoader = Jenkins.getInstance().getPluginManager().uberClassLoader
            groovyClass = new GroovyClassLoader(clazzLoader).parseClass(groovyFile);
            groovyObject = groovyClass.newInstance()

        } catch (Exception e) {
            output.println("Error here !!!! " + e.toString())
            if (exceptionHandler) {
                initModulesInfo.addAll(exceptionHandler.getExceptionStack(e))
            }
        }
        return groovyObject
    }


    static def implicitLoad(classes, info, tmplist = []) {
        def output = info['output']
        def library_space = info.get('library_space')
        def now = getNow()

        for (cl in classes) {
            if (!(tmplist.any { curc -> cl == curc })) {
                initModulesInfo.add("${now} [IMPLICIT_LOAD]  Adding to loadlist ${cl}")
                tmplist.add(cl)
                def fileName = "${library_space}/${cl}.groovy"
                File fd = new File(fileName)
                def lines = fd.readLines()
                def internalList = []
                for (l in lines) {
                    if (l =~ /classArray.get/) {
                        def cFile = l.replace("'", "\"").split(/"/)[1]
                        if (cFile) {
                            if (cFile =~ /\./) {
                                cFile = "apps/" + cFile.replace(".", "/modules/")
                            } else {
                                cFile = "modules/${cFile}"
                            }
                            if (!(tmplist.any { curc -> cl == cFile })) {
                                internalList.add(cFile)
                            }
                        }
                    }
                }
                if (internalList.size() > 0) {
                    implicitLoad(internalList, info, tmplist)
                }
            }
        }
        implicitList = tmplist
    }

    static def classLoader(classFiles, info) {
        def envMap = info.get("envMap")
        def buildManager = info.get('buildManager')
        def library_space = info.get('library_space')
        def h_instance = info.get('instance')
        def workspace = info.get('workspace')
        def params = info.get('params')
        def brickname = info.get('brickname')
        def output = info.get('output')
        def err = info.get('err')

        if (output == null) {
            output = buildManager.listener.logger
            err = output
            info.put('output', output)
            info.put('err', err)
        }


        def loadClasses = [:]
        def groovyHome

        groovyHome = library_space
        exceptionHandler = null

        for (cf in classFiles) {
            def groovyFileName = "${groovyHome}/${cf}.groovy"
            def module_index
            if (cf =~ /apps/) {
                module_index = cf.split('/')[-3] + '.' + cf.split('/')[-1]
            } else {
                module_index = cf.split("/")[-1]
            }
            try {
                def obj = loadSpecific(groovyFileName, output)
                loadClasses.put(module_index, obj)
                if (groovyFileName.endsWith('ExceptionHandler')) {
                    exceptionHandler = obj
                }

            } catch (Exception e) {
                output.println("Error Loading file ...." + e.toString())
                if (exceptionHandler) {
                    initModulesInfo.addAll(exceptionHandler.getExceptionStack(e))
                }
            }
        }


        def phandler = loadClasses.get("PrintHandler")
        phandler.printInit(output, err)
        def class_info = info


        for (c_entry in loadClasses) {
            def c_name = c_entry.key
            def cobj = loadClasses.get(c_name)
            def now = getNow()
            initModulesInfo.add("${now} [LOADING_INFO] Initializing ${c_name}")
            cobj.initClass(loadClasses, class_info)
        }

        def moreinfo = [:]

        moreinfo.put("WORKSPACE", workspace)
        moreinfo.put('TRI_GROOVY_HOME', groovyHome)
        moreinfo.put('TRIGROOVYHOME', groovyHome)
        moreinfo.put('TRIDENTLIBHOME', groovyHome)
        moreinfo.put('APPS_HOME', groovyHome + "/apps")
        moreinfo.put('PYTHON_HOME', groovyHome + "/python")

        def jenv = loadClasses.get("JenkinsEnv")
        if (envMap) {
            jenv.setenv(envMap)
        }
        jenv.setenv(moreinfo)

        return loadClasses
    }

    static def runMethod(loadClasses, runClasses, info) {
        def envMap = info.get('envMap')
        def defaultClasses = ["modules/ExceptionHandler", "modules/PrintHandler", "modules/JenkinsEnv", "modules/LogHandler", "modules/RunShell", "modules/RunPython",
                              "modules/WorkUtils", "modules/JenkinsPageUpdate"]
        def status = 0

        if (envMap.get('FUNCTION_PRINT') == "true") {
            defaultClasses.add("modules/StackHandler")
        }

        loadClasses = loadClasses.trim()
        def lClasses = loadClasses.split(',')
        def rClasses = runClasses.split(',')

        def classes = []

        classes.addAll(defaultClasses)
        classes.addAll(lClasses)

        try {
            def jenkins_info = info
            implicitLoad(classes, info)
            def uniquelist = implicitList
            def myclasses = classLoader(uniquelist, jenkins_info)
            def phandler = myclasses.get("PrintHandler")
            def workutils = myclasses.get("WorkUtils")
            def nanoTime = System.nanoTime().toString()
            def logHandler = myclasses.get('LogHandler')
            def jenkinsEnv = myclasses.get('JenkinsEnv')
            def exceptionHandler = myclasses.get("ExceptionHandler")

            phandler.printConsole(phandler.emphasize("Classes loaded and initialized", '-', '-', 10))
            logHandler.createLogFile(info.get('appName'))
            initModulesInfo.each {
                phandler.printLog(it)
            }
            jenkinsEnv.printenvToLog()


            def tmp_work_area = workutils.createTmpWorkArea(null, nanoTime)
            jenkins_info.put('workarea', tmp_work_area)


            for (cl in rClasses) {
                def p = myclasses.get(cl)
                try {
                    phandler.printRawLog("Executing class: " + cl + "Class: " + p.getClass())
                    status +=  p.internalMain(jenkins_info)
                    phandler.printBoxLog("InternalMain returned ${status}")
                } catch (Exception e) {
                    phandler.printWarning("COULD NOT Execute class  " + cl + " because " + e.toString())
                    if (exceptionHandler) {
                        exceptionHandler.printExceptionStack(e)
                        status +=  1 
                    }
                }
            }
            workutils.removeTmpWorkArea(tmp_work_area)
            phandler.closeLogs()
        }
        catch (dlerror) {
            if (exceptionHandler) {
                initModulesInfo.addAll(exceptionHandler.getExceptionStack(dlerror))
                status += 1
            }
        }
        return status
    }
}

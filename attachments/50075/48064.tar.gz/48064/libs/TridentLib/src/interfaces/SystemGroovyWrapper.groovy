import hudson.*
import hudson.model.*
import jenkins.*
import jenkins.model.*

class SystemGroovyWrapperClass {
    def jenkins_info = [:]

    def getParams(buildInfo) {
        def params = [:]
        buildInfo.getActions(ParametersAction).each { action ->
            action.getAllParameters().each { param ->
                def value = param.getValue().trim()
                def name = param.getName().trim()
                params.put(name, value)
            }
        }
        return params
    }

    def getEnvironment(build, output, h_instance, j_instance) {
        def envMap = [:]
        def ignore_this = true
        try {
            envMap = h_instance.getGlobalNodeProperties()[0].getEnvVars()
        } catch (Exception e) {
            ignore_this = false
        }
        try {
            envMap = envMap + build.parent.builds[0].properties.get("envVars")
        }catch (Exception e) {
            ignore_this = false
        }
        try {
            envMap = envMap + System.getenv()
        } catch (Exception e) {
            ignore_this = false
        }
        return envMap
    }

    def getWorkSpace(envMap, output) {
        def workspace = envMap.get('WORKSPACE')
        if (!workspace) {
            workspace = new File('.').getAbsolutePath()
        }
        return workspace
    }

    def getLibrarySpace(loadFile, envMap, params, output) {

        def return_d = ""

        def file_d = new File(loadFile)
        def file_path = file_d.getAbsolutePath()
        if (file_path =~ /.*src.*/) {
            file_path = file_path.split('/src/')[0] + '/src'
        } else {
            def directory = file_d.getParentFile().getAbsolutePath()
            while (!directory.endsWith('apps') && directory =~ /\//) {
                def fd = new File(directory)
                directory = fd.getParentFile().getAbsolutePath()
            }
            if (directory.endsWith('apps')) {
                def fd = new File(directory)
                return fd.getParentFile().getAbsolutePath()
            }
            def homelist = ['TRIDENTLIBHOME','TRIGROOVYHOME', 'TRI_GROOVY_HOME', 'trigroovyHome', 'tri_groovy_Home']
            def tmp_file_path = null
            homelist.each { v ->
                if (!tmp_file_path) {
                    tmp_file_path = params.get(v) ?: envMap.get(v) ?: System.getenv(v)
                }
            }
            file_path = tmp_file_path
        }
        return_d = file_path
        return return_d
    }

    def getBuildStructure() {
        def build = Thread.currentThread().executable
/*        def jobName = buildArray[0]
        def buildNo = buildArray[1].toInteger()
        def item = hudson.model.Hudson.instance.getItem(jobName)
        def build_list = item.builds[0..-1]
        def listnumbers = []
        build_list.each { it ->
            String tmpstr = it
            if (tmpstr.find('#')) {
                tmpstr = tmpstr.split('#')[1].trim()
            }
            listnumbers.add(tmpstr.find((/\d+/)))
        }
        def ind = listnumbers.indexOf(buildNo)
        printHandler.printDebug("Index Found is " + ind)
        return build_list[ind]*/
        return build
    }

    def initializeSession(config, loadFile) {


        def buildManager = ''
        def build = getBuildStructure()
        def h_instance = Hudson.instance
        def j_instance = Jenkins.getInstance()
        def output = config['out']
        def err = output
        def envMap = getEnvironment(build, output, h_instance, j_instance)
        def jenkins_info = [:]

        config.each { k, v ->
            output.println(k + "=" + v)
        }

        jenkins_info.put('buildManager', buildManager)
        jenkins_info.put('h_instance', h_instance)
        jenkins_info.put('output', output)
        jenkins_info.put('err', err)
        jenkins_info.put('j_instance', j_instance)
        jenkins_info.put('build', build)
        jenkins_info.put('brickName', build.getBuiltOnStr())
        jenkins_info.put('params', getParams(build))
        jenkins_info.put('envMap', envMap)
        jenkins_info.put('library_space', getLibrarySpace(loadFile, envMap, jenkins_info.get('params'), output))
        jenkins_info.put('workspace', getWorkSpace(envMap, output))
        jenkins_info.put('buildResult', build.result)

        return jenkins_info
    }

    def runMethod(config, loadFile) {

        def File groovyFile
        def Class groovyClass
        def GroovyObject groovyObject
        def groovyFileName = loadFile
        def jenkins_info

        println('RunMethod Before Initialization')
        jenkins_info = initializeSession(config, loadFile)
        println('After Initialization')
        def output = jenkins_info.get('output')

        output.println("Loading ${groovyFileName}")
        groovyFile = new File(groovyFileName);

        def clazzLoader = Jenkins.getInstance().getPluginManager().uberClassLoader
        groovyClass = new GroovyClassLoader(clazzLoader).parseClass(groovyFile);

        groovyObject = groovyClass.newInstance()
        groovyObject.runMethod(jenkins_info)
    }

}

def main() {
    return SystemGroovyWrapperClass.newInstance()
}

main()

import hudson.*
import hudson.model.*
import jenkins.*
import jenkins.model.*

class PostGroovyWrapperClass {
    def jenkins_info = [:]

    static def getParams(buildInfo) {
        def params = [:]
        buildInfo.getActions(ParametersAction).each { action ->
            action.getAllParameters().each { param ->
                if (param) {
                    def value = param.getValue()
                    def name = param.getName()
                    if (value && value instanceof String) {
                        value = value.trim()
                    }
                    if (name) {
                        name = name.trim()
                    }
                    params.put(name, value)
                }
            }
        }
        return params
    }

    static def getJenkinsGlobalProperties(buildManager, h_instance, j_instance) {
        def globalMap = [:]
        def props
        try {
            props = j_instance.getGlobalNodeProperties()
        } catch (e) {
            props = Jenkins.getInstance().getGlobalNodeProperties()
        }

        def propList = props.getAll(hudson.slaves.EnvironmentVariablesNodeProperty.class)
        def vars = propList.get(0).getEnvVars()
        vars.each { k, v ->
            globalMap.put(k, v)
        }
        return globalMap
    }

    static def addtoMap(envMap, newMap, output) {
        newMap.each { k, v ->
            if (!envMap.get(k)) {
                //output.println("Adding new env value - ${k} = ${v}")
                envMap.put(k, v)
            }
        }
        return envMap
    }

    static def printEnvMap(envMap, time, output) {
        output.println("\n\n\nENVMAP version " + time)
        envMap.each { k, v ->
            output.println("${k}=${v}")
        }
    }

    static def getEnvironment(buildManager, h_instance, j_instance) {
        def envMap = [:]
        def output = buildManager.listener.logger
        try {
            output.println("STARTING GROOVY POST BUILD STEP PLEASE WAIT")
            output.println("-------------------------------------------")
            output.println("Getting instance variables ....")
            //printEnvMap(envMap, "Stage 1 Build Variables",output)
            envMap = addtoMap(envMap, buildManager.envVars, output)
            //printEnvMap(envMap, "Stage 2 Global Properties",output)
            envMap = addtoMap(envMap, getJenkinsGlobalProperties(buildManager, h_instance, j_instance), output)
            //printEnvMap(envMap, "Stage 3 System Properties",output)
            envMap = addtoMap(envMap, System.getenv(), output)
            //printEnvMap(envMap, "Stage 4",output)
        } catch (Exception e) {
            output.println("Failed to get environement " + e.toString())
        }
        return envMap
    }

    static def getWorkSpace(envMap, output) {
        def workspace = envMap.get('WORKSPACE')
        if (!workspace) {
            workspace = new File('.').getAbsolutePath()
        }
        return workspace
    }

    static def getLibrarySpace(envMap, output, groovyHome) {

        def return_d = groovyHome // GroovyHome is for hard coding debugging purposes

        // Search for debug variable then default variable if neither exists and groovyHome == "" or null return default value
        if (return_d == "" || (return_d && !new File(return_d).isDirectory())) {
            return_d = envMap.get('DEBUGTRIDENTGROOVY')
            if (!return_d) {
                return_d = envMap.get("TRIDENTLIBHOME") ?: envMap.get('TRIGROOVYHOME') ?: envMap.get('TRI_GROOVY_HOME')
            }
            def exists = false
            if (return_d) {
                def existing = new File(return_d)
                exists = existing.exists() && existing.isDirectory()
            }

            if (!exists) {
                if (envMap.get("JENKINS_URL").contains("qa")) {
                    return_d = "/root/TridentLib/src"
                } else {
                    return_d = "/home/jenkins-dev/TridentLib/src"
                }
            }
        }
        // output.println ("RETURNING " + return_d)
        return return_d
    }

    static def initializeSession(loadFile, manager, groovyHome) {
        def buildManager = manager
        def h_instance = Hudson.instance
        def j_instance = Jenkins.getInstance()
        def envMap = getEnvironment(buildManager, h_instance, j_instance)
        def jenkins_info = [:]

        def output = buildManager.listener.logger
        jenkins_info.put('buildManager', buildManager)
        jenkins_info.put('output', output)
        jenkins_info.put('err', output)
        jenkins_info.put('h_instance', h_instance)
        jenkins_info.put('j_instance', j_instance)
        jenkins_info.put('build', buildManager.build)
        jenkins_info.put('brickName', buildManager.build.getBuiltOnStr())
        jenkins_info.put('params', getParams(buildManager.build))

        jenkins_info.put('library_space', getLibrarySpace(envMap, output, groovyHome))
        envMap.put("TRI_GROOVY_HOME", jenkins_info.get('library_space'))
        envMap.put("TRIGROOVYHOME", jenkins_info.get('library_space'))
        envMap.put("TRIDENTLIBHOME", jenkins_info.get('library_space'))
        jenkins_info.put('envMap', envMap)
        jenkins_info.put('workspace', getWorkSpace(envMap, output))
        jenkins_info.put('buildResult', manager.build.result)
        // jenkins_info.each { k,v -> output.println(k + " = " + v)}
        return jenkins_info
    }

    def runMethod(loadFile, manager, groovyHome = "") {

//        def loadFile = sprintf("%s/%s", groovyHome, "DynamicClassMethod.groovy")


        def File groovyFile
        def Class groovyClass
        def GroovyObject groovyObject
        def groovyFileName = loadFile

        try {
            def jenkins_info = initializeSession(loadFile, manager, groovyHome)
            def output = jenkins_info.get('buildManager').listener.logger

            output.println("Now Loading ${groovyFileName} ...")
            groovyFile = new File(groovyFileName);

            def clazzLoader = Jenkins.getInstance().getPluginManager().uberClassLoader
            groovyClass = new GroovyClassLoader(clazzLoader).parseClass(groovyFile);

            groovyObject = groovyClass.newInstance()
            groovyObject.runMethod(jenkins_info)
        } catch (e) {
            manager.listener.logger.println ("We caught " + e.toString())
        }
    }
}

def main() {
    // this is a test
    return PostGroovyWrapperClass.newInstance()
}

main()

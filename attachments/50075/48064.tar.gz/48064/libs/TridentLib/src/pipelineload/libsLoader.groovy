


def loadLibrary(currentEnvironment, obj, library_space, workingDir)
{
    try {

       print "loadLibrary starting ...."

       //def String library_space = libFunc.getLibrarySpace()

       def info = [ 'cluster_workspace':workingDir,
                    'library_space':library_space,
                    'brickName':'dummy',
                    'work_area':workingDir,
                    'params':params,
                    'envMap':currentEnvironment,
                    'bManager':currentBuild.getRawBuild(),
                    'build':currentBuild,
                    'h_instance':Hudson.instance]

        def p = new PipelineLib()
        def lib=p.loadPipelineLibs(info,obj)

        if(lib.getClass().toString().contains("String")) { // if a string is returned there was an error during load print it here
            print "Loaded libs ..... returning " + lib
        }
        return lib
    } catch(Exception e){
        print "Error loading "+e.toString()
    }
}

def executeAPP (brickName, currentEnvironment, obj, library_space,workingDir) {
    def p = new PipelineWrapper()
    def returnVal = 9999
    //def String library_space = libFunc.getLibrarySpace()

    def info = ['cluster_workspace': workingDir,
                'library_space'    : library_space,
                'brickName'        : brickName,
                'params'           : params,
                'envMap'           : currentEnvironment,
                'bManager'         : currentBuild.getRawBuild(),
                'build'            : currentBuild,
                'h_instance'       : Hudson.instance]

    print ">>>> Running External APP"
    try {
      returnVal = p.runExternalClass(info, obj)
    } catch (e) {
        print(">>>> Exception: " + e.toString())
    }
    print ">>>> Run External finished"

    return returnVal
}

return this;

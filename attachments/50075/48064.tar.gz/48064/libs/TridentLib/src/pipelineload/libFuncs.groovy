// Functions and Global Variables useful when using external libraries

static def NODENAME = ''
static def workingDir = ''
static def clusterWorkspace = ''

def setWorkingDir() {
    this.workingDir = pwd()
}

String getNodeName() {
    return this.NODENAME
}
def setNodeName(name) {
    this.NODENAME = name
}
String getWorkingDir() {
    return this.workingDir
}

String setClusterWorkSpace(ws)
{
    this.clusterWorkspace = ws
}

String getClusterWorkSpace()
{
    return this.clusterWorkspace
}
String getLibrarySpace(libName) {
       return getWorkingDir().split('@')[0]+"@libs/${libName}/src"
}

return this;

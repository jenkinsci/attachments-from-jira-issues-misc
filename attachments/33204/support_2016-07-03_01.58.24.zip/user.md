User
====

Authentication
--------------

  * Authenticated: true
  * Name: mwaite
  * Authorities 
      - `sambashare`
      - `docker`
      - `dip`
      - `lpadmin`
      - `cdrom`
      - `mwaite`
      - `adm`
      - `sudo`
      - `plugdev`
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@4f0f23ba: Username: org.acegisecurity.userdetails.User@0: Username: mwaite; Password: [PROTECTED]; Enabled: true; AccountNonExpired: true; credentialsNonExpired: true; AccountNonLocked: true; Granted Authorities: sambashare, docker, dip, lpadmin, cdrom, mwaite, adm, sudo, plugdev, authenticated; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@0: RemoteIpAddress: 172.16.16.108; SessionId: u9gv1zmh08pcqx07vh5m8lxy; Granted Authorities: sambashare, docker, dip, lpadmin, cdrom, mwaite, adm, sudo, plugdev, authenticated`


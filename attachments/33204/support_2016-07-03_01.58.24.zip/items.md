Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 2
    - Number of items per container: 5.5 [n=2, s=0.7]
  * `com.github.mjdetullio.jenkins.plugins.multibranch.FreeStyleMultiBranchProject`
    - Number of items: 6
    - Number of items per container: 10.5 [n=6, s=8.0]
  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 1673
    - Number of builds per job: 6.971309025702332 [n=1673, s=8.788810811163366]
  * `hudson.matrix.MatrixProject`
    - Number of items: 59
    - Number of builds per job: 17.322033898305083 [n=59, s=10.0]
    - Number of items per container: 28.35593220338983 [n=59, s=20.0]
  * `hudson.maven.MavenModule`
    - Number of items: 2
    - Number of builds per job: 15.0 [n=2, s=0.0]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 2
    - Number of builds per job: 15.0 [n=2, s=0.0]
    - Number of items per container: 1.0 [n=2, s=0.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 246
    - Number of builds per job: 41.833333333333336 [n=246, s=160.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 41
    - Number of builds per job: 6.780487804878049 [n=41, s=10.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 5
    - Number of items per container: 7.2 [n=5, s=5.0]

Total job statistics
======================

  * Number of jobs: 2023
  * Number of builds per job: 11.524468610973802 [n=2023, s=58.43103816441391]

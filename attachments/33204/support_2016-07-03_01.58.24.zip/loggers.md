Loggers currently enabled
=========================
org.apache.sshd - WARNING
edu.umd.cs.findbugs - WARNING
winstone - INFO
 - INFO

Current build queue has 1 item(s).
---------------
 * Name of item: Git Plugin » multi-master
    - In queue for: 1 hr 4 min
    - Is blocked: true
    - Why in queue: Build #130 is already in progress (ETA:47 min)
    - Current queue trigger cause: Started by an SCM change
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@4511c3f2
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@1157684b
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@1801cd2
    - Can run: null
----


Monitors
========

`OldData`
--------------
  * Problematic object: `git-client-plugin/git-client-my-branches-new/ongoing%2Flatest-jenkins-release #25`
    -  1.651.2 -  1.651.2
  * Problematic object: `git-client-plugin/git-client-my-branches-new/ongoing%2Flatest-jenkins-release #26`
    -  1.651.2 -  1.651.2

`hudson.triggers.SCMTrigger$AdministrativeMonitorImpl`
--------------
(active and enabled)

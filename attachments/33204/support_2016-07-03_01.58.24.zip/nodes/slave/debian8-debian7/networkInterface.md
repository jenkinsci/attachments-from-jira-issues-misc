-----------
 * Name eth0
 ** Hardware Address - 0242ac110005
 ** Index - 10
 ** InetAddress - /fe80:0:0:0:42:acff:fe11:5%eth0
 ** InetAddress - /172.17.0.5
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

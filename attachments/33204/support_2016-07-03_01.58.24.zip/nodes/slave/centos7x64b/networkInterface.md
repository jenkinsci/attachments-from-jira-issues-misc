-----------
 * Name veth707c735
 ** Hardware Address - c652ea57ccac
 ** Index - 9
 ** InetAddress - /fe80:0:0:0:c452:eaff:fe57:ccac%veth707c735
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 024274f80264
 ** Index - 5
 ** InetAddress - /fe80:0:0:0:42:74ff:fef8:264%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name virbr0
 ** Hardware Address - 525400187413
 ** Index - 3
 ** InetAddress - /192.168.122.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name enp2s0
 ** Hardware Address - 0024e83f7a5c
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:224:e8ff:fe3f:7a5c%enp2s0
 ** InetAddress - /172.16.16.119
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

Node statistics
===============

  * Total number of nodes
      - Sample size:        4308
      - Average (mean):     24.000000000000004
      - Average (median):   24.0
      - Standard deviation: 3.552713678800501E-15
      - Minimum:            24
      - Maximum:            24
      - 95th percentile:    24.0
      - 99th percentile:    24.0
  * Total number of nodes online
      - Sample size:        4308
      - Average (mean):     10.0
      - Average (median):   10.0
      - Standard deviation: 9.208229169423812E-16
      - Minimum:            9
      - Maximum:            10
      - 95th percentile:    10.0
      - 99th percentile:    10.0
  * Total number of executors
      - Sample size:        4308
      - Average (mean):     27.0
      - Average (median):   27.0
      - Standard deviation: 5.524937501654287E-15
      - Minimum:            21
      - Maximum:            27
      - 95th percentile:    27.0
      - 99th percentile:    27.0
  * Total number of executors in use
      - Sample size:        4308
      - Average (mean):     7.983630525219006
      - Average (median):   8.0
      - Standard deviation: 0.2189843693395659
      - Minimum:            2
      - Maximum:            26
      - 95th percentile:    8.0
      - 99th percentile:    8.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/var/lib/jenkins`
      - Labels:         non-existent-slave
      - Usage:          `EXCLUSIVE`
      - Slave Version:  2.59
      - Java
          + Home:           `/usr/lib/jvm/java-7-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_80
          + Maximum memory:   1.32 GB (1420820480)
          + Allocated memory: 365.00 MB (382730240)
          + Free memory:      154.27 MB (161766344)
          + In-use memory:    210.73 MB (220963896)
          + PermGen used:     113.17 MB (118669848)
          + PermGen max:      768.00 MB (805306368)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.80-b11
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.2.0-41-generic
          + Distribution: Ubuntu 14.04.4 LTS
      - Process ID: 2779 (0xadb)
      - Process started: 2016-07-02 02:01:09.665-0600
      - Process uptime: 17 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-7-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-7-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-7-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-7-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-7-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-7-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-7-oracle/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`
          + arg[1]: `-Xmx1524m`
          + arg[2]: `-XX:MaxPermSize=768m`

  * centos67a (`hudson.slaves.DumbSlave`)
      - Description:    _CentOS 6.7 x64_
      - Executors:      1
      - Remote FS root: `/home/jenkins/mark-pc1-slave`
      - Labels:         git-1.7.1 32bit
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el6.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_91
          + Maximum memory:   638.50 MB (669515776)
          + Allocated memory: 107.50 MB (112721920)
          + Free memory:      36.60 MB (38380560)
          + In-use memory:    70.90 MB (74341360)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.91-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-642.1.1.el6.x86_64
          + Distribution: "CentOS release 6.8 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 2537 (0x9e9)
      - Process started: 2016-07-02 02:01:27.744-0600
      - Process uptime: 17 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el6.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el6.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el6.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el6.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el6.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el6.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el6.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el6.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * centos7x64 (`hudson.slaves.DumbSlave`)
      - Description:    _CentOS 7 x64_
      - Executors:      2
      - Remote FS root: `/var/lib/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/java/jdk1.8.0_73/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_73
          + Maximum memory:   830.50 MB (870842368)
          + Allocated memory: 129.00 MB (135266304)
          + Free memory:      54.66 MB (57318608)
          + In-use memory:    74.34 MB (77947696)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.73-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-327.22.2.el7.x86_64
          + Distribution: "CentOS Linux release 7.2.1511 (Core) "
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
      - Process ID: 8832 (0x2280)
      - Process started: 2016-07-02 02:01:27.386-0600
      - Process uptime: 17 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_73/jre/lib/resources.jar:/usr/java/jdk1.8.0_73/jre/lib/rt.jar:/usr/java/jdk1.8.0_73/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_73/jre/lib/jsse.jar:/usr/java/jdk1.8.0_73/jre/lib/jce.jar:/usr/java/jdk1.8.0_73/jre/lib/charsets.jar:/usr/java/jdk1.8.0_73/jre/lib/jfr.jar:/usr/java/jdk1.8.0_73/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * centos7x64b (`hudson.slaves.DumbSlave`)
      - Description:    _CentOS 7 x64_
      - Executors:      2
      - Remote FS root: `/home/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/java/jdk1.8.0_73/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_73
          + Maximum memory:   429.25 MB (450101248)
          + Allocated memory: 27.12 MB (28442624)
          + Free memory:      3.60 MB (3775440)
          + In-use memory:    23.52 MB (24667184)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.73-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-327.18.2.el7.x86_64
          + Distribution: "CentOS Linux release 7.2.1511 (Core) "
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
      - Process ID: 23612 (0x5c3c)
      - Process started: 2016-07-02 14:17:18.522-0600
      - Process uptime: 5 hr 41 min
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_73/jre/lib/resources.jar:/usr/java/jdk1.8.0_73/jre/lib/rt.jar:/usr/java/jdk1.8.0_73/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_73/jre/lib/jsse.jar:/usr/java/jdk1.8.0_73/jre/lib/jce.jar:/usr/java/jdk1.8.0_73/jre/lib/charsets.jar:/usr/java/jdk1.8.0_73/jre/lib/jfr.jar:/usr/java/jdk1.8.0_73/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * coleen-pc2 (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 10 x64_
      - Executors:      4
      - Remote FS root: `C:\J`
      - Labels:         32bit
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53.2
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_92`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_92
          + Maximum memory:   866.00 MB (908066816)
          + Allocated memory: 281.00 MB (294649856)
          + Free memory:      73.93 MB (77518648)
          + In-use memory:    207.07 MB (217131208)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.92-b14
      - Operating system
          + Name:         Windows 10
          + Architecture: amd64
          + Version:      10.0
      - Process ID: 5776 (0x1690)
      - Process started: 2016-06-30 09:14:35.146-0600
      - Process uptime: 2 days 10 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_92\lib\resources.jar;C:\Program Files\Java\jre1.8.0_92\lib\rt.jar;C:\Program Files\Java\jre1.8.0_92\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_92\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_92\lib\jce.jar;C:\Program Files\Java\jre1.8.0_92\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_92\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_92\classes`
          + Classpath: `slave.jar`
          + Library path: `C:\ProgramData\Oracle\Java\javapath;C:\WINDOWS\Sun\Java\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\ProgramData\Oracle\Java\javapath;C:\Program Files\Common Files\Microsoft Shared\Windows Live;C:\Program Files (x86)\Common Files\Microsoft Shared\Windows Live;%JAVA_HOME%\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\apache-maven-3.3.9\bin;C:\apache-ant-1.9.3\bin;C:\Program Files (x86)\Microsoft SQL Server\100\Tools\Binn\;C:\Program Files\Microsoft SQL Server\100\Tools\Binn\;C:\Program Files\Microsoft SQL Server\100\DTS\Binn\;C:\Program Files (x86)\Windows Live\Shared;C:\emacs-24.3\bin;C:\Python27;C:\Python27\Scripts;C:\Program Files (x86)\PICT\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files (x86)\Skype\Phone\;C:\Program Files\Git\cmd;C:\Users\Coleen\AppData\Local\Programs\Python\Python35-32\Scripts\;C:\Users\Coleen\AppData\Local\Programs\Python\Python35-32\;.`

  * coleen-pc3 (`hudson.slaves.DumbSlave`)
      - Description:    _Coleen's Windows 7 Computer_
      - Executors:      4
      - Remote FS root: `C:\J`
      - Labels:         visual-studio-2010 32bit
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_92`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_92
          + Maximum memory:   1.73 GB (1862270976)
          + Allocated memory: 691.00 MB (724566016)
          + Free memory:      63.79 MB (66893448)
          + In-use memory:    627.21 MB (657672568)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.92-b14
      - Operating system
          + Name:         Windows 10
          + Architecture: amd64
          + Version:      10.0
      - Process ID: 788 (0x314)
      - Process started: 2016-06-30 09:04:14.332-0600
      - Process uptime: 2 days 10 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_92\lib\resources.jar;C:\Program Files\Java\jre1.8.0_92\lib\rt.jar;C:\Program Files\Java\jre1.8.0_92\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_92\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_92\lib\jce.jar;C:\Program Files\Java\jre1.8.0_92\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_92\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_92\classes;C:\Program Files\Java\jre1.8.0_92\lib\deploy.jar;C:\Program Files\Java\jre1.8.0_92\lib\javaws.jar;C:\Program Files\Java\jre1.8.0_92\lib\plugin.jar`
          + Classpath: `C:\Program Files\Java\jre1.8.0_92\lib\deploy.jar`
          + Library path: `C:\Program Files\Java\jre1.8.0_92\bin;C:\WINDOWS\Sun\Java\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\Program Files\Java\jre1.8.0_92\bin;C:\ProgramData\Oracle\Java\javapath;%JAVA_HOME%\bin;C:\apache-maven-3.3.9\bin;C:\apache-ant-1.9.3\bin;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\Program Files\Intel\WiFi\bin\;C:\Program Files\Common Files\Intel\WirelessCommon\;C:\Program Files\WIDCOMM\Bluetooth Software\;C:\Program Files\WIDCOMM\Bluetooth Software\syswow64;C:\emacs-24.3\bin;C:\Python27;C:\Program Files (x86)\Skype\Phone\;C:\Program Files\Git\cmd;C:\Program Files\Git\bin;"C:\Program Files\Java\jre1.8.0_92\bin";.`
          + arg[0]: `-Xbootclasspath/a:C:\Program Files\Java\jre1.8.0_92\lib\deploy.jar;C:\Program Files\Java\jre1.8.0_92\lib\javaws.jar;C:\Program Files\Java\jre1.8.0_92\lib\plugin.jar`
          + arg[1]: `-Xverify:remote`
          + arg[2]: `-Djava.security.manager`
          + arg[3]: `-Djava.security.policy=file:C:\Program Files\Java\jre1.8.0_92\lib\security\javaws.policy`
          + arg[4]: `-DtrustProxy=true`
          + arg[5]: `-Djnlpx.home=C:\Program Files\Java\jre1.8.0_92\bin`
          + arg[6]: `-Djnlpx.origFilenameArg=C:\Users\Mark\Desktop\Jenkins-slave-agent.jnlp`
          + arg[7]: `-Djnlpx.remove=true`
          + arg[8]: `-Djnlpx.splashport=50869`
          + arg[9]: `-Djnlpx.jvm=C:\Program Files\Java\jre1.8.0_92\bin\javaw.exe`

  * debian8 (`hudson.slaves.DumbSlave`)
      - Description:    _Debian 8 (Testing)_
      - Executors:      2
      - Remote FS root: `/home/jenkins/mark-pc1-slave`
      - Labels:         32bit docker
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_91
          + Maximum memory:   1.71 GB (1836580864)
          + Allocated memory: 151.50 MB (158859264)
          + Free memory:      84.60 MB (88709576)
          + In-use memory:    66.90 MB (70149688)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.91-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.16.0-4-amd64
          + Distribution: Debian GNU/Linux 8.5 (jessie)
      - Process ID: 31373 (0x7a8d)
      - Process started: 2016-07-02 02:01:49.321-0600
      - Process uptime: 17 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.io.tmpdir=/home/jenkins/tmp/`

  * debian8-debian7 (`hudson.slaves.DumbSlave`)
      - Description:    _Debian Wheezy x64_
      - Executors:      2
      - Remote FS root: `/home/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_66
          + Maximum memory:   1.71 GB (1836580864)
          + Allocated memory: 164.50 MB (172490752)
          + Free memory:      113.49 MB (119000472)
          + In-use memory:    51.01 MB (53490280)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.66-b17
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.16.0-4-amd64
          + Distribution: Debian GNU/Linux 7.9 (wheezy)
          + LSB Modules:  `core-2.0-amd64:core-2.0-noarch:core-3.0-amd64:core-3.0-noarch:core-3.1-amd64:core-3.1-noarch:core-3.2-amd64:core-3.2-noarch:core-4.0-amd64:core-4.0-noarch:core-4.1-amd64:core-4.1-noarch:cxx-3.0-amd64:cxx-3.0-noarch:cxx-3.1-amd64:cxx-3.1-noarch:cxx-3.2-amd64:cxx-3.2-noarch:cxx-4.0-amd64:cxx-4.0-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-3.1-amd64:desktop-3.1-noarch:desktop-3.2-amd64:desktop-3.2-noarch:desktop-4.0-amd64:desktop-4.0-noarch:desktop-4.1-amd64:desktop-4.1-noarch:graphics-2.0-amd64:graphics-2.0-noarch:graphics-3.0-amd64:graphics-3.0-noarch:graphics-3.1-amd64:graphics-3.1-noarch:graphics-3.2-amd64:graphics-3.2-noarch:graphics-4.0-amd64:graphics-4.0-noarch:graphics-4.1-amd64:graphics-4.1-noarch:languages-3.2-amd64:languages-3.2-noarch:languages-4.0-amd64:languages-4.0-noarch:languages-4.1-amd64:languages-4.1-noarch:multimedia-3.2-amd64:multimedia-3.2-noarch:multimedia-4.0-amd64:multimedia-4.0-noarch:multimedia-4.1-amd64:multimedia-4.1-noarch:printing-3.2-amd64:printing-3.2-noarch:printing-4.0-amd64:printing-4.0-noarch:printing-4.1-amd64:printing-4.1-noarch:qt4-3.1-amd64:qt4-3.1-noarch:security-4.0-amd64:security-4.0-noarch:security-4.1-amd64:security-4.1-noarch`
      - Process ID: 20851 (0x5173)
      - Process started: 2016-07-02 08:02:23.029+0000
      - Process uptime: 17 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * debian8-ubuntu12 (`hudson.slaves.DumbSlave`)
      - Description:    _Ubuntu 12.04_
      - Executors:      2
      - Remote FS root: `/home/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_91
          + Maximum memory:   1.71 GB (1836056576)
          + Allocated memory: 115.50 MB (121110528)
          + Free memory:      96.70 MB (101393320)
          + In-use memory:    18.80 MB (19717208)
          + PermGen used:     14.85 MB (15575144)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.91-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.16.0-4-amd64
          + Distribution: Ubuntu 12.04.5 LTS
          + LSB Modules:  `core-2.0-amd64:core-2.0-noarch:core-3.0-amd64:core-3.0-noarch:core-3.1-amd64:core-3.1-noarch:core-3.2-amd64:core-3.2-noarch:core-4.0-amd64:core-4.0-noarch:cxx-3.0-amd64:cxx-3.0-noarch:cxx-3.1-amd64:cxx-3.1-noarch:cxx-3.2-amd64:cxx-3.2-noarch:cxx-4.0-amd64:cxx-4.0-noarch:desktop-3.1-amd64:desktop-3.1-noarch:desktop-3.2-amd64:desktop-3.2-noarch:desktop-4.0-amd64:desktop-4.0-noarch:graphics-2.0-amd64:graphics-2.0-noarch:graphics-3.0-amd64:graphics-3.0-noarch:graphics-3.1-amd64:graphics-3.1-noarch:graphics-3.2-amd64:graphics-3.2-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-3.2-amd64:printing-3.2-noarch:printing-4.0-amd64:printing-4.0-noarch:qt4-3.1-amd64:qt4-3.1-noarch`
      - Process ID: 1122 (0x462)
      - Process started: 2016-07-02 08:02:27.720+0000
      - Process uptime: 17 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`

  * debian8x86a (`hudson.slaves.DumbSlave`)
      - Description:    _Debian 8 Squeeze_
      - Executors:      2
      - Remote FS root: `/home/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_91
          + Maximum memory:   247.50 MB (259522560)
          + Allocated memory: 15.50 MB (16252928)
          + Free memory:      7.10 MB (7444392)
          + In-use memory:    8.40 MB (8808536)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Oracle Corporation
          + Version: 25.91-b14
      - Operating system
          + Name:         Linux
          + Architecture: i386
          + Version:      3.16.0-4-686-pae
          + Distribution: Debian GNU/Linux 8.5 (jessie)
      - Process ID: 5727 (0x165f)
      - Process started: 2016-07-02 14:17:16.754-0600
      - Process uptime: 5 hr 41 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/i386:/lib:/usr/lib`
          + arg[0]: `-Djava.io.tmpdir=/home/jenkins/tmp/`

  * debian9a (`hudson.slaves.DumbSlave`)
      - Description:    _Debian Testing x64_
      - Executors:      2
      - Remote FS root: `/home/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * family-win7-a (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 7 x64_
      - Executors:      1
      - Remote FS root: `C:\E\J`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * ubuntu14a (`hudson.slaves.DumbSlave`)
      - Description:    _Ubuntu 14.04_
      - Executors:      1
      - Remote FS root: `/home/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_91
          + Maximum memory:   876.50 MB (919076864)
          + Allocated memory: 97.00 MB (101711872)
          + Free memory:      83.41 MB (87460520)
          + In-use memory:    13.59 MB (14251352)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.91-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.16.0-73-generic
          + Distribution: Ubuntu 14.04.4 LTS
      - Process ID: 682 (0x2aa)
      - Process started: 2016-07-02 14:17:17.136-0600
      - Process uptime: 5 hr 41 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * ubuntu14a-debian6 (`hudson.slaves.DumbSlave`)
      - Description:    _Debian Squeeze_
      - Executors:      1
      - Remote FS root: `/home/jenkins/mark-pc1-debian6-slave`
      - Labels:         git-1.7.1
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_66
          + Maximum memory:   876.50 MB (919076864)
          + Allocated memory: 76.50 MB (80216064)
          + Free memory:      49.54 MB (51950216)
          + In-use memory:    26.96 MB (28265848)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.66-b17
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.16.0-73-generic
          + Distribution: Debian GNU/Linux 6.0.10 (squeeze)
          + LSB Modules:  `core-2.0-amd64:core-2.0-noarch:core-3.0-amd64:core-3.0-noarch:core-3.1-amd64:core-3.1-noarch:core-3.2-amd64:core-3.2-noarch:cxx-3.0-amd64:cxx-3.0-noarch:cxx-3.1-amd64:cxx-3.1-noarch:cxx-3.2-amd64:cxx-3.2-noarch:desktop-3.1-amd64:desktop-3.1-noarch:desktop-3.2-amd64:desktop-3.2-noarch:graphics-2.0-amd64:graphics-2.0-noarch:graphics-3.0-amd64:graphics-3.0-noarch:graphics-3.1-amd64:graphics-3.1-noarch:graphics-3.2-amd64:graphics-3.2-noarch:qt4-3.1-amd64:qt4-3.1-noarch`
      - Process ID: 12 (0xc)
      - Process started: 2016-07-02 20:17:16.800+0000
      - Process uptime: 4 hr 57 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * ubuntu14b (`hudson.slaves.DumbSlave`)
      - Description:    _Ubuntu 14.04_
      - Executors:      1
      - Remote FS root: `/home/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_91
          + Maximum memory:   1.24 GB (1333264384)
          + Allocated memory: 87.00 MB (91226112)
          + Free memory:      65.67 MB (68859744)
          + In-use memory:    21.33 MB (22366368)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.91-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.16.0-73-generic
          + Distribution: Ubuntu 14.04.4 LTS
      - Process ID: 8211 (0x2013)
      - Process started: 2016-07-02 14:17:21.702-0600
      - Process uptime: 5 hr 41 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * ubuntu14b-ubuntu15 (`hudson.slaves.DumbSlave`)
      - Description:    _Ubuntu 15.10_
      - Executors:      1
      - Remote FS root: `/home/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_91
          + Maximum memory:   1.24 GB (1332740096)
          + Allocated memory: 86.50 MB (90701824)
          + Free memory:      72.88 MB (76418608)
          + In-use memory:    13.62 MB (14283216)
          + PermGen used:     14.81 MB (15527384)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.91-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.16.0-73-generic
          + Distribution: Ubuntu 15.10
          + LSB Modules:  `core-2.0-amd64:core-2.0-noarch:core-3.0-amd64:core-3.0-noarch:core-3.1-amd64:core-3.1-noarch:core-3.2-amd64:core-3.2-noarch:core-4.0-amd64:core-4.0-noarch:core-4.1-amd64:core-4.1-noarch:cxx-3.0-amd64:cxx-3.0-noarch:cxx-3.1-amd64:cxx-3.1-noarch:cxx-3.2-amd64:cxx-3.2-noarch:cxx-4.0-amd64:cxx-4.0-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-3.1-amd64:desktop-3.1-noarch:desktop-3.2-amd64:desktop-3.2-noarch:desktop-4.0-amd64:desktop-4.0-noarch:desktop-4.1-amd64:desktop-4.1-noarch:graphics-2.0-amd64:graphics-2.0-noarch:graphics-3.0-amd64:graphics-3.0-noarch:graphics-3.1-amd64:graphics-3.1-noarch:graphics-3.2-amd64:graphics-3.2-noarch:graphics-4.0-amd64:graphics-4.0-noarch:graphics-4.1-amd64:graphics-4.1-noarch:languages-3.2-amd64:languages-3.2-noarch:languages-4.0-amd64:languages-4.0-noarch:languages-4.1-amd64:languages-4.1-noarch:multimedia-3.2-amd64:multimedia-3.2-noarch:multimedia-4.0-amd64:multimedia-4.0-noarch:multimedia-4.1-amd64:multimedia-4.1-noarch:printing-3.2-amd64:printing-3.2-noarch:printing-4.0-amd64:printing-4.0-noarch:printing-4.1-amd64:printing-4.1-noarch:qt4-3.1-amd64:qt4-3.1-noarch:security-4.0-amd64:security-4.0-noarch:security-4.1-amd64:security-4.1-noarch`
      - Process ID: 35 (0x23)
      - Process started: 2016-07-02 20:17:18.734+0000
      - Process uptime: 5 hr 41 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`

  * ubuntu14c (`hudson.slaves.DumbSlave`)
      - Description:    _Ubuntu 14.04_
      - Executors:      1
      - Remote FS root: `/home/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_91
          + Maximum memory:   1.07 GB (1152385024)
          + Allocated memory: 94.00 MB (98566144)
          + Free memory:      50.21 MB (52650032)
          + In-use memory:    43.79 MB (45916112)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.91-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.2.0-38-generic
          + Distribution: Ubuntu 14.04.4 LTS
      - Process ID: 7867 (0x1ebb)
      - Process started: 2016-07-02 14:17:17.062-0600
      - Process uptime: 5 hr 41 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * waima04-rhel7 (`hudson.slaves.DumbSlave`)
      - Description:    _Red Hat Enterprise Developer 7 x64_
      - Executors:      6
      - Remote FS root: `/var/lib/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/java/jdk1.8.0_91/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_91
          + Maximum memory:   1.71 GB (1840250880)
          + Allocated memory: 109.00 MB (114294784)
          + Free memory:      62.92 MB (65973592)
          + In-use memory:    46.08 MB (48321192)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.91-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-327.22.2.el7.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 7.2 (Maipo)"
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch`
      - Process ID: 11160 (0x2b98)
      - Process started: 2016-07-02 18:41:24.457-0600
      - Process uptime: 1 hr 17 min
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_91/jre/lib/resources.jar:/usr/java/jdk1.8.0_91/jre/lib/rt.jar:/usr/java/jdk1.8.0_91/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_91/jre/lib/jsse.jar:/usr/java/jdk1.8.0_91/jre/lib/jce.jar:/usr/java/jdk1.8.0_91/jre/lib/charsets.jar:/usr/java/jdk1.8.0_91/jre/lib/jfr.jar:/usr/java/jdk1.8.0_91/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * waite2011 (`hudson.slaves.DumbSlave`)
      - Description:    _Windows Home Server 2011_
      - Executors:      2
      - Remote FS root: `J:\Jenkins`
      - Labels:         visual-studio-2010 32bit
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.47
      - Java
          + Home:           `D:\Program Files\Java\jdk1.8.0_40\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_40
          + Maximum memory:   907.00 MB (951058432)
          + Allocated memory: 358.00 MB (375390208)
          + Free memory:      309.31 MB (324334880)
          + In-use memory:    48.69 MB (51055328)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.40-b25
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 2200 (0x898)
      - Process started: 2016-07-02 08:38:45.584-0600
      - Process uptime: 11 hr
      - JVM startup parameters:
          + Boot classpath: `D:\Program Files\Java\jdk1.8.0_40\jre\lib\resources.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\rt.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\sunrsasign.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\jsse.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\jce.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\charsets.jar;D:\Program Files\Java\jdk1.8.0_40\jre\lib\jfr.jar;D:\Program Files\Java\jdk1.8.0_40\jre\classes`
          + Classpath: `bin\slave.jar`
          + Library path: `D:\Program Files\Java\jdk1.8.0_40\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;tools;J:\Jenkins\bin;D:\Program Files\Java\jdk1.8.0_40\bin;C:\Program Files (x86)\Microsoft Visual Studio 10.0\VSTSDB\Deploy;C:\Program Files (x86)\Microsoft Visual Studio 10.0\Common7\IDE\;C:\Program Files (x86)\Microsoft Visual Studio 10.0\VC\BIN;C:\Program Files (x86)\Microsoft Visual Studio 10.0\Common7\Tools;C:\Windows\Microsoft.NET\Framework\v4.0.30319;C:\Windows\Microsoft.NET\Framework\v3.5;C:\Program Files (x86)\Microsoft Visual Studio 10.0\VC\VCPackages;C:\Program Files (x86)\HTML Help Workshop;C:\Program Files (x86)\Microsoft Visual Studio 10.0\Team Tools\Performance Tools;c:\Program Files (x86)\Microsoft SDKs\Windows\v7.0A\bin\NETFX 4.0 Tools;c:\Program Files (x86)\Microsoft SDKs\Windows\v7.0A\bin;C:\ProgramData\Oracle\Java\javapath;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files (x86)\Microsoft SQL Server\100\Tools\Binn\;C:\Program Files\Microsoft SQL Server\100\Tools\Binn\;C:\Program Files\Microsoft SQL Server\100\DTS\Binn\;D:\Python27;D:\Python27\Scripts;D:\Program Files (x86)\NUnit 2.6.2\bin;D:\apache-maven-3.1.1\bin;D:\Program Files\Java\jdk1.8.0_40\bin;D:\Program Files\Git\cmd;D:\emacs-24.1\bin;D:\Program Files (x86)\Git\bin;D:\apache-ant-1.8.4\bin;.`

  * wheezy64b (`hudson.slaves.DumbSlave`)
      - Description:    _Debian Wheezy x64_
      - Executors:      1
      - Remote FS root: `/var/lib/jenkins/mark-pc1-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * win10x64a (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 10 x64_
      - Executors:      2
      - Remote FS root: `C:\J`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * win10x64b (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 10 x64_
      - Executors:      2
      - Remote FS root: `C:\J`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * win7x64a (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 7 x64_
      - Executors:      2
      - Remote FS root: `C:\J`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * win7x86a (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 7 x86_
      - Executors:      2
      - Remote FS root: `C:\J`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line


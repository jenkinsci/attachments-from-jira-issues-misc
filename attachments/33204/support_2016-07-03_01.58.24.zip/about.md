Jenkins
=======

Version details
---------------

  * Version: `1.651.3`
  * Mode:    WAR
  * Url:     http://mark-pc1.markwaite.net:8080/
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.9`
  * Java
      - Home:           `/usr/lib/jvm/java-7-oracle/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_80
      - Maximum memory:   1.32 GB (1420820480)
      - Allocated memory: 352.50 MB (369623040)
      - Free memory:      101.76 MB (106707304)
      - In-use memory:    250.74 MB (262915736)
      - PermGen used:     113.17 MB (118669848)
      - PermGen max:      768.00 MB (805306368)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.80-b11
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.2.0-41-generic
      - Distribution: Ubuntu 14.04.4 LTS
  * Process ID: 2779 (0xadb)
  * Process started: 2016-07-02 02:01:09.665-0600
  * Process uptime: 17 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-7-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-7-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-7-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-7-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-7-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-7-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-7-oracle/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`
      - arg[1]: `-Xmx1524m`
      - arg[2]: `-XX:MaxPermSize=768m`

Important configuration
---------------

  * Security realm: `hudson.security.PAMSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-core:1.78 'Static Analysis Utilities'
  * ant:1.3 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * bitbucket:1.1.5 'Jenkins Bitbucket Plugin'
  * branch-api:1.10 'Branch API Plugin'
  * build-flow-plugin:0.19 'Build Flow plugin'
  * build-name-setter:1.6.5 'build-name-setter'
  * build-timeout:1.17 'Jenkins build timeout plugin'
  * cloudbees-folder:5.12 'Folders Plugin'
  * conditional-buildstep:1.3.5 'Conditional BuildStep'
  * config-file-provider:2.11 'Config File Provider Plugin'
  * configurationslicing:1.45 'Configuration Slicing plugin'
  * credentials:2.1.4 'Credentials Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * depgraph-view:0.11 'Dependency Graph Viewer Plugin'
  * description-setter:1.10 'Jenkins description setter plugin'
  * durable-task:1.11 'Durable Task Plugin'
  * elastic-axis:1.2 'elastic-axis'
  * email-ext:2.44 'Email Extension Plugin'
  * envinject:1.92.1 'Environment Injector Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * file-leak-detector:1.4 'CloudBees File Leak Detector Plugin'
  * findbugs:4.65 'FindBugs Plug-in'
  * git:2.5.1-SNAPSHOT (private-d0c92bc5-mwaite) 'Jenkins Git plugin'
  * git-client:1.19.6 'Jenkins Git client plugin'
  * git-parameter:0.5.1 'Git Parameter Plug-In'
  * git-server:1.6 'Git server plugin'
  * git-userContent:1.4 '/userContent in Git plugin'
  * github:1.19.2 'GitHub plugin'
  * github-api:1.76 'GitHub API Plugin'
  * gravatar:2.1 'Jenkins Gravatar plugin'
  * groovy-postbuild:2.3.1 'Groovy Postbuild'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * hgca:1.3 'Hudson Generic Changelog Annotator Plugin'
  * htmlpublisher:1.11 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * implied-labels:0.5 'Implied Labels Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * jacoco:2.0.1 'Jenkins JaCoCo plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * junit:1.13 'JUnit Plugin'
  * ldap:1.12 'LDAP Plugin'
  * leastload:1.0.3 'Least Load plugin'
  * log-parser:2.0 'Log Parser Plugin'
  * mailer:1.17 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.4 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.7.1 'Matrix Project Plugin'
  * maven-plugin:2.13 'Maven Integration plugin'
  * mercurial:1.55 'Jenkins Mercurial plugin'
  * metrics:3.1.2.8 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * multi-branch-project-plugin:0.5 'Multi-Branch Project Plugin'
  * multiple-scms:0.6 'Jenkins Multiple SCMs plugin'
  * nested-view:1.14 'Nested View Plugin'
  * nodelabelparameter:1.7.2 'Node and Label parameter plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parallel-test-executor:1.8 'Jenkins Parallel Test Executor Plugin'
  * parameterized-trigger:2.31 'Jenkins Parameterized Trigger plugin'
  * pegdown-formatter:1.3 'PegDown Formatter Plugin'
  * pipeline-build-step:2.1 'Pipeline: Build Step'
  * pipeline-input-step:2.0 'Pipeline: Input Step'
  * pipeline-rest-api:1.5 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.1 'Pipeline: Stage Step'
  * pipeline-stage-view:1.5 'Pipeline: Stage View Plugin'
  * plain-credentials:1.2 'Plain Credentials Plugin'
  * platformlabeler:1.1 'Hudson platformlabeler plugin'
  * pollscm:1.3 'Jenkins Poll SCM plugin'
  * postbuildscript:0.17 'Jenkins Post-Build Script Plug-in'
  * preSCMbuildstep:0.3 'Pre SCM BuildStep Plugin'
  * project-description-setter:1.1 'Project Description Setter'
  * promoted-builds:2.27 'Jenkins promoted builds plugin'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:1.2 'SCM API Plugin'
  * script-security:1.20 'Script Security Plugin'
  * sidebar-link:1.7 'Sidebar Link'
  * ssh-credentials:1.12 'SSH Credentials Plugin'
  * ssh-slaves:1.11 'Jenkins SSH Slaves plugin'
  * structs:1.2 'Structs Plugin'
  * subversion:2.6 'Jenkins Subversion Plug-in'
  * support-core:2.32 'Support Core Plugin'
  * swarm:2.1 'Jenkins Self-Organizing Swarm Plug-in Modules'
  * text-finder:1.10 'Jenkins TextFinder plugin'
  * token-macro:1.12.1 'Token Macro Plugin'
  * tool-labels-plugin:3.0 'Tool Labels Plugin for Jenkins'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * valgrind:0.27 'Jenkins Valgrind Plug-in'
  * view-job-filters:1.27 'View Job Filters'
  * warnings:4.56 'Warnings Plug-in'
  * windows-slaves:1.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.2 'Pipeline'
  * workflow-api:2.1 'Pipeline: API'
  * workflow-basic-steps:2.0 'Pipeline: Basic Steps'
  * workflow-cps:2.8 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.1 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.3 'Pipeline: Nodes and Processes'
  * workflow-job:2.3 'Pipeline: Job'
  * workflow-multibranch:2.8 'Pipeline: Multibranch'
  * workflow-scm-step:2.1 'Pipeline: SCM Step'
  * workflow-step-api:2.2 'Pipeline: Step API'
  * workflow-support:2.1 'Pipeline: Supporting APIs'
  * xshell:0.10 'Jenkins cross-platform shell plugin'
  * xunit:1.102 'xUnit plugin'
  * xvnc:1.23 'Jenkins Xvnc plugin'

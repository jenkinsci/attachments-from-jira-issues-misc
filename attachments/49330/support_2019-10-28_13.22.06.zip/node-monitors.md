Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * worker-1: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * worker-1: 3 min 1 sec behind
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: 41.814GB left on /var/jenkins_home.
   * worker-1: 56.401GB left on /home/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:4685/19912MB  Swap:2668/10047MB
   * worker-1: Memory:6962/16010MB  Swap:7991/8127MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: 41.814GB left on /tmp.
   * worker-1: 41.973GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * worker-1: 61ms

User
====

Authentication
--------------

  * Authenticated: true
  * Name: nordlicht
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@530414a8: Username: hudson.security.HudsonPrivateSecurityRealm$Details@23d8e8ba; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@fffbcba8: RemoteIpAddress: 193.58.196.42; SessionId: node011wx02tmn0xkob9yhsgzklp8w3; Granted Authorities: authenticated`


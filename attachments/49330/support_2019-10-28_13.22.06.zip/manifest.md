Support Bundle Manifest
=======================

Generated on 2019-10-28 13:22:06.834+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2019-10-28_13.19.10.log`

      - `nodes/master/logs/all_2019-10-28_13.19.28.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Download metadata.log`

      - `other-logs/Download metadata.log.1`

      - `other-logs/Download metadata.log.2`

      - `other-logs/Download metadata.log.3`

      - `other-logs/Download metadata.log.4`

      - `other-logs/Download metadata.log.5`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Fingerprint cleanup.log.1`

      - `other-logs/Fingerprint cleanup.log.2`

      - `other-logs/Fingerprint cleanup.log.3`

      - `other-logs/Fingerprint cleanup.log.4`

      - `other-logs/Fingerprint cleanup.log.5`

      - `other-logs/Gravatar periodic lookup.log`

      - `other-logs/Gravatar periodic lookup.log.1`

      - `other-logs/Gravatar periodic lookup.log.2`

      - `other-logs/Gravatar periodic lookup.log.3`

      - `other-logs/Gravatar periodic lookup.log.4`

      - `other-logs/Gravatar periodic lookup.log.5`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/Workspace clean-up.log.1`

      - `other-logs/Workspace clean-up.log.2`

      - `other-logs/Workspace clean-up.log.3`

      - `other-logs/Workspace clean-up.log.4`

      - `other-logs/Workspace clean-up.log.5`

      - `other-logs/copy_reference_file.log`

      - `other-logs/health-checker.log`

      - `other-logs/jobAnalytics.log`

      - `other-logs/jobAnalytics.log.1`

      - `other-logs/jobAnalytics.log.2`

      - `other-logs/jobAnalytics.log.3`

      - `other-logs/jobAnalytics.log.4`

      - `other-logs/jobAnalytics.log.5`

      - `other-logs/selenium.log`

      - `other-logs/telemetry collection.log`

      - `other-logs/telemetry collection.log.1`

      - `other-logs/telemetry collection.log.2`

      - `other-logs/telemetry collection.log.3`

      - `other-logs/telemetry collection.log.4`

      - `other-logs/telemetry collection.log.5`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `identity.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/worker-1/checksums.md5`

      - `plugins/active.txt`

      - `plugins/backup.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump agent export tables (could reveal some memory leaks)

      - `nodes/slave/worker-1/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/worker-1/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/worker-1/file-descriptors.txt`

  * Master JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/linux/gnuplot`

      - `load-stats/label/linux/hour.csv`

      - `load-stats/label/linux/min.csv`

      - `load-stats/label/linux/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/worker-1/gnuplot`

      - `load-stats/label/worker-1/hour.csv`

      - `load-stats/label/worker-1/min.csv`

      - `load-stats/label/worker-1/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/worker-1/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Reverse Proxy

      - `reverse-proxy.md`

  * Running Builds

      - `running-builds.txt`

  * Agent Command Statistics

      - `nodes/slave/worker-1/command-stats.md`

  * Master system configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/worker-1/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/worker-1/thread-dump.txt`


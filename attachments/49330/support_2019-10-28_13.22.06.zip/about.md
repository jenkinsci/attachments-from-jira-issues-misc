Jenkins
=======

Version details
---------------

  * Version: `2.201`
  * Instance ID: `4a1000ad59b86d581eea8a0cb871f4ef`
  * Mode:    WAR
  * Url:     https://jenkins.nordlicht.cloud/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0&#95;181
      - Maximum memory:   4.32 GB (4642045952)
      - Allocated memory: 1.92 GB (2063073280)
      - Free memory:      1.21 GB (1298850184)
      - In-use memory:    728.82 MB (764223096)
      - GC strategy:      ParallelGC
      - Available CPUs:   8
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.181-b13
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-957.5.1.el7.x86&#95;64
  * Process ID: 7 (0x7)
  * Process started: 2019-10-28 13:19:25.583+0000
  * Process uptime: 2 min 41 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Duser.home=/var/jenkins_home`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ant:1.10 'Ant Plugin'
  * antisamy-markup-formatter:1.6 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.10-2.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * bitbucket:1.1.11 'Jenkins Bitbucket Plugin'
  * blueocean:1.19.0 'Blue Ocean'
  * blueocean-autofavorite:1.2.4 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.19.0 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.19.0 'Common API for Blue Ocean'
  * blueocean-config:1.19.0 'Config API for Blue Ocean'
  * blueocean-core-js:1.19.0 'Blue Ocean Core JS'
  * blueocean-dashboard:1.19.0 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.3.0 'Display URL for Blue Ocean'
  * blueocean-events:1.19.0 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.19.0 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.19.0 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.19.0 'i18n for Blue Ocean'
  * blueocean-jira:1.19.0 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.19.0 'JWT for Blue Ocean'
  * blueocean-personalization:1.19.0 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.19.0 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.19.0 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.19.0 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.19.0 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.19.0 'REST Implementation for Blue Ocean'
  * blueocean-web:1.19.0 'Web for Blue Ocean'
  * bouncycastle-api:2.17 'bouncycastle API Plugin'
  * branch-api:2.5.4 'Branch API Plugin'
  * build-failure-analyzer:1.23.1 *(update available)* 'Build Failure Analyzer'
  * build-monitor-plugin:1.12+build.201809061734 'Build Monitor View'
  * build-timeout:1.19 'Build Timeout'
  * chucknorris:1.2 'ChuckNorris Plugin'
  * claim:2.15 'Jenkins Claim Plugin'
  * cloudbees-bitbucket-branch-source:2.5.0 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.9 'Folders Plugin'
  * command-launcher:1.3 'Command Agent Launcher Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * config-file-provider:3.6.2 'Config File Provider Plugin'
  * configuration-as-code:1.32 'Configuration as Code Plugin'
  * configuration-as-code-support:1.18 'Configuration as Code Support Plugin'
  * credentials:2.3.0 'Credentials Plugin'
  * credentials-binding:1.20 'Credentials Binding Plugin'
  * dashboard-view:2.12 'Dashboard View'
  * delivery-pipeline-plugin:1.4.0 'Delivery Pipeline Plugin'
  * display-url-api:2.3.2 'Display URL API'
  * docker-commons:1.15 'Docker Commons Plugin'
  * docker-workflow:1.21 'Docker Pipeline'
  * durable-task:1.31 'Durable Task Plugin'
  * email-ext:2.68 'Email Extension Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * favorite:2.3.2 'Favorite'
  * git:3.12.1 'Jenkins Git plugin'
  * git-client:2.9.0 'Jenkins Git client plugin'
  * git-parameter:0.9.11 'Git Parameter Plug-In'
  * git-server:1.8 'Jenkins GIT server Plugin'
  * github:1.29.5 'GitHub plugin'
  * github-api:1.95 'GitHub API Plugin'
  * github-branch-source:2.5.8 'GitHub Branch Source Plugin'
  * gitlab-merge-request-jenkins:2.0.0 'Gitlab Merge Request Builder'
  * gitlab-plugin:1.5.13 'GitLab Plugin'
  * gradle:1.34 'Gradle Plugin'
  * gravatar:2.1 'Jenkins Gravatar plugin'
  * greenballs:1.15 'Green Balls'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * handy-uri-templates-2-api:2.1.8-1.0 'Handy Uri Templates 2.x API Plugin'
  * htmlpublisher:1.21 'HTML Publisher plugin'
  * jackson2-api:2.10.0 'Jackson 2 API Plugin'
  * javadoc:1.5 'Javadoc Plugin'
  * jaxb:2.3.0.1 'JAXB plugin'
  * jdk-tool:1.3 'Oracle Java SE Development Kit Installer Plugin'
  * jenkins-design-language:1.19.0 'Jenkins Design Language'
  * jira:3.0.10 'Jenkins JIRA plugin'
  * jquery:1.12.4-1 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.55.1 'Jenkins JSch dependency plugin'
  * junit:1.28 'JUnit Plugin'
  * ldap:1.20 'LDAP Plugin'
  * lockable-resources:2.6 'Lockable Resources plugin'
  * mailer:1.29 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:2.5 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.14 'Matrix Project Plugin'
  * maven-plugin:3.4 'Maven Integration plugin'
  * mercurial:2.8 'Jenkins Mercurial plugin'
  * metrics:4.0.2.6 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * nodejs:1.3.4 'NodeJS Plugin'
  * pam-auth:1.6 'PAM Authentication plugin'
  * parameterized-trigger:2.35.2 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.9 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.10 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.11 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.3.9 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.3.9 'Pipeline: Declarative'
  * pipeline-model-extensions:1.3.9 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.12 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.3.9 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.12 'Pipeline: Stage View Plugin'
  * plain-credentials:1.5 'Plain Credentials Plugin'
  * pubsub-light:1.13 'Jenkins Pub-Sub "light" Bus'
  * radiatorviewplugin:1.29 'Radiator View Plugin'
  * resource-disposer:0.14 'Resource Disposer Plugin'
  * run-condition:1.2 'Run Condition Plugin'
  * scm-api:2.6.3 'SCM API Plugin'
  * script-security:1.66 'Script Security Plugin'
  * sonar:2.10 'SonarQube Scanner for Jenkins'
  * sse-gateway:1.20 'Server Sent Events (SSE) Gateway Plugin'
  * ssh:2.6.1 'Jenkins SSH plugin'
  * ssh-agent:1.17 'SSH Agent Plugin'
  * ssh-credentials:1.18 'SSH Credentials Plugin'
  * ssh-slaves:1.31.0 'Jenkins SSH Slaves plugin'
  * structs:1.20 'Structs Plugin'
  * subversion:2.12.2 'Jenkins Subversion Plug-in'
  * support-core:2.62 'Support Core Plugin'
  * timestamper:1.10 'Timestamper'
  * token-macro:2.10 'Token Macro Plugin'
  * trilead-api:1.0.5 'Trilead API Plugin'
  * variant:1.3 'Variant Plugin'
  * windows-slaves:1.5 'WMI Windows Agents Plugin'
  * workflow-aggregator:2.6 'Pipeline'
  * workflow-api:2.37 'Pipeline: API'
  * workflow-basic-steps:2.18 'Pipeline: Basic Steps'
  * workflow-cps:2.74 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.15 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.34 'Pipeline: Nodes and Processes'
  * workflow-job:2.35 'Pipeline: Job'
  * workflow-multibranch:2.21 'Pipeline: Multibranch'
  * workflow-scm-step:2.9 'Pipeline: SCM Step'
  * workflow-step-api:2.20 'Pipeline: Step API'
  * workflow-support:3.3 'Pipeline: Supporting APIs'
  * ws-cleanup:0.37 'Jenkins Workspace Cleanup Plugin'

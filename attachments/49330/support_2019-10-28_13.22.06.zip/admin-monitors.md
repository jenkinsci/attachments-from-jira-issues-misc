Monitors
========

`OldData`
--------------
  * Problematic object: `hudson.plugins.sonar.SonarGlobalConfiguration@551daa3a`
    - CannotResolveClassException: hudson.plugins.sonar.SonarGlobalConfiguration$$Lambda$110/1967149625

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)

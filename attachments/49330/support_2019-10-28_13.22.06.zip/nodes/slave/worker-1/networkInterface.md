-----------
 * Name docker0
 ** Hardware Address - 02429ec98cd9
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:42:9eff:fec9:8cd9%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 52540047d926
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:6cf9:c9b0:330a:9657%eth0
 ** InetAddress - /172.16.64.27
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

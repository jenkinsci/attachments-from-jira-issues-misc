Node statistics
===============

  * Total number of nodes
      - Sample size:        10
      - Average (mean):     0.9999999999999999
      - Average (median):   1.0
      - Standard deviation: 1.1102230246251564E-16
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of nodes online
      - Sample size:        10
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        10
      - Average (mean):     11.999999999999996
      - Average (median):   12.0
      - Standard deviation: 3.5527136788005005E-15
      - Minimum:            12
      - Maximum:            12
      - 95th percentile:    12.0
      - 99th percentile:    12.0
  * Total number of executors in use
      - Sample size:        10
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      0
      - FS root:        `/var/jenkins_home`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.35
      - Java
          + Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;181
          + Maximum memory:   4.32 GB (4642045952)
          + Allocated memory: 1.92 GB (2063073280)
          + Free memory:      1.21 GB (1294710720)
          + In-use memory:    732.77 MB (768362560)
          + GC strategy:      ParallelGC
          + Available CPUs:   8
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-957.5.1.el7.x86&#95;64
      - Process ID: 7 (0x7)
      - Process started: 2019-10-28 13:19:25.583+0000
      - Process uptime: 2 min 41 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Duser.home=/var/jenkins_home`

  * `worker-1` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      12
      - Remote FS root: `/home/jenkins`
      - Labels:         linux
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.35
      - Java
          + Home:           `/usr/lib/jvm/java-11-amazon-corretto`
          + Vendor:           Amazon.com Inc.
          + Version:          11.0.4
          + Maximum memory:   3.91 GB (4198498304)
          + Allocated memory: 252.00 MB (264241152)
          + Free memory:      217.70 MB (228275840)
          + In-use memory:    34.30 MB (35965312)
          + GC strategy:      G1
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Amazon.com Inc.
          + Version: 11.0.4+11-LTS
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-1062.1.1.el7.x86&#95;64
      - Process ID: 3141 (0xc45)
      - Process started: 2019-10-28 13:16:37.189+0000
      - Process uptime: 2 min 28 sec
      - JVM startup parameters:
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib:/usr/lib64:/lib64:/lib:/usr/lib`


Node statistics
===============

  * Total number of nodes
      - Sample size:        20
      - Average (mean):     1.9872313974358138
      - Average (median):   2.0
      - Standard deviation: 0.15929271143693347
      - Minimum:            0
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of nodes online
      - Sample size:        20
      - Average (mean):     1.9827859521075013
      - Average (median):   2.0
      - Standard deviation: 0.17229720546729566
      - Minimum:            0
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors
      - Sample size:        20
      - Average (mean):     1.9827859521075013
      - Average (median):   2.0
      - Standard deviation: 0.17229720546729566
      - Minimum:            0
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors in use
      - Sample size:        20
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      0
      - FS root:        `/var/jenkins_home`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.12
      - Java
          + Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_141
          + Maximum memory:   1.29 GB (1388838912)
          + Allocated memory: 619.50 MB (649592832)
          + Free memory:      208.65 MB (218784464)
          + In-use memory:    410.85 MB (430808368)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.141-b15
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.9.46-moby
          + Distribution: Debian GNU/Linux 9.1 (stretch)
      - Process ID: 7 (0x7)
      - Process started: 2017-09-20 17:08:49.261+0000
      - Process uptime: 5 min 26 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Duser.home=/var/jenkins_home`
          + arg[1]: `-Dorg.apache.commons.jelly.tags.fmt.timeZone=America/New_York`
          + arg[2]: `-Dcb.distributable.name=Docker Common`
          + arg[3]: `-Dcb.distributable.commit_sha=c065988fd8246f4c952f378738d962c9e709878a`

  * 39c634d0d212-f096f61d (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.21.0.4 : CJT Demo Swarm Agent_
      - Executors:      1
      - Remote FS root: `/var/jenkins_home`
      - Labels:         swarm
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        3.4.1
      - Java
          + Home:           `/usr/lib/jvm/java-1.8-openjdk/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_121
          + Maximum memory:   1.29 GB (1388838912)
          + Allocated memory: 163.50 MB (171442176)
          + Free memory:      108.56 MB (113832016)
          + In-use memory:    54.94 MB (57610160)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.121-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.9.46-moby
      - Process ID: 1 (0x1)
      - Process started: 2017-09-20 17:09:45.860+0000
      - Process uptime: 4 min 29 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/resources.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/rt.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jce.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8-openjdk/jre/classes`
          + Classpath: `swarm-client-3.4.jar`
          + Library path: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64/server:/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64:/usr/lib/jvm/java-1.8-openjdk/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * a6b76ba11522-22a9369a (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 172.21.0.3 : CJT Demo Swarm Agent_
      - Executors:      1
      - Remote FS root: `/var/jenkins_home`
      - Labels:         swarm
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        3.4.1
      - Java
          + Home:           `/usr/lib/jvm/java-1.8-openjdk/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_121
          + Maximum memory:   1.29 GB (1388838912)
          + Allocated memory: 163.50 MB (171442176)
          + Free memory:      107.88 MB (113119440)
          + In-use memory:    55.62 MB (58322736)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.121-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.9.46-moby
      - Process ID: 1 (0x1)
      - Process started: 2017-09-20 17:09:43.673+0000
      - Process uptime: 4 min 32 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/resources.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/rt.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jce.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8-openjdk/jre/classes`
          + Classpath: `swarm-client-3.4.jar`
          + Library path: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64/server:/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64:/usr/lib/jvm/java-1.8-openjdk/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`


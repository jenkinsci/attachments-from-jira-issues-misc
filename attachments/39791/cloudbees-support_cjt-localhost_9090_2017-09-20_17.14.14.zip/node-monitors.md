Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * 39c634d0d212-f096f61d: Linux (amd64)
   * a6b76ba11522-22a9369a: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * 39c634d0d212-f096f61d: In sync
   * a6b76ba11522-22a9369a: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 179.484GB left on /var/jenkins_home.
   * 39c634d0d212-f096f61d: Disk space is too low. Only 179.484GB left on /var/jenkins_home.
   * a6b76ba11522-22a9369a: Disk space is too low. Only 179.484GB left on /var/jenkins_home.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:1104/5957MB  Swap:837/1023MB
   * 39c634d0d212-f096f61d: Memory:1098/5957MB  Swap:837/1023MB
   * a6b76ba11522-22a9369a: Memory:1099/5957MB  Swap:837/1023MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 45.872GB left on /tmp.
   * 39c634d0d212-f096f61d: Disk space is too low. Only 45.872GB left on /tmp.
   * a6b76ba11522-22a9369a: Disk space is too low. Only 45.872GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * 39c634d0d212-f096f61d: 274ms
   * a6b76ba11522-22a9369a: 269ms

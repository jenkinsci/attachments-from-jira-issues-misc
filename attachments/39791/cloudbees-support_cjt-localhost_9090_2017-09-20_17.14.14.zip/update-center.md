=== Sites ===
 - Url: file:/var/jenkins_home/war/WEB-INF/plugins/update-center.json
 - Connection Url: file:/var/jenkins_home/war/WEB-INF/plugins/update-center.json
 - Implementation Type: com.cloudbees.jenkins.plugins.license.nectar.CloudBeesUpdateSite
 - Url: http://jenkins-updates.cloudbees.com/update-center/envelope-cjt/update-center.json
 - Connection Url: null
 - Implementation Type: com.cloudbees.jenkins.plugins.license.nectar.CloudBeesUpdateSite
======
Last updated: 5 min 1 sec
=== Proxy ===

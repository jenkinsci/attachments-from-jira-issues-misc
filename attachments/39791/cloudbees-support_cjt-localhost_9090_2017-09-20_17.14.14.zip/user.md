User
====

Authentication
--------------

  * Authenticated: true
  * Name: admin
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@800afe8e: Username: hudson.security.HudsonPrivateSecurityRealm$Details@13dbc2fd; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@7798: RemoteIpAddress: 172.21.0.1; SessionId: node05jfeg9xtu4ohjofykf4vue250; Granted Authorities: authenticated`


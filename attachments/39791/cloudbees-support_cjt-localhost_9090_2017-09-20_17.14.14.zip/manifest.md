CloudBees Support Bundle Manifest
=================================

Generated on 2017-09-20 17:14:14.262+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-09-20_15.38.51.log`

      - `nodes/master/logs/all_2017-09-20_15.46.36.log`

      - `nodes/master/logs/all_2017-09-20_15.47.06.log`

      - `nodes/master/logs/all_2017-09-20_16.31.57.log`

      - `nodes/master/logs/all_2017-09-20_16.48.44.log`

      - `nodes/master/logs/all_2017-09-20_17.08.57.log`

      - `nodes/master/logs/all_2017-09-20_17.09.51.log`

      - `nodes/master/logs/all_2017-09-20_17.09.53.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/copy_reference_file.log`

      - `other-logs/health-checker.log`

      - `other-logs/jenkins.branch.MultiBranchProject.log`

      - `other-logs/jenkins.branch.OrganizationFolder.log`

  * Garbage Collection Logs

  * CloudBees Assurance Program

      - `cap/beekeeper.md`

      - `cap/properties.md`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/39c634d0d212-f096f61d/checksums.md5`

      - `nodes/slave/a6b76ba11522-22a9369a/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/39c634d0d212-f096f61d/exportTable.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/39c634d0d212-f096f61d/environment.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/39c634d0d212-f096f61d/file-descriptors.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/39c634d0d212-f096f61d/proc/meminfo.txt`

      - `nodes/slave/39c634d0d212-f096f61d/proc/self/cmdline`

      - `nodes/slave/39c634d0d212-f096f61d/proc/self/environ`

      - `nodes/slave/39c634d0d212-f096f61d/proc/self/limits.txt`

      - `nodes/slave/39c634d0d212-f096f61d/proc/self/mountstats.txt`

      - `nodes/slave/39c634d0d212-f096f61d/proc/self/status.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/proc/meminfo.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/proc/self/cmdline`

      - `nodes/slave/a6b76ba11522-22a9369a/proc/self/environ`

      - `nodes/slave/a6b76ba11522-22a9369a/proc/self/limits.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/proc/self/mountstats.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/39c634d0d212-f096f61d/gnuplot`

      - `load-stats/label/39c634d0d212-f096f61d/hour.csv`

      - `load-stats/label/39c634d0d212-f096f61d/min.csv`

      - `load-stats/label/39c634d0d212-f096f61d/sec10.csv`

      - `load-stats/label/a6b76ba11522-22a9369a/gnuplot`

      - `load-stats/label/a6b76ba11522-22a9369a/hour.csv`

      - `load-stats/label/a6b76ba11522-22a9369a/min.csv`

      - `load-stats/label/a6b76ba11522-22a9369a/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/swarm/gnuplot`

      - `load-stats/label/swarm/hour.csv`

      - `load-stats/label/swarm/min.csv`

      - `load-stats/label/swarm/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/39c634d0d212-f096f61d/metrics.json`

      - `nodes/slave/a6b76ba11522-22a9369a/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/39c634d0d212-f096f61d/networkInterface.md`

      - `nodes/slave/a6b76ba11522-22a9369a/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/39c634d0d212-f096f61d/dmesg.txt`

      - `nodes/slave/39c634d0d212-f096f61d/dmi.txt`

      - `nodes/slave/39c634d0d212-f096f61d/proc/cpuinfo.txt`

      - `nodes/slave/39c634d0d212-f096f61d/proc/mounts.txt`

      - `nodes/slave/39c634d0d212-f096f61d/proc/net/rpc/nfs.txt`

      - `nodes/slave/39c634d0d212-f096f61d/proc/net/rpc/nfsd.txt`

      - `nodes/slave/39c634d0d212-f096f61d/proc/swaps.txt`

      - `nodes/slave/39c634d0d212-f096f61d/proc/system-uptime.txt`

      - `nodes/slave/39c634d0d212-f096f61d/sysctl.txt`

      - `nodes/slave/39c634d0d212-f096f61d/userid.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/dmesg.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/dmi.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/proc/cpuinfo.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/proc/mounts.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/proc/net/rpc/nfs.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/proc/net/rpc/nfsd.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/proc/swaps.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/proc/system-uptime.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/sysctl.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/39c634d0d212-f096f61d/system.properties`

      - `nodes/slave/a6b76ba11522-22a9369a/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

      - `slow-requests/20170628-173607.145.txt`

      - `slow-requests/20170628-173652.145.txt`

      - `slow-requests/20170628-173755.145.txt`

      - `slow-requests/20170629-134734.688.txt`

      - `slow-requests/20170629-135201.688.txt`

      - `slow-requests/20170629-140145.614.txt`

      - `slow-requests/20170711-173821.039.txt`

      - `slow-requests/20170712-180750.106.txt`

      - `slow-requests/20170712-181805.106.txt`

      - `slow-requests/20170718-192626.801.txt`

      - `slow-requests/20170718-192920.803.txt`

      - `slow-requests/20170719-202619.994.txt`

      - `slow-requests/20170724-193855.880.txt`

      - `slow-requests/20170725-142557.943.txt`

      - `slow-requests/20170725-202800.942.txt`

      - `slow-requests/20170816-133035.812.txt`

      - `slow-requests/20170816-133035.813.txt`

      - `slow-requests/20170816-133035.814.txt`

      - `slow-requests/20170816-133035.815.txt`

      - `slow-requests/20170816-133035.816.txt`

      - `slow-requests/20170816-133035.817.txt`

      - `slow-requests/20170816-133738.812.txt`

      - `slow-requests/20170816-133738.813.txt`

      - `slow-requests/20170816-133738.814.txt`

      - `slow-requests/20170816-133738.815.txt`

      - `slow-requests/20170816-133738.816.txt`

      - `slow-requests/20170816-133738.817.txt`

      - `slow-requests/20170816-133738.818.txt`

      - `slow-requests/20170816-133741.812.txt`

      - `slow-requests/20170816-133741.813.txt`

      - `slow-requests/20170816-133744.812.txt`

      - `slow-requests/20170816-133744.813.txt`

      - `slow-requests/20170816-133750.812.txt`

      - `slow-requests/20170816-133802.812.txt`

      - `slow-requests/20170828-182226.870.txt`

      - `slow-requests/20170831-155555.759.txt`

      - `slow-requests/20170908-205217.699.txt`

      - `slow-requests/20170911-163540.838.txt`

      - `slow-requests/20170911-163640.836.txt`

      - `slow-requests/20170911-192822.869.txt`

      - `slow-requests/20170920-133751.775.txt`

      - `slow-requests/20170920-154357.355.txt`

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/39c634d0d212-f096f61d/thread-dump.txt`

      - `nodes/slave/a6b76ba11522-22a9369a/thread-dump.txt`


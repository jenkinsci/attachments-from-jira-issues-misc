Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 1
    - Number of builds per job: 5 [n=1]
  * `jenkins.branch.OrganizationFolder`
    - Number of items: 1
    - Number of items per container: 3 [n=1]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 19
    - Number of builds per job: 3.3684210526315788 [n=19, s=4.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 3
    - Number of items per container: 6.0 [n=3, s=4.0]

Total job statistics
======================

  * Number of jobs: 20
  * Number of builds per job: 3.45 [n=20, s=4.0]

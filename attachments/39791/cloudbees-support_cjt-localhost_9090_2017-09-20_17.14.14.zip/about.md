Jenkins
=======

Version details
---------------

  * Version: `2.73.1.2`
  * Mode:    WAR
  * Url:     http://localhost:9090/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_141
      - Maximum memory:   1.29 GB (1388838912)
      - Allocated memory: 619.50 MB (649592832)
      - Free memory:      210.71 MB (220945240)
      - In-use memory:    408.79 MB (428647592)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.141-b15
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.9.46-moby
      - Distribution: Debian GNU/Linux 9.1 (stretch)
  * Process ID: 7 (0x7)
  * Process started: 2017-09-20 17:08:49.261+0000
  * Process uptime: 5 min 26 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Duser.home=/var/jenkins_home`
      - arg[1]: `-Dorg.apache.commons.jelly.tags.fmt.timeZone=America/New_York`
      - arg[2]: `-Dcb.distributable.name=Docker Common`
      - arg[3]: `-Dcb.distributable.commit_sha=c065988fd8246f4c952f378738d962c9e709878a`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * async-http-client:1.7.24.1 'Async Http Client'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * blueocean:1.1.7 'Blue Ocean'
  * blueocean-autofavorite:1.0.0 'Autofavorite for Blue Ocean'
  * blueocean-commons:1.1.7 'Common API for Blue Ocean'
  * blueocean-config:1.1.7 'Config API for Blue Ocean'
  * blueocean-dashboard:1.1.7 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.1.0 'Display URL for Blue Ocean'
  * blueocean-events:1.1.7 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.1.7 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.1.7 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.1.7 'i18n for Blue Ocean'
  * blueocean-jwt:1.1.7 'JWT for Blue Ocean'
  * blueocean-personalization:1.1.7 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.1.7 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:0.2.0 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.1.7 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.1.7 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.1.7 'REST Implementation for Blue Ocean'
  * blueocean-web:1.1.7 'Web for Blue Ocean'
  * bouncycastle-api:2.16.1 'bouncycastle API Plugin'
  * branch-api:2.0.10 'Branch API Plugin'
  * cloudbees-assurance:2.73.0.1 'Beekeeper Upgrade Assistant Plugin'
  * cloudbees-folder:6.0.4 'Folders Plugin'
  * cloudbees-jenkins-advisor:1.2 'CloudBees Jenkins Advisor Plugin'
  * cloudbees-license:9.14 'CloudBees License Manager'
  * cloudbees-support:3.10 'CloudBees Support Plugin'
  * credentials:2.1.13 'Credentials Plugin'
  * credentials-binding:1.12 'Credentials Binding Plugin'
  * display-url-api:2.0 'Display URL API'
  * docker-commons:1.8 'Docker Commons Plugin'
  * docker-workflow:1.12 'Docker Pipeline'
  * durable-task:1.14 'Durable Task Plugin'
  * email-ext:2.57.2 'Email Extension Plugin'
  * favorite:2.3.0 'Favorite'
  * git:3.3.2 'Jenkins Git plugin'
  * git-client:2.4.6 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.27.0 'GitHub plugin'
  * github-api:1.85.1 'GitHub API Plugin'
  * github-branch-source:2.0.8 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * gradle:1.26 'Gradle Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.20 'JUnit Plugin'
  * ldap:1.15 'LDAP Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.6 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.11 'Matrix Project Plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * nectar-license:8.6 'CloudBees Jenkins Enterprise License Entitlement Check'
  * pipeline-build-step:2.5.1 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.4 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.1.6 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.1.6 'Pipeline: Model Definition'
  * pipeline-model-extensions:1.1.6 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.8 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.1.6 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.8 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * scm-api:2.1.1 'SCM API Plugin'
  * script-security:1.33 'Script Security Plugin'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * structs:1.8 'Structs Plugin'
  * support-core:2.41 'Support Core Plugin'
  * swarm:3.4 'Jenkins Self-Organizing Swarm Plug-in Modules'
  * token-macro:2.1 'Token Macro Plugin'
  * variant:1.1 'Variant Plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.18 'Pipeline: API'
  * workflow-basic-steps:2.5 'Pipeline: Basic Steps'
  * workflow-cps:2.39 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.8 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.12 'Pipeline: Nodes and Processes'
  * workflow-job:2.12.2 'Pipeline: Job'
  * workflow-multibranch:2.16 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.11 'Pipeline: Step API'
  * workflow-support:2.14 'Pipeline: Supporting APIs'

Packaging details
-----------------

DockerHub


CloudBees Product Description
-----------------------------

 * Product Distribution: rolling 
 * Product Id: cjt 
 * Product Name: CloudBees Jenkins Team 
 * Product Version: 2.73.1.2 

CloudBees Distributable Description
-----------------------------------

 * Distributable Name: Docker Common
 * UDR Commit SHA: c065988fd8246f4c952f378738d962c9e709878a

License details
---------------

 * Jenkins Instance ID:  `fcfa4ce06fbc8504a2072b749bd9b852`
 * Expires:              Mar 18, 2020
 * Issued to:            David Schott
 * Organization:         CloudBees, Inc.
 * Edition:              Team Edition
     - CloudBees Jenkins Team licensed for 1,000 users

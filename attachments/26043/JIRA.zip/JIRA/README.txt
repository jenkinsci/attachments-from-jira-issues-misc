Note : the slave seemingly stuck used during this threadDump is rhel6-5

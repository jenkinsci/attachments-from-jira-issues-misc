User
====

Authentication
--------------

  * Authenticated: true
  * Name: user_dry_emotion
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@120a8e03: Username: hudson.security.HudsonPrivateSecurityRealm$Details@7e200e40; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@fffbcba8: RemoteIpAddress: ip_physical_basis; SessionId: node017c9lxljopimk1kaqd3v0bg8691; Granted Authorities: authenticated`


-----------
 * Name eth0
 ** Hardware Address - 001e06106b95
 ** Index - 2
 ** InetAddress - /ip_frozen_skull%eth0
 ** InetAddress - /ip_whole_monster
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /ip_standard_uncle%lo
 ** InetAddress - /ip_absent_battery
 ** MTU - 4096
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

-----------
 * Name Software Loopback Interface 1
 ** Index - 1
 ** InetAddress - /ip_absent_battery
 ** InetAddress - /ip_standard_uncle
 ** MTU - -1
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (SSTP)
 ** Index - 2
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (L2TP)
 ** Index - 3
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (PPTP)
 ** Index - 4
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (PPPOE)
 ** Index - 5
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IPv6)
 ** Index - 6
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (Network Monitor)
 ** Index - 7
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IP)
 ** Index - 8
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name RAS Async Adapter
 ** Index - 9
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IKEv2)
 ** Index - 10
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Intel(R) PRO/1000 MT Network Connection
 ** Hardware Address - 005056932e5a
 ** Index - 11
 ** InetAddress - /ip_complex_turn
 ** InetAddress - /ip_loud_urge%eth3
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft ISATAP Adapter
 ** Hardware Address - 00000000000000e0
 ** Index - 12
 ** InetAddress - /ip_present_beard%net4
 ** MTU - 1280
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - false
-----------
 * Name Intel(R) PRO/1000 MT Network Connection-QoS Packet Scheduler-0000
 ** Index - 13
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Intel(R) PRO/1000 MT Network Connection-WFP LightWeight Filter-0000
 ** Index - 14
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IPv6)-QoS Packet Scheduler-0000
 ** Index - 15
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IP)-QoS Packet Scheduler-0000
 ** Index - 16
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (Network Monitor)-QoS Packet Scheduler-0000
 ** Index - 17
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

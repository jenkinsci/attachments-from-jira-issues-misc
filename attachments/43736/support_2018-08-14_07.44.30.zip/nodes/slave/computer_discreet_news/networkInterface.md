-----------
 * Name Software Loopback Interface 1
 ** Index - 1
 ** InetAddress - /ip_absent_battery
 ** InetAddress - /ip_standard_uncle
 ** MTU - -1
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (SSTP)
 ** Index - 2
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (L2TP)
 ** Index - 3
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (PPTP)
 ** Index - 4
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (PPPOE)
 ** Index - 5
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IPv6)
 ** Index - 6
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (Network Monitor)
 ** Index - 7
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IP)
 ** Index - 8
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name RAS Async Adapter
 ** Index - 9
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IKEv2)
 ** Index - 10
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Intel(R) PRO/1000 MT-Netzwerkverbindung
 ** Hardware Address - 005056930016
 ** Index - 11
 ** InetAddress - /ip_late_conservation
 ** InetAddress - /ip_formal_experience%eth3
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft-ISATAP-Adapter
 ** Hardware Address - 00000000000000e0
 ** Index - 12
 ** MTU - 1280
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - false
-----------
 * Name Intel(R) PRO/1000 MT-Netzwerkverbindung-Kaspersky Lab NDIS 6 Filter-0000
 ** Index - 13
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Intel(R) PRO/1000 MT-Netzwerkverbindung-QoS Packet Scheduler-0000
 ** Index - 14
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IPv6)-Kaspersky Lab NDIS 6 Filter-0000
 ** Index - 15
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IPv6)-QoS Packet Scheduler-0000
 ** Index - 16
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (Network Monitor)-Kaspersky Lab NDIS 6 Filter-0000
 ** Index - 17
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (Network Monitor)-QoS Packet Scheduler-0000
 ** Index - 18
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Intel(R) PRO/1000 MT-Netzwerkverbindung-WFP LightWeight Filter-0000
 ** Index - 19
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IP)-Kaspersky Lab NDIS 6 Filter-0000
 ** Index - 20
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name WAN Miniport (IP)-QoS Packet Scheduler-0000
 ** Index - 21
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

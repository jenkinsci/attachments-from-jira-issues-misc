-----------
 * Name ens32
 ** Hardware Address - 005056935e19
 ** Index - 2
 ** InetAddress - /ip_continental_consumption%ens32
 ** InetAddress - /ip_vulnerable_bankruptcy
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /ip_standard_uncle%lo
 ** InetAddress - /ip_absent_battery
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

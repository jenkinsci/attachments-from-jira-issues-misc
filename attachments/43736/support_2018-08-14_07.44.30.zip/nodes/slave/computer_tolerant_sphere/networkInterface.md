-----------
 * Name ens32
 ** Hardware Address - 00505693288c
 ** Index - 2
 ** InetAddress - /ip_strategic_implication%ens32
 ** InetAddress - /ip_socialist_privilege
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /ip_standard_uncle%lo
 ** InetAddress - /ip_absent_battery
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

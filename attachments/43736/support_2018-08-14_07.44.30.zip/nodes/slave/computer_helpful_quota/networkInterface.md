-----------
 * Name eth0
 ** Hardware Address - 005056936f5e
 ** Index - 2
 ** InetAddress - /ip_literary_imagination%eth0
 ** InetAddress - /ip_just_hypothesis
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /ip_standard_uncle%lo
 ** InetAddress - /ip_absent_battery
 ** MTU - 16436
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

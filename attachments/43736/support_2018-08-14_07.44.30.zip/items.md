Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 1
    - Number of items per container: 13 [n=1]
  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 820
    - Number of builds per job: 32.31951219512195 [n=820, s=15.0]
  * `hudson.matrix.MatrixProject`
    - Number of items: 95
    - Number of builds per job: 41.305263157894736 [n=95, s=10.0]
    - Number of items per container: 8.631578947368421 [n=95, s=9.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 338
    - Number of builds per job: 50.281065088757394 [n=338, s=140.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 66
    - Number of builds per job: 35.28787878787879 [n=66, s=20.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 17
    - Number of items per container: 1.0 [n=17, s=0.4]

Total job statistics
======================

  * Number of jobs: 1319
  * Number of builds per job: 37.717968157695225 [n=1319, s=73.22077267382491]

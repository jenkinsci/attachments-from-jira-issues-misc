Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: label_uneasy_auditor (amd64)
   * computer_terminal_federation: label_uneasy_auditor (amd64)
   * computer_asleep_integrity: null
   * computer_discreet_news: label_bloody_competition 7 (amd64)
   * computer_helpful_quota: label_uneasy_auditor (amd64)
   * computer_molecular_spectrum: label_uneasy_auditor (i386)
   * computer_reasonable_visitor: null
   * computer_thoughtful_boat: label_bloody_competition Server 2012 R2 (amd64)
   * computer_automatic_craft: label_bloody_competition Server 2012 R2 (amd64)
   * computer_dominant_fence: label_uneasy_auditor (arm)
   * computer_historical_interest: label_uneasy_auditor (arm)
   * computer_moving_noise: null
   * computer_related_racism: null
   * computer_tolerant_sphere: label_uneasy_auditor (i386)
   * computer_awful_volunteer: label_uneasy_auditor (amd64)
   * computer_dull_bond: label_uneasy_auditor (aarch64)
   * computer_honorable_creation: label_uneasy_auditor (aarch64)
   * computer_mutual_few: label_bloody_competition Server 2008 R2 (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * computer_terminal_federation: In sync
   * computer_asleep_integrity: null
   * computer_discreet_news: In sync
   * computer_helpful_quota: In sync
   * computer_molecular_spectrum: In sync
   * computer_reasonable_visitor: null
   * computer_thoughtful_boat: In sync
   * computer_automatic_craft: In sync
   * computer_dominant_fence: In sync
   * computer_historical_interest: In sync
   * computer_moving_noise: null
   * computer_related_racism: null
   * computer_tolerant_sphere: In sync
   * computer_awful_volunteer: In sync
   * computer_dull_bond: In sync
   * computer_honorable_creation: In sync
   * computer_mutual_few: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 19.119GB left on /var/lib/jenkins.
   * computer_terminal_federation: Disk space is too low. Only 58.658GB left on /var/lib/jenkins.
   * computer_asleep_integrity: null
   * computer_discreet_news: Disk space is too low. Only 10.477GB left on C:\JenkinsMk2.
   * computer_helpful_quota: Disk space is too low. Only 10.482GB left on /var/lib/jenkins.
   * computer_molecular_spectrum: Disk space is too low. Only 13.615GB left on /var/lib/jenkins.
   * computer_reasonable_visitor: null
   * computer_thoughtful_boat: Disk space is too low. Only 28.862GB left on C:\JenkinsMk2.
   * computer_automatic_craft: Disk space is too low. Only 20.659GB left on C:\JenkinsMk2.
   * computer_dominant_fence: Disk space is too low. Only 875.590GB left on /mnt/hd/jenkins_workspace.
   * computer_historical_interest: Disk space is too low. Only 437.471GB left on /mnt/hd/jenkins.
   * computer_moving_noise: null
   * computer_related_racism: null
   * computer_tolerant_sphere: Disk space is too low. Only 36.062GB left on /var/lib/jenkins.
   * computer_awful_volunteer: Disk space is too low. Only 30.345GB left on /var/lib/jenkins.
   * computer_dull_bond: Disk space is too low. Only 408.787GB left on /mnt/hd/jenkins_workspace.
   * computer_honorable_creation: Disk space is too low. Only 437.421GB left on /mnt/hd/jenkins_workspace.
   * computer_mutual_few: Disk space is too low. Only 72.298GB left on C:\JenkinsMk2.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:4234/16050MB  Swap:1009/1020MB
   * computer_terminal_federation: Memory:253/3945MB  Swap:2006/2047MB
   * computer_asleep_integrity: null
   * computer_discreet_news: Memory:1089/4095MB  Swap:12359/16378MB
   * computer_helpful_quota: Memory:2378/3954MB  Swap:4093/4093MB
   * computer_molecular_spectrum: Memory:2827/4034MB  Swap:4093/4093MB
   * computer_reasonable_visitor: null
   * computer_thoughtful_boat: Memory:5263/8191MB  Swap:6854/9471MB
   * computer_automatic_craft: Memory:4997/8191MB  Swap:6428/9471MB
   * computer_dominant_fence: Memory:323/1990MB  Swap:0/0MB
   * computer_historical_interest: Memory:452/1990MB  Swap:0/0MB
   * computer_moving_noise: null
   * computer_related_racism: null
   * computer_tolerant_sphere: Memory:2551/4041MB  Swap:4530/4605MB
   * computer_awful_volunteer: Memory:198/3951MB  Swap:3992/4093MB
   * computer_dull_bond: Memory:184/1718MB  Swap:0/0MB
   * computer_honorable_creation: Memory:417/1718MB  Swap:793/859MB
   * computer_mutual_few: Memory:2716/4095MB  Swap:5792/8189MB
Free view_educational_set Space
----
 - Is Ignored: false
 - Threshold: 100MB
 - Computers:
   * master: Disk space is too low. Only 19.119GB left on /tmp.
   * computer_terminal_federation: Disk space is too low. Only 58.658GB left on /tmp.
   * computer_asleep_integrity: null
   * computer_discreet_news: Disk space is too low. Only 10.477GB left on C:\label_bloody_competition\view_educational_set.
   * computer_helpful_quota: Disk space is too low. Only 10.482GB left on /tmp.
   * computer_molecular_spectrum: Disk space is too low. Only 13.615GB left on /tmp.
   * computer_reasonable_visitor: null
   * computer_thoughtful_boat: Disk space is too low. Only 28.862GB left on C:\label_bloody_competition\view_educational_set.
   * computer_automatic_craft: Disk space is too low. Only 20.659GB left on C:\label_bloody_competition\view_educational_set.
   * computer_dominant_fence: Disk space is too low. Only 44.357GB left on /tmp.
   * computer_historical_interest: Disk space is too low. Only 51.309GB left on /tmp.
   * computer_moving_noise: null
   * computer_related_racism: null
   * computer_tolerant_sphere: Disk space is too low. Only 36.062GB left on /tmp.
   * computer_awful_volunteer: Disk space is too low. Only 30.345GB left on /tmp.
   * computer_dull_bond: Disk space is too low. Only 3.153GB left on /tmp.
   * computer_honorable_creation: Disk space is too low. Only 7.373GB left on /tmp.
   * computer_mutual_few: Disk space is too low. Only 72.298GB left on C:\label_bloody_competition\view_educational_set.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * computer_terminal_federation: 80ms
   * computer_asleep_integrity: Timed out for last 5 attempts
   * computer_discreet_news: 81ms
   * computer_helpful_quota: 81ms
   * computer_molecular_spectrum: 79ms
   * computer_reasonable_visitor: Timed out for last 5 attempts
   * computer_thoughtful_boat: 79ms
   * computer_automatic_craft: 79ms
   * computer_dominant_fence: 92ms
   * computer_historical_interest: 78ms
   * computer_moving_noise: Timed out for last 5 attempts
   * computer_related_racism: Timed out for last 5 attempts
   * computer_tolerant_sphere: 91ms
   * computer_awful_volunteer: 77ms
   * computer_dull_bond: 78ms
   * computer_honorable_creation: 77ms
   * computer_mutual_few: 90ms

Browser
=======

  * Screen size: 1920x1200
  * User Agent
      - Type:     Browser
      - Name:     Chrome
      - Family:   CHROME
      - Producer: Google Inc.
      - Version:  68.0.3440.75
      - Raw:      `Mozilla/5.0 (label_bloody_competition NT 10.0; Win64; item_logical_credibility) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.75 Safari/537.36`
  * Operating System
      - Name:     label_bloody_competition
      - Family:   label_bloody_competition
      - Producer: Microsoft Corporation.
      - Version:  10.0


Node statistics
===============

  * Total number of nodes
      - Sample size:        15
      - Average (mean):     18.0
      - Average (median):   18.0
      - Standard deviation: 0.0
      - Minimum:            18
      - Maximum:            18
      - 95th percentile:    18.0
      - 99th percentile:    18.0
  * Total number of nodes online
      - Sample size:        15
      - Average (mean):     12.999999999999996
      - Average (median):   13.0
      - Standard deviation: 3.5527136788005005E-15
      - Minimum:            13
      - Maximum:            13
      - 95th percentile:    13.0
      - 99th percentile:    13.0
  * Total number of executors
      - Sample size:        15
      - Average (mean):     101.00000000000001
      - Average (median):   101.0
      - Standard deviation: 1.4210854715202004E-14
      - Minimum:            101
      - Maximum:            101
      - 95th percentile:    101.0
      - 99th percentile:    101.0
  * Total number of executors in use
      - Sample size:        15
      - Average (mean):     1.0164688087425733
      - Average (median):   2.0
      - Standard deviation: 0.9998643799729043
      - Minimum:            0
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      64
      - FS root:        `/var/lib/jenkins`
      - Labels:         master
      - Usage:          `NORMAL`
      - Slave Version:  3.20
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_91
          + Maximum memory:   3.48 GB (3741319168)
          + Allocated memory: 1.99 GB (2137522176)
          + Free memory:      392.83 MB (411914136)
          + In-use memory:    1.61 GB (1725608040)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.91-b14
      - Operating system
          + Name:         label_uneasy_auditor
          + Architecture: amd64
          + Version:      3.2.0-35-generic
          + Distribution: Ubuntu 12.04.1 LTS
      - Process ID: 1295 (0x50f)
      - Process started: 2018-08-10 13:44:12.882+0000
      - Process uptime: 3 days 18 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`

  * computer_terminal_federation (`hudson.slaves.DumbSlave`)
      - Description:    _Ubuntu 18.04 x86&#95;64 [ip_vulnerable_bankruptcy]_
      - Executors:      4
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         label_uneasy_auditor label_empirical_enthusiasm label_valuable_shopping
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.20
      - Java
          + Home:           `/usr/lib/jvm/java-11-openjdk-amd64`
          + Vendor:           Oracle Corporation
          + Version:          10.0.1
          + Maximum memory:   988.00 MB (1035993088)
          + Allocated memory: 62.00 MB (65011712)
          + Free memory:      18.42 MB (19315104)
          + In-use memory:    43.58 MB (45696608)
          + GC strategy:      G1
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 10
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 10
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 10.0.1+10-Ubuntu-3ubuntu1
      - Operating system
          + Name:         label_uneasy_auditor
          + Architecture: amd64
          + Version:      4.15.0-29-generic
          + Distribution: Ubuntu 18.04 LTS
      - Process ID: 16275 (0x3f93)
      - Process started: 2018-08-10 13:44:52.339+0000
      - Process uptime: 3 days 18 hr
      - JVM startup parameters:
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib:/usr/lib/x86_64-label_uneasy_auditor-gnu/jni:/lib/x86_64-label_uneasy_auditor-gnu:/usr/lib/x86_64-label_uneasy_auditor-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Djsse.enableSNIExtension=false`

  * computer_asleep_integrity (`hudson.slaves.DumbSlave`)
      - Description:    _Uninitialized machine for future use. [ip_part-time_side]_
      - Executors:      4
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * computer_discreet_news (`hudson.slaves.DumbSlave`)
      - Description:    _Windows (NOT view_restless_company!).  [ip_late_conservation]_
      - Executors:      8
      - Remote FS root: `C:\JenkinsMk2`
      - Labels:         label_bloody_competition label_nuclear_mill label_rough_preoccupation label_other_europe label_serious_prey item_convenient_vote item_logical_credibility label_enthusiastic_average label_childish_concession label_imperial_predecessor
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.20
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_181`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_181
          + Maximum memory:   910,50 MB (954728448)
          + Allocated memory: 447,00 MB (468713472)
          + Free memory:      278,84 MB (292381496)
          + In-use memory:    168,16 MB (176331976)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         label_bloody_competition 7
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 15028 (0x3ab4)
      - Process started: 2018-08-10 13:44:59.035+0000
      - Process uptime: 3 Tage 17 Stunden
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_181\lib\resources.jar;C:\Program Files\Java\jre1.8.0_181\lib\rt.jar;C:\Program Files\Java\jre1.8.0_181\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_181\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_181\lib\jce.jar;C:\Program Files\Java\jre1.8.0_181\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_181\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_181\classes`
          + Classpath: `slave.jar`
          + Library path: `C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\label_bloody_competition\Sun\Java\bin;C:\label_bloody_competition\system32;C:\label_bloody_competition;C:\view_nervous_attitude\cygwin\bin;C:\Program Files\Conan\conan;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\label_bloody_competition\system32;C:\label_bloody_competition;C:\label_bloody_competition\System32\Wbem;C:\label_bloody_competition\System32\WindowsPowerShell\v1.0;C:\ProgramData\chocolatey\bin;C:\Python27;C:\label_bloody_competition\System32\WindowsPowerShell\v1.0;C:\label_bloody_competition\System32\WindowsPowerShell\v1.0;C:\Program Files (x86)\label_bloody_competition Kits\8.1\label_bloody_competition Performance Toolkit;C:\Program Files\CMake\bin;C:\label_bloody_competition\SysWOW64\WindowsPowerShell\v1.0\Modules\TShell\TShell;C:\Program Files (x86)\label_bloody_competition Kits\10\label_bloody_competition Performance Toolkit;C:\Program Files (x86)\HTML Help Workshop;C:\Program Files (x86)\SignTools;C:\label_bloody_competition\System32\WindowsPowerShell\v1.0;C:\Program Files\TortoiseSVN\bin;C:\Strawberry\c\bin;C:\Strawberry\perl\site\bin;C:\Strawberry\perl\bin;C:\ProgramData\Oracle\Java\javapath;C:\Program Files (x86)\CMake\bin;.`
          + arg[0]: `-Djsse.enableSNIExtension=false`

  * computer_helpful_quota (`hudson.slaves.DumbSlave`)
      - Description:    _Ubuntu 12.04 x86&#95;64 [ip_just_hypothesis]_
      - Executors:      4
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         label_uneasy_auditor item_square_frustration label_impressive_honour item_inevitable_psychologist label_internal_trust label_childish_concession
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.20
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_91
          + Maximum memory:   880.00 MB (922746880)
          + Allocated memory: 41.00 MB (42991616)
          + Free memory:      12.34 MB (12939632)
          + In-use memory:    28.66 MB (30051984)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.91-b14
      - Operating system
          + Name:         label_uneasy_auditor
          + Architecture: amd64
          + Version:      3.2.0-40-generic
          + Distribution: Ubuntu 12.04.5 LTS
      - Process ID: 11759 (0x2def)
      - Process started: 2018-08-10 13:44:51.549+0000
      - Process uptime: 3 days 18 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djsse.enableSNIExtension=false`

  * computer_molecular_spectrum (`hudson.slaves.DumbSlave`)
      - Description:    _Ubuntu 12.04 i686 [ip_small_tube]_
      - Executors:      4
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         label_uneasy_auditor item_liberal_career  item_considerable_summer item_certain_information label_internal_trust label_childish_concession
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.20
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_91
          + Maximum memory:   898.00 MB (941621248)
          + Allocated memory: 37.25 MB (39059456)
          + Free memory:      14.90 MB (15620168)
          + In-use memory:    22.35 MB (23439288)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.91-b14
      - Operating system
          + Name:         label_uneasy_auditor
          + Architecture: i386
          + Version:      3.5.0-27-generic
          + Distribution: Ubuntu 12.04.5 LTS
      - Process ID: 7515 (0x1d5b)
      - Process started: 2018-08-10 13:44:56.362+0000
      - Process uptime: 3 days 18 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/i386:/lib:/usr/lib`
          + arg[0]: `-Djsse.enableSNIExtension=false`

  * computer_reasonable_visitor (`hudson.slaves.DumbSlave`)
      - Description:    _VRmagic D3 [ip_favorable_barrier]_
      - Executors:      2
      - Remote FS root: `/home/siderepos/jenkins`
      - Labels:         label_uneasy_auditor item_strange_introduction label_childish_concession item_secular_vegetarian
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * computer_thoughtful_boat (`hudson.slaves.DumbSlave`)
      - Description:    _Windows (CVB view_restless_company) [ip_patient_money]_
      - Executors:      2
      - Remote FS root: `C:\JenkinsMk2`
      - Labels:         label_bloody_competition label_viable_model label_careful_presentation label_unfortunate_shareholder label_classical_trouble label_closed_princess label_other_europe label_short_housewife label_brown_treat label_enthusiastic_average label_experienced_ballet label_intense_conductor label_ordinary_misery label_serious_prey
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.20
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_172`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_172
          + Maximum memory:   1,78 GB (1908932608)
          + Allocated memory: 663,50 MB (695730176)
          + Free memory:      153,62 MB (161078808)
          + In-use memory:    509,88 MB (534651368)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.172-b11
      - Operating system
          + Name:         label_bloody_competition Server 2012 R2
          + Architecture: amd64
          + Version:      6.3
      - Process ID: 3732 (0xe94)
      - Process started: 2018-08-10 13:44:53.722+0000
      - Process uptime: 3 days 17 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_172\lib\resources.jar;C:\Program Files\Java\jre1.8.0_172\lib\rt.jar;C:\Program Files\Java\jre1.8.0_172\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_172\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_172\lib\jce.jar;C:\Program Files\Java\jre1.8.0_172\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_172\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_172\classes`
          + Classpath: `slave.jar`
          + Library path: `C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\label_bloody_competition\Sun\Java\bin;C:\label_bloody_competition\system32;C:\label_bloody_competition;C:\view_nervous_attitude\cygwin\bin;C:\Python3\Scripts;C:\Python3;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\Program Files (x86)\Embarcadero\RAD Studio\9.0\bin;C:\Users\Public\Documents\RAD Studio\9.0\Bpl;C:\Program Files (x86)\Embarcadero\RAD Studio\9.0\bin64;C:\Users\Public\Documents\RAD Studio\9.0\Bpl\Win64;C:\label_bloody_competition\system32;C:\label_bloody_competition;C:\label_bloody_competition\System32\Wbem;C:\label_bloody_competition\System32\WindowsPowerShell\v1.0;C:\ProgramData\chocolatey\bin;C:\Program Files (x86)\CMake\bin;C:\Program Files\TortoiseSVN\bin;C:\CVB;.`

  * computer_automatic_craft (`hudson.slaves.DumbSlave`)
      - Description:    _Windows (CVB view_restless_company) [ip_sophisticated_ideal]_
      - Executors:      2
      - Remote FS root: `C:\JenkinsMk2`
      - Labels:         label_bloody_competition label_characteristic_hospitality label_closed_princess label_other_europe label_short_housewife label_brown_treat label_enthusiastic_average label_experienced_ballet label_intense_conductor label_childish_concession label_serious_prey label_ordinary_misery
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.20
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_172`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_172
          + Maximum memory:   1,78 GB (1908932608)
          + Allocated memory: 514,00 MB (538968064)
          + Free memory:      378,66 MB (397055128)
          + In-use memory:    135,34 MB (141912936)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.172-b11
      - Operating system
          + Name:         label_bloody_competition Server 2012 R2
          + Architecture: amd64
          + Version:      6.3
      - Process ID: 6984 (0x1b48)
      - Process started: 2018-08-10 13:44:54.176+0000
      - Process uptime: 3 days 17 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_172\lib\resources.jar;C:\Program Files\Java\jre1.8.0_172\lib\rt.jar;C:\Program Files\Java\jre1.8.0_172\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_172\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_172\lib\jce.jar;C:\Program Files\Java\jre1.8.0_172\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_172\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_172\classes`
          + Classpath: `slave.jar`
          + Library path: `C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\label_bloody_competition\Sun\Java\bin;C:\label_bloody_competition\system32;C:\label_bloody_competition;C:\view_nervous_attitude\cygwin\bin;C:\Python3\Scripts;C:\Python3;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\Program Files (x86)\Embarcadero\RAD Studio\9.0\bin;C:\Users\Public\Documents\RAD Studio\9.0\Bpl;C:\Program Files (x86)\Embarcadero\RAD Studio\9.0\bin64;C:\Users\Public\Documents\RAD Studio\9.0\Bpl\Win64;C:\label_bloody_competition\system32;C:\label_bloody_competition;C:\label_bloody_competition\System32\Wbem;C:\label_bloody_competition\System32\WindowsPowerShell\v1.0;C:\ProgramData\chocolatey\bin;C:\Program Files (x86)\CMake\bin;C:\Program Files\TortoiseSVN\bin;C:\CVB;C:\Program Files\dotnet;C:\Program Files\Microsoft SQL Server\130\view_nervous_attitude\Binn;.`

  * computer_dominant_fence (`hudson.slaves.DumbSlave`)
      - Description:    _ODROID ARM [ip_persistent_exemption]_
      - Executors:      2
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         label_uneasy_auditor item_cheerful_core label_childish_concession
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        (timeout with no cache available)

  * computer_historical_interest (`hudson.slaves.DumbSlave`)
      - Description:    _ODROID ARM [ip_faithful_momentum]_
      - Executors:      2
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         label_uneasy_auditor item_cheerful_core label_childish_concession
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        (timeout with no cache available)

  * computer_moving_noise (`hudson.slaves.DumbSlave`)
      - Description:    _ODROID ARM [ip_fashionable_excitement]_
      - Executors:      2
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         label_uneasy_auditor item_satisfied_cooperation label_childish_concession
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * computer_related_racism (`hudson.slaves.DumbSlave`)
      - Description:    _ODROID ARM [ip_jealous_priority]_
      - Executors:      2
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         label_uneasy_auditor item_satisfied_cooperation label_childish_concession
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * computer_tolerant_sphere (`hudson.slaves.DumbSlave`)
      - Description:    _Ubuntu 16.04 i686 [ip_socialist_privilege]_
      - Executors:      4
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         label_uneasy_auditor item_steady_carrot item_linear_sunshine item_inner_inhibition label_childish_concession
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.20
      - Java
          + Home:           `/usr/lib/jvm/java-8-openjdk-i386/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_181
          + Maximum memory:   899.75 MB (943456256)
          + Allocated memory: 40.50 MB (42467328)
          + Free memory:      11.10 MB (11637392)
          + In-use memory:    29.40 MB (30829936)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         label_uneasy_auditor
          + Architecture: i386
          + Version:      4.4.0-130-generic
          + Distribution: Ubuntu 16.04 LTS
      - Process ID: 6116 (0x17e4)
      - Process started: 2018-08-10 13:44:51.550+0000
      - Process uptime: 3 days 18 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-openjdk-i386/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-i386/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-i386/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-i386/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-i386/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-i386/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-i386/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-i386/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/i386:/usr/lib/i386-label_uneasy_auditor-gnu/jni:/lib/i386-label_uneasy_auditor-gnu:/usr/lib/i386-label_uneasy_auditor-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Djsse.enableSNIExtension=false`

  * computer_awful_volunteer (`hudson.slaves.DumbSlave`)
      - Description:    _Ubuntu 16.04 x86&#95;64 [ip_compatible_connection]_
      - Executors:      4
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         label_uneasy_auditor item_controversial_funeral item_constructive_parallel item_separate_publication label_childish_concession
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.20
      - Java
          + Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_181
          + Maximum memory:   878.50 MB (921174016)
          + Allocated memory: 53.50 MB (56098816)
          + Free memory:      15.29 MB (16031256)
          + In-use memory:    38.21 MB (40067560)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.181-b13
      - Operating system
          + Name:         label_uneasy_auditor
          + Architecture: amd64
          + Version:      4.4.0-130-generic
          + Distribution: Ubuntu 16.04 LTS
      - Process ID: 25118 (0x621e)
      - Process started: 2018-08-10 13:44:52.551+0000
      - Process uptime: 3 days 18 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-label_uneasy_auditor-gnu/jni:/lib/x86_64-label_uneasy_auditor-gnu:/usr/lib/x86_64-label_uneasy_auditor-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Djsse.enableSNIExtension=false`

  * computer_dull_bond (`hudson.slaves.DumbSlave`)
      - Description:    _ODROID C2 ARM [ip_welcome_signature]_
      - Executors:      1
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         label_uneasy_auditor item_secular_vegetarian label_childish_concession
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.20

  * computer_honorable_creation (`hudson.slaves.DumbSlave`)
      - Description:    _ODROID C2 ARM [ip_whole_monster]_
      - Executors:      1
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         label_uneasy_auditor item_secular_vegetarian label_childish_concession
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.20

  * computer_mutual_few (`hudson.slaves.DumbSlave`)
      - Description:    _InstallShield Node *** NEVER CHANGE THE # of EXECUTORS!!! *** [ip_complex_turn]_
      - Executors:      1
      - Remote FS root: `C:\JenkinsMk2`
      - Labels:         label_bloody_competition label_noble_shadow label_imperial_predecessor label_bland_hole
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.20
      - Java
          + Home:           `C:\Program Files\Java\jre1.8.0_171`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_171
          + Maximum memory:   910,50 MB (954728448)
          + Allocated memory: 327,50 MB (343408640)
          + Free memory:      112,68 MB (118151856)
          + In-use memory:    214,82 MB (225256784)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.171-b11
      - Operating system
          + Name:         label_bloody_competition Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 6840 (0x1ab8)
      - Process started: 2018-08-10 13:44:56.071+0000
      - Process uptime: 3 days 17 hr
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files\Java\jre1.8.0_171\lib\resources.jar;C:\Program Files\Java\jre1.8.0_171\lib\rt.jar;C:\Program Files\Java\jre1.8.0_171\lib\sunrsasign.jar;C:\Program Files\Java\jre1.8.0_171\lib\jsse.jar;C:\Program Files\Java\jre1.8.0_171\lib\jce.jar;C:\Program Files\Java\jre1.8.0_171\lib\charsets.jar;C:\Program Files\Java\jre1.8.0_171\lib\jfr.jar;C:\Program Files\Java\jre1.8.0_171\classes`
          + Classpath: `slave.jar`
          + Library path: `C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\label_bloody_competition\Sun\Java\bin;C:\label_bloody_competition\system32;C:\label_bloody_competition;C:\view_nervous_attitude\cygwin\bin;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\label_bloody_competition\system32;C:\label_bloody_competition;C:\label_bloody_competition\System32\Wbem;C:\label_bloody_competition\System32\WindowsPowerShell\v1.0;C:\ProgramData\chocolatey\bin;C:\Program Files\TortoiseSVN\bin;C:\Program Files\Java\jre7\bin;C:\view_nervous_attitude\python2;C:\label_bloody_competition\System32\WindowsPowerShell\v1.0;C:\Program Files (x86)\SignTools;C:\Program Files (x86)\CMake\bin;.`


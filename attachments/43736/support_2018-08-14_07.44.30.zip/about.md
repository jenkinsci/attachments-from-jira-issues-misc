Jenkins
=======

Version details
---------------

  * Version: `2.121.1`
  * Mode:    WAR
  * Url:     http://siderepos:8080/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-8-oracle/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_91
      - Maximum memory:   3.48 GB (3741319168)
      - Allocated memory: 1.99 GB (2137522176)
      - Free memory:      509.55 MB (534303928)
      - In-use memory:    1.49 GB (1603218248)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.91-b14
  * Operating system
      - Name:         label_uneasy_auditor
      - Architecture: amd64
      - Version:      3.2.0-35-generic
      - Distribution: Ubuntu 12.04.1 LTS
  * Process ID: 1295 (0x50f)
  * Process started: 2018-08-10 13:44:12.882+0000
  * Process uptime: 3 days 18 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: true

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * all-changes:1.5 'All changes plugin'
  * ansicolor:0.5.2 'AnsiColor'
  * ant:1.8 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * any-buildstep:0.1 'Any Build Step Plugin'
  * apache-httpcomponents-client-4-api:4.5.5-3.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * bouncycastle-api:2.16.3 'bouncycastle API Plugin'
  * branch-api:2.0.20 'Branch API Plugin'
  * build-flow-plugin:0.20 'Build Flow plugin'
  * build-pipeline-plugin:1.5.8 'Build Pipeline Plugin'
  * buildgraph-view:1.8 'buildgraph-view'
  * buildresult-trigger:0.17 'Jenkins BuildResultTrigger Plug-in'
  * built-on-column:1.1 'built-on-column'
  * bulk-builder:1.5 'Bulk Builder'
  * cloudbees-folder:6.5.1 'Folders Plugin'
  * cmakebuilder:2.6.0 'CMake plugin'
  * command-launcher:1.2 'Command Agent Launcher Plugin'
  * compact-columns:1.10 'Compact Columns'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * config-file-provider:2.18 'Config File Provider Plugin'
  * console-column-plugin:1.5 'Console Column Plugin'
  * convert-to-pipeline:1.0 'Convert To Pipeline'
  * credentials:2.1.17 *(update available)* 'Credentials Plugin'
  * credentials-binding:1.16 'Credentials Binding Plugin'
  * cron_column:1.4 'Cron Column Plugin'
  * cvs:2.14 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.11 'Dashboard View'
  * dependency-queue-plugin:1.2-SNAPSHOT (private-01/24/2017 13:10-user_dry_emotion) 'Dependency Queue Plugin'
  * disk-usage:0.28 'Jenkins disk-usage plugin'
  * display-url-api:2.2.0 'Display URL API'
  * docker-commons:1.13 'Docker Commons Plugin'
  * docker-workflow:1.17 'Docker Pipeline'
  * durable-task:1.22 *(update available)* 'Durable Task Plugin'
  * envinject:2.1.6 'Environment Injector Plugin'
  * envinject-api:1.5 'EnvInject API Plugin'
  * excludeMatrixParent:1.1 'excludeMatrixParent'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * flexible-publish:0.15.2 'Flexible Publish Plugin'
  * fstrigger:0.39 'Jenkins Filesystem Trigger Plug-in'
  * git-client:2.7.2 *(update available)* 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * ivytrigger:0.34 'Jenkins IvyTrigger Plug-in'
  * jackson2-api:ip_conscious_process 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jdk-tool:1.1 'JDK Tool Plugin'
  * job-restrictions:0.7 'Jenkins Job Restrictions Plugin'
  * jquery:1.12.4-0 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * jsch:ip_fine_simplicity 'Jenkins JSch dependency plugin'
  * junit:1.24 'JUnit Plugin'
  * ldap:1.20 'LDAP Plugin'
  * lockable-resources:2.3 'Lockable Resources plugin'
  * mailer:1.21 'Jenkins Mailer Plugin'
  * managed-scripts:1.4 'Managed Scripts'
  * mapdb-api:ip_legal_tyre 'MapDB API Plugin'
  * matrix-auth:2.2 *(update available)* 'Matrix Authorization Strategy Plugin'
  * matrix-combinations-parameter:1.3.0 'Matrix Configuration Parameter Plugin'
  * matrix-project:1.13 'Matrix Project Plugin'
  * matrix-reloaded:1.1.3 'Matrix Reloaded Plugin'
  * Matrix-sorter-plugin:1.3 'Matrix sorter plugin'
  * maven-plugin:3.1.2 'Maven Integration plugin'
  * metrics:ip_visible_example 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * msbuild:1.29 'Jenkins MSBuild Plugin'
  * multi-branch-project-plugin:0.7 'Multi-Branch Project Plugin (DEPRECATED)'
  * next-build-number:1.5 'Next Build Number Plugin'
  * nodelabelparameter:1.7.2 'Node and Label parameter plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.35.2 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.7 'Pipeline: Build Step'
  * pipeline-graph-analysis:1.7 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.3.1 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.3.1 'Pipeline: Declarative'
  * pipeline-model-extensions:1.3.1 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.10 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.3.1 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.10 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:2.1.0 'Pipeline Utility Steps'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * powershell:1.3 'Jenkins PowerShell plugin'
  * project-stats-plugin:0.4 'Project statistics Plugin'
  * promoted-builds:3.2 'Jenkins promoted builds plugin'
  * purge-build-queue-plugin:1.0 'Purge Build Queue Plugin'
  * pyenv-pipeline:1.0.4 'Pyenv Pipeline Plugin'
  * python:1.3 'Python Plugin'
  * role-strategy:2.8.1 *(update available)* 'Role-based Authorization Strategy'
  * run-condition:1.0 'Run Condition Plugin'
  * saferestart:0.3 'Safe Restart Plugin'
  * scm-api:2.2.7 'SCM API Plugin'
  * script-security:1.44 'Script Security Plugin'
  * scripttrigger:0.34 'scripttrigger'
  * secure-requester-whitelist:1.2 'Secure Requester Whitelist Plugin'
  * ssh-credentials:1.14 'SSH Credentials Plugin'
  * ssh-slaves:1.26 'Jenkins SSH Slaves plugin'
  * ssh-steps:1.1.0 'SSH Pipeline Steps'
  * structs:1.14 'Structs Plugin'
  * subversion:2.11.0 *(update available)* 'Jenkins Subversion Plug-in'
  * support-core:2.49 'Support Core Plugin'
  * thinBackup:1.9 'ThinBackup'
  * timestamper:1.8.10 'Timestamper'
  * token-macro:2.5 'Token Macro Plugin'
  * translation:1.16 'Jenkins Translation Assistance plugin'
  * urltrigger:0.43 *(update available)* 'Jenkins URLTrigger Plug-in'
  * variant:1.1 'Variant Plugin'
  * label_bloody_competition-slaves:1.3.1 'label_bloody_competition Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.28 *(update available)* 'Pipeline: API'
  * workflow-basic-steps:2.9 'Pipeline: Basic Steps'
  * workflow-cps:2.54 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.9 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.19 *(update available)* 'Pipeline: Nodes and Processes'
  * workflow-job:2.22 *(update available)* 'Pipeline: Job'
  * workflow-multibranch:2.19 *(update available)* 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.16 'Pipeline: Step API'
  * workflow-support:2.19 *(update available)* 'Pipeline: Supporting APIs'
  * xtrigger:0.54 'Jenkins XTrigger Plug-in'

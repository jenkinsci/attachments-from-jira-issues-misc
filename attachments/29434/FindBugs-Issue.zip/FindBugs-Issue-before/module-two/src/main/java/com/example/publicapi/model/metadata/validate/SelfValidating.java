package com.example.publicapi.model.metadata.validate;

import com.example.publicapi.model.metadata.validate.SelfValidatingException;
import com.example.publicapi.model.metadata.validate.Validatable;

public interface SelfValidating extends Validatable {
    void validate() throws SelfValidatingException;
}

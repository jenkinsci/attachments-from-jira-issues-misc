package com.example;


import static org.apache.commons.lang.StringUtils.join;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import org.apache.log4j.Logger;

public class CommandRunner {

    private static final Logger LOGGER = Logger.getLogger(CommandRunner.class);

    public static void runCmd(String cmd) throws IOException, InterruptedException {
        LOGGER.info("Running cmd: " + cmd);
        Runtime run = Runtime.getRuntime();
        Process pr = run.exec(new String[] { "bash", "-c", cmd });
        BufferedReader buf = new BufferedReader(new InputStreamReader(pr.getInputStream(), StandardCharsets.UTF_8));
        String line;
        while ((line = buf.readLine()) != null) {
            LOGGER.info(line);
        }
        boolean foundError = false;
        BufferedReader buf2 = new BufferedReader(new InputStreamReader(pr.getErrorStream()));
        String line2;
        while ((line2 = buf2.readLine()) != null) {
            foundError = true;
            LOGGER.error(line2);
        }
        pr.waitFor();

        if (foundError) {
            throw new RuntimeException("Failed to run cmd: " + cmd);
        }
        LOGGER.info("Successfully ran cmd: " + cmd);
    }

    public static void runCmd(String[] cmd) throws IOException, InterruptedException {

        LOGGER.info("Running cmd: " + join(cmd, ",").replaceAll("\n", " "));
        Runtime runtime = Runtime.getRuntime();
        Process pr = runtime.exec(cmd);
        BufferedReader buf = new BufferedReader(new InputStreamReader(pr.getInputStream(), StandardCharsets.UTF_8));
        String line;
        while ((line = buf.readLine()) != null) {
            LOGGER.info(line);
        }
        boolean foundError = false;
        BufferedReader buf2 = new BufferedReader(new InputStreamReader(pr.getErrorStream()));
        String line2;
        while ((line2 = buf2.readLine()) != null) {
            foundError = true;
            LOGGER.error(line2);
        }
        pr.waitFor();

        if (foundError) {
            throw new RuntimeException("Failed to run cmd: '" + join(cmd, ",") + "'");
        }
        LOGGER.info("Successfully ran cmd: " + join(cmd, ",").replaceAll("\n", ""));
    }

}

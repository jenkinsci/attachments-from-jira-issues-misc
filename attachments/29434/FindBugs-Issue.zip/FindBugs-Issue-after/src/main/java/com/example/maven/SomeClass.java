/**
 * Created by vlad on 19.03.15.
 */

package com.example.maven;

public class SomeClass {
    public int someMethod(final int inputVar) {
        final int someVar = (inputVar * 2);
        return someVar * 5;
    }
}

package com.example.track.selector.util;

import com.example.publicapi.model.metadata.LocalisedHeading;
import org.apache.commons.lang.StringUtils;

import static com.example.publicapi.model.metadata.LocalisedHeading.Builder.localisedHeading;

public class ExplicitCensor {

    public static final String CENSORER = "*";

    public static LocalisedHeading censor(LocalisedHeading heading) {
        LocalisedHeading.Builder censoredHeading = localisedHeading();
        if (heading.getTitle()!=null) {
            censoredHeading.withTitle(censorPhrase(heading.getTitle().getTitle()));
        }
        if (heading.getSubtitle()!=null) {
            censoredHeading.withSubtitle(censorPhrase(heading.getSubtitle().getSubtitle()));
        }
        return censoredHeading.build();
    }


    private static String censorPhrase(String phrase) {
        return null;
    }

    private static String replace(String phrase, String find) {
        do {
            String inLower = phrase.toLowerCase();
            int pos = inLower.indexOf(find);
            if (pos > -1) {
                phrase = phrase.substring(0, pos+1) + StringUtils.repeat(CENSORER, find.length() - 2) +
                        phrase.substring(pos+find.length()-1);
            } else {
                break;
            }
        } while (true);
        return phrase;
    }
}

package com.example.track.selector.util;

import com.google.common.base.CharMatcher;
import com.example.publicapi.model.metadata.LocalisedHeading;

import java.lang.Character.UnicodeBlock;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;

import static com.google.common.base.CharMatcher.inRange;
import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Lists.reverse;
import static com.google.common.collect.Sets.newHashSet;
import static java.lang.Character.UnicodeBlock.*;

public class AlphabetDetector {
    // From highest priority to lowest. Prefer rare languages
    @SuppressWarnings("serial")
    public static LinkedHashMap<UnicodeBlock, String> scriptPriorities =
            new LinkedHashMap<UnicodeBlock, String>() {{
                put(HANGUL_SYLLABLES, "ko");
                put(KATAKANA, "ja");
                put(HIRAGANA, "ja");
                put(CJK_UNIFIED_IDEOGRAPHS, "zh");
                put(CYRILLIC, "ru");
                put(GREEK, "el");
                put(BASIC_LATIN, "en");
            }};

    private static final CharMatcher KATAKANA_WIDTH = inRange((char) 0xFF65, (char) 0xFF9F);
    private static final CharMatcher CJK_WIDTH = inRange((char) 0xFF61, (char) 0xFF64);
    private static final CharMatcher HANGUL_WIDTH = inRange((char) 0xFFA0, (char) 0xFFDC);

    public static String detectHeadingLanguage(LocalisedHeading localisedHeading) {
        String title = "";
        String subtitle = "";
        if (localisedHeading.getTitle() != null) {
            title = localisedHeading.getTitle().getTitle();
        }
        if (localisedHeading.getSubtitle() != null) {
            subtitle = localisedHeading.getSubtitle().getSubtitle();
        }
        UnicodeBlock halfWidthBlock = checkHalfWidth(title + subtitle);
        if(halfWidthBlock != null) {
            return scriptPriorities.get(halfWidthBlock);
        }
        UnicodeBlock headerScript = detectPhrase(title + subtitle);

        return scriptPriorities.get(headerScript);
    }

    private static UnicodeBlock checkHalfWidth(String phrase) {
        if (KATAKANA_WIDTH.matchesAnyOf(phrase)) {
            return KATAKANA;
        } else if (CJK_WIDTH.matchesAnyOf(phrase)) {
            return CJK_UNIFIED_IDEOGRAPHS;
        } else if (HANGUL_WIDTH.matchesAnyOf(phrase)) {
            return HANGUL_SYLLABLES;
        }
        return null;
    }

    public static UnicodeBlock detectPhrase(String phrase) {
        Set<UnicodeBlock> phraseScripts = newHashSet();
        for (int i = 0; i < phrase.length(); i++) {
            phraseScripts.add(UnicodeBlock.of(phrase.charAt(i)));
        }
        return highestPrioritizedAlphabet(phraseScripts);
    }

    private static UnicodeBlock highestPrioritizedAlphabet(Set<UnicodeBlock> phraseScripts) {
        for (UnicodeBlock script : scriptPriorities.keySet()) {
            if (phraseScripts.contains(script)) {
                return script;
            }
        }
        return BASIC_LATIN;
    }

    public static List<String> countryCodePriorities() {
        // Reversed priority list represents how common the language is
        return reverse(newArrayList(scriptPriorities.values()));
    }

    public static String getMostCommonLanguage() {
        return countryCodePriorities().get(0);
    }
}

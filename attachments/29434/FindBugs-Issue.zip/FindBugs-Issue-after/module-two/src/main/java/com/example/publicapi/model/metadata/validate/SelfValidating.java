package com.example.publicapi.model.metadata.validate;

public interface SelfValidating extends Validatable {
    void validate() throws SelfValidatingException;
}

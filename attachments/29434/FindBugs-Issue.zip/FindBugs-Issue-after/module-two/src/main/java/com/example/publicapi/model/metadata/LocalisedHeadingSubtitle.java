package com.example.publicapi.model.metadata;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonValue;

public class LocalisedHeadingSubtitle {
    private String subtitle;

    private LocalisedHeadingSubtitle() {
    }

    private LocalisedHeadingSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    @JsonValue
    public String getSubtitle() {
        return this.subtitle;
    }

    @JsonCreator
    public static LocalisedHeadingSubtitle fromString(String string) {
        return new LocalisedHeadingSubtitle(string);
    }

    public static LocalisedHeadingSubtitle localisedHeadingSubtitle(String subtitle) {
        return fromString(subtitle);
    }

    public String toString() {
        return "LocalisedHeadingSubtitle{subtitle=\'" + this.subtitle + '\'' + '}';
    }
}

package com.example.track.selector.util;

import com.example.publicapi.model.metadata.LocalisedHeading;

import java.util.List;

import static com.google.common.collect.Lists.newArrayList;

public class ExplicitDetector {

    public static final List<String> swearWords = newArrayList("nigga", "nigger", "cunt", "fuck");

    public static boolean containsExplicitText(LocalisedHeading localisedHeading) {
        if (titleContainsExplicitContent(localisedHeading)) return true;
        if (subTitleContainsExplicitContent(localisedHeading)) return true;
        return false;
    }

    private static boolean titleContainsExplicitContent(LocalisedHeading localisedHeading) {
        if (localisedHeading.getTitle() == null) return false;
        String title = localisedHeading.getTitle().getTitle().toLowerCase();
        return containsSwearWordIn(title);
    }

    private static boolean subTitleContainsExplicitContent(LocalisedHeading localisedHeading) {
        if (localisedHeading.getSubtitle() == null) return false;
        String subTitle = localisedHeading.getSubtitle().getSubtitle().toLowerCase();
        return containsSwearWordIn(subTitle);
    }

    private static boolean containsSwearWordIn(String phrase) {
        for (String swear : swearWords){
            if (phrase.contains(swear)) return true;
        }
        return false;
    }
}

package com.example.track.selector.model;

import com.google.common.base.Optional;
import com.google.common.collect.ForwardingMap;
import com.example.publicapi.model.LanguageTag;
import com.example.publicapi.model.metadata.LocalisedHeading;

import java.util.HashMap;
import java.util.Map;

import static com.example.track.selector.util.AlphabetDetector.detectHeadingLanguage;
import static com.example.track.selector.util.AlphabetDetector.getMostCommonLanguage;
import static com.example.track.selector.util.ExplicitCensor.censor;
import static com.example.track.selector.util.ExplicitDetector.containsExplicitText;
import static com.example.publicapi.model.LanguageTag.languageTag;

public class LocalisedHeadingAggregator extends ForwardingMap<LanguageTag, LocalisedHeading> {

    public static final String LANGUAGE_TAG_X_ALT = "-x-alt";
    public static final String LANGUAGE_TAG_X_EXPLICIT = "-x-explicit";
    public static final int MAX_ALTERNATIVE_TAGS = 10;
    private Map<LanguageTag,LocalisedHeading> delegate;
    private boolean useLanguageDetection;

    public LocalisedHeadingAggregator(boolean useLanguageDetection) {
        this.delegate = new HashMap<LanguageTag, LocalisedHeading>();
        this.useLanguageDetection = useLanguageDetection;
    }

    @Override
    protected Map<LanguageTag, LocalisedHeading> delegate() {
        return delegate;
    }

    public void addHeading(LocalisedHeading localisedHeading) {
        LanguageTag baseLanguageTag = detectBaseLanguageTag(localisedHeading);
        Optional<LanguageTag> firstAvailableLanguageTag = nextAvailableLanguageTag(baseLanguageTag);

        if (firstAvailableLanguageTag.isPresent()) {
            super.put(firstAvailableLanguageTag.get(), localisedHeading);

            if (containsExplicitContent(firstAvailableLanguageTag.get())) {
                addHeading(censor(localisedHeading));
            }
        }
    }

    private LanguageTag detectBaseLanguageTag(LocalisedHeading localisedHeading) {
        String languageTag = determineHeadingLanguage(localisedHeading);

        if (containsExplicitText(localisedHeading)) {
            languageTag += LANGUAGE_TAG_X_EXPLICIT;
        }
        return languageTag(languageTag);
    }

    private String determineHeadingLanguage(LocalisedHeading localisedHeading) {
        if (useLanguageDetection) {
            return detectHeadingLanguage(localisedHeading);
        } else {
            return getMostCommonLanguage();
        }
    }

    private Optional<LanguageTag> nextAvailableLanguageTag(LanguageTag languageTag) {
        LanguageTag nextLanguageTag = languageTag;
        int index = 0;
        while (super.containsKey(nextLanguageTag)) {
            index++;
            if (tooManyAlternatives(index)) {
                return Optional.absent();
            }
            nextLanguageTag = getNextLanguageTag(languageTag.getLanguage(), index);
        }
        return Optional.of(nextLanguageTag);
    }

    private boolean tooManyAlternatives(int index) {
        return index > MAX_ALTERNATIVE_TAGS;
    }

    private LanguageTag getNextLanguageTag(String languageTag, int index) {
        if (index > 0) {
            if (!languageTag.endsWith(LANGUAGE_TAG_X_EXPLICIT)) languageTag += LANGUAGE_TAG_X_ALT;
            return languageTag(languageTag + "-" + index);
        }
        return languageTag(languageTag);
    }

    private boolean containsExplicitContent(LanguageTag languageTag) {
        return languageTag.getLanguage().contains(LANGUAGE_TAG_X_EXPLICIT);
    }
}

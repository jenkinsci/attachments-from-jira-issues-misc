package com.example.track.selector;


import com.example.publicapi.model.metadata.LocalisedHeading;

public class PrioritizedHeading implements Comparable<PrioritizedHeading> {
    private Integer frequencyPriority;
    private LocalisedHeading localisedHeading;
    private Boolean containsForbiddenCharacters;

    public PrioritizedHeading(int frequencyPriority, LocalisedHeading localisedHeading, boolean containsForbiddenCharacters) {
        this.frequencyPriority = frequencyPriority;
        this.localisedHeading = localisedHeading;
        this.containsForbiddenCharacters = containsForbiddenCharacters;
    }

    public Integer getFrequencyPriority() {
        return frequencyPriority;
    }

    public LocalisedHeading getLocalisedHeading() {
        return localisedHeading;
    }

    public Boolean isContainsForbiddenCharacters() {
        return containsForbiddenCharacters;
    }

    @Override
    public int compareTo(PrioritizedHeading other) {
        int firstComparison = isContainsForbiddenCharacters().compareTo(other.isContainsForbiddenCharacters());

        if (firstComparison != 0) {
            return firstComparison;
        } else {
            return frequencyPriority.compareTo(other.getFrequencyPriority());
        }
    }
}

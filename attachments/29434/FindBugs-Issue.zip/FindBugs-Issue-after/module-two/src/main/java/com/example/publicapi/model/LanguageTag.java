package com.example.publicapi.model;

import com.example.publicapi.model.metadata.validate.SelfValidating;
import com.example.publicapi.model.metadata.validate.SelfValidatingException;
import java.util.IllformedLocaleException;
import java.util.Locale.Builder;
import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonValue;
import org.hamcrest.Description;
import org.hamcrest.SelfDescribing;

public class LanguageTag implements SelfDescribing, SelfValidating {
    private String language;

    private LanguageTag() {
    }

    private LanguageTag(String language) {
        this.language = language;
    }

    @JsonValue
    public String getLanguage() {
        return this.language;
    }

    void setLanguage(String language) {
        this.language = language;
    }

    @JsonCreator
    public static LanguageTag fromString(String language) {
        return new LanguageTag(language);
    }

    public static LanguageTag languageTag(String language) {
        return fromString(language);
    }

    public void describeTo(Description description) {
        description.appendValue(this.language);
    }

    public String toString() {
        return this.language;
    }

    public boolean equals(Object o) {
        if(this == o) {
            return true;
        } else if(o != null && this.getClass() == o.getClass()) {
            LanguageTag that = (LanguageTag)o;
            if(this.language != null) {
                if(!this.language.equals(that.language)) {
                    return false;
                }
            } else if(that.language != null) {
                return false;
            }

            return true;
        } else {
            return false;
        }
    }

    public int hashCode() {
        return this.language != null?this.language.hashCode():0;
    }

    public void validate() throws SelfValidatingException {
        Builder locale = new Builder();

        try {
            locale.setLanguageTag(this.language);
        } catch (IllformedLocaleException var3) {
            throw new SelfValidatingException("Malformed IETF Language Tag");
        }
    }
}

package com.example.publicapi.model.metadata.validate;

public class SelfValidatingException extends RuntimeException {
    private final String validationFailureCause;

    public SelfValidatingException(String validationFailureCause) {
        super(validationFailureCause);
        this.validationFailureCause = validationFailureCause;
    }

    public String getValidationFailureCause() {
        return this.validationFailureCause;
    }
}

package com.example.publicapi.model.metadata;


public class LocalisedHeading {
    private LocalisedHeadingTitle title;
    private LocalisedHeadingSubtitle subtitle;

    private LocalisedHeading() {
    }

    private LocalisedHeading(LocalisedHeading.Builder builder) {
        this.subtitle = builder.subtitle;
        this.title = builder.title;
    }

    public LocalisedHeadingTitle getTitle() {
        return this.title;
    }

    public LocalisedHeadingSubtitle getSubtitle() {
        return this.subtitle;
    }

    public boolean hasSubtitle() {
        return this.subtitle != null;
    }

    public String toString() {
        return "LocalisedHeading{title=\'" + this.title + '\'' + ", subtitle=\'" + this.subtitle + '\'' + '}';
    }

    public static class Builder {
        private LocalisedHeadingTitle title;
        private LocalisedHeadingSubtitle subtitle;

        public Builder() {
        }

        public static LocalisedHeading.Builder localisedHeading() {
            return new LocalisedHeading.Builder();
        }

        public static LocalisedHeading.Builder from(LocalisedHeading from) {
            return localisedHeading().withSubtitle((LocalisedHeadingSubtitle)from.subtitle).withTitle((LocalisedHeadingTitle)from.title);
        }

        public LocalisedHeading.Builder withTitle(String title) {
            this.title = LocalisedHeadingTitle.fromString(title);
            return this;
        }

        public LocalisedHeading.Builder withTitle(LocalisedHeadingTitle title) {
            this.title = title;
            return this;
        }

        public LocalisedHeading.Builder withSubtitle(String subtitle) {
            this.subtitle = LocalisedHeadingSubtitle.fromString(subtitle);
            return this;
        }

        public LocalisedHeading.Builder withSubtitle(LocalisedHeadingSubtitle subtitle) {
            this.subtitle = subtitle;
            return this;
        }

        public LocalisedHeading build() {
            return new LocalisedHeading(this);
        }
    }
}

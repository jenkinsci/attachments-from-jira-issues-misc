package com.example.publicapi.model.metadata.validate;

public interface Validatable {
}

package com.example.publicapi.model.metadata;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonValue;

public class LocalisedHeadingTitle {
    private String title;

    private LocalisedHeadingTitle() {
    }

    private LocalisedHeadingTitle(String title) {
        this.title = title;
    }

    @JsonValue
    public String getTitle() {
        return this.title;
    }

    @JsonCreator
    public static LocalisedHeadingTitle fromString(String title) {
        return localisedHeadingTitle(title);
    }

    public static LocalisedHeadingTitle localisedHeadingTitle(String title) {
        return new LocalisedHeadingTitle(title);
    }

    public String toString() {
        return "LocalisedHeadingTitle{title=\'" + this.title + '\'' + '}';
    }
}

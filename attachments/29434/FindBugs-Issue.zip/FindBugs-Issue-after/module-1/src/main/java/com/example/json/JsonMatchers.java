package com.example.json;

import com.jayway.jsonpath.JsonPath;
import com.jayway.jsonpath.PathNotFoundException;
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeDiagnosingMatcher;
import org.skyscreamer.jsonassert.JSONAssert;

public class JsonMatchers {

    public static Matcher<String> sameJsonString(final String expected) {
        return new TypeSafeDiagnosingMatcher<String>() {
            @Override
            protected boolean matchesSafely(String actual, Description mismatchDescription) {
                try {
                    JSONAssert.assertEquals(actual, expected, false);
                    return true;
                } catch (Exception assertionFailure) {
                    mismatchDescription.appendText(assertionFailure.getMessage());
                    return false;
                } catch (Error assertionFailure) {
                    mismatchDescription.appendText(assertionFailure.getMessage());
                    return false;
                }
            }

            @Override
            public void describeTo(Description description) {
                description.appendText("JSON string ")
                        .appendValue(expected);
            }
        };
    }

    public static Matcher<? super String> hasPropertyAt(final String path) {
        return new TypeSafeDiagnosingMatcher<String>() {
            @Override
            protected boolean matchesSafely(String json, Description mismatchDescription) {
                boolean matches = pathExists(json, path);
                if (!matches) {
                    mismatchDescription
                            .appendText("no property at ")
                            .appendValue(path);
                }
                return matches;
            }

            @Override
            public void describeTo(Description description) {
                description.appendText("JSON property at ")
                        .appendValue(path);
            }
        };
    }


    public static <T> Matcher<String> hasPropertyAt(final String path, final T expected) {
        return new TypeSafeDiagnosingMatcher<String>() {
            @Override
            protected boolean matchesSafely(String json, Description mismatchDescription) {
                if (!pathExists(json, path)) {
                    mismatchDescription
                            .appendText("no element at ")
                            .appendValue(path);
                }
                T actual = valueAt(json, path);
                boolean matches = actual.equals(expected);
                if (!matches) {
                    mismatchDescription
                            .appendText("value at ")
                            .appendValue(path)
                            .appendText(" is ")
                            .appendValue(actual);
                }

                return matches;
            }

            @Override
            public void describeTo(Description description) {
                description.appendText("JSON property at ")
                        .appendValue(path)
                        .appendText(" with value ")
                        .appendValue(expected);
            }
        };
    }

    private static <T> T valueAt(String json, String path) {
        return JsonPath.read(json, path);
    }

    private static boolean pathExists(String json, String path) {
        try {
            JsonPath.read(json, path);
            return true;
        } catch (PathNotFoundException e) {
            return false;
        }
    }

}

Browser
=======

  * Screen size: 1920x1200
  * User Agent
      - Type:     Browser
      - Name:     Chromium
      - Family:   CHROMIUM
      - Producer: Google Inc. and contributors
      - Version:  58.0.3029.110
      - Raw:      `Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/58.0.3029.110 Chrome/58.0.3029.110 Safari/537.36`
  * Operating System
      - Name:     Linux (Ubuntu)
      - Family:   LINUX
      - Producer: Canonical Ltd.
      - Version:  


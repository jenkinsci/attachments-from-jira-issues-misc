Node statistics
===============

  * Total number of nodes
      - Sample size:        31845
      - Average (mean):     15.999999999999998
      - Average (median):   16.0
      - Standard deviation: 1.7763568394002503E-15
      - Minimum:            16
      - Maximum:            16
      - 95th percentile:    16.0
      - 99th percentile:    16.0
  * Total number of nodes online
      - Sample size:        31845
      - Average (mean):     14.0
      - Average (median):   14.0
      - Standard deviation: 0.0
      - Minimum:            14
      - Maximum:            14
      - 95th percentile:    14.0
      - 99th percentile:    14.0
  * Total number of executors
      - Sample size:        31845
      - Average (mean):     33.00000000000001
      - Average (median):   33.0
      - Standard deviation: 7.105427357601002E-15
      - Minimum:            33
      - Maximum:            33
      - 95th percentile:    33.0
      - 99th percentile:    33.0
  * Total number of executors in use
      - Sample size:        31845
      - Average (mean):     4.044036377252663
      - Average (median):   4.0
      - Standard deviation: 0.2630342984180328
      - Minimum:            0
      - Maximum:            6
      - 95th percentile:    4.0
      - 99th percentile:    6.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/data/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.7
      - Java
          + Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_121
          + Maximum memory:   3.56 GB (3817865216)
          + Allocated memory: 1.14 GB (1225785344)
          + Free memory:      622.76 MB (653016288)
          + In-use memory:    546.24 MB (572769056)
          + PermGen used:     162.38 MB (170268824)
          + PermGen max:      512.00 MB (536870912)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.121-b00
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.16.0-4-amd64
      - Process ID: 706 (0x2c2)
      - Process started: 2017-08-23 17:49:34.663+0000
      - Process uptime: 5 days 12 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`
          + arg[1]: `-Dhudson.model.DirectoryBrowserSupport.CSP=`
          + arg[2]: `-Xmx4g`
          + arg[3]: `-XX:MaxPermSize=512m`
          + arg[4]: `-Dcom.sun.management.jmxremote.port=3333`
          + arg[5]: `-Dcom.sun.management.jmxremote.ssl=false`
          + arg[6]: `-Dcom.sun.management.jmxremote.authenticate=false`

Loggers currently enabled
=========================
hudson.plugins.audit_trail - CONFIG
org.jenkinsci.plugins.periodicbackup - ALL
org.apache.sshd - WARNING
winstone - INFO
 - INFO

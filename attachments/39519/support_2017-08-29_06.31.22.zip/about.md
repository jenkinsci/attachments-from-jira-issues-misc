Jenkins
=======

Version details
---------------

  * Version: `2.46.2`
  * Mode:    WAR
  * Url:     http://jenkins-mw.miclaser.net/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_121
      - Maximum memory:   3.56 GB (3817865216)
      - Allocated memory: 1.14 GB (1225785344)
      - Free memory:      628.39 MB (658913800)
      - In-use memory:    540.61 MB (566871544)
      - PermGen used:     162.38 MB (170268824)
      - PermGen max:      512.00 MB (536870912)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.121-b00
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.16.0-4-amd64
  * Process ID: 706 (0x2c2)
  * Process started: 2017-08-23 17:49:34.663+0000
  * Process uptime: 5 days 12 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`
      - arg[1]: `-Dhudson.model.DirectoryBrowserSupport.CSP=`
      - arg[2]: `-Xmx4g`
      - arg[3]: `-XX:MaxPermSize=512m`
      - arg[4]: `-Dcom.sun.management.jmxremote.port=3333`
      - arg[5]: `-Dcom.sun.management.jmxremote.ssl=false`
      - arg[6]: `-Dcom.sun.management.jmxremote.authenticate=false`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-collector:1.52 'Static Analysis Collector Plug-in'
  * analysis-core:1.92 'Static Analysis Utilities'
  * ant:1.7 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * audit-trail:2.2 'Audit Trail'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * blueocean:1.2.0 'Blue Ocean'
  * blueocean-autofavorite:1.0.0 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.2.0 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.2.0 'Common API for Blue Ocean'
  * blueocean-config:1.2.0 'Config API for Blue Ocean'
  * blueocean-dashboard:1.2.0 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.1.0 'Display URL for Blue Ocean'
  * blueocean-events:1.2.0 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.2.0 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.2.0 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.2.0 'i18n for Blue Ocean'
  * blueocean-jwt:1.2.0 'JWT for Blue Ocean'
  * blueocean-personalization:1.2.0 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.2.0 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.2.0 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.2.0 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.2.0 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.2.0 'REST Implementation for Blue Ocean'
  * blueocean-web:1.2.0 'Web for Blue Ocean'
  * bouncycastle-api:2.16.2 'bouncycastle API Plugin'
  * branch-api:2.0.11 'Branch API Plugin'
  * build-flow-plugin:0.20 'Build Flow plugin'
  * build-keeper-plugin:1.3 'Build Keeper Plugin'
  * build-metrics:1.3 'build-metrics'
  * build-monitor-plugin:1.12+build.201704111018 'Build Monitor View'
  * build-timeout:1.18 'Jenkins build timeout plugin'
  * buildgraph-view:1.8 'buildgraph-view'
  * built-on-column:1.1 'built-on-column'
  * checkstyle:3.49 'Checkstyle Plug-in'
  * ci-game:1.26 'Jenkins Continuous Integration game'
  * claim:2.9 'Jenkins Claim Plugin'
  * cloudbees-bitbucket-branch-source:2.2.3 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.1.2 'Folders Plugin'
  * cobertura:1.11 'Jenkins Cobertura Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * confluence-publisher:1.8 'Confluence Publisher'
  * copyartifact:1.38.1 'Copy Artifact Plugin'
  * cppcheck:1.21 'Jenkins Cppcheck Plug-in'
  * credentials:2.1.14 'Credentials Plugin'
  * credentials-binding:1.13 'Credentials Binding Plugin'
  * cvs:2.13 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.11 'Dashboard View'
  * display-url-api:2.0 'Display URL API'
  * docker-commons:1.8 'Docker Commons Plugin'
  * docker-workflow:1.12 'Docker Pipeline'
  * doxygen:0.18 'Jenkins Doxygen Plug-in'
  * dry:2.49 'DRY Plug-in'
  * durable-task:1.14 'Durable Task Plugin'
  * email-ext:2.58 'Email Extension Plugin'
  * emma:1.29 'Jenkins Emma plugin'
  * envinject:2.1.3 'Environment Injector Plugin'
  * envinject-api:1.2 'EnvInject API Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * favorite:2.3.0 'Favorite'
  * findbugs:4.71 'FindBugs Plug-in'
  * git:3.5.1 'Jenkins Git plugin'
  * git-client:2.5.0 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.28.0 'GitHub plugin'
  * github-api:1.86 'GitHub API Plugin'
  * github-branch-source:2.2.3 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * global-build-stats:1.4 'Hudson global-build-stats plugin'
  * greenballs:1.15 'Green Balls'
  * groovy:2.0 'Groovy'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * hipchat:2.1.1 'Jenkins HipChat Plugin'
  * htmlpublisher:1.14 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * jacoco:2.2.1 'Jenkins JaCoCo plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jdepend:1.2.4 'Jenkins JDepend Plugin'
  * jira:2.4.2 'Jenkins JIRA plugin'
  * job-import-plugin:1.8 'Job Import Plugin'
  * jobConfigHistory:2.17 'Jenkins Job Configuration History Plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * junit:1.21 'JUnit Plugin'
  * junit-attachments:1.4.2 'JUnit Attachments Plugin'
  * ldap:1.16 'LDAP Plugin'
  * lockable-resources:2.0 'Lockable Resources plugin'
  * log-parser:2.0 'Log Parser Plugin'
  * mail-watcher-plugin:1.16 'Mail Watcher Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.7 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.11 'Matrix Project Plugin'
  * matrixtieparent:1.2 'Matrix Tie Parent plugin'
  * maven-plugin:2.17 'Maven Integration plugin'
  * mercurial:2.0 *(update available)* 'Jenkins Mercurial plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * monitoring:1.68.1 *(update available)* 'Monitoring'
  * msbuild:1.27 'Jenkins MSBuild Plugin'
  * mstest:0.19 'MSTest plugin'
  * mstestrunner:1.3.0 'Jenkins MSTestRunner plugin'
  * multi-slave-config-plugin:1.2.0 'Multi slave config plugin'
  * next-build-number:1.4 'Next Build Number Plugin'
  * nodelabelparameter:1.7.2 'Node and Label parameter plugin'
  * ownership:0.10.0 'Job and Node ownership plugin'
  * p4:1.7.4 'P4 Plugin'
  * page-markup:0.3 'Hudson Page Markup Plug-in'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parallel-test-executor:1.9 'Parallel Test Executor Plugin'
  * parameterized-trigger:2.35.1 'Jenkins Parameterized Trigger plugin'
  * percentage-du-node-column:0.1.0 'Percentage Disk Space Node Column plugin'
  * perforce:1.3.36 'Perforce Plugin'
  * performance:3.3 'Performance Plugin'
  * periodicbackup:1.5 'Periodic Backup'
  * pipeline-build-step:2.5.1 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.5 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.1.9 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.1.9 'Pipeline: Model Definition'
  * pipeline-model-extensions:1.1.9 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.8 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.1.9 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.8 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * pmd:3.49 'PMD Plug-in'
  * postbuild-task:1.8 'Hudson Post build task'
  * progress-bar-column-plugin:1.0 'Progress Bar Column Plugin'
  * promoted-builds:2.29 'Jenkins promoted builds plugin'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * release:2.8 'Jenkins Release Plugin'
  * resource-disposer:0.7 'Resource Disposer Plugin'
  * role-strategy:2.5.1 'Role-based Authorization Strategy'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:2.2.1 'SCM API Plugin'
  * script-security:1.33 'Script Security Plugin'
  * sidebar-link:1.9.1 'Sidebar Link'
  * sloccount:1.21 'Jenkins SLOCCount Plug-in'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-agent:1.15 'SSH Agent Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.21 'Jenkins SSH Slaves plugin'
  * structs:1.10 'Structs Plugin'
  * subversion:2.9 'Jenkins Subversion Plug-in'
  * support-core:2.41 'Support Core Plugin'
  * tasks:4.52 'Task Scanner Plug-in'
  * terminal:1.4 'Jenkins Terminal Plugin'
  * timestamper:1.8.8 'Timestamper'
  * token-macro:2.2 'Token Macro Plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * valgrind:0.27 'Jenkins Valgrind Plug-in'
  * variant:1.1 'Variant Plugin'
  * view-job-filters:1.27 'View Job Filters'
  * violations:0.7.11 'Jenkins Violations plugin'
  * vncviewer:1.5 'VncViewer Plugin'
  * warnings:4.63 'Warnings Plug-in'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.20 'Pipeline: API'
  * workflow-basic-steps:2.6 'Pipeline: Basic Steps'
  * workflow-cps:2.39 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.8 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.13 *(update available)* 'Pipeline: Nodes and Processes'
  * workflow-job:2.11.2 'Pipeline: Job'
  * workflow-multibranch:2.16 'Pipeline: Multibranch'
  * workflow-scm-step:2.5 'Pipeline: SCM Step'
  * workflow-step-api:2.12 'Pipeline: Step API'
  * workflow-support:2.14 'Pipeline: Supporting APIs'
  * ws-cleanup:0.34 'Jenkins Workspace Cleanup Plugin'
  * xvnc:1.24 'Jenkins Xvnc plugin'

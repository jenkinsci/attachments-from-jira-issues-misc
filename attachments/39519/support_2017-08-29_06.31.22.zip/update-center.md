=== Sites ===
 - Url: http://updates.jenkins-ci.org/update-center.json
 - Connection Url: http://www.google.com/
 - Implementation Type: hudson.model.UpdateSite
======
Last updated: 19 hr
Proxy: 'async-http-client' not installed, so no proxy info available.

Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 17
    - Number of items per container: 6.823529411764706 [n=17, s=6.0]
  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 8
    - Number of builds per job: 2.5 [n=8, s=2.0]
  * `hudson.matrix.MatrixProject`
    - Number of items: 2
    - Number of builds per job: 3.0 [n=2, s=3.0]
    - Number of items per container: 4.0 [n=2, s=1.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 110
    - Number of builds per job: 25.3 [n=110, s=45.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 28
    - Number of builds per job: 47.035714285714285 [n=28, s=70.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 1
    - Number of items per container: 1 [n=1]

Total job statistics
======================

  * Number of jobs: 148
  * Number of builds per job: 27.87837837837838 [n=148, s=49.0]

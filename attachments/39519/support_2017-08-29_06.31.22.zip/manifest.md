Support Bundle Manifest
=======================

Generated on 2017-08-29 06:31:22.666+0000

Requested components:

  * Garbage Collection Logs

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * Administrative monitors

      - `admin-monitors.md`

  * All loggers currently enabled.

      - `loggers.md`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records


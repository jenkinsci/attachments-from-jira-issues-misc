Item statistics
===============

  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 16
    - Number of builds per job: 7.9375 [n=16, s=30.0]
  * `hudson.matrix.MatrixProject`
    - Number of items: 16
    - Number of builds per job: 8.6875 [n=16, s=30.0]
    - Number of items per container: 1.0 [n=16, s=0.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 41
    - Number of builds per job: 201.85365853658536 [n=41, s=1000.0]

Total job statistics
======================

  * Number of jobs: 73
  * Number of builds per job: 117.01369863013699 [n=73, s=900.0]

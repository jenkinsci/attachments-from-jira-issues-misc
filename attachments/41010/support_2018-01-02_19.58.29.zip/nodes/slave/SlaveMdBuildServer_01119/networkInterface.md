-----------
 * Name utun0
 ** Index - 9
 ** InetAddress - /fe80:0:0:0:7d90:a377:a267:c5d5%utun0
 ** MTU - 2000
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name en1
 ** Hardware Address - 3c07547d0f4e
 ** Index - 5
 ** InetAddress - /fe80:0:0:0:1c18:336b:fe75:c129%en1
 ** InetAddress - /10.194.194.145
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo0
 ** Index - 1
 ** InetAddress - /fe80:0:0:0:0:0:0:1%lo0
 ** InetAddress - /0:0:0:0:0:0:0:1%lo0
 ** InetAddress - /127.0.0.1
 ** MTU - 16384
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true

-----------
 * Name utun0
 ** Index - 9
 ** InetAddress - /fe80:0:0:0:17a9:3143:9bfc:d959%utun0
 ** MTU - 2000
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name en0
 ** Hardware Address - e80688cb7a71
 ** Index - 4
 ** InetAddress - /fe80:0:0:0:ca4:64ed:f49:b659%en0
 ** InetAddress - /10.194.194.147
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo0
 ** Index - 1
 ** InetAddress - /fe80:0:0:0:0:0:0:1%lo0
 ** InetAddress - /0:0:0:0:0:0:0:1%lo0
 ** InetAddress - /127.0.0.1
 ** MTU - 16384
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true

Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * SlaveMdBuildServer_01119: Mac OS X (x86_64)
   * SlaveMdBuildServer_01217: Mac OS X (x86_64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * SlaveMdBuildServer_01119: In sync
   * SlaveMdBuildServer_01217: 1.7 sec behind
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 272.495GB left on /var/lib/jenkins.
   * SlaveMdBuildServer_01119: Disk space is too low. Only 136.031GB left on /Users/mdbuildserver/Jenkins.
   * SlaveMdBuildServer_01217: Disk space is too low. Only 107.782GB left on /Users/mdbuildserver/Jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:2676/7822MB  Swap:6143/6143MB
   * SlaveMdBuildServer_01119: Memory:0/0MB  Swap:1579/3072MB
   * SlaveMdBuildServer_01217: Memory:0/0MB  Swap:1698/8192MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 272.495GB left on /tmp.
   * SlaveMdBuildServer_01119: Disk space is too low. Only 136.031GB left on /private/var/folders/qh/jpbmk9bn5vq5v4gx0vthvljw0000gp/T.
   * SlaveMdBuildServer_01217: Disk space is too low. Only 107.782GB left on /private/var/folders/qh/jpbmk9bn5vq5v4gx0vthvljw0000gp/T.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * SlaveMdBuildServer_01119: 1689ms
   * SlaveMdBuildServer_01217: 3349ms
nslookup
----
 - Is Ignored: false
 - Computers:
   * master: null
   * SlaveMdBuildServer_01119: null
   * SlaveMdBuildServer_01217: null

Jenkins
=======

Version details
---------------

  * Version: `2.99`
  * Mode:    WAR
  * Url:     https://nps-jenkins.gamesys.co.uk/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_151
      - Maximum memory:   3.56 GB (3817865216)
      - Allocated memory: 1.48 GB (1588592640)
      - Free memory:      185.95 MB (194987872)
      - In-use memory:    1.30 GB (1393604768)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.151-b12
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-693.11.1.el7.x86_64
  * Process ID: 27121 (0x69f1)
  * Process started: 2018-01-02 19:54:20.991+0000
  * Process uptime: 4 min 9 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`
      - arg[1]: `-Dcom.sun.net.ssl.enableECC=false`
      - arg[2]: `-Xmx4g`
      - arg[3]: `-XX:MaxPermSize=512m`
      - arg[4]: `-XX:ReservedCodeCacheSize=512m`
      - arg[5]: `-Dhudson.model.ParametersAction.keepUndefinedParameters=true`
      - arg[6]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `hudson.plugins.active_directory.ActiveDirectorySecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * active-directory:2.6 'Jenkins Active Directory plugin'
  * analysis-collector:1.52 'Static Analysis Collector Plug-in'
  * analysis-core:1.93 'Static Analysis Utilities'
  * android-lint:2.5 'Android Lint Plugin'
  * android-signing:2.2.5 'Android Signing Plugin'
  * ansicolor:0.5.2 'AnsiColor'
  * ant:1.7 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.3-2.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * artifactdeployer:0.33 'Jenkins Artifact Deployer Plug-in'
  * artifactory:2.14.0 'Jenkins Artifactory Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * blame-upstream-commiters:1.2 'Blame Upstream Committers'
  * blueocean:1.3.5 'Blue Ocean'
  * blueocean-autofavorite:1.2.1 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.3.5 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.3.5 'Common API for Blue Ocean'
  * blueocean-config:1.3.5 'Config API for Blue Ocean'
  * blueocean-dashboard:1.3.5 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.2.0 'Display URL for Blue Ocean'
  * blueocean-events:1.3.5 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.3.5 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.3.5 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.3.5 'i18n for Blue Ocean'
  * blueocean-jira:1.3.5 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.3.5 'JWT for Blue Ocean'
  * blueocean-personalization:1.3.5 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.3.5 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.3.5 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.3.5 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.3.5 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.3.5 'REST Implementation for Blue Ocean'
  * blueocean-web:1.3.5 'Web for Blue Ocean'
  * bouncycastle-api:2.16.2 'bouncycastle API Plugin'
  * branch-api:2.0.17 'Branch API Plugin'
  * build-flow-plugin:0.20 'Build Flow plugin'
  * build-pipeline-plugin:1.5.8 'Build Pipeline Plugin'
  * buildgraph-view:1.8 'buildgraph-view'
  * built-on-column:1.1 'built-on-column'
  * ccm:3.1 'CCM Plug-in'
  * clang-scanbuild-plugin:1.7 'Clang Scan-Build Plugin'
  * cloudbees-bitbucket-branch-source:2.2.8 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.2.1 'Folders Plugin'
  * cobertura:1.12 'Jenkins Cobertura Plugin'
  * command-launcher:1.2 'Command Agent Launcher Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * config-file-provider:2.16.4 'Config File Provider Plugin'
  * confluence-publisher:2.0.1 'Confluence Publisher'
  * copy-to-slave:1.4.4 'Copy To Slave Plugin'
  * credentials:2.1.16 'Credentials Plugin'
  * credentials-binding:1.13 'Credentials Binding Plugin'
  * cvs:2.13 'Jenkins CVS Plug-in'
  * display-url-api:2.2.0 'Display URL API'
  * docker-commons:1.10 'Docker Commons Plugin'
  * docker-workflow:1.14 'Docker Pipeline'
  * dry:2.49 'DRY Plug-in'
  * durable-task:1.17 'Durable Task Plugin'
  * email-ext:2.61 'Email Extension Plugin'
  * embeddable-build-status:1.9 'embeddable-build-status'
  * envinject:2.1.5 'Environment Injector Plugin'
  * envinject-api:1.5 'EnvInject API Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * external-workspace-manager:1.1.2 'External Workspace Manager Plugin'
  * ez-templates:1.3.1 'EZ Templates'
  * fail-the-build-plugin:1.0 'Fail The Build Plugin'
  * favorite:2.3.1 'Favorite'
  * ghprb:1.39.0 'GitHub Pull Request Builder'
  * git:3.7.0 'Jenkins Git plugin'
  * git-changelog:1.54 'Git Changelog'
  * git-client:2.7.0 'Jenkins Git client plugin'
  * git-notes:0.0.4 'git-notes Plugin'
  * git-parameter:0.9.0 'Git Parameter Plug-In'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * git-tag-message:1.6.1 'Git Tag Message Plugin'
  * github:1.28.1 'GitHub plugin'
  * github-api:1.90 'GitHub API Plugin'
  * github-branch-source:2.3.2 'GitHub Branch Source Plugin'
  * github-oauth:0.28.1 'GitHub Authentication plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * google-oauth-plugin:0.5 'Google OAuth Credentials plugin'
  * google-play-android-publisher:1.5 'Google Play Android Publisher Plugin'
  * gradle:1.28 'Gradle Plugin'
  * greenballs:1.15 'Green Balls'
  * groovy:2.0 'Groovy'
  * groovy-postbuild:2.3.1 'Groovy Postbuild'
  * groovy-remote:0.2 'Groovy Remote Control Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * hipchat:2.1.1 'Jenkins HipChat Plugin'
  * htmlpublisher:1.14 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * ivy:1.28 'Ivy Plugin'
  * jackson2-api:2.8.10.1 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jenkins-jira-issue-updater:1.18 'Jenkins Jira Issue Updater'
  * jenkins-multijob-plugin:1.28 'Jenkins Multijob plugin'
  * jira:2.5 'Jenkins JIRA plugin'
  * jira-trigger:0.5.1 'JIRA Trigger Plugin'
  * job-direct-mail:1.5 'Job Direct Mail Plugin'
  * job-dsl:1.66 'Job DSL'
  * job-fan-in:1.1.3 'JobFanIn'
  * job-restrictions:0.6 'Jenkins Job Restrictions Plugin'
  * jquery:1.12.4-0 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * jsch:0.1.54.1 'Jenkins JSch dependency plugin'
  * junit:1.23 'JUnit Plugin'
  * label-verifier:1.2 'Jenkins Label Verifier plugin'
  * ldap:1.18 'LDAP Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:2.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.12 'Matrix Project Plugin'
  * matrix-reloaded:1.1.3 'Matrix Reloaded Plugin'
  * maven-plugin:3.0 'Maven Integration plugin'
  * mercurial:2.2 'Jenkins Mercurial plugin'
  * metadata:1.1.0b 'Metadata plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * mock-slave:1.11 'Mock Agent Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * nested-view:1.14 'Nested View Plugin'
  * network-monitor:1.1 'Slave Monitor for network connectivity'
  * nodelabelparameter:1.7.2 'Node and Label parameter plugin'
  * oauth-credentials:0.3 'OAuth Credentials plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.35.2 'Jenkins Parameterized Trigger plugin'
  * persona:2.4 'Jenkins Persona Plugin'
  * pipeline-build-step:2.6 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-githubnotify-step:1.0.3 'Pipeline GitHub Notify Step Plugin'
  * pipeline-graph-analysis:1.5 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.2.5 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.2.5 'Pipeline: Declarative'
  * pipeline-model-extensions:1.2.5 'Pipeline: Declarative Extension Points API'
  * pipeline-multibranch-defaults:1.1 'Pipeline: Multibranch with defaults'
  * pipeline-rest-api:2.9 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.2.5 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.9 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:1.5.1 'Pipeline Utility Steps'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * pmd:3.49 'PMD Plug-in'
  * postbuildscript:2.2.1 'Jenkins PostBuildScript Plugin'
  * promoted-builds:2.31 'Jenkins promoted builds plugin'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * purge-job-history:1.1 'Purge Job History Plugin'
  * rebuild:1.27 'Rebuilder'
  * resource-disposer:0.8 'Resource Disposer Plugin'
  * ruby-runtime:0.13 'ruby-runtime'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:2.2.6 'SCM API Plugin'
  * scp:1.8 'Hudson SCP publisher plugin'
  * script-security:1.39 'Script Security Plugin'
  * scriptler:2.9 'Scriptler'
  * selenium-axis:0.0.6 'Selenium Capability Axis'
  * slave-prerequisites:1.0 'Slave Prerequisites plugin'
  * slave-status:1.6 'slave-status'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh:2.5 'Jenkins SSH plugin'
  * ssh-agent:1.15 'SSH Agent Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.24 'Jenkins SSH Slaves plugin'
  * structs:1.10 'Structs Plugin'
  * subversion:2.10.2 'Jenkins Subversion Plug-in'
  * support-core:2.44 'Support Core Plugin'
  * swarm:3.7 'Jenkins Self-Organizing Swarm Plug-in Modules'
  * testflight:1.3.9 'Testflight Plugin'
  * thinBackup:1.9 'ThinBackup'
  * throttle-concurrents:2.0.1 'Jenkins Throttle Concurrent Builds Plug-in'
  * token-macro:2.3 'Token Macro Plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * variant:1.1 'Variant Plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.24 'Pipeline: API'
  * workflow-basic-steps:2.6 'Pipeline: Basic Steps'
  * workflow-cps:2.42 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.9 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.17 'Pipeline: Nodes and Processes'
  * workflow-job:2.16 'Pipeline: Job'
  * workflow-multibranch:2.16 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.14 'Pipeline: Step API'
  * workflow-support:2.16 'Pipeline: Supporting APIs'
  * ws-cleanup:0.34 'Jenkins Workspace Cleanup Plugin'
  * xcode-plugin:2.0.0 'Xcode integration'

Node statistics
===============

  * Total number of nodes
      - Sample size:        15
      - Average (mean):     3.0
      - Average (median):   3.0
      - Standard deviation: 0.0
      - Minimum:            3
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of nodes online
      - Sample size:        15
      - Average (mean):     2.970924509261502
      - Average (median):   3.0
      - Standard deviation: 0.21473224692660794
      - Minimum:            1
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors
      - Sample size:        15
      - Average (mean):     8.883698037046008
      - Average (median):   9.0
      - Standard deviation: 0.8589289877064318
      - Minimum:            1
      - Maximum:            9
      - 95th percentile:    9.0
      - 99th percentile:    9.0
  * Total number of executors in use
      - Sample size:        15
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      1
      - FS root:        `/var/lib/jenkins`
      - Labels:         CentOS
      - Usage:          `NORMAL`
      - Slave Version:  3.15
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_151
          + Maximum memory:   3.56 GB (3817865216)
          + Allocated memory: 1.48 GB (1588592640)
          + Free memory:      175.58 MB (184114104)
          + In-use memory:    1.31 GB (1404478536)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.151-b12
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-693.11.1.el7.x86_64
      - Process ID: 27121 (0x69f1)
      - Process started: 2018-01-02 19:54:20.991+0000
      - Process uptime: 4 min 9 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.151-5.b12.el7_4.x86_64/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`
          + arg[1]: `-Dcom.sun.net.ssl.enableECC=false`
          + arg[2]: `-Xmx4g`
          + arg[3]: `-XX:MaxPermSize=512m`
          + arg[4]: `-XX:ReservedCodeCacheSize=512m`
          + arg[5]: `-Dhudson.model.ParametersAction.keepUndefinedParameters=true`
          + arg[6]: `-DJENKINS_HOME=/var/lib/jenkins`

  * SlaveMdBuildServer_01119 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      4
      - Remote FS root: `/Users/mdbuildserver/Jenkins`
      - Labels:         JenkinsSlaveXcode9 slaveTests buildSubmit testAllCommits ParallelCodeTests
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.14
      - Java
          + Home:           `/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_152
          + Maximum memory:   3.56 GB (3817865216)
          + Allocated memory: 245.50 MB (257425408)
          + Free memory:      184.87 MB (193849736)
          + In-use memory:    60.63 MB (63575672)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.152-b16
      - Operating system
          + Name:         Mac OS X
          + Architecture: x86_64
          + Version:      10.12.6
      - Process ID: 27957 (0x6d35)
      - Process started: 2018-01-02 19:54:56.231+0000
      - Process uptime: 3 min 34 sec
      - JVM startup parameters:
          + Boot classpath: `/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/lib/resources.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/lib/rt.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/lib/sunrsasign.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/lib/jsse.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/lib/jce.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/lib/charsets.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/lib/jfr.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/classes`
          + Classpath: `agent.jar`
          + Library path: `/Users/mdbuildserver/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.`

  * SlaveMdBuildServer_01217 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      4
      - Remote FS root: `/Users/mdbuildserver/Jenkins`
      - Labels:         JenkinsSlave_Xcode8 JenkinsSlave
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.14
      - Java
          + Home:           `/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_152
          + Maximum memory:   3.56 GB (3817865216)
          + Allocated memory: 245.50 MB (257425408)
          + Free memory:      189.85 MB (199076736)
          + In-use memory:    55.65 MB (58348672)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.152-b16
      - Operating system
          + Name:         Mac OS X
          + Architecture: x86_64
          + Version:      10.12.6
      - Process ID: 95973 (0x176e5)
      - Process started: 2018-01-02 19:55:07.457+0000
      - Process uptime: 3 min 21 sec
      - JVM startup parameters:
          + Boot classpath: `/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/lib/resources.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/lib/rt.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/lib/sunrsasign.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/lib/jsse.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/lib/jce.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/lib/charsets.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/lib/jfr.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_152.jdk/Contents/Home/jre/classes`
          + Classpath: `agent.jar`
          + Library path: `/Users/mdbuildserver/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.`


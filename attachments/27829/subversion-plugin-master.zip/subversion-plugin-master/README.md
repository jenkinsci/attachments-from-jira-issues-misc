Jenkins Subversion Plugin
=========================

Provides Jenkins integration with [Apache Subversion](http://subversion.apache.org/).

See [Subversion Plugin](https://wiki.jenkins-ci.org/display/JENKINS/Subversion+Plugin) on the Jenkins Wiki for more information.

Apache, Apache Subversion and Subversion are trademarks of the Apache Software Foundation.

Jenkins
=======

Version details
---------------

  * Version: `1.651.3`
  * Mode:    WAR
  * Url:     null
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.9`
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_72-internal
      - Maximum memory:   1.71 GB (1836580864)
      - Allocated memory: 723.00 MB (758120448)
      - Free memory:      371.26 MB (389299064)
      - In-use memory:    351.74 MB (368821384)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.72-b15
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.16.0-4-amd64
      - Distribution: Debian GNU/Linux 8.4 (jessie)
  * Process ID: 6 (0x6)
  * Process started: 2016-07-01 06:13:01.764-0600
  * Process uptime: 54 min
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Duser.timezone=America/Denver`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-core:1.78 'Static Analysis Utilities'
  * ant:1.3 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * bitbucket:1.1.5 'Jenkins Bitbucket Plugin'
  * bouncycastle-api:1.648.3 'bouncycastle API Plugin'
  * branch-api:1.10 'Branch API Plugin'
  * cloudbees-folder:5.12 'Folders Plugin'
  * conditional-buildstep:1.3.5 'Conditional BuildStep'
  * config-file-provider:2.11 'Config File Provider Plugin'
  * configurationslicing:1.45 'Configuration Slicing plugin'
  * credentials:2.1.4 'Credentials Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * depgraph-view:0.11 'Dependency Graph Viewer Plugin'
  * description-setter:1.10 'Jenkins description setter plugin'
  * durable-task:1.11 'Durable Task Plugin'
  * elastic-axis:1.2 'elastic-axis'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * findbugs:4.65 'FindBugs Plug-in'
  * git:2.5.0 'Jenkins Git plugin'
  * git-client:1.19.6 'Jenkins Git client plugin'
  * git-parameter:0.5.1 'Git Parameter Plug-In'
  * git-server:1.6 'Git server plugin'
  * github:1.19.2 'GitHub plugin'
  * github-api:1.76 'GitHub API Plugin'
  * github-branch-source:1.7 'GitHub Branch Source Plugin'
  * github-organization-folder:1.3 'GitHub Organization Folder Plugin'
  * groovy-postbuild:2.3.1 'Groovy Postbuild'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * htmlpublisher:1.11 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * implied-labels:0.5 'Implied Labels Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * jacoco:1.0.19 *(update available)* 'Jenkins JaCoCo plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * junit:1.13 'JUnit Plugin'
  * leastload:1.0.3 'Least Load plugin'
  * log-parser:2.0 'Log Parser Plugin'
  * mailer:1.17 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.4 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.7.1 'Matrix Project Plugin'
  * maven-plugin:2.13 'Maven Integration plugin'
  * mercurial:1.55 'Jenkins Mercurial plugin'
  * metrics:3.1.2.8 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * multi-branch-project-plugin:0.4.2 'Multi-Branch Project Plugin'
  * multiple-scms:0.6 'Jenkins Multiple SCMs plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parallel-test-executor:1.8 'Jenkins Parallel Test Executor Plugin'
  * parameterized-trigger:2.31 'Jenkins Parameterized Trigger plugin'
  * pegdown-formatter:1.3 'PegDown Formatter Plugin'
  * pipeline-build-step:2.1 'Pipeline: Build Step'
  * pipeline-input-step:2.0 'Pipeline: Input Step'
  * pipeline-rest-api:1.5 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.1 'Pipeline: Stage Step'
  * pipeline-stage-view:1.5 'Pipeline: Stage View Plugin'
  * plain-credentials:1.2 'Plain Credentials Plugin'
  * platformlabeler:1.1 'Hudson platformlabeler plugin'
  * pollscm:1.3 'Jenkins Poll SCM plugin'
  * preSCMbuildstep:0.3 'Pre SCM BuildStep Plugin'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:1.2 'SCM API Plugin'
  * script-security:1.20 'Script Security Plugin'
  * sidebar-link:1.7 'Sidebar Link'
  * ssh-agent:1.13 'SSH Agent Plugin'
  * ssh-credentials:1.12 'SSH Credentials Plugin'
  * ssh-slaves:1.11 'Jenkins SSH Slaves plugin'
  * structs:1.2 'Structs Plugin'
  * subversion:2.6 'Jenkins Subversion Plug-in'
  * support-core:2.32 'Support Core Plugin'
  * swarm:2.1 'Jenkins Self-Organizing Swarm Plug-in Modules'
  * text-finder:1.10 'Jenkins TextFinder plugin'
  * timestamper:1.8.4 'Timestamper'
  * token-macro:1.12.1 'Token Macro Plugin'
  * tool-labels-plugin:3.0 'Tool Labels Plugin for Jenkins'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * view-job-filters:1.27 'View Job Filters'
  * warnings:4.56 'Warnings Plug-in'
  * windows-slaves:1.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.2 'Pipeline'
  * workflow-api:2.1 'Pipeline: API'
  * workflow-basic-steps:2.0 'Pipeline: Basic Steps'
  * workflow-cps:2.8 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.1 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.3 'Pipeline: Nodes and Processes'
  * workflow-job:2.3 'Pipeline: Job'
  * workflow-multibranch:2.8 'Pipeline: Multibranch'
  * workflow-scm-step:2.1 'Pipeline: SCM Step'
  * workflow-step-api:2.2 'Pipeline: Step API'
  * workflow-support:2.1 'Pipeline: Supporting APIs'
  * xshell:0.10 'Jenkins cross-platform shell plugin'

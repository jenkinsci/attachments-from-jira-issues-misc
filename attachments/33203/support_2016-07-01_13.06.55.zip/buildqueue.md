Current build queue has 4 item(s).
---------------
 * Name of item: git-plugin-multi
    - In queue for: 10 min
    - Is blocked: true
    - Why in queue: Build #2 is already in progress (ETA:27 min)
    - Current queue trigger cause: Started by an SCM change
    - Current queue trigger cause: Started by an SCM change
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@9c065f0
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@c24895b
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@277b077f
    - Can run: null
----

 * Name of item: git-plugin-multi » jdk7,coleen-pc3
    - In queue for: 10 min
    - Is blocked: false
    - Why in queue: Waiting for next available executor on coleen-pc3
    - Current queue trigger cause: Started by upstream project "git-plugin-multi" build number 2
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@9c065f0
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@c24895b
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@277b077f
    - Can run: null
----

 * Name of item: git-plugin-multi » jdk7,coleen-pc2
    - In queue for: 10 min
    - Is blocked: false
    - Why in queue: Waiting for next available executor on coleen-pc2
    - Current queue trigger cause: Started by upstream project "git-plugin-multi" build number 2
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@9c065f0
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@c24895b
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@277b077f
    - Can run: null
----

 * Name of item: auth-data-multi » jdk7,pi-b
    - In queue for: 11 min
    - Is blocked: false
    - Why in queue: Waiting for next available executor on pi-b
    - Current queue trigger cause: Started by upstream project "auth-data-multi" build number 2
  * Task Dispatcher: com.cloudbees.hudson.plugins.folder.computed.ThrottleComputationQueueTaskDispatcher@9c065f0
    - Can run: null
  * Task Dispatcher: jenkins.branch.RateLimitBranchProperty$QueueTaskDispatcherImpl@c24895b
    - Can run: null
  * Task Dispatcher: org.jenkinsci.plugins.durabletask.executors.ContinuedTask$Scheduler@277b077f
    - Can run: null
----


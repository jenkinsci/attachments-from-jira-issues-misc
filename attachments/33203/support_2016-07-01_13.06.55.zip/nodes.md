Node statistics
===============

  * Total number of nodes
      - Sample size:        216
      - Average (mean):     16.999999999999996
      - Average (median):   17.0
      - Standard deviation: 3.552713678800501E-15
      - Minimum:            17
      - Maximum:            17
      - 95th percentile:    17.0
      - 99th percentile:    17.0
  * Total number of nodes online
      - Sample size:        216
      - Average (mean):     9.99999999797863
      - Average (median):   10.0
      - Standard deviation: 5.3419547673276106E-5
      - Minimum:            8
      - Maximum:            10
      - 95th percentile:    10.0
      - 99th percentile:    10.0
  * Total number of executors
      - Sample size:        216
      - Average (mean):     23.985807580722383
      - Average (median):   23.0
      - Standard deviation: 1.426386603676818
      - Minimum:            15
      - Maximum:            29
      - 95th percentile:    26.0
      - 99th percentile:    27.0
  * Total number of executors in use
      - Sample size:        216
      - Average (mean):     15.036753512212362
      - Average (median):   13.0
      - Standard deviation: 3.8017941277555463
      - Minimum:            0
      - Maximum:            26
      - 95th percentile:    23.0
      - 99th percentile:    23.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/var/jenkins_home`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Slave Version:  2.59
      - Java
          + Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_72-internal
          + Maximum memory:   1.71 GB (1836580864)
          + Allocated memory: 723.00 MB (758120448)
          + Free memory:      340.17 MB (356693552)
          + In-use memory:    382.83 MB (401426896)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.72-b15
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.16.0-4-amd64
          + Distribution: Debian GNU/Linux 8.4 (jessie)
      - Process ID: 6 (0x6)
      - Process started: 2016-07-01 06:13:01.764-0600
      - Process uptime: 54 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Duser.timezone=America/Denver`

  * centos67a-mwaite (`hudson.slaves.DumbSlave`)
      - Description:    _CentOS 6 x64_
      - Executors:      1
      - Remote FS root: `/home/mwaite/debian8-docker-slave`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_101
          + Maximum memory:   638.50 MB (669515776)
          + Allocated memory: 48.50 MB (50855936)
          + Free memory:      24.54 MB (25736920)
          + In-use memory:    23.96 MB (25119016)
          + PermGen used:     32.09 MB (33644968)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.95-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-642.1.1.el6.x86_64
          + Distribution: "CentOS release 6.8 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 11547 (0x2d1b)
      - Process started: 2016-07-01 06:13:16.651-0600
      - Process uptime: 53 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.101.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * centos7x64-mwaite (`hudson.slaves.DumbSlave`)
      - Description:    _CentOS 7 x64_
      - Executors:      2
      - Remote FS root: `/home/mwaite/debian8-docker-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el7_2.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_91
          + Maximum memory:   830.50 MB (870842368)
          + Allocated memory: 45.50 MB (47710208)
          + Free memory:      17.36 MB (18204920)
          + In-use memory:    28.14 MB (29505288)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.91-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-327.22.2.el7.x86_64
          + Distribution: "CentOS Linux release 7.2.1511 (Core) "
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch:cxx-4.1-amd64:cxx-4.1-noarch:desktop-4.1-amd64:desktop-4.1-noarch:languages-4.1-amd64:languages-4.1-noarch:printing-4.1-amd64:printing-4.1-noarch`
      - Process ID: 13040 (0x32f0)
      - Process started: 2016-07-01 06:13:17.359-0600
      - Process uptime: 53 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el7_2.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el7_2.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el7_2.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el7_2.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el7_2.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el7_2.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el7_2.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.91-1.b14.el7_2.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * centos7x64b-mwaite (`hudson.slaves.DumbSlave`)
      - Description:    _CentOS 7 x64_
      - Executors:      1
      - Remote FS root: `/home/mwaite/debian8-docker-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * coleen-pc2 (`hudson.slaves.DumbSlave`)
      - Description:    _First Windows PC_
      - Executors:      3
      - Remote FS root: `C:\J\D`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        (timeout with no cache available)

  * coleen-pc3 (`hudson.slaves.DumbSlave`)
      - Description:    _Second Windows PC_
      - Executors:      3
      - Remote FS root: `C:\J\D`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59

  * debian8-mwaite (`hudson.slaves.DumbSlave`)
      - Description:    _Debian 8 x64_
      - Executors:      1
      - Remote FS root: `/home/mwaite/debian8-docker-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/java-7-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_80
          + Maximum memory:   1.71 GB (1836056576)
          + Allocated memory: 118.00 MB (123731968)
          + Free memory:      88.85 MB (93164008)
          + In-use memory:    29.15 MB (30567960)
          + PermGen used:     9.88 MB (10363432)
          + PermGen max:      82.00 MB (85983232)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.80-b11
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.16.0-4-amd64
          + Distribution: Debian GNU/Linux 8.5 (jessie)
      - Process ID: 8364 (0x20ac)
      - Process started: 2016-07-01 06:13:15.585-0600
      - Process uptime: 13 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-7-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-7-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-7-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-7-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-7-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-7-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-7-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * debian8x86a-mwaite (`hudson.slaves.DumbSlave`)
      - Description:    _Debian 8 32 bit_
      - Executors:      1
      - Remote FS root: `/home/mwaite/debian8-docker-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * debian9a-mwaite (`hudson.slaves.DumbSlave`)
      - Description:    _Debian 9 (testing) x64_
      - Executors:      1
      - Remote FS root: `/home/mwaite/debian8-docker-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * mark-pc1-mwaite (`hudson.slaves.DumbSlave`)
      - Description:    _Ubuntu 14.04 x64_
      - Executors:      4
      - Remote FS root: `/home/mwaite/debian8-docker-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/java-7-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_80
          + Maximum memory:   1.72 GB (1851260928)
          + Allocated memory: 276.50 MB (289931264)
          + Free memory:      39.42 MB (41334024)
          + In-use memory:    237.08 MB (248597240)
          + PermGen used:     30.09 MB (31549304)
          + PermGen max:      82.00 MB (85983232)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.80-b11
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.2.0-41-generic
          + Distribution: Ubuntu 14.04.4 LTS
      - Process ID: 1720 (0x6b8)
      - Process started: 2016-07-01 06:13:15.738-0600
      - Process uptime: 53 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-7-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-7-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-7-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-7-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-7-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-7-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-7-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * pi-a (`hudson.slaves.DumbSlave`)
      - Description:    _Raspberry Pi time keeper_
      - Executors:      1
      - Remote FS root: `/home/mwaite/debian8-docker-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * pi-b (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/home/mwaite/debian8-docker-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/jdk-8-oracle-arm32-vfp-hflt/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_65
          + Maximum memory:   235.88 MB (247332864)
          + Allocated memory: 15.50 MB (16252928)
          + Free memory:      7.15 MB (7493336)
          + In-use memory:    8.35 MB (8759592)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Oracle Corporation
          + Version: 25.65-b01
      - Operating system
          + Name:         Linux
          + Architecture: arm
          + Version:      4.4.11-v7+
          + Distribution: Raspbian GNU/Linux 8.0 (jessie)
          + LSB Modules:  `core-2.0-armhf:core-2.0-noarch:core-3.0-armhf:core-3.0-noarch:core-3.1-armhf:core-3.1-noarch:core-3.2-armhf:core-3.2-noarch:core-4.0-armhf:core-4.0-noarch:core-4.1-armhf:core-4.1-noarch:cxx-3.0-armhf:cxx-3.0-noarch:cxx-3.1-armhf:cxx-3.1-noarch:cxx-3.2-armhf:cxx-3.2-noarch:cxx-4.0-armhf:cxx-4.0-noarch:cxx-4.1-armhf:cxx-4.1-noarch:desktop-3.1-armhf:desktop-3.1-noarch:desktop-3.2-armhf:desktop-3.2-noarch:desktop-4.0-armhf:desktop-4.0-noarch:desktop-4.1-armhf:desktop-4.1-noarch:graphics-2.0-armhf:graphics-2.0-noarch:graphics-3.0-armhf:graphics-3.0-noarch:graphics-3.1-armhf:graphics-3.1-noarch:graphics-3.2-armhf:graphics-3.2-noarch:graphics-4.0-armhf:graphics-4.0-noarch:graphics-4.1-armhf:graphics-4.1-noarch:languages-3.2-armhf:languages-3.2-noarch:languages-4.0-armhf:languages-4.0-noarch:languages-4.1-armhf:languages-4.1-noarch:multimedia-3.2-armhf:multimedia-3.2-noarch:multimedia-4.0-armhf:multimedia-4.0-noarch:multimedia-4.1-armhf:multimedia-4.1-noarch:printing-3.2-armhf:printing-3.2-noarch:printing-4.0-armhf:printing-4.0-noarch:printing-4.1-armhf:printing-4.1-noarch:qt4-3.1-armhf:qt4-3.1-noarch:security-4.0-armhf:security-4.0-noarch:security-4.1-armhf:security-4.1-noarch`
      - Process ID: 15325 (0x3bdd)
      - Process started: 2016-07-01 06:13:16.396-0600
      - Process uptime: 13 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/jdk-8-oracle-arm32-vfp-hflt/jre/lib/resources.jar:/usr/lib/jvm/jdk-8-oracle-arm32-vfp-hflt/jre/lib/rt.jar:/usr/lib/jvm/jdk-8-oracle-arm32-vfp-hflt/jre/lib/sunrsasign.jar:/usr/lib/jvm/jdk-8-oracle-arm32-vfp-hflt/jre/lib/jsse.jar:/usr/lib/jvm/jdk-8-oracle-arm32-vfp-hflt/jre/lib/jce.jar:/usr/lib/jvm/jdk-8-oracle-arm32-vfp-hflt/jre/lib/charsets.jar:/usr/lib/jvm/jdk-8-oracle-arm32-vfp-hflt/jre/lib/jfr.jar:/usr/lib/jvm/jdk-8-oracle-arm32-vfp-hflt/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/arm:/lib:/usr/lib`

  * ubuntu14a-mwaite (`hudson.slaves.DumbSlave`)
      - Description:    _Ubuntu 14.04 x64 - older computer_
      - Executors:      1
      - Remote FS root: `/home/mwaite/debian8-docker-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * ubuntu14b-mwaite (`hudson.slaves.DumbSlave`)
      - Description:    _Ubuntu 14.04 x64_
      - Executors:      1
      - Remote FS root: `/home/mwaite/debian8-docker-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * ubuntu14c-mwaite (`hudson.slaves.DumbSlave`)
      - Description:    _Ubuntu 14.04 x64 - older computer_
      - Executors:      1
      - Remote FS root: `/home/mwaite/debian8-docker-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * waima04-rhel7 (`hudson.slaves.DumbSlave`)
      - Description:    _Red Hat Enterprise Developer 7 x64_
      - Executors:      3
      - Remote FS root: `/home/mwaite/debian8-docker-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/java/jdk1.8.0_91/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_91
          + Maximum memory:   1.71 GB (1840250880)
          + Allocated memory: 65.50 MB (68681728)
          + Free memory:      35.16 MB (36871616)
          + In-use memory:    30.34 MB (31810112)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.91-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.10.0-327.22.2.el7.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 7.2 (Maipo)"
          + LSB Modules:  `:core-4.1-amd64:core-4.1-noarch`
      - Process ID: 2452 (0x994)
      - Process started: 2016-07-01 06:13:17.191-0600
      - Process uptime: 53 min
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_91/jre/lib/resources.jar:/usr/java/jdk1.8.0_91/jre/lib/rt.jar:/usr/java/jdk1.8.0_91/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_91/jre/lib/jsse.jar:/usr/java/jdk1.8.0_91/jre/lib/jce.jar:/usr/java/jdk1.8.0_91/jre/lib/charsets.jar:/usr/java/jdk1.8.0_91/jre/lib/jfr.jar:/usr/java/jdk1.8.0_91/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * wheezy64b-mwaite (`hudson.slaves.DumbSlave`)
      - Description:    _Debian 8 x64_
      - Executors:      1
      - Remote FS root: `/home/mwaite/debian8-docker-slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_91
          + Maximum memory:   868.00 MB (910163968)
          + Allocated memory: 59.50 MB (62390272)
          + Free memory:      43.02 MB (45113440)
          + In-use memory:    16.48 MB (17276832)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.91-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.2.0-4-amd64
          + Distribution: Debian GNU/Linux 7.11 (wheezy)
      - Process ID: 26544 (0x67b0)
      - Process started: 2016-07-01 06:13:16.573-0600
      - Process uptime: 13 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`


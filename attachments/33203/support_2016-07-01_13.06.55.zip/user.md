User
====

Authentication
--------------

  * Authenticated: true
  * Name: mwaite
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@d704362a: Username: hudson.security.HudsonPrivateSecurityRealm$Details@a535b8d; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@ef30: RemoteIpAddress: 172.16.16.108; SessionId: 9ikzo2xlsdvhgpesqs75lzkv; Granted Authorities: authenticated`


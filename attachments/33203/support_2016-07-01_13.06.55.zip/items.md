Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 5
    - Number of items per container: 20.8 [n=5, s=30.0]
  * `com.github.mjdetullio.jenkins.plugins.multibranch.FreeStyleMultiBranchProject`
    - Number of items: 2
    - Number of items per container: 0.0 [n=2, s=0.0]
  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 94
    - Number of builds per job: 1.0425531914893618 [n=94, s=0.3]
  * `hudson.matrix.MatrixProject`
    - Number of items: 10
    - Number of builds per job: 0.0 [n=10, s=0.0]
    - Number of items per container: 9.4 [n=10, s=7.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 99
    - Number of builds per job: 0.0 [n=99, s=0.0]
  * `jenkins.branch.OrganizationFolder`
    - Number of items: 1
    - Number of items per container: 0 [n=1]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 31
    - Number of builds per job: 0.9354838709677419 [n=31, s=0.2]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 4
    - Number of items per container: 7.25 [n=4, s=7.0]

Total job statistics
======================

  * Number of jobs: 234
  * Number of builds per job: 0.5427350427350427 [n=234, s=0.56]

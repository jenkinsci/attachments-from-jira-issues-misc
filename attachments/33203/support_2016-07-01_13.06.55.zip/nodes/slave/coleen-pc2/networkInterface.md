-----------
 * Name Software Loopback Interface 1
 ** Index - 1
 ** InetAddress - /127.0.0.1
 ** InetAddress - /0:0:0:0:0:0:0:1
 ** MTU - -1
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Virtual WiFi Miniport Adapter
 ** Index - 2
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Bluetooth Device (Personal Area Network)
 ** Hardware Address - 1c659db06257
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:d4d5:6c3f:5f1e:feb3%eth0
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name DW1520 Wireless-N WLAN Half-Mini Card
 ** Hardware Address - c0cb3877dbbf
 ** Index - 4
 ** InetAddress - /fe80:0:0:0:e9ed:c548:9322:ab19%wlan1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Broadcom NetXtreme 57xx Gigabit Controller
 ** Hardware Address - 782bcbc80dfa
 ** Index - 5
 ** InetAddress - /172.16.16.130
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Bluetooth Device (RFCOMM Protocol TDI)
 ** Index - 6
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Kernel Debug Network Adapter
 ** Index - 7
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Apple Mobile Device Ethernet
 ** Index - 8
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Teredo Tunneling Pseudo-Interface
 ** Hardware Address - 00000000000000e0
 ** Index - 9
 ** InetAddress - /2001:0:9d38:6abd:89:39e6:b656:9a3d
 ** InetAddress - /fe80:0:0:0:89:39e6:b656:9a3d%net1
 ** MTU - 1280
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - false
-----------
 * Name Microsoft Hosted Network Virtual Adapter
 ** Hardware Address - c0cb3877dbbf
 ** Index - 10
 ** InetAddress - /fe80:0:0:0:4900:f1a8:4169:6744%wlan2
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft ISATAP Adapter #2
 ** Index - 11
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Broadcom NetXtreme 57xx Gigabit Controller-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 12
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Broadcom NetXtreme 57xx Gigabit Controller-QoS Packet Scheduler-0000
 ** Index - 13
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Broadcom NetXtreme 57xx Gigabit Controller-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 14
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name DW1520 Wireless-N WLAN Half-Mini Card-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 15
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name DW1520 Wireless-N WLAN Half-Mini Card-Virtual WiFi Filter Driver-0000
 ** Index - 16
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name DW1520 Wireless-N WLAN Half-Mini Card-Native WiFi Filter Driver-0000
 ** Index - 17
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name DW1520 Wireless-N WLAN Half-Mini Card-QoS Packet Scheduler-0000
 ** Index - 18
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name DW1520 Wireless-N WLAN Half-Mini Card-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 19
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Hosted Network Virtual Adapter-WFP Native MAC Layer LightWeight Filter-0000
 ** Index - 20
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Hosted Network Virtual Adapter-Native WiFi Filter Driver-0000
 ** Index - 21
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Hosted Network Virtual Adapter-QoS Packet Scheduler-0000
 ** Index - 22
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name Microsoft Hosted Network Virtual Adapter-WFP 802.3 MAC Layer LightWeight Filter-0000
 ** Index - 23
 ** MTU - -1
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true

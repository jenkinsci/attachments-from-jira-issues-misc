Loggers currently enabled
=========================
edu.umd.cs.findbugs - WARNING
winstone - INFO
org.apache.sshd - WARNING
 - INFO

/*___Generated_by_IDEA___*/

/** Automatically generated file. DO NOT MODIFY */
package org.jenkins.testflightplugin.android.AndroidRTE;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
Node monitors
=============
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 296.624GB left on D:\Program Files (x86)\Jenkins.
   * MIOKETSBLDWVT01: Disk space is too low. Only 2.723GB left on D:\Jenkins.
   * Newdev-Build11: Disk space is too low. Only 296.624GB left on D:\Jenkins.
Node owners
----
 - Is Ignored: false
 - Computers:
   * master: null
   * MIOKETSBLDWVT01: null
   * Newdev-Build11: null
Architecture
----
 - Is Ignored: true
Clock Difference
----
 - Is Ignored: true
Free Swap Space
----
 - Is Ignored: true
Free Temp Space
----
 - Is Ignored: true
 - Threshold: 1GB
Response Time
----
 - Is Ignored: true
Approved Folders
----
 - Is Ignored: false
 - Computers:
   * master: null
   * MIOKETSBLDWVT01: null
   * Newdev-Build11: null

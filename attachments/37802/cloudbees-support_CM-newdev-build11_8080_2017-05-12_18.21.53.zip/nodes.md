Node statistics
===============

  * Total number of nodes
      - Sample size:        17340
      - Average (mean):     2.0
      - Average (median):   2.0
      - Standard deviation: 0.0
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of nodes online
      - Sample size:        17340
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        17340
      - Average (mean):     5.0
      - Average (median):   5.0
      - Standard deviation: 0.0
      - Minimum:            5
      - Maximum:            5
      - 95th percentile:    5.0
      - 99th percentile:    5.0
  * Total number of executors in use
      - Sample size:        17340
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      0
      - FS root:        `D:\Program Files (x86)\Jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.7
      - Java
          + Home:           `D:\Program Files (x86)\Jenkins\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_60
          + Maximum memory:   989.88 MB (1037959168)
          + Allocated memory: 368.69 MB (386596864)
          + Free memory:      106.69 MB (111872504)
          + In-use memory:    262.00 MB (274724360)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Oracle Corporation
          + Version: 25.60-b23
      - Operating system
          + Name:         Windows 7
          + Architecture: x86
          + Version:      6.1
      - Process ID: 461556 (0x70af4)
      - Process started: 2017-05-09 18:06:11.400+0000
      - Process uptime: 3 days 0 hr
      - JVM startup parameters:
          + Boot classpath: `D:\Program Files (x86)\Jenkins\jre\lib\resources.jar;D:\Program Files (x86)\Jenkins\jre\lib\rt.jar;D:\Program Files (x86)\Jenkins\jre\lib\sunrsasign.jar;D:\Program Files (x86)\Jenkins\jre\lib\jsse.jar;D:\Program Files (x86)\Jenkins\jre\lib\jce.jar;D:\Program Files (x86)\Jenkins\jre\lib\charsets.jar;D:\Program Files (x86)\Jenkins\jre\lib\jfr.jar;D:\Program Files (x86)\Jenkins\jre\classes`
          + Classpath: `D:\Program Files (x86)\Jenkins\jenkins.war`
          + Library path: `D:\Program Files (x86)\Jenkins\jre\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\ProgramData\Oracle\Java\javapath;c:\apache-maven-3.0.4\bin;C:\Oracle\product\11.2.0\client_1\bin;C:\product\11.2.0\client_1\bin;C:\Windows;C:\Program Files\Java\jdk1.8.0_65\bin;C:\Program Files (x86)\Java\jre1.8.0_60;C:\Program Files (x86)\AccuRev\bin;C:\Program Files (x86)\CVSNT\;D:\Program Files\groovy-2.4.1\bin;.`
          + arg[0]: `-Xrs`
          + arg[1]: `-Xmx1024m`
          + arg[2]: `-XX:MaxPermSize=512m`
          + arg[3]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`

  * MIOKETSBLDWVT01 (`hudson.slaves.DumbSlave`)
      - Description:    _Concept testing Build VM for Jenkins Test instance_
      - Executors:      5
      - Remote FS root: `D:\Jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.23
      - Java
          + Home:           `C:\Program Files (x86)\Java\jre1.8.0_91`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_91
          + Maximum memory:   247.50 MB (259522560)
          + Allocated memory: 48.14 MB (50475008)
          + Free memory:      25.08 MB (26296904)
          + In-use memory:    23.06 MB (24178104)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Oracle Corporation
          + Version: 25.91-b15
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: x86
          + Version:      6.1
      - Process ID: 4828 (0x12dc)
      - Process started: 2017-04-19 07:49:23.156+0000
      - Process uptime: 23 days
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files (x86)\Java\jre1.8.0_91\lib\resources.jar;C:\Program Files (x86)\Java\jre1.8.0_91\lib\rt.jar;C:\Program Files (x86)\Java\jre1.8.0_91\lib\sunrsasign.jar;C:\Program Files (x86)\Java\jre1.8.0_91\lib\jsse.jar;C:\Program Files (x86)\Java\jre1.8.0_91\lib\jce.jar;C:\Program Files (x86)\Java\jre1.8.0_91\lib\charsets.jar;C:\Program Files (x86)\Java\jre1.8.0_91\lib\jfr.jar;C:\Program Files (x86)\Java\jre1.8.0_91\classes`
          + Classpath: `slave.jar`
          + Library path: `C:\Program Files (x86)\Java\jre1.8.0_91\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\apache-maven-3.0.4\bin;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;D:\Program Files\HP OpenView\lib;D:\Program Files\HP OpenView\bin;D:\Program Files\HP OpenView\bin\win64;D:\Program Files\HP OpenView\bin\win64\OpC;C:\Program Files (x86)\CVSNT\;.`

  * Newdev-Build11 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `D:\Jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.52
      - Java
          + Home:           `C:\JavaHome\jdk8`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_65
          + Maximum memory:   247.50 MB (259522560)
          + Allocated memory: 19.53 MB (20480000)
          + Free memory:      5.89 MB (6173960)
          + In-use memory:    13.64 MB (14306040)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Oracle Corporation
          + Version: 25.65-b01
      - Operating system
          + Name:         Windows 7
          + Architecture: x86
          + Version:      6.1
      - Process ID: 2036 (0x7f4)
      - Process started: 2017-02-26 07:22:07.820+0000
      - Process uptime: 2 mo 15 days
      - JVM startup parameters:
          + Boot classpath: `C:\JavaHome\jdk8\lib\resources.jar;C:\JavaHome\jdk8\lib\rt.jar;C:\JavaHome\jdk8\lib\sunrsasign.jar;C:\JavaHome\jdk8\lib\jsse.jar;C:\JavaHome\jdk8\lib\jce.jar;C:\JavaHome\jdk8\lib\charsets.jar;C:\JavaHome\jdk8\lib\jfr.jar;C:\JavaHome\jdk8\classes`
          + Classpath: `slave.jar`
          + Library path: `C:\JavaHome\jdk8\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;c:\apache-maven-3.0.4\bin;C:\Oracle\product\11.2.0\client_1\bin;C:\product\11.2.0\client_1\bin;C:\Windows;C:\Program Files\Java\jdk1.8.0_65\bin;C:\Program Files (x86)\Java\jre1.8.0_60;C:\Program Files (x86)\AccuRev\bin;C:\Program Files (x86)\CVSNT\;D:\Program Files\groovy-2.4.1\bin;.`
          + arg[0]: `-Dlog4j.configuration=/log4j.properties`


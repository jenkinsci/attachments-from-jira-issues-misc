CloudBees Support Bundle Manifest
=================================

Generated on 2017-05-12 18:21:53.029+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-05-01_15.30.29.log`

      - `nodes/master/logs/all_2017-05-01_20.06.51.log`

      - `nodes/master/logs/all_2017-05-02_15.05.59.log`

      - `nodes/master/logs/all_2017-05-08_18.07.55.log`

      - `nodes/master/logs/all_2017-05-08_20.51.40.log`

      - `nodes/master/logs/all_2017-05-09_15.42.45.log`

      - `nodes/master/logs/all_2017-05-09_18.06.17.log`

      - `nodes/master/logs/all_2017-05-10_16.17.29.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/custom/Audit Trail.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Out of order build detection.log`

      - `other-logs/audit.log`

      - `other-logs/audit.log.1`

      - `other-logs/audit.log.10`

      - `other-logs/audit.log.11`

      - `other-logs/audit.log.12`

      - `other-logs/audit.log.13`

      - `other-logs/audit.log.14`

      - `other-logs/audit.log.15`

      - `other-logs/audit.log.16`

      - `other-logs/audit.log.17`

      - `other-logs/audit.log.18`

      - `other-logs/audit.log.2`

      - `other-logs/audit.log.3`

      - `other-logs/audit.log.4`

      - `other-logs/audit.log.5`

      - `other-logs/audit.log.6`

      - `other-logs/audit.log.7`

      - `other-logs/audit.log.8`

      - `other-logs/audit.log.9`

      - `other-logs/health-checker.log`

      - `other-logs/jenkins.0.err.log`

      - `other-logs/jenkins.1.err.log`

      - `other-logs/jenkins.2.err.log`

      - `other-logs/jenkins.3.err.log`

      - `other-logs/jenkins.4.err.log`

      - `other-logs/jenkins.5.err.log`

      - `other-logs/jenkins.6.err.log`

      - `other-logs/jenkins.7.err.log`

      - `other-logs/jenkins.err.log`

      - `other-logs/jenkins.out.log`

      - `other-logs/jenkins.wrapper.log`

  * Garbage Collection Logs

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/MIOKETSBLDWVT01/checksums.md5`

      - `nodes/slave/Newdev-Build11/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/MIOKETSBLDWVT01/exportTable.txt`

      - `nodes/slave/Newdev-Build11/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/MIOKETSBLDWVT01/environment.txt`

      - `nodes/slave/Newdev-Build11/environment.txt`

  * File descriptors (Unix only)

  * JVM process system metrics (Linux only)

  * Load Statistics

      - `load-stats/label/MIOKETSBLDWVT01/gnuplot`

      - `load-stats/label/MIOKETSBLDWVT01/hour.csv`

      - `load-stats/label/MIOKETSBLDWVT01/min.csv`

      - `load-stats/label/MIOKETSBLDWVT01/sec10.csv`

      - `load-stats/label/Newdev-Build11/gnuplot`

      - `load-stats/label/Newdev-Build11/hour.csv`

      - `load-stats/label/Newdev-Build11/min.csv`

      - `load-stats/label/Newdev-Build11/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/MIOKETSBLDWVT01/metrics.json`

      - `nodes/slave/Newdev-Build11/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/MIOKETSBLDWVT01/networkInterface.md`

      - `nodes/slave/Newdev-Build11/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/MIOKETSBLDWVT01/system.properties`

      - `nodes/slave/Newdev-Build11/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

      - `slow-requests/20150915-091303.984.txt`

      - `slow-requests/20150915-092334.025.txt`

      - `slow-requests/20151023-113711.296.txt`

      - `slow-requests/20151023-113747.294.txt`

      - `slow-requests/20151023-115247.260.txt`

      - `slow-requests/20151027-123147.352.txt`

      - `slow-requests/20151027-125656.445.txt`

      - `slow-requests/20151027-125659.445.txt`

      - `slow-requests/20151103-131049.046.txt`

      - `slow-requests/20151105-105255.409.txt`

      - `slow-requests/20151105-110443.452.txt`

      - `slow-requests/20151105-111058.476.txt`

      - `slow-requests/20151105-111101.476.txt`

      - `slow-requests/20151105-111334.485.txt`

      - `slow-requests/20151105-112307.521.txt`

      - `slow-requests/20151105-112507.528.txt`

      - `slow-requests/20151105-112531.530.txt`

      - `slow-requests/20151105-113728.574.txt`

      - `slow-requests/20151106-102653.226.txt`

      - `slow-requests/20151112-073902.533.txt`

      - `slow-requests/20151112-074247.456.txt`

      - `slow-requests/20160105-110901.903.txt`

      - `slow-requests/20160122-114210.843.txt`

      - `slow-requests/20160125-074336.592.txt`

      - `slow-requests/20160202-142908.787.txt`

      - `slow-requests/20160202-142908.788.txt`

      - `slow-requests/20160218-073810.307.txt`

      - `slow-requests/20160226-105300.950.txt`

      - `slow-requests/20160322-103128.040.txt`

      - `slow-requests/20160330-095739.254.txt`

      - `slow-requests/20160811-093430.782.txt`

      - `slow-requests/20160815-141030.528.txt`

      - `slow-requests/20160822-104014.212.txt`

      - `slow-requests/20161206-150419.321.txt`

      - `slow-requests/20170227-070602.748.txt`

      - `slow-requests/20170417-193305.548.txt`

      - `slow-requests/20170419-140034.656.txt`

      - `slow-requests/20170419-143053.822.txt`

      - `slow-requests/20170420-154210.682.txt`

      - `slow-requests/20170501-141851.533.txt`

      - `slow-requests/20170501-204105.550.txt`

      - `slow-requests/20170501-204417.485.txt`

      - `slow-requests/20170502-192807.678.txt`

      - `slow-requests/20170508-180903.531.txt`

      - `slow-requests/20170509-151639.005.txt`

      - `slow-requests/20170509-154051.083.txt`

      - `slow-requests/20170509-154541.804.txt`

      - `slow-requests/20170509-194215.863.txt`

      - `slow-requests/20170510-112735.206.txt`

      - `slow-requests/20170510-200641.763.txt`

  * Deadlock Records

  * Operations Center Connector Logs

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/MIOKETSBLDWVT01/thread-dump.txt`

      - `nodes/slave/Newdev-Build11/thread-dump.txt`


=== Sites ===
 - Url: http://jenkins-updates.cloudbees.com/update-center.json
 - Connection Url: null
 - Implementation Type: com.cloudbees.jenkins.plugins.license.nectar.CloudBeesUpdateSite
 - Url: https://wiki.jenkins-ci.org/display/JENKINS/Plugins
 - Connection Url: http://www.google.com/
 - Implementation Type: hudson.model.UpdateSite
 - Url: http://updates.jenkins-ci.org/update-center.json
 - Connection Url: http://www.google.com/
 - Implementation Type: jp.ikedam.jenkins.plugins.updatesitesmanager.ManagedUpdateSite
 - Url: http://updates.jenkins-ci.org/download/plugins/
 - Connection Url: http://www.google.com/
 - Implementation Type: jp.ikedam.jenkins.plugins.updatesitesmanager.ManagedUpdateSite
 - Url: http://mirrors.jenkins-ci.org/plugins/
 - Connection Url: http://www.google.com/
 - Implementation Type: jp.ikedam.jenkins.plugins.updatesitesmanager.ManagedUpdateSite
======
Last updated: 14 min
=== Proxy ===

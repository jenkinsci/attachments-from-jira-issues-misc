Browser
=======

  * Screen size: 1920x1080
  * User Agent
      - Type:     Browser
      - Name:     Firefox
      - Family:   FIREFOX
      - Producer: Mozilla Foundation
      - Version:  53.0
      - Raw:      `Mozilla/5.0 (Windows NT 6.1; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0`
  * Operating System
      - Name:     Windows 7
      - Family:   WINDOWS
      - Producer: Microsoft Corporation.
      - Version:  6.1


Jenkins
=======

Version details
---------------

  * Version: `2.46.2`
  * Mode:    WAR
  * Url:     http://newdev-build11:8080/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `D:\Program Files (x86)\Jenkins\jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_60
      - Maximum memory:   989.88 MB (1037959168)
      - Allocated memory: 368.69 MB (386596864)
      - Free memory:      111.27 MB (116673240)
      - In-use memory:    257.42 MB (269923624)
      - GC strategy:      SerialGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) Client VM
      - Vendor:  Oracle Corporation
      - Version: 25.60-b23
  * Operating system
      - Name:         Windows 7
      - Architecture: x86
      - Version:      6.1
  * Process ID: 461556 (0x70af4)
  * Process started: 2017-05-09 18:06:11.400+0000
  * Process uptime: 3 days 0 hr
  * JVM startup parameters:
      - Boot classpath: `D:\Program Files (x86)\Jenkins\jre\lib\resources.jar;D:\Program Files (x86)\Jenkins\jre\lib\rt.jar;D:\Program Files (x86)\Jenkins\jre\lib\sunrsasign.jar;D:\Program Files (x86)\Jenkins\jre\lib\jsse.jar;D:\Program Files (x86)\Jenkins\jre\lib\jce.jar;D:\Program Files (x86)\Jenkins\jre\lib\charsets.jar;D:\Program Files (x86)\Jenkins\jre\lib\jfr.jar;D:\Program Files (x86)\Jenkins\jre\classes`
      - Classpath: `D:\Program Files (x86)\Jenkins\jenkins.war`
      - Library path: `D:\Program Files (x86)\Jenkins\jre\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\ProgramData\Oracle\Java\javapath;c:\apache-maven-3.0.4\bin;C:\Oracle\product\11.2.0\client_1\bin;C:\product\11.2.0\client_1\bin;C:\Windows;C:\Program Files\Java\jdk1.8.0_65\bin;C:\Program Files (x86)\Java\jre1.8.0_60;C:\Program Files (x86)\AccuRev\bin;C:\Program Files (x86)\CVSNT\;D:\Program Files\groovy-2.4.1\bin;.`
      - arg[0]: `-Xrs`
      - arg[1]: `-Xmx1024m`
      - arg[2]: `-XX:MaxPermSize=512m`
      - arg[3]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`

Important configuration
---------------

  * Security realm: `hudson.plugins.active_directory.ActiveDirectorySecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * accelerated-build-now-plugin:1.0.1 'accelerated-build-now-plugin'
  * accurev:0.6.19-SNAPSHOT (private-09/18/2013 04:45-efusciardi) *(update available)* 'Jenkins Accurev plugin'
  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * active-directory:2.4 'Jenkins Active Directory plugin'
  * analysis-core:1.86 'Static Analysis Utilities'
  * ant:1.5 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * artifactdeployer:0.33 'Jenkins Artifact Deployer Plug-in'
  * async-http-client:1.7.24.1 'Async Http Client'
  * audit-trail:2.2 'Audit Trail'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * aws-credentials:1.19 'CloudBees Amazon Web Services Credentials Plugin'
  * aws-java-sdk:1.11.119 'Amazon Web Services SDK'
  * backup:1.6.1 'Backup plugin'
  * backup-interrupt-plugin:1.0 'Backup and interrupt job pluign'
  * blueocean:1.0.1 'Blue Ocean'
  * blueocean-autofavorite:0.7 'Autofavorite for Blue Ocean'
  * blueocean-commons:1.0.1 'Common API for Blue Ocean'
  * blueocean-config:1.0.1 'Config API for Blue Ocean'
  * blueocean-dashboard:1.0.1 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.0 'BlueOcean Display URL plugin'
  * blueocean-events:1.0.1 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.0.1 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.0.1 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.0.1 'i18n for Blue Ocean'
  * blueocean-jwt:1.0.1 'JWT for Blue Ocean'
  * blueocean-personalization:1.0.1 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.0.1 'Pipeline REST API for Blue Ocean'
  * blueocean-pipeline-editor:0.2.0 'Blue Ocean Pipeline Editor'
  * blueocean-rest:1.0.1 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.0.1 'REST Implementation for Blue Ocean'
  * blueocean-web:1.0.1 'Web for Blue Ocean'
  * bouncycastle-api:2.16.1 'bouncycastle API Plugin'
  * branch-api:2.0.9 'Branch API Plugin'
  * build-blocker-plugin:1.7.3 'Build Blocker Plugin'
  * build-failure-analyzer:1.19.0 'Build Failure Analyzer'
  * build-metrics:1.3 'build-metrics'
  * build-timeout:1.18 'Jenkins build timeout plugin'
  * build-view-column:0.3 'Build View Column Plugin'
  * built-on-column:1.1 'built-on-column'
  * bulk-builder:1.5 'Bulk Builder'
  * cloudbees-aborted-builds:1.9 'CloudBees Restart Aborted Builds Plugin'
  * cloudbees-consolidated-build-view:1.5 'CloudBees Consolidated Build View Plugin'
  * cloudbees-credentials:3.3 'CloudBees Credentials Plugin'
  * cloudbees-even-scheduler:3.7 'CloudBees Even Scheduler Plugin'
  * cloudbees-folder:6.0.4 'Folders Plugin'
  * cloudbees-folders-plus:3.1 'CloudBees Folders Plus Plugin'
  * cloudbees-ha:4.7 'CloudBees High Availability Management plugin'
  * cloudbees-jsync-archiver:5.5 'CloudBees Fast Archiving Plugin'
  * cloudbees-label-throttling-plugin:3.4 'CloudBees Label Throttling Plugin'
  * cloudbees-license:9.9 'CloudBees License Manager'
  * cloudbees-long-running-build:1.9 'CloudBees Long-Running Build Plugin'
  * cloudbees-monitoring:2.5 'CloudBees Monitoring Plugin'
  * cloudbees-nodes-plus:1.14 'CloudBees Nodes Plus Plugin'
  * cloudbees-plugin-usage:1.6 'CloudBees Plugin Usage Plugin'
  * cloudbees-quiet-start:1.2 'CloudBees Quiet Start Plugin'
  * cloudbees-secure-copy:3.9 'CloudBees Secure Copy Plugin'
  * cloudbees-ssh-slaves:1.7 'CloudBees SSH Build Agents Plugin'
  * cloudbees-support:3.9 'CloudBees Support Plugin'
  * cloudbees-template:4.28 'CloudBees Template Plugin'
  * cloudbees-update-center-plugin:4.23 'CloudBees Update Center Plugin'
  * cloudbees-view-creation-filter:1.3 'CloudBees View Creation Filter Plugin'
  * conditional-buildstep:1.3.5 'Conditional BuildStep'
  * copyartifact:1.38.1 'Copy Artifact Plugin'
  * credentials:2.1.13 'Credentials Plugin'
  * credentials-binding:1.11 'Credentials Binding Plugin'
  * custom-job-icon:0.2 'Custom Job Icon plugin'
  * cvs:2.13 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.10 'Dashboard View'
  * display-url-api:2.0 'Display URL API'
  * docker-commons:1.6 'Docker Commons Plugin'
  * docker-workflow:1.11 'Docker Pipeline'
  * downstream-ext:1.8 'Downstream-Ext'
  * durable-task:1.13 'Durable Task Plugin'
  * email-ext:2.57.2 'Email Extension Plugin'
  * envinject:2.0 *(update available)* 'Environment Injector Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * extra-columns:1.18 'Extra Columns Plugin'
  * favorite:2.0.4 'Favorite'
  * findbugs:4.70 'FindBugs Plug-in'
  * ftppublisher:1.2 'FTP publisher plugin'
  * git:3.3.0 'Jenkins Git plugin'
  * git-client:2.4.5 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.27.0 'GitHub plugin'
  * github-api:1.85 'GitHub API Plugin'
  * github-branch-source:2.0.5 'GitHub Branch Source Plugin'
  * global-build-stats:1.4 'Hudson global-build-stats plugin'
  * greenballs:1.15 'Green Balls'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * infradna-backup:3.34 'CloudBees Back-up Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jobConfigHistory:2.16 'Jenkins Job Configuration History Plugin'
  * join:1.21 'Join plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.20 'JUnit Plugin'
  * ldap:1.15 'LDAP Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * mask-passwords:2.10.1 'Mask Passwords Plugin'
  * matrix-auth:1.5 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.10 *(update available)* 'Matrix Project Plugin'
  * maven-plugin:2.15.1 'Maven Integration plugin'
  * mercurial:1.60 'Jenkins Mercurial plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * monitoring:1.65.1 *(update available)* 'Monitoring'
  * nectar-license:8.6 'CloudBees Jenkins Enterprise License Entitlement Check'
  * nectar-rbac:5.15 'CloudBees Role-Based Access Control Plugin'
  * nectar-vmware:4.3.5 'CloudBees VMWare Autoscaling Plugin'
  * node-iterator-api:1.5 'Node Iterator API Plugin'
  * openid4java:0.9.8.0 'OpenID4Java API'
  * operations-center-agent:2.46.0.2 'Operations Center Agent'
  * operations-center-client:2.46.0.2 'Operations Center Client Plugin'
  * operations-center-cloud:2.46.0.2 'Operations Center Cloud'
  * operations-center-context:2.46.0.3 'Operations Center Context'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.33 'Jenkins Parameterized Trigger plugin'
  * pipeline-graph-analysis:1.3 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.7 'Pipeline: Input Step'
  * pipeline-model-api:1.1.4 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.1.4 'Pipeline: Model Definition'
  * pipeline-model-extensions:1.1.4 'Pipeline: Declarative Extension Points API'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.1.4 'Pipeline: Stage Tags Metadata'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * postbuildscript:0.17 'Jenkins Post-Build Script Plug-in'
  * powershell:1.3 'Jenkins PowerShell plugin'
  * preSCMbuildstep:0.3 'Pre SCM BuildStep Plugin'
  * PrioritySorter:3.5.0 'Jenkins Priority Sorter Plugin'
  * promoted-builds:2.28.1 'Jenkins promoted builds plugin'
  * publish-over-ssh:1.17 'Publish Over SSH'
  * pubsub-light:1.8 'Jenkins Pub-Sub "light" Bus'
  * purge-build-queue-plugin:1.0 'Purge Build Queue Plugin'
  * resource-disposer:0.6 'Resource Disposer Plugin'
  * run-condition:1.0 'Run Condition Plugin'
  * schedule-failed-builds:1.1 'Retry Failed Builds'
  * scm-api:2.1.1 'SCM API Plugin'
  * script-security:1.27 'Script Security Plugin'
  * sidebar-link:1.7 'Sidebar Link'
  * sidebar-update-notification:1.1.0 'Sidebar Update Notification Plugin'
  * skip-plugin:4.0 'CloudBees Skip Next Build Plugin'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-agent:1.15 'SSH Agent Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.17 'Jenkins SSH Slaves plugin'
  * structs:1.6 'Structs Plugin'
  * subversion:2.7.2 'Jenkins Subversion Plug-in'
  * support-core:2.40 'Support Core Plugin'
  * thinBackup:1.9 'ThinBackup'
  * timestamper:1.8.8 'Timestamper'
  * token-macro:2.1 'Token Macro Plugin'
  * update-sites-manager:2.0.0 'UpdateSites Manager plugin'
  * variant:1.1 'Variant Plugin'
  * vsphere-cloud:2.15 'vSphere Plugin'
  * warnings:4.62 'Warnings Plug-in'
  * wikitext:3.7 'CloudBees WikiText Security Plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-api:2.13 'Pipeline: API'
  * workflow-basic-steps:2.4 'Pipeline: Basic Steps'
  * workflow-cps:2.30 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.8 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.11 'Pipeline: Nodes and Processes'
  * workflow-job:2.10 'Pipeline: Job'
  * workflow-multibranch:2.14 'Pipeline: Multibranch'
  * workflow-scm-step:2.4 'Pipeline: SCM Step'
  * workflow-step-api:2.9 'Pipeline: Step API'
  * workflow-support:2.14 'Pipeline: Supporting APIs'
  * ws-cleanup:0.33 'Jenkins Workspace Cleanup Plugin'

Packaging details
-----------------

#UNKNOWN#

CloudBees Product Description
-----------------------------

#UNKNOWN#

License details
---------------

 * Jenkins Instance ID:  `b6d8763c63b7b9174d15a2a783be75e9`
 * Expires:              Jan 30, 2018
 * Issued to:            Jeffery Noonon
 * Organization:         Delta Dental MI
 * Edition:              Enterprise Edition
     - Team Management
     - Enterprise Analytics
     - Enterprise Security
     - VMware vSphere Builds
     - Security
     - Analytics
     - Developer Productivity
     - Core
     - Build & Master Resilience
     - Optimized Utilization
     - Enterprise Management
     - Enterprise Continuous Delivery
     - CloudBees Jenkins Enterprise license with 5 executors

Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 5
    - Number of items per container: 1.2 [n=5, s=0.4]
  * `com.cloudbees.plugins.updatecenter.UpdateCenter`
    - Number of items: 1
  * `hudson.model.FreeStyleProject`
    - Number of items: 51
    - Number of builds per job: 124.41176470588235 [n=51, s=200.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 2
    - Number of builds per job: 47.0 [n=2, s=30.0]

Total job statistics
======================

  * Number of jobs: 53
  * Number of builds per job: 121.49056603773585 [n=53, s=100.0]

Loggers currently enabled
=========================
hudson.plugins.audit_trail - FINER
org.apache.sshd - WARNING
winstone - INFO
 - INFO

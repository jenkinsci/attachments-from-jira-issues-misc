Node statistics
===============

  * Total number of nodes
      - Sample size:        16
      - Average (mean):     1.9999999999999998
      - Average (median):   2.0
      - Standard deviation: 2.2204460492503128E-16
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of nodes online
      - Sample size:        16
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        16
      - Average (mean):     1.0000000000000002
      - Average (median):   1.0
      - Standard deviation: 2.220446049250313E-16
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors in use
      - Sample size:        16
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the Jenkins controller's built-in node_
      - Executors:      0
      - FS root:        `/var/jenkins_home`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  4.13.2
      - Java
          + Home:           `/opt/java/openjdk`
          + Vendor:           Eclipse Adoptium
          + Version:          11.0.15
          + Maximum memory:   15.63 GB (16785604608)
          + Allocated memory: 6.56 GB (7046430720)
          + Free memory:      4.58 GB (4918876928)
          + In-use memory:    1.98 GB (2127553792)
          + GC strategy:      G1
          + Available CPUs:   20
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Eclipse Adoptium
          + Version: 11.0.15+10
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      5.18.0-0.bpo.1-amd64
      - Process ID: 7 (0x7)
      - Process started: 2022-07-01 12:31:44.081+0000
      - Process uptime: 17 min
      - JVM startup parameters:
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Duser.home=/var/jenkins_home`
          + arg[1]: `-Djenkins.model.Jenkins.slaveAgentPort=50000`
          + arg[2]: `-Dhudson.lifecycle=hudson.lifecycle.ExitLifecycle`

  * `ubuntu` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/var/lib/jenkins-agent/agent`
      - Labels:         docker-root
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `ubuntu-rootless-docker` (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/var/lib/jenkins-agent/agent`
      - Labels:         docker-rootless
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.13.2
      - Java
          + Home:           `/usr/lib/jvm/temurin-11-jdk-amd64`
          + Vendor:           Eclipse Adoptium
          + Version:          11.0.15
          + Maximum memory:   3.91 GB (4196401152)
          + Allocated memory: 252.00 MB (264241152)
          + Free memory:      222.08 MB (232871008)
          + In-use memory:    29.92 MB (31370144)
          + GC strategy:      G1
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 11
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Eclipse Adoptium
          + Version: 11.0.15+10
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      5.13.0-51-generic
          + Distribution: Ubuntu 20.04.4 LTS
      - Process ID: 9190 (0x23e6)
      - Process started: 2022-07-01 12:31:49.171+0000
      - Process uptime: 17 min
      - JVM startup parameters:
          + Classpath: `remoting.jar`
          + Library path: `/usr/java/packages/lib:/usr/lib64:/lib64:/lib:/usr/lib`


Item statistics
===============

  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 3
    - Number of builds per job: 5.0 [n=3, s=2.0]

Total job statistics
======================

  * Number of jobs: 3
  * Number of builds per job: 5.0 [n=3, s=2.0]

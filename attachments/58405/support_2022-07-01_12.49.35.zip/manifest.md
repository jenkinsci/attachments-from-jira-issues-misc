Support Bundle Manifest
=======================

Generated on 2022-07-01 12:49:35.661+0000

Requested components:

  * Agent Configuration File

      - `nodes/slave/ubuntu-rootless-docker/config.xml`

      - `nodes/slave/ubuntu/config.xml`

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.plugins.emailext.ExtendedEmailPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/jenkins.model.JenkinsLocationConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.telemetry.Correlator.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.flow.FlowExecutionList.xml`

      - `jenkins-root-configuration-files/support-core.xml`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `identity.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/ubuntu-rootless-docker/checksums.md5`

      - `nodes/slave/ubuntu/checksums.md5`

      - `plugins/active.txt`

      - `plugins/backup.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Agent Protocols

      - `agent-protocols.md`

  * Build queue

      - `buildqueue.md`

  * Controller Custom Log Recorders

  * Dump agent export tables (could reveal some memory leaks)

      - `nodes/slave/ubuntu-rootless-docker/exportTable.txt`

      - `nodes/slave/ubuntu/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/ubuntu-rootless-docker/environment.txt`

      - `nodes/slave/ubuntu/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/ubuntu-rootless-docker/file-descriptors.txt`

  * Items Content (Computationally expensive)

      - `items.md`

  * Agent JVM process system metrics (Linux only)

      - `nodes/slave/ubuntu-rootless-docker/proc/meminfo.txt`

      - `nodes/slave/ubuntu-rootless-docker/proc/self/cmdline`

      - `nodes/slave/ubuntu-rootless-docker/proc/self/environ`

      - `nodes/slave/ubuntu-rootless-docker/proc/self/limits.txt`

      - `nodes/slave/ubuntu-rootless-docker/proc/self/mountstats.txt`

      - `nodes/slave/ubuntu-rootless-docker/proc/self/status.txt`

  * Controller JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

  * Controller Log Recorders

      - `nodes/master/logs/all_2022-07-01_12.45.31.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

  * Load Statistics

      - `load-stats/label/built-in/gnuplot`

      - `load-stats/label/built-in/hour.csv`

      - `load-stats/label/built-in/min.csv`

      - `load-stats/label/built-in/sec10.csv`

      - `load-stats/label/docker-root/gnuplot`

      - `load-stats/label/docker-root/hour.csv`

      - `load-stats/label/docker-root/min.csv`

      - `load-stats/label/docker-root/sec10.csv`

      - `load-stats/label/docker-rootless/gnuplot`

      - `load-stats/label/docker-rootless/hour.csv`

      - `load-stats/label/docker-rootless/min.csv`

      - `load-stats/label/docker-rootless/sec10.csv`

      - `load-stats/label/ubuntu-rootless-docker/gnuplot`

      - `load-stats/label/ubuntu-rootless-docker/hour.csv`

      - `load-stats/label/ubuntu-rootless-docker/min.csv`

      - `load-stats/label/ubuntu-rootless-docker/sec10.csv`

      - `load-stats/label/ubuntu/gnuplot`

      - `load-stats/label/ubuntu/hour.csv`

      - `load-stats/label/ubuntu/min.csv`

      - `load-stats/label/ubuntu/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/ubuntu-rootless-docker/networkInterface.md`

      - `nodes/slave/ubuntu/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Reverse Proxy

      - `reverse-proxy.md`

  * Running Builds

      - `running-builds.txt`

  * Agent Command Statistics

  * Agent Launch Logs

      - `nodes/slave/ubuntu-rootless-docker/launchLogs/slave.log`

      - `nodes/slave/ubuntu/launchLogs/slave.log`

      - `nodes/slave/ubuntu/launchLogs/slave.log.1`

      - `nodes/slave/ubuntu/launchLogs/slave.log.2`

      - `nodes/slave/ubuntu/launchLogs/slave.log.3`

      - `nodes/slave/ubuntu/launchLogs/slave.log.4`

  * Agent system configuration (Linux only)

      - `nodes/slave/ubuntu-rootless-docker/dmesg.txt`

      - `nodes/slave/ubuntu-rootless-docker/dmi.txt`

      - `nodes/slave/ubuntu-rootless-docker/proc/cpuinfo.txt`

      - `nodes/slave/ubuntu-rootless-docker/proc/mounts.txt`

      - `nodes/slave/ubuntu-rootless-docker/proc/net/rpc/nfs.txt`

      - `nodes/slave/ubuntu-rootless-docker/proc/net/rpc/nfsd.txt`

      - `nodes/slave/ubuntu-rootless-docker/proc/swaps.txt`

      - `nodes/slave/ubuntu-rootless-docker/proc/system-uptime.txt`

      - `nodes/slave/ubuntu-rootless-docker/sysctl.txt`

      - `nodes/slave/ubuntu-rootless-docker/userid.txt`

  * Controller system configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/ubuntu-rootless-docker/system.properties`

      - `nodes/slave/ubuntu/system.properties`

  * Controller Task Log Recorders

      - `task-logs/Fingerprint cleanup.log`

      - `task-logs/Fingerprint cleanup.log.1`

      - `task-logs/Fingerprint cleanup.log.2`

      - `task-logs/Periodic background build discarder.log`

      - `task-logs/Periodic background build discarder.log.1`

      - `task-logs/Periodic background build discarder.log.2`

      - `task-logs/Periodic background build discarder.log.3`

      - `task-logs/Workspace clean-up.log`

      - `task-logs/Workspace clean-up.log.1`

      - `task-logs/health-checker.log`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/ubuntu-rootless-docker/thread-dump.txt`

      - `nodes/slave/ubuntu/thread-dump.txt`

  * Update Center

      - `update-center.md`

  * User Count

      - `users/count.md`

  * Slow Request Records

  * Thread dumps on high CPU usage

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`


Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: Linux (amd64)
   * ubuntu: null
   * ubuntu-rootless-docker: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: In sync
   * ubuntu: null
   * ubuntu-rootless-docker: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * Built-In Node: 137.697GB left on /var/jenkins_home.
   * ubuntu: null
   * ubuntu-rootless-docker: 14.406GB left on /var/lib/jenkins-agent/agent.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: Memory:8225/64019MB  Swap:971/976MB
   * ubuntu: null
   * ubuntu-rootless-docker: Memory:13468/16003MB  Swap:1162/1162MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * Built-In Node: 137.697GB left on /tmp.
   * ubuntu: null
   * ubuntu-rootless-docker: 14.406GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: 0ms
   * ubuntu: null
   * ubuntu-rootless-docker: 39ms

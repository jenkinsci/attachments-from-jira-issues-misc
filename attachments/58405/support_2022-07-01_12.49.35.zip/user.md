User
====

Authentication
--------------

  * Authenticated: true
  * Name: admin
  * Authorities 
      - `authenticated`


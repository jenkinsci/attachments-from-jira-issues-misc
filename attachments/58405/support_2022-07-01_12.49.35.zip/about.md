Jenkins
=======

Version details
---------------

  * Version: `2.346.1`
  * Instance ID: `73f044ea534199f5eb822e4146677b21`
  * Mode:    WAR
  * Url:     http://localhost:8080/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.45.v20220203`
  * Java
      - Home:           `/opt/java/openjdk`
      - Vendor:           Eclipse Adoptium
      - Version:          11.0.15
      - Maximum memory:   15.63 GB (16785604608)
      - Allocated memory: 6.56 GB (7046430720)
      - Free memory:      4.58 GB (4918876928)
      - In-use memory:    1.98 GB (2127553792)
      - GC strategy:      G1
      - Available CPUs:   20
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 11
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 11
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Eclipse Adoptium
      - Version: 11.0.15+10
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      5.18.0-0.bpo.1-amd64
  * Process ID: 7 (0x7)
  * Process started: 2022-07-01 12:31:44.081+0000
  * Process uptime: 17 min
  * JVM startup parameters:
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Duser.home=/var/jenkins_home`
      - arg[1]: `-Djenkins.model.Jenkins.slaveAgentPort=50000`
      - arg[2]: `-Dhudson.lifecycle=hudson.lifecycle.ExitLifecycle`

Remoting details
---------------

  * Embedded Version: `4.13.2`
  * Minimum Supported Version: `3.14`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ant:475.vf34069fef73c 'Ant Plugin'
  * antisamy-markup-formatter:2.7 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.13-1.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.4 'Authentication Tokens API Plugin'
  * bootstrap5-api:5.1.3-7 'Bootstrap 5 API Plugin'
  * bouncycastle-api:2.26 'bouncycastle API Plugin'
  * branch-api:2.1046.v0ca_37783ecc5 'Branch API Plugin'
  * build-timeout:1.21 'Build Timeout'
  * caffeine-api:2.9.3-65.v6a_47d0f4d1fe 'Caffeine API Plugin'
  * checks-api:1.7.4 'Checks API plugin'
  * cloudbees-folder:6.729.v2b_9d1a_74d673 'Folders Plugin'
  * command-launcher:84.v4a_97f2027398 'Command Agent Launcher Plugin'
  * commons-lang3-api:3.12.0.0 'commons-lang3 v3.x Jenkins Api Plugin'
  * commons-text-api:1.9-9.v39a_53e2e0343 'commons-text API Plugin'
  * configuration-as-code:1464.vd8507b_82e41a_ 'Configuration as Code Plugin'
  * credentials:1129.vef26f5df883c 'Credentials Plugin'
  * credentials-binding:523.vd859a_4b_122e6 'Credentials Binding Plugin'
  * display-url-api:2.3.6 'Display URL API'
  * docker-commons:1.19 'Docker Commons Plugin'
  * docker-workflow:1.29 'Docker Pipeline'
  * durable-task:496.va67c6f9eefa7 'Durable Task Plugin'
  * echarts-api:5.3.3-1 'ECharts API Plugin'
  * email-ext:2.89 'Email Extension Plugin'
  * font-awesome-api:6.1.1-1 'Font Awesome API Plugin'
  * git:4.11.3 'Git plugin'
  * git-client:3.11.0 'Jenkins Git client plugin'
  * github:1.34.4 'GitHub plugin'
  * github-api:1.303-400.v35c2d8258028 'GitHub API Plugin'
  * github-branch-source:1656.v77eddb_b_e95df 'GitHub Branch Source Plugin'
  * gradle:1.39.2 'Gradle Plugin'
  * handlebars:3.0.8 'JavaScript GUI Lib: Handlebars bundle plugin'
  * jackson2-api:2.13.3-285.vc03c0256d517 'Jackson 2 API Plugin'
  * javax-activation-api:1.2.0-3 'JavaBeans Activation Framework (JAF) API'
  * javax-mail-api:1.6.2-6 'JavaMail API'
  * jaxb:2.3.6-1 'JAXB plugin'
  * jdk-tool:1.5 'Oracle Java SE Development Kit Installer Plugin'
  * jjwt-api:0.11.5-77.v646c772fddb_0 'Java JSON Web Token (JJWT) Plugin'
  * jquery3-api:3.6.0-4 'JQuery3 API Plugin'
  * jsch:0.1.55.2 'Jenkins JSch dependency plugin'
  * junit:1119.1121.vc43d0fc45561 'JUnit Plugin'
  * ldap:2.10 'LDAP Plugin'
  * mailer:414.vcc4c33714601 'Jenkins Mailer Plugin'
  * matrix-auth:3.1.3 'Matrix Authorization Strategy Plugin'
  * matrix-project:772.v494f19991984 'Matrix Project Plugin'
  * metrics:4.1.6.2 'Metrics Plugin'
  * mina-sshd-api-common:2.8.0-21.v493b_6b_db_22c6 'Mina SSHD API :: Common'
  * mina-sshd-api-core:2.8.0-21.v493b_6b_db_22c6 'Mina SSHD API :: Core'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * okhttp-api:4.9.3-105.vb96869f8ac3a 'OkHttp Plugin'
  * pam-auth:1.8 'PAM Authentication plugin'
  * pipeline-build-step:2.18 'Pipeline: Build Step'
  * pipeline-github-lib:38.v445716ea_edda_ 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:195.v5812d95a_a_2f9 'Pipeline Graph Analysis Plugin'
  * pipeline-groovy-lib:593.va_a_fc25d520e9 'Pipeline: Groovy Libraries'
  * pipeline-input-step:449.v77f0e8b_845c4 'Pipeline: Input Step'
  * pipeline-milestone-step:101.vd572fef9d926 'Pipeline: Milestone Step'
  * pipeline-model-api:2.2097.v33db_b_de764b_e 'Pipeline: Model API'
  * pipeline-model-definition:2.2097.v33db_b_de764b_e 'Pipeline: Declarative'
  * pipeline-model-extensions:2.2097.v33db_b_de764b_e 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.24 'Pipeline: REST API Plugin'
  * pipeline-stage-step:293.v200037eefcd5 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:2.2097.v33db_b_de764b_e 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.24 'Pipeline: Stage View Plugin'
  * plain-credentials:1.8 'Plain Credentials Plugin'
  * plugin-util-api:2.17.0 'Plugin Utilities API Plugin'
  * popper2-api:2.11.5-2 'Popper.js 2 API Plugin'
  * resource-disposer:0.19 'Resource Disposer Plugin'
  * scm-api:608.vfa_f971c5a_a_e9 'SCM API Plugin'
  * script-security:1175.v4b_d517d6db_f0 'Script Security Plugin'
  * snakeyaml-api:1.30.2-76.vc104f7ce9870 'SnakeYAML API Plugin'
  * ssh-credentials:291.v8211e4f8efb_c 'SSH Credentials Plugin'
  * ssh-slaves:1.821.vd834f8a_c390e 'SSH Build Agents plugin'
  * sshd:3.242.va_db_9da_b_26a_c3 'SSH server'
  * structs:318.va_f3ccb_729b_71 'Structs Plugin'
  * support-core:1174.vc46f6b_04d894 'Support Core Plugin'
  * timestamper:1.18 'Timestamper'
  * token-macro:293.v283932a_0a_b_49 'Token Macro Plugin'
  * trilead-api:1.57.v6e90e07157e1 'Trilead API Plugin'
  * variant:1.4 'Variant Plugin'
  * workflow-aggregator:590.v6a_d052e5a_a_b_5 'Pipeline'
  * workflow-api:1165.v02c3db_a_6b_e36 'Pipeline: API'
  * workflow-basic-steps:948.v2c72a_091b_b_68 'Pipeline: Basic Steps'
  * workflow-cps:2725.v7b_c717eb_12ce 'Pipeline: Groovy'
  * workflow-durable-task-step:1155.v79567b_e0a_2de 'Pipeline: Nodes and Processes'
  * workflow-job:1189.va_d37a_e9e4eda_ 'Pipeline: Job'
  * workflow-multibranch:716.vc692a_e52371b_ 'Pipeline: Multibranch'
  * workflow-scm-step:400.v6b_89a_1317c9a_ 'Pipeline: SCM Step'
  * workflow-step-api:625.vd896b_f445a_f8 'Pipeline: Step API'
  * workflow-support:820.vd1a_6cc65ef33 'Pipeline: Supporting APIs'
  * ws-cleanup:0.42 'Jenkins Workspace Cleanup Plugin'

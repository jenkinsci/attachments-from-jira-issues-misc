Browser
=======

  * Screen size: 2560x1440
  * User Agent
      - Type:     Browser
      - Name:     Firefox
      - Family:   FIREFOX
      - Producer: Mozilla Foundation
      - Version:  91.0
      - Raw:      `Mozilla/5.0 (X11; Linux x86_64; rv:91.0) Gecko/20100101 Firefox/91.0`
  * Operating System
      - Name:     Linux
      - Family:   LINUX
      - Producer: 
      - Version:  


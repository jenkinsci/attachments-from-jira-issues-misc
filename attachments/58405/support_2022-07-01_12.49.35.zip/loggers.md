Loggers currently enabled
=========================
 - INFO
winstone - INFO
org.apache.sshd - WARNING

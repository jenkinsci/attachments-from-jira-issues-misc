=== Sites ===
 - Id: default
 - Url: https://updates.jenkins.io/update-center.json
 - Connection Url: http://www.google.com/
 - Implementation Type: hudson.model.UpdateSite
======
Last updated: 6 hr 2 min
=== Proxy ===

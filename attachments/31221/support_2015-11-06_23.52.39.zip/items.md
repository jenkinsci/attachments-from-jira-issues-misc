Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 4
    - Number of builds per job: 34.75 [n=4, s=30.0]

Total job statistics
======================

  * Number of jobs: 4
  * Number of builds per job: 34.75 [n=4, s=30.0]

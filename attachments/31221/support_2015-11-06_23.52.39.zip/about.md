Jenkins
=======

Version details
---------------

  * Version: `1.636`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_85
      - Maximum memory:   643.81 MB (675086336)
      - Allocated memory: 87.99 MB (92262400)
      - Free memory:      26.36 MB (27637624)
      - In-use memory:    61.63 MB (64624776)
      - PermGen used:     61.48 MB (64469488)
      - PermGen max:      166.00 MB (174063616)
      - GC strategy:      SerialGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.85-b03
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.1.7-15.23.amzn1.x86_64
  * Process ID: 3074 (0xc02)
  * Process started: 2015-11-06 23:51:59.094+0000
  * Process uptime: 41 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.85.x86_64/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`
      - arg[1]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`

Active Plugins
--------------

  * analysis-core:1.74 'Static Analysis Utilities'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * aws-java-sdk:1.10.26 'Amazon Web Services SDK'
  * checkstyle:3.43 'Checkstyle Plug-in'
  * credentials:1.24 'Credentials Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * durable-task:1.6 'Durable Task Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * git-client:1.19.0 'Jenkins GIT client plugin'
  * git-server:1.6 'Git server plugin'
  * greenballs:1.15 'Green Balls'
  * hipchat:0.2.0 'Jenkins HipChat Plugin'
  * htmlpublisher:1.9 'HTML Publisher plugin'
  * jackson2-api:2.5.4 'Jackson 2 API Plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * junit:1.9 'JUnit Plugin'
  * ldap:1.11 'LDAP Plugin'
  * mailer:1.16 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * matrix-auth:1.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.6 'Matrix Project Plugin'
  * maven-plugin:2.12.1 'Maven Integration plugin'
  * metrics:3.1.2.1 'Metrics Plugin'
  * p4:1.3.2 'P4 Plugin'
  * pam-auth:1.2 'PAM Authentication plugin'
  * scm-api:0.2 'SCM API Plugin'
  * script-security:1.15 'Script Security Plugin'
  * snsnotify:1.9 'Amazon SNS Build Notifier'
  * ssh-credentials:1.11 'SSH Credentials Plugin'
  * ssh-slaves:1.10 'Jenkins SSH Slaves plugin'
  * subversion:2.5.4 'Jenkins Subversion Plug-in'
  * support-core:2.28 'Support Core Plugin'
  * translation:1.12 'Jenkins Translation Assistance plugin'
  * windows-slaves:1.1 'Windows Slaves Plugin'
  * workflow-aggregator:1.10.1 'Workflow: Aggregator'
  * workflow-api:1.10.1 'Workflow: API'
  * workflow-basic-steps:1.10.1 'Workflow: Basic Steps'
  * workflow-cps:1.10.1 'Workflow: Groovy CPS Execution'
  * workflow-cps-global-lib:1.10.1 'Workflow: Global Shared Library for CPS workflow'
  * workflow-durable-task-step:1.10.1 'Workflow: Durable Task Step'
  * workflow-job:1.10.1 'Workflow: Job'
  * workflow-scm-step:1.10.1 'Workflow: SCM Step'
  * workflow-step-api:1.10.1 'Workflow: Step API'
  * workflow-support:1.10.1 'Workflow: Execution Support'

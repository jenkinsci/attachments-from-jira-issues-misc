Support Bundle Manifest
=======================

Generated on 2015-11-06 23:52:39.922+0000

Requested components:

  * Log Recorders

      - `nodes/master/logs/all_2015-11-06_23.52.04.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `nodes/slave/kingmaker-macpro01/jenkins.log`

      - `nodes/slave/kingmaker-macpro01/launchLogs/slave.log`

      - `nodes/slave/kingmaker-macpro01/logs/all_2015-11-06_23.52.25.log`

      - `nodes/slave/kingmaker-macpro01/logs/all_memory_buffer.log`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Workspace clean-up.log`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/kingmaker-macpro01/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/kingmaker-macpro01/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/kingmaker-macpro01/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/kingmaker-macpro01/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/kingmaker-macpro01/gnuplot`

      - `load-stats/label/kingmaker-macpro01/hour.csv`

      - `load-stats/label/kingmaker-macpro01/min.csv`

      - `load-stats/label/kingmaker-macpro01/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/kingmaker-macpro01/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/kingmaker-macpro01/networkInterface.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/kingmaker-macpro01/system.properties`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/kingmaker-macpro01/thread-dump.txt`


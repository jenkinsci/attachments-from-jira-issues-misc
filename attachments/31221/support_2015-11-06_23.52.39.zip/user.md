User
====

Authentication
--------------

  * Authenticated: true
  * Name: mdouglass
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@652de668: Username: hudson.security.HudsonPrivateSecurityRealm$Details@90234bb; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@fffe9938: RemoteIpAddress: 38.99.56.154; SessionId: kmb26lulnv78ng3f3agmglwx; Granted Authorities: authenticated`



package net.test;

public final class Example
{
    private Example()
    {
    }
    
    public static double ex(double param)
    {
        return param;
    }
}

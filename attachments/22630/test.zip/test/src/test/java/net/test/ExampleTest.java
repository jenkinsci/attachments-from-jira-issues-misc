package net.test;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Unit test.
 */
public class ExampleTest
{
    @Test
    public void testExample()
    {
        Assert.assertEquals(1, 1);
    }
}

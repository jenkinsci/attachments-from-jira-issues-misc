main(int argc, char *argv[])
{

 int answer;
 char answer_string[255];


 answer = 0;
 gets(answer_string);
 sscanf(answer_string, "%d", &answer);

}


static char H_SSALC_TXE_YM []=" @(#) my_ext_class.h Release 1.1 ~";
/*=====================*/
/*=== my enum types ===*/
/*=====================*/

/*typedef enum                                     */
/*{                                                */
/*  MY_EXT_ENU1,                                   */
/*  MY_EXT_ENU2,                                   */
/*  MY_EXT_ENU3,                                   */
/*  MY_EXT_ENU4,             /* Currently not used */
/*  MY_EXT_ENU5,             /* Currently not used */
/*  MY_EXT_ENU6,             /* Currently not used */
/*  MY_EXT_ENU7              /* Currently not used */
/*} T_MY_enum_type; 

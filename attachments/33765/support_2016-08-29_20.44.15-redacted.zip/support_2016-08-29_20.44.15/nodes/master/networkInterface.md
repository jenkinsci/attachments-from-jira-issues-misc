-----------
 * Name vboxnet9
 ** Hardware Address - 0a0027000009
 ** Index - 195
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:9%vboxnet9
 ** InetAddress - /192.168.70.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet8
 ** Hardware Address - 0a0027000008
 ** Index - 194
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:8%vboxnet8
 ** InetAddress - /192.168.56.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet7
 ** Hardware Address - 0a0027000007
 ** Index - 193
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:7%vboxnet7
 ** InetAddress - /192.168.55.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet6
 ** Hardware Address - 0a0027000006
 ** Index - 192
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:6%vboxnet6
 ** InetAddress - /192.168.54.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet5
 ** Hardware Address - 0a0027000005
 ** Index - 191
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:5%vboxnet5
 ** InetAddress - /192.168.40.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet4
 ** Hardware Address - 0a0027000004
 ** Index - 182
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:4%vboxnet4
 ** InetAddress - /192.168.39.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet3
 ** Hardware Address - 0a0027000003
 ** Index - 171
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:3%vboxnet3
 ** InetAddress - /192.168.38.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet2
 ** Hardware Address - 0a0027000002
 ** Index - 160
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:2%vboxnet2
 ** InetAddress - /192.168.24.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet11
 ** Hardware Address - 0a002700000b
 ** Index - 151
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:b%vboxnet11
 ** InetAddress - /192.168.72.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet10
 ** Hardware Address - 0a002700000a
 ** Index - 150
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:a%vboxnet10
 ** InetAddress - /192.168.71.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet1
 ** Hardware Address - 0a0027000001
 ** Index - 149
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:1%vboxnet1
 ** InetAddress - /192.168.23.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet0
 ** Hardware Address - 0a0027000000
 ** Index - 148
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:0%vboxnet0
 ** InetAddress - /192.168.22.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 782bcb5f77e4
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:7a2b:cbff:fe5f:77e4%eth0
 ** InetAddress - /192.168.200.30
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

-----------
 * Name vboxnet9
 ** Hardware Address - 0a0027000009
 ** Index - 14
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:9%vboxnet9
 ** InetAddress - /192.168.38.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet8
 ** Hardware Address - 0a0027000008
 ** Index - 13
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:8%vboxnet8
 ** InetAddress - /192.168.24.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet7
 ** Hardware Address - 0a0027000007
 ** Index - 12
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:7%vboxnet7
 ** InetAddress - /192.168.23.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet6
 ** Hardware Address - 0a0027000006
 ** Index - 11
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:6%vboxnet6
 ** InetAddress - /192.168.22.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet11
 ** Hardware Address - 0a002700000b
 ** Index - 6
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:b%vboxnet11
 ** InetAddress - /192.168.40.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vboxnet10
 ** Hardware Address - 0a002700000a
 ** Index - 5
 ** InetAddress - /fe80:0:0:0:800:27ff:fe00:a%vboxnet10
 ** InetAddress - /192.168.39.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - fcaa14941f18
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:feaa:14ff:fe94:1f18%eth0
 ** InetAddress - /192.168.201.33
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

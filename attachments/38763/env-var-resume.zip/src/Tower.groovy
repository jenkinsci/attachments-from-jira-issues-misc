class Tower implements Serializable {
    def steps;
    def env;

    Tower(steps, env) {
        this.steps = steps
        this.env = env
    }

    def lift() {
        steps.echo "build number is :${env.BUILD_NUMBER}"
        steps.sleep time: 3, unit: 'MINUTES'
        steps.echo "build number is :${env.BUILD_NUMBER}"
    }
}
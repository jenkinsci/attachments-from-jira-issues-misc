def call() {
    Tower tower = new Tower(steps, env)
    tower.lift()
}
Jenkins
=======

Version details
---------------

  * Version: `2.46.1`
  * Mode:    WAR
  * Url:     http://jenkins:8082/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `C:\Program Files (x86)\Jenkins\jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_66
      - Maximum memory:   247.50 MB (259522560)
      - Allocated memory: 124.44 MB (130486272)
      - Free memory:      24.36 MB (25545520)
      - In-use memory:    100.08 MB (104940752)
      - GC strategy:      SerialGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) Client VM
      - Vendor:  Oracle Corporation
      - Version: 25.66-b18
  * Operating system
      - Name:         Windows Server 2012 R2
      - Architecture: x86
      - Version:      6.3
  * Process ID: 3528 (0xdc8)
  * Process started: 2017-05-02 05:07:47.516+0000
  * Process uptime: 46 min
  * JVM startup parameters:
      - Boot classpath: `C:\Program Files (x86)\Jenkins\jre\lib\resources.jar;C:\Program Files (x86)\Jenkins\jre\lib\rt.jar;C:\Program Files (x86)\Jenkins\jre\lib\sunrsasign.jar;C:\Program Files (x86)\Jenkins\jre\lib\jsse.jar;C:\Program Files (x86)\Jenkins\jre\lib\jce.jar;C:\Program Files (x86)\Jenkins\jre\lib\charsets.jar;C:\Program Files (x86)\Jenkins\jre\lib\jfr.jar;C:\Program Files (x86)\Jenkins\jre\classes`
      - Classpath: `C:\Program Files (x86)\Jenkins\jenkins.war`
      - Library path: `C:\Program Files (x86)\Jenkins\jre\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Program Files (x86)\PHP\v5.6;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\Microsoft SQL Server\120\Tools\Binn\;C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\110\Tools\Binn\;C:\Program Files (x86)\Microsoft SQL Server\120\Tools\Binn\;C:\Program Files\Microsoft SQL Server\120\DTS\Binn\;C:\Program Files (x86)\Microsoft SQL Server\120\Tools\Binn\ManagementStudio\;C:\Program Files (x86)\Microsoft SQL Server\120\DTS\Binn\;C:\Program Files\Amazon\cfn-bootstrap\;C:\Program Files (x86)\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft SQL Server\110\DTS\Binn\;C:\Program Files\Git\cmd;;.`
      - arg[0]: `-Xrs`
      - arg[1]: `-Xmx256m`
      - arg[2]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`

Important configuration
---------------

  * Security realm: `hudson.plugins.active_directory.ActiveDirectorySecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * active-directory:2.4 'Jenkins Active Directory plugin'
  * ant:1.4 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * bouncycastle-api:2.16.1 'bouncycastle API Plugin'
  * branch-api:2.0.8 'Branch API Plugin'
  * build-timeout:1.18 'Jenkins build timeout plugin'
  * cloudbees-folder:6.0.3 'Folders Plugin'
  * credentials:2.1.13 'Credentials Plugin'
  * credentials-binding:1.11 'Credentials Binding Plugin'
  * display-url-api:2.0 'Display URL API'
  * docker-commons:1.6 'Docker Commons Plugin'
  * docker-workflow:1.10 'Docker Pipeline'
  * durable-task:1.13 'Durable Task Plugin'
  * email-ext:2.57.2 'Email Extension Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * git:3.3.0 'Jenkins Git plugin'
  * git-client:2.4.2 *(update available)* 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.27.0 'GitHub plugin'
  * github-api:1.85 'GitHub API Plugin'
  * github-branch-source:2.0.5 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * gradle:1.26 'Gradle Plugin'
  * groovy:2.0 'Groovy'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.20 'JUnit Plugin'
  * ldap:1.14 'LDAP Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.5 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.10 'Matrix Project Plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * msbuild:1.27 'Jenkins MSBuild Plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * pipeline-build-step:2.5 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.3 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.5 *(update available)* 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.1.3 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.1.3 'Pipeline: Model Definition'
  * pipeline-model-extensions:1.1.3 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.6 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.1.3 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.6 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * resource-disposer:0.6 'Resource Disposer Plugin'
  * scm-api:2.1.1 'SCM API Plugin'
  * script-security:1.27 'Script Security Plugin'
  * slave-setup:1.10 'Jenkins Slave SetupPlugin'
  * ssh-agent:1.15 'SSH Agent Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.17 'Jenkins SSH Slaves plugin'
  * structs:1.6 'Structs Plugin'
  * subversion:2.7.2 'Jenkins Subversion Plug-in'
  * support-core:2.40 'Support Core Plugin'
  * throttle-concurrents:1.9.0 'Jenkins Throttle Concurrent Builds Plug-in'
  * timestamper:1.8.8 'Timestamper'
  * token-macro:2.1 'Token Macro Plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.13 'Pipeline: API'
  * workflow-basic-steps:2.4 'Pipeline: Basic Steps'
  * workflow-cps:2.29 *(update available)* 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.7 *(update available)* 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.10 *(update available)* 'Pipeline: Nodes and Processes'
  * workflow-job:2.10 'Pipeline: Job'
  * workflow-multibranch:2.14 'Pipeline: Multibranch'
  * workflow-scm-step:2.4 'Pipeline: SCM Step'
  * workflow-step-api:2.9 'Pipeline: Step API'
  * workflow-support:2.14 'Pipeline: Supporting APIs'
  * ws-cleanup:0.32 *(update available)* 'Jenkins Workspace Cleanup Plugin'

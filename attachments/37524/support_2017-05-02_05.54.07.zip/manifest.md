Support Bundle Manifest
=======================

Generated on 2017-05-02 05:54:07.150+0000

Requested components:

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/buildbox7-lite/checksums.md5`

      - `nodes/slave/buildbox7/checksums.md5`

      - `nodes/slave/buildbox8/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`


Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 10
    - Number of builds per job: 18.5 [n=10, s=20.0]

Total job statistics
======================

  * Number of jobs: 10
  * Number of builds per job: 18.5 [n=10, s=20.0]

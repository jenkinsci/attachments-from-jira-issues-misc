Node statistics
===============

  * Total number of nodes
      - Sample size:        185
      - Average (mean):     2.9999999999999996
      - Average (median):   3.0
      - Standard deviation: 4.4408920985006257E-16
      - Minimum:            3
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of nodes online
      - Sample size:        185
      - Average (mean):     3.0
      - Average (median):   3.0
      - Standard deviation: 1.378305615782218E-9
      - Minimum:            0
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors
      - Sample size:        185
      - Average (mean):     3.0
      - Average (median):   3.0
      - Standard deviation: 1.3783056157822177E-9
      - Minimum:            0
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors in use
      - Sample size:        185
      - Average (mean):     0.015528404419747604
      - Average (median):   0.0
      - Standard deviation: 0.12364171252423015
      - Minimum:            0
      - Maximum:            1
      - 95th percentile:    0.0
      - 99th percentile:    1.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      0
      - FS root:        `C:\Program Files (x86)\Jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.7
      - Java
          + Home:           `C:\Program Files (x86)\Jenkins\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_66
          + Maximum memory:   247.50 MB (259522560)
          + Allocated memory: 124.44 MB (130486272)
          + Free memory:      23.66 MB (24810224)
          + In-use memory:    100.78 MB (105676048)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Oracle Corporation
          + Version: 25.66-b18
      - Operating system
          + Name:         Windows Server 2012 R2
          + Architecture: x86
          + Version:      6.3
      - Process ID: 3528 (0xdc8)
      - Process started: 2017-05-02 05:07:47.516+0000
      - Process uptime: 46 min
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files (x86)\Jenkins\jre\lib\resources.jar;C:\Program Files (x86)\Jenkins\jre\lib\rt.jar;C:\Program Files (x86)\Jenkins\jre\lib\sunrsasign.jar;C:\Program Files (x86)\Jenkins\jre\lib\jsse.jar;C:\Program Files (x86)\Jenkins\jre\lib\jce.jar;C:\Program Files (x86)\Jenkins\jre\lib\charsets.jar;C:\Program Files (x86)\Jenkins\jre\lib\jfr.jar;C:\Program Files (x86)\Jenkins\jre\classes`
          + Classpath: `C:\Program Files (x86)\Jenkins\jenkins.war`
          + Library path: `C:\Program Files (x86)\Jenkins\jre\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Program Files (x86)\PHP\v5.6;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\Microsoft SQL Server\120\Tools\Binn\;C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\110\Tools\Binn\;C:\Program Files (x86)\Microsoft SQL Server\120\Tools\Binn\;C:\Program Files\Microsoft SQL Server\120\DTS\Binn\;C:\Program Files (x86)\Microsoft SQL Server\120\Tools\Binn\ManagementStudio\;C:\Program Files (x86)\Microsoft SQL Server\120\DTS\Binn\;C:\Program Files\Amazon\cfn-bootstrap\;C:\Program Files (x86)\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft SQL Server\110\DTS\Binn\;C:\Program Files\Git\cmd;;.`
          + arg[0]: `-Xrs`
          + arg[1]: `-Xmx256m`
          + arg[2]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`

  * buildbox7 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `C:\Jenkins`
      - Labels:         buildbox7 win7
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.7

  * buildbox7-lite (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `D:\Jenkins`
      - Labels:         lite win7 buildbox7-lite
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.7

  * buildbox8 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `C:\Jenkins`
      - Labels:         buildbox8 win7
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.7
      - Java
          + Home:           `C:\Program Files (x86)\Java\jre1.8.0_131`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_131
          + Maximum memory:   247.50 MB (259522560)
          + Allocated memory: 15.50 MB (16252928)
          + Free memory:      5.12 MB (5367248)
          + In-use memory:    10.38 MB (10885680)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) Client VM
          + Vendor:  Oracle Corporation
          + Version: 25.131-b11
      - Operating system
          + Name:         Windows 7
          + Architecture: x86
          + Version:      6.1
      - Process ID: 6544 (0x1990)
      - Process started: 2017-05-02 03:34:44.521+0000
      - Process uptime: 2 hr 19 min
      - JVM startup parameters:
          + Boot classpath: `C:\Program Files (x86)\Java\jre1.8.0_131\lib\resources.jar;C:\Program Files (x86)\Java\jre1.8.0_131\lib\rt.jar;C:\Program Files (x86)\Java\jre1.8.0_131\lib\sunrsasign.jar;C:\Program Files (x86)\Java\jre1.8.0_131\lib\jsse.jar;C:\Program Files (x86)\Java\jre1.8.0_131\lib\jce.jar;C:\Program Files (x86)\Java\jre1.8.0_131\lib\charsets.jar;C:\Program Files (x86)\Java\jre1.8.0_131\lib\jfr.jar;C:\Program Files (x86)\Java\jre1.8.0_131\classes`
          + Classpath: `slave.jar`
          + Library path: `C:\ProgramData\Oracle\Java\javapath;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\ProgramData\Oracle\Java\javapath;C:\Perl64\site\bin;C:\Perl64\bin;C:\Program Files (x86)\Intel\iCLS Client\;C:\Program Files\Intel\iCLS Client\;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\Intel\Intel(R) Management Engine Components\DAL;C:\Program Files\Intel\Intel(R) Management Engine Components\IPT;C:\Program Files (x86)\Intel\Intel(R) Management Engine Components\DAL;C:\Program Files (x86)\Intel\Intel(R) Management Engine Components\IPT;C:\Program Files (x86)\Windows Kits\8.1\Windows Performance Toolkit\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Build;C:\Program Files (x86)\Microsoft SDKs\TypeScript\1.0\;C:\Program Files\Microsoft SQL Server\120\Tools\Binn\;C:\Program Files (x86)\Rational\ClearCase\bin;C:\Program Files (x86)\Rational\common;C:\Program Files (x86)\Microsoft SQL Server\100\Tools\Binn\;C:\Program Files\Microsoft SQL Server\100\Tools\Binn\;C:\Program Files\Microsoft SQL Server\100\DTS\Binn\;C:\PROGRA~2\Borland\Delphi6\Bin;C:\PROGRA~2\Borland\Delphi6\Projects\Bpl;C:\Program Files (x86)\Microsoft SQL Server\100\Tools\Binn\VSShell\Common7\IDE\;C:\Program Files (x86)\Microsoft SQL Server\100\DTS\Binn\;C:\Program Files (x86)\Windows Kits\10\Windows Performance Toolkit\;C:\Program Files\Git\cmd;C:\Program Files\Git LFS;C:\Program Files\Git\usr\bin;.`


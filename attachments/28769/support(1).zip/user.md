User
====

Authentication
--------------

  * Authenticated: true
  * Name: dspartz
  * Authorities 
      - `8465.A`
      - `authenticated`
  * Raw: `hudson.security.ContainerAuthentication@5e547431`


Support Bundle Manifest
=======================

Generated on 2015-03-17 03:30:09 -0700

Requested components:

  * Log Recorders

      - `nodes/master/logs/all_2015-03-17_21.57.45.log`

      - `nodes/master/logs/all_2015-03-17_22.00.17.log`

      - `nodes/master/logs/all_2015-03-17_22.03.24.log`

      - `nodes/master/logs/all_2015-03-17_22.11.05.log`

      - `nodes/master/logs/all_2015-03-17_22.24.02.log`

      - `nodes/master/logs/all_2015-03-17_22.26.29.log`

      - `nodes/master/logs/all_2015-03-17_22.27.59.log`

      - `nodes/master/logs/all_2015-03-17_22.29.32.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/custom/Audit Trail.log`

      - `nodes/master/logs/jenkins.log`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/jenkins.log`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/launchLogs/slave.log`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/launchLogs/slave.log.1`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/launchLogs/slave.log.10`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/launchLogs/slave.log.2`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/launchLogs/slave.log.3`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/launchLogs/slave.log.4`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/launchLogs/slave.log.5`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/launchLogs/slave.log.6`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/launchLogs/slave.log.7`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/launchLogs/slave.log.8`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/launchLogs/slave.log.9`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/logs/all_2015-03-17_21.53.10.log`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/logs/all_2015-03-17_21.57.58.log`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/logs/all_2015-03-17_22.00.37.log`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/logs/all_2015-03-17_22.03.37.log`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/logs/all_2015-03-17_22.24.18.log`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/logs/all_2015-03-17_22.26.45.log`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/logs/all_2015-03-17_22.28.16.log`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/logs/all_2015-03-17_22.29.45.log`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/logs/all_memory_buffer.log`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/jenkins.log`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/launchLogs/slave.log`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/launchLogs/slave.log.1`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/launchLogs/slave.log.10`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/launchLogs/slave.log.2`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/launchLogs/slave.log.3`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/launchLogs/slave.log.4`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/launchLogs/slave.log.5`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/launchLogs/slave.log.6`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/launchLogs/slave.log.7`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/launchLogs/slave.log.8`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/launchLogs/slave.log.9`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/logs/all_2015-03-17_21.53.10.log`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/logs/all_2015-03-17_21.57.58.log`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/logs/all_2015-03-17_22.00.37.log`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/logs/all_2015-03-17_22.03.37.log`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/logs/all_2015-03-17_22.24.18.log`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/logs/all_2015-03-17_22.26.45.log`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/logs/all_2015-03-17_22.28.16.log`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/logs/all_2015-03-17_22.29.45.log`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/logs/all_memory_buffer.log`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/jenkins.log`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/launchLogs/slave.log`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/launchLogs/slave.log.1`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/launchLogs/slave.log.10`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/launchLogs/slave.log.2`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/launchLogs/slave.log.3`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/launchLogs/slave.log.4`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/launchLogs/slave.log.5`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/launchLogs/slave.log.6`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/launchLogs/slave.log.7`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/launchLogs/slave.log.8`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/launchLogs/slave.log.9`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/logs/all_2015-03-17_21.53.10.log`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/logs/all_2015-03-17_21.57.58.log`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/logs/all_2015-03-17_22.00.37.log`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/logs/all_2015-03-17_22.03.37.log`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/logs/all_2015-03-17_22.24.18.log`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/logs/all_2015-03-17_22.26.45.log`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/logs/all_2015-03-17_22.28.16.log`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/logs/all_2015-03-17_22.29.45.log`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/logs/all_memory_buffer.log`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Out of order build detection.log`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/audit.log`

      - `other-logs/jenkins.metrics.api.Metrics$HealthChecker.log`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/checksums.md5`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/checksums.md5`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/environment.txt`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/environment.txt`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/file-descriptors.txt`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/file-descriptors.txt`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/file-descriptors.txt`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/metrics.json`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/metrics.json`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/metrics.json`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/system.properties`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/system.properties`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/system.properties`

  * Slow Request Records

      - `slow-requests/20150212-175146.380.txt`

      - `slow-requests/20150310-150140.300.txt`

      - `slow-requests/20150310-191513.372.txt`

      - `slow-requests/20150310-192304.372.txt`

      - `slow-requests/20150310-192349.372.txt`

      - `slow-requests/20150310-192631.372.txt`

      - `slow-requests/20150310-192746.372.txt`

      - `slow-requests/20150310-192801.372.txt`

      - `slow-requests/20150310-202904.372.txt`

      - `slow-requests/20150310-202907.372.txt`

      - `slow-requests/20150310-202913.372.txt`

      - `slow-requests/20150310-202913.373.txt`

      - `slow-requests/20150310-202913.374.txt`

      - `slow-requests/20150310-202919.372.txt`

      - `slow-requests/20150310-202925.372.txt`

      - `slow-requests/20150310-202928.372.txt`

      - `slow-requests/20150310-202943.372.txt`

      - `slow-requests/20150310-203816.372.txt`

      - `slow-requests/20150310-203831.372.txt`

      - `slow-requests/20150310-203955.372.txt`

      - `slow-requests/20150310-204007.372.txt`

      - `slow-requests/20150310-213846.372.txt`

      - `slow-requests/20150310-213846.373.txt`

      - `slow-requests/20150310-213849.372.txt`

      - `slow-requests/20150310-213849.373.txt`

      - `slow-requests/20150310-213852.372.txt`

      - `slow-requests/20150310-213852.373.txt`

      - `slow-requests/20150310-213852.374.txt`

      - `slow-requests/20150310-213901.372.txt`

      - `slow-requests/20150310-213901.373.txt`

      - `slow-requests/20150310-215716.372.txt`

      - `slow-requests/20150310-215734.372.txt`

      - `slow-requests/20150310-220252.372.txt`

      - `slow-requests/20150310-220255.372.txt`

      - `slow-requests/20150310-220301.372.txt`

      - `slow-requests/20150310-220301.373.txt`

      - `slow-requests/20150310-220307.372.txt`

      - `slow-requests/20150310-220319.372.txt`

      - `slow-requests/20150310-220610.372.txt`

      - `slow-requests/20150310-220610.373.txt`

      - `slow-requests/20150310-220613.372.txt`

      - `slow-requests/20150310-220625.372.txt`

      - `slow-requests/20150310-220625.373.txt`

      - `slow-requests/20150310-221049.372.txt`

      - `slow-requests/20150310-221222.372.txt`

      - `slow-requests/20150310-221313.372.txt`

      - `slow-requests/20150310-223004.372.txt`

      - `slow-requests/20150313-161947.900.txt`

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/freebsd-gq1-factory-slave-079.infra/thread-dump.txt`

      - `nodes/slave/rhel-gq1-factory-slave-080.infra/thread-dump.txt`

      - `nodes/slave/rhel6-gq1-factory-slave-081.infra/thread-dump.txt`


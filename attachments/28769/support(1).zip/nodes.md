Node statistics
===============

  * Total number of nodes
      - Sample size:        2
      - Average (mean):     4.0
      - Average (median):   4.0
      - Standard deviation: 0.0
      - Minimum:            4
      - Maximum:            4
      - 95th percentile:    4.0
      - 99th percentile:    4.0
  * Total number of nodes online
      - Sample size:        2
      - Average (mean):     2.5
      - Average (median):   2.5
      - Standard deviation: 2.1213203435596424
      - Minimum:            1
      - Maximum:            4
      - 95th percentile:    4.0
      - 99th percentile:    4.0
  * Total number of executors
      - Sample size:        2
      - Average (mean):     11.0
      - Average (median):   11.0
      - Standard deviation: 12.727922061357855
      - Minimum:            2
      - Maximum:            20
      - 95th percentile:    20.0
      - 99th percentile:    20.0
  * Total number of executors in use
      - Sample size:        2
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/home/y/var/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Java
          + Home:           `/home/y/libexec64/jdk64-1.8.0/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   5.00 GB (5368709120)
          + Allocated memory: 5.00 GB (5368709120)
          + Free memory:      4.52 GB (4858501240)
          + In-use memory:    486.57 MB (510207880)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-431.23.3.el6.YAHOO.20140804.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.5 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 3327 (0xcff)
      - Process started: 2015-03-17 15:29:26.810-0700
      - Process uptime: 43 sec
      - JVM startup parameters:
          + Boot classpath: `/home/y/libexec64/jdk64-1.8.0/jre/lib/resources.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/rt.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/sunrsasign.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/jsse.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/jce.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/charsets.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/jfr.jar:/home/y/libexec64/jdk64-1.8.0/jre/classes`
          + Classpath: `:/home/y/libexec/yjava_jetty/lib/slf4j-api.jar:/home/y/libexec/yjava_jetty/lib/log4j-over-slf4j.jar:/home/y/libexec/yjava_jetty/lib/logback-core.jar:/home/y/libexec/yjava_jetty/lib/logback-classic.jar:/home/y/libexec/yjava_jetty/lib/jul-to-slf4j.jar:/home/y/libexec/yjava_jetty/lib/jcl-over-slf4j.jar:/home/y/libexec/yjava_jetty/lib/jetty-webapp-logging.jar:/home/y/libexec/yjava_jetty/lib/yjava_yiv.jar:/home/y/libexec/yjava_jetty/lib/jetty-webapp-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/jaspi/javax.security.auth.message-1.0.0.v201108011116.jar:/home/y/libexec/yjava_jetty/lib/jetty-quickstart-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/xercesImpl.jar:/home/y/libexec/yjava_jetty/lib/jetty-jaas-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/jetty-servlet-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/jetty-xml-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/jetty-client-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/jsp/javax.el-3.0.0.jar:/home/y/libexec/yjava_jetty/lib/jsp/org.eclipse.jdt.core-3.8.2.v20130121.jar:/home/y/libexec/yjava_jetty/lib/jsp/jetty-jsp-jdt-2.3.3.jar:/home/y/libexec/yjava_jetty/lib/jsp/javax.servlet.jsp.jstl-1.2.2.jar:/home/y/libexec/yjava_jetty/lib/jsp/org.eclipse.jetty.orbit.javax.servlet.jsp.jstl-1.2.0.v201105211821.jar:/home/y/libexec/yjava_jetty/lib/jsp/jetty-jsp-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/jsp/javax.servlet.jsp-2.3.2.jar:/home/y/libexec/yjava_jetty/lib/jsp/javax.servlet.jsp-api-2.3.1.jar:/home/y/libexec/yjava_jetty/lib/yjava_jetty.jar:/home/y/libexec/yjava_jetty/lib/jetty-io-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/annotations/asm-commons-5.0.1.jar:/home/y/libexec/yjava_jetty/lib/annotations/javax.annotation-api-1.2.jar:/home/y/libexec/yjava_jetty/lib/annotations/asm-5.0.1.jar:/home/y/libexec/yjava_jetty/lib/jetty-alpn-server-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/servlet-api-3.1.jar:/home/y/libexec/yjava_jetty/lib/yjava_yca.jar:/home/y/libexec/yjava_jetty/lib/jetty-jmx-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/xml-apis.jar:/home/y/libexec/yjava_jetty/lib/commons-logging.jar:/home/y/libexec/yjava_jetty/lib/jetty-jndi-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/jetty-annotations-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/setuid/jetty-setuid-java-1.0.1.jar:/home/y/libexec/yjava_jetty/lib/yjava_ysecure.jar:/home/y/libexec/yjava_jetty/lib/jetty-servlets-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/jetty-alpn-client-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/spdy/spdy-server-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/spdy/spdy-core-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/spdy/spdy-client-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/spdy/spdy-http-common-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/spdy/spdy-http-server-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/jetty-deploy-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/yjava_yck.jar:/home/y/libexec/yjava_jetty/lib/jetty-server-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/jetty-http-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/yjava_remote_ip_servlet_filter.jar:/home/y/libexec/yjava_jetty/lib/yjava_ycore.jar:/home/y/libexec/yjava_jetty/lib/yjava_cookie_data_servlet_filter.jar:/home/y/libexec/yjava_jetty/lib/jetty-continuation-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/jetty-schemas-3.1.jar:/home/y/libexec/yjava_jetty/lib/jetty-rewrite-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/fcgi/fcgi-client-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/fcgi/fcgi-server-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/yjava_ynet.jar:/home/y/libexec/yjava_jetty/lib/jetty-proxy-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/yjava_status_filter.jar:/home/y/libexec/yjava_jetty/lib/bouncer_auth_java.jar:/home/y/libexec/yjava_jetty/lib/yjava_bcookie.jar:/home/y/libexec/yjava_jetty/lib/monitor/jetty-monitor-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/jetty-plus-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/yjava_ysecure_native.jar:/home/y/libexec/yjava_jetty/lib/jetty-cdi-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/jetty-jaspi-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/yjava_byauth.jar:/home/y/libexec/yjava_jetty/lib/jetty-security-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/yjava_yiv_servlet.jar:/home/y/libexec/yjava_jetty/lib/yjava_filter_logic.jar:/home/y/libexec/yjava_jetty/lib/yjava_servlet_filters.jar:/home/y/libexec/yjava_jetty/lib/websocket/websocket-client-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/websocket/javax-websocket-client-impl-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/websocket/javax-websocket-server-impl-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/websocket/websocket-servlet-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/websocket/javax.websocket-api-1.0.jar:/home/y/libexec/yjava_jetty/lib/websocket/websocket-api-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/websocket/websocket-common-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/websocket/websocket-server-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/yjava_servlet.jar:/home/y/libexec/yjava_jetty/lib/yjava_daemon.jar:/home/y/libexec/yjava_jetty/lib/jetty-util-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/spring/jetty-spring-9.2.9.v20150224.jar:/home/y/libexec/yjava_jetty/lib/yjava_resource_handler.jar:/home/y/libexec/yjava_jetty/lib/yjava_yhdrs.jar:/home/y/lib/jars/yjava_ysecure_agent.jar`
          + Library path: `/home/y/lib64`
          + arg[0]: `-Djava.library.path=/home/y/lib64`
          + arg[1]: `-Xms5120m`
          + arg[2]: `-Xmx5120m`
          + arg[3]: `-Djava.awt.headless=true`
          + arg[4]: `-XX:+UseG1GC`
          + arg[5]: `-XX:PermSize=512m`
          + arg[6]: `-XX:MaxPermSize=512m`
          + arg[7]: `-XX:MaxGCPauseMillis=200`
          + arg[8]: `-Xloggc:/home/y/logs/yjava_jetty/gc.log`
          + arg[9]: `-XX:+PrintHeapAtGC`
          + arg[10]: `-XX:+PrintGCDetails`
          + arg[11]: `-XX:+PrintGCTimeStamps`
          + arg[12]: `-XX:+PrintGCDateStamps`
          + arg[13]: `-XX:+PrintGCApplicationStoppedTime`
          + arg[14]: `-XX:+ParallelRefProcEnabled`
          + arg[15]: `-XX:+DisableExplicitGC`
          + arg[16]: `-XX:+AggressiveOpts`
          + arg[17]: `-XX:+UnlockExperimentalVMOptions`
          + arg[18]: `-XX:G1NewSizePercent=2`
          + arg[19]: `-Dsun.net.client.defaultConnectTimeout=5000`
          + arg[20]: `-Dsun.net.client.defaultReadTimeout=60000`
          + arg[21]: `-Djavax.net.ssl.keyStoreType=JKS`
          + arg[22]: `-javaagent:/home/y/lib/jars/yjava_ysecure_agent.jar`
          + arg[23]: `-Dyjava.started_by_daemon=true`
          + arg[24]: `-XX:+HeapDumpOnOutOfMemoryError`
          + arg[25]: `-XX:HeapDumpPath=/home/y/logs/yjava_jetty`
          + arg[26]: `-Dhudson.slaves.WorkspaceList=_`
          + arg[27]: `-Dhudson.model.UpdateCenter.never=true`
          + arg[28]: `-Djava.awt.headless=true`
          + arg[29]: `-Dhudson.scm.SubversionSCM.pollFromMaster=true`
          + arg[30]: `-XX:ErrorFile=/home/y/logs/jenkins_diagnostic_dumps/hs_err_pid%p.log`
          + arg[31]: `-XX:HeapDumpPath=/home/y/logs/jenkins_diagnostic_dumps/hprof%p.log`
          + arg[32]: `-XX:-HeapDumpOnOutOfMemoryError`
          + arg[33]: `-XX:+UnlockCommercialFeatures`
          + arg[34]: `-XX:+FlightRecorder`
          + arg[35]: `-Dcom.sun.management.jmxremote`
          + arg[36]: `-Dcom.sun.management.jmxremote.port=18050`
          + arg[37]: `-Dcom.sun.management.jmxremote.authenticate=false`
          + arg[38]: `-Dcom.sun.management.jmxremote.ssl=false`
          + arg[39]: `-XX:+UseStringDeduplication`
          + arg[40]: `-XX:+PrintStringDeduplicationStatistics`
          + arg[41]: `-Djenkins.InitReactorRunner.concurrency=192`
          + arg[42]: `-Dhudson.model.Items.typecacheEnabled=false`
          + arg[43]: `-Dhudson.model.ItemTypeCache.cacheExpiry=86400`
          + arg[44]: `-Dcom.yahoo.yhudson.plugins.jobmetadata.MISSING_OR_INVALID_OWNER_FAILS_BUILD=true`
          + arg[45]: `-Dcom.yahoo.yhudson.plugins.jobmetadata.MISSING_JOB_TYPE_FAILS_BUILD=false`
          + arg[46]: `-Dcom.yahoo.yhudson.plugins.jobmetadata.MISSING_OR_INVALID_FEATURE_TEAM_FAILS_BUILD=false`
          + arg[47]: `-Dcom.yahoo.yhudson.plugins.jobmetadata.MISSING_OR_INVALID_POD_FAILS_BUILD=false`
          + arg[48]: `-Dcom.yahoo.yhudson.plugins.jobmetadata.MISSING_OR_INVALID_PRODUCT_GROUP_FAILS_BUILD=false`
          + arg[49]: `-Dcom.yahoo.yhudson.plugins.jobmetadata.MISSING_OR_INVALID_SYSTEM_FAILS_BUILD=false`
          + arg[50]: `-DJENKINS_HOME=/home/y/var/jenkins`
          + arg[51]: `-Dhudson.disableLoadChangeLogsOnStart=true`
          + arg[52]: `-Dhudson.lifecycle=com.yahoo.jenkins.lifecycle.YjavaDaemonLifecycle`
          + arg[53]: `-Djetty.home=/home/y/libexec/yjava_jetty`
          + arg[54]: `-Djetty.webapps=/home/y/libexec/webapps`
          + arg[55]: `-Djetty.port=9999`
          + arg[56]: `-Djetty.tls.port=8443`
          + arg[57]: `-Djetty.logs=/home/y/logs/yjava_jetty`
          + arg[58]: `-Djava.io.tmpdir=/home/y/libexec/yjava_jetty/temp`
          + arg[59]: `-Djava.library.path=/home/y/lib64`
          + arg[60]: `-Djava.security.auth.login.config=/home/y/libexec/yjava_jetty/etc/jaas.config`
          + arg[61]: `-Dlogback.configurationFile=file:///home/y/libexec/yjava_jetty/resources/logback.xml`
          + arg[62]: `-Dyjava.child_pid=3327`
          + arg[63]: `-Dyjava.start_time=1426631366`
          + arg[64]: `-Dyjava.times_restarted=1`
          + arg[65]: `-Dyjava.restart_delay=0`
          + arg[66]: `-Dyjava.skip_entry=0`
          + arg[67]: `-Dyjava.reload=0`
          + arg[68]: `-Dyjava.main_class=yjava.servlet.container.jetty.JettyDaemon`
          + arg[69]: `-Dyjava.groupName=yjava.servlet.container.jetty.JettyDaemon_0`
          + arg[70]: `-Dyjava.groupId=0`
          + arg[71]: `-Djava.net.preferIPv4Stack=true`
          + arg[72]: `-XX:ErrorFile=/home/y/var/crash/hs_err_pid%p.log`
          + arg[73]: `abort`

  * rhel-gq1-factory-slave-080.infra (`hudson.slaves.DumbSlave`)
      - Description:    _fqdn: factory-slave-080.infra.corp.gq1.yahoo.com_
      - Executors:      6
      - Remote FS root: `/home/yahoo/hudson-ws`
      - Labels:         rhel6_4on6 rhel_x86_64 rhel6 rhel6_4on6_gq1
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/home/y/libexec64/jdk64-1.8.0/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_25
          + Maximum memory:   1.78 GB (1908932608)
          + Allocated memory: 491.00 MB (514850816)
          + Free memory:      426.73 MB (447461200)
          + In-use memory:    64.27 MB (67389616)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.25-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-431.23.3.el6.YAHOO.20140804.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.5 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 16294 (0x3fa6)
      - Process started: 2015-03-17 15:29:43.533-0700
      - Process uptime: 26 sec
      - JVM startup parameters:
          + Boot classpath: `/home/y/libexec64/jdk64-1.8.0/jre/lib/resources.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/rt.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/sunrsasign.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/jsse.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/jce.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/charsets.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/jfr.jar:/home/y/libexec64/jdk64-1.8.0/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/home/y/lib64`
          + arg[0]: `-Djava.library.path=/home/y/lib64`
          + arg[1]: `-Xms512m`
          + arg[2]: `-Xmx2048m`
          + arg[3]: `-Dfile.encoding=UTF-8`
          + arg[4]: `-Djava.awt.headless=true`
          + arg[5]: `-XX:-HeapDumpOnOutOfMemoryError`
          + arg[6]: `-XX:HeapDumpPath=/home/y/logs/yjava_jetty/java_pid%p.hprof`
          + arg[7]: `-XX:ErrorFile=/home/y/logs/yjava_jetty/hs_err_pid%p.log`

  * rhel6-gq1-factory-slave-081.infra (`hudson.slaves.DumbSlave`)
      - Description:    _fqdn: factory-slave-081.infra.corp.gq1.yahoo.com_
      - Executors:      6
      - Remote FS root: `/home/yahoo/hudson-ws`
      - Labels:         rhel6_native rhel6 rhel6_native_gq1
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/home/y/libexec64/jdk64-1.8.0/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_31
          + Maximum memory:   1.78 GB (1908932608)
          + Allocated memory: 491.00 MB (514850816)
          + Free memory:      424.15 MB (444750744)
          + In-use memory:    66.85 MB (70100072)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.31-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-431.23.3.el6.YAHOO.20140804.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.5 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 15104 (0x3b00)
      - Process started: 2015-03-17 15:29:43.532-0700
      - Process uptime: 27 sec
      - JVM startup parameters:
          + Boot classpath: `/home/y/libexec64/jdk64-1.8.0/jre/lib/resources.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/rt.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/sunrsasign.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/jsse.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/jce.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/charsets.jar:/home/y/libexec64/jdk64-1.8.0/jre/lib/jfr.jar:/home/y/libexec64/jdk64-1.8.0/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/home/y/lib64`
          + arg[0]: `-Djava.library.path=/home/y/lib64`
          + arg[1]: `-Xms512m`
          + arg[2]: `-Xmx2048m`
          + arg[3]: `-Dfile.encoding=UTF-8`
          + arg[4]: `-Djava.awt.headless=true`
          + arg[5]: `-XX:-HeapDumpOnOutOfMemoryError`
          + arg[6]: `-XX:HeapDumpPath=/home/y/logs/yjava_jetty/java_pid%p.hprof`
          + arg[7]: `-XX:ErrorFile=/home/y/logs/yjava_jetty/hs_err_pid%p.log`

  * freebsd-gq1-factory-slave-079.infra (`hudson.slaves.DumbSlave`)
      - Description:    _fqdn: factory-slave-079.infra.corp.gq1.yahoo.com_
      - Executors:      6
      - Remote FS root: `/home/yahoo/hudson-ws`
      - Labels:         freebsd
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/home/y/libexec64/jdk1.7.0/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_45
          + Maximum memory:   1.78 GB (1908932608)
          + Allocated memory: 491.50 MB (515375104)
          + Free memory:      439.86 MB (461230576)
          + In-use memory:    51.64 MB (54144528)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.45-b08
      - Operating system
          + Name:         FreeBSD
          + Architecture: amd64
          + Version:      7.5-YAHOO-20140929
      - Process ID: 55088 (0xd730)
      - Process started: 2015-03-17 15:29:43.506-0700
      - Process uptime: 27 sec
      - JVM startup parameters:
          + Boot classpath: `/home/y/libexec64/jdk1.7.0/jre/lib/resources.jar:/home/y/libexec64/jdk1.7.0/jre/lib/rt.jar:/home/y/libexec64/jdk1.7.0/jre/lib/sunrsasign.jar:/home/y/libexec64/jdk1.7.0/jre/lib/jsse.jar:/home/y/libexec64/jdk1.7.0/jre/lib/jce.jar:/home/y/libexec64/jdk1.7.0/jre/lib/charsets.jar:/home/y/libexec64/jdk1.7.0/jre/lib/jfr.jar:/home/y/libexec64/jdk1.7.0/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/home/y/lib64`
          + arg[0]: `-Djava.library.path=/home/y/lib64`
          + arg[1]: `-Xms512m`
          + arg[2]: `-Xmx2048m`
          + arg[3]: `-Dfile.encoding=UTF-8`
          + arg[4]: `-Djava.awt.headless=true`
          + arg[5]: `-XX:-HeapDumpOnOutOfMemoryError`
          + arg[6]: `-XX:HeapDumpPath=/home/y/logs/yjava_jetty/java_pid%p.hprof`
          + arg[7]: `-XX:ErrorFile=/home/y/logs/yjava_jetty/hs_err_pid%p.log`


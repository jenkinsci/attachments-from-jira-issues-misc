Monitors
========

`OldData`
--------------
  * Problematic object: `hudson.model.FreeStyleProject@75650165[tests-thefactory-regex_selected_job3]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@7213121[tests-thefactory-jmd_valid_owner]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `hudson.model.FreeStyleProject@73b570b6[tests-thefactory-regex_selected_job1]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-abort_build #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-predefined_trigger_A_unstable #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: hudson.plugins.labeledgroupedtests.LabeledGroupedTestResultAction, CannotResolveClassException: hudson.plugins.parameterizedtrigger.CapturedEnvironmentAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-bugzilla_link #2`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-join_trigger_parallel_B #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-git-polling #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@2b384134[tests-thefactory-predefined_trigger_A]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: hudson.plugins.parameterizedtrigger.BuildTrigger
  * Problematic object: `hudson.model.FreeStyleProject@617af777[tests-thefactory-api_create_policy_compliant_job]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-downstream_A_unstable #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests_asdf #6`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@7d667e77[tests-thefactory-keep_build_forever]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, DuplicateFieldException: logRotator
---- Debugging information ----
duplicate-field     : logRotator
-------------------------------
  * Problematic object: `hudson.model.FreeStyleProject@2affebee[tests-thefactory-upstream_B]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-Choice-parameter #2`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-add_build_description #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-bugzilla_link #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-boolean_parameterTrue #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@2c9ee588[tests-thefactory-downstream_A_success]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@3c88cf92[tests_asdf]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.FileExec
  * Problematic object: `tests-thefactory-rhel6_native_ARYA_assembly_java #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@42b91299[tests-thefactory-rhel6_4on6_ARYA_assembly_java]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `hudson.model.FreeStyleProject@533c341d[tests-thefactory-rhel6_native_ARYA_deploy_java]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.FileExec
  * Problematic object: `tests-thefactory-poll_scm-edit #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@751f553d[tests-thefactory-create_job_from_copy]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@63b3c190[tests-thefactory-svn_trigger_A]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, MissingFieldException: No field 'ignoreDirPropChanges' found in class 'hudson.scm.SubversionSCM', MissingFieldException: No field 'filterChangelog' found in class 'hudson.scm.SubversionSCM', CannotResolveClassException: hudson.plugins.parameterizedtrigger.BuildTrigger
  * Problematic object: `hudson.model.FreeStyleProject@799d4eba[globalmedia-lego_core-trunk-deploy-qa1p-gq1]`
    - CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake, CannotResolveClassException: hudson.plugins.descriptionsetter.DescriptionSetterPublisher, CannotResolveClassException: hudson.plugins.parameterizedtrigger.BuildTrigger, CannotResolveClassException: hudson.plugins.emailext.ExtendedEmailPublisher
  * Problematic object: `hudson.model.FreeStyleProject@62f444dc[tests-thefactory-jmd_no_owner]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `tests-thefactory-join_trigger_intersection #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-currentBuildParams_trigger_A_unstable #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: hudson.plugins.labeledgroupedtests.LabeledGroupedTestResultAction, CannotResolveClassException: hudson.plugins.parameterizedtrigger.CapturedEnvironmentAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@2a6b4041[tests-thefactory-run_build]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-predefined_trigger_B_unstable #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-edit_build_description #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.Hudson@25a4f194`
    - IllegalArgumentException: Failed to parse 'hudson.model.Item.ViewStatus:tf_argus_check' --- no such permission
  * Problematic object: `hudson.model.FreeStyleProject@403b2e09[tests-thefactory-rhel6_4on6_assembly_java]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `hudson.model.FreeStyleProject@ab44687[tests-thefactory-downstream_B_unstable]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@61cfbcfc[tests-thefactory-downstream_B_failure]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@11edaede[tests-thefactory-currentBuildParams_trigger_A_unstable]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.FileExec, CannotResolveClassException: hudson.plugins.labeledgroupedtests.LabeledGroupedTestArchiver, CannotResolveClassException: hudson.plugins.parameterizedtrigger.BuildTrigger
  * Problematic object: `tests-thefactory-api_update_scm_trigger #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@4fc2caf6[tests-thefactory-predefined_trigger_A_unstable]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.FileExec, CannotResolveClassException: hudson.plugins.labeledgroupedtests.LabeledGroupedTestArchiver, CannotResolveClassException: hudson.plugins.parameterizedtrigger.BuildTrigger
  * Problematic object: `hudson.model.FreeStyleProject@552a1c1f[tests-thefactory-disabled_job]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@3e532066[tests-thefactory-join_trigger_parallel_A]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@2fe6e8d1[tests-thefactory-currentBuildParams_trigger_B]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, MissingFieldException: No field 'ignoreDirPropChanges' found in class 'hudson.scm.SubversionSCM', MissingFieldException: No field 'filterChangelog' found in class 'hudson.scm.SubversionSCM'
  * Problematic object: `hudson.model.FreeStyleProject@664e7579[tests-thefactory-boolean_parameterFalse]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `hudson.model.FreeStyleProject@1a819eb6[tests-thefactory-rhel6_native_deploy_java]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-currentBuildParams_trigger_A #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: hudson.plugins.parameterizedtrigger.CapturedEnvironmentAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@47426105[tests-thefactory-rhel6_native_component_java]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `hudson.model.FreeStyleProject@4a15d15c[tests-thefactory-String-parameter]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-rhel6_4on6_component_java #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@5825e46e[tests-thefactory-delete_build]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@3cf45fbb[tests-thefactory-Choice-parameter]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-predefined_trigger_B #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@6342e016[tests-thefactory-rhel6_4on6_component_java]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `tests-thefactory-rhel6_native_ARYA_deploy_java #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@76edb1b8[tests-thefactory-bugzilla_link]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, MissingFieldException: No field 'ignoreDirPropChanges' found in class 'hudson.scm.SubversionSCM', MissingFieldException: No field 'filterChangelog' found in class 'hudson.scm.SubversionSCM', CannotResolveClassException: com.yahoo.yhudson.tasks.FileExec
  * Problematic object: `globalmedia-lego_core-trunk-deploy-qa1p-gq1 #6150`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: hudson.plugins.descriptionsetter.DescriptionSetterAction, CannotResolveClassException: hudson.plugins.parameterizedtrigger.CapturedEnvironmentAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@e531909[oops]`
    - CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake, CannotResolveClassException: hudson.plugins.descriptionsetter.DescriptionSetterPublisher, CannotResolveClassException: hudson.plugins.parameterizedtrigger.BuildTrigger, CannotResolveClassException: hudson.plugins.emailext.ExtendedEmailPublisher
  * Problematic object: `hudson.model.FreeStyleProject@2b780c25[tests-thefactory-jmd_invalid_owner]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `tests-thefactory-jmd_no_owner #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-join_trigger_parallel_A #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@24626f02[tests-thefactory-api_update_job_description]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-rhel6_4on6_ARYA_deploy_java #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@47e61c81[tests-thefactory-upstream_A]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@16b3b1dd[tests-thefactory-abort_build]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-currentBuildParams_trigger_B #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-rhel6_4on6_assembly_java #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@4fe94e9b[tests-thefactory-enabled_job]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-rhel6_native_assembly_java #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@3a8b0aff[tests-thefactory-join_trigger_starting]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: join.JoinTrigger
  * Problematic object: `tests_asdf #7`
    - CannotResolveClassException: hudson.plugins.jobConfigHistory.JobConfigBadgeAction, CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `timezone #5`
    - CannotResolveClassException: hudson.plugins.jobConfigHistory.JobConfigBadgeAction, CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@2d110b66[tests-thefactory-downstream_B_success]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@39f4058d[tests-thefactory-rhel6_native_assembly_java]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `hudson.model.FreeStyleProject@1fb630cc[tests-thefactory-poll_scm-edit]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `hudson.model.FreeStyleProject@156712d[tests-thefactory-downstream_B]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@1bc253bd[tests-thefactory-checkbox_selected_job1]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `timezone #6`
    - CannotResolveClassException: hudson.plugins.jobConfigHistory.JobConfigBadgeAction, CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-run_build #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@23128495[tests-thefactory-rhel6_4on6_deploy_java]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `tests-thefactory-keep_build_forever #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `timezone #2`
    - CannotResolveClassException: hudson.plugins.jobConfigHistory.JobConfigBadgeAction, CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests_asdf #10`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@3b7a6ef7[tony-test]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-jmd_invalid_owner #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `timezone #4`
    - CannotResolveClassException: hudson.plugins.jobConfigHistory.JobConfigBadgeAction, CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@25ec917f[tests-thefactory-join_trigger_parallel_B]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@44f82b6d[tests-thefactory-currentBuildParams_trigger_A]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: hudson.plugins.parameterizedtrigger.BuildTrigger
  * Problematic object: `hudson.model.FreeStyleProject@1c20f6b6[tests-thefactory-svn_trigger_B]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, MissingFieldException: No field 'ignoreDirPropChanges' found in class 'hudson.scm.SubversionSCM', MissingFieldException: No field 'filterChangelog' found in class 'hudson.scm.SubversionSCM'
  * Problematic object: `oops #6150`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: hudson.plugins.descriptionsetter.DescriptionSetterAction, CannotResolveClassException: hudson.plugins.parameterizedtrigger.CapturedEnvironmentAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@e839714[tests-thefactory-Publish_Test_Results_in_Labeled_Groups-edit]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: hudson.plugins.labeledgroupedtests.LabeledGroupedTestArchiver
  * Problematic object: `tests-thefactory-gitDataLink #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-rhel6_native_component_java #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@453ab4a5[tests-thefactory-predefined_trigger_B]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, MissingFieldException: No field 'ignoreDirPropChanges' found in class 'hudson.scm.SubversionSCM', MissingFieldException: No field 'filterChangelog' found in class 'hudson.scm.SubversionSCM'
  * Problematic object: `hudson.matrix.MatrixProject@6d2e56b1[tests_builds]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: jenkins.plugins.buildhighlights.LogAppender, CannotResolveClassException: com.yahoo.yhudson.tasks.FileExec
  * Problematic object: `tests_asdf #5`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@36f98f5b[timezone]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.FileExec, CannotResolveClassException: hudson.plugins.timestamper.TimestamperBuildWrapper
  * Problematic object: `hudson.model.FreeStyleProject@598eac2d[tests-thefactory-join_trigger_intersection]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@60406be4[tests-thefactory-checkbox_selected_job3]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@e0c11ab[tests-thefactory-gitDataLink]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@5c8ecb29[tests-thefactory-labelled_test_groups]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.FileExec, CannotResolveClassException: com.yahoo.yhudson.tasks.FileExec, CannotResolveClassException: com.yahoo.yhudson.tasks.FileExec, CannotResolveClassException: com.yahoo.yhudson.tasks.FileExec, CannotResolveClassException: com.yahoo.yhudson.tasks.FileExec, CannotResolveClassException: hudson.plugins.labeledgroupedtests.LabeledGroupedTestArchiver
  * Problematic object: `hudson.model.FreeStyleProject@514372ea[tests-thefactory-copy_job_original]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-svn_trigger_B #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@72efac45[tests-thefactory-yroot_bim-edit]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@6594963e[tests-thefactory-predefined_trigger_B_unstable]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, MissingFieldException: No field 'ignoreDirPropChanges' found in class 'hudson.scm.SubversionSCM', MissingFieldException: No field 'filterChangelog' found in class 'hudson.scm.SubversionSCM'
  * Problematic object: `tests-thefactory-downstream_A_success #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-jmd_valid_owner_no_other #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@1215adbb[tests-thefactory-downstream_A_failure]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.FileExec
  * Problematic object: `hudson.model.FreeStyleProject@65275c89[tests-thefactory-jmd_valid_owner_no_other]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `tests_asdf #9`
    - CannotResolveClassException: hudson.plugins.jobConfigHistory.JobConfigBadgeAction, CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-predefined_trigger_A #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: hudson.plugins.parameterizedtrigger.CapturedEnvironmentAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests_asdf #11`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-join_trigger_starting #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: join.JoinAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-simple_gmake_job #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-svn_trigger_A #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: hudson.plugins.parameterizedtrigger.CapturedEnvironmentAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-text-parameter #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests_asdf #8`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-rhel6_4on6_ARYA_assembly_java #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@4344dafa[tests-thefactory-add_build_description]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@6f3cd482[tests-thefactory-rhel6_4on6_ARYA_deploy_java]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.FileExec
  * Problematic object: `timezone #7`
    - CannotResolveClassException: hudson.plugins.jobConfigHistory.JobConfigBadgeAction, CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@304dd98f[tests-thefactory-regex_selected_job2]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-jmd_valid_owner #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@24ecf725[tests-thefactory-rhel6_native_ARYA_assembly_java]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `hudson.model.FreeStyleProject@79cff403[tests-thefactory-currentBuildParams_trigger_B_unstable]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, MissingFieldException: No field 'ignoreDirPropChanges' found in class 'hudson.scm.SubversionSCM', MissingFieldException: No field 'filterChangelog' found in class 'hudson.scm.SubversionSCM'
  * Problematic object: `tests-thefactory-String-parameter #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@57af9c7f[tests-thefactory-git-polling]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@740f70dc[tests-thefactory-downstream_A_unstable]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.FileExec, CannotResolveClassException: hudson.plugins.labeledgroupedtests.LabeledGroupedTestArchiver
  * Problematic object: `tests-thefactory-downstream_B_success #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `timezone #3`
    - CannotResolveClassException: hudson.plugins.jobConfigHistory.JobConfigBadgeAction, CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@535bad81[tests-thefactory-svn_repo-edit]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@4d7a89a0[tests-thefactory-boolean_parameterTrue]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `hudson.model.FreeStyleProject@49494895[tests-thefactory-api_add_string_parameter]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@5c77c6ab[tests-thefactory-api_update_scm_trigger]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@6d4e9393[tests-thefactory-edit_build_description]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-labelled_test_groups #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: hudson.plugins.labeledgroupedtests.LabeledGroupedTestResultAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-currentBuildParams_trigger_B_unstable #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-downstream_A_failure #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tony-test #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `tests-thefactory-boolean_parameterFalse #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@746bc887[tests-thefactory-free-style-job_create]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-next_build_number #555`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@468cc161[tests-thefactory-checkbox_selected_job2]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `tests-thefactory-Choice-parameter #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@3fed451d[tests-thefactory-downstream_project-edit]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty
  * Problematic object: `hudson.model.FreeStyleProject@817c8e4[tests-thefactory-text-parameter]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `hudson.model.FreeStyleProject@25c40437[tests-thefactory-simple_gmake_job]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty, CannotResolveClassException: com.yahoo.yhudson.tasks.Gmake
  * Problematic object: `tests-thefactory-rhel6_4on6_deploy_java #1`
    - CannotResolveClassException: org.jenkinsci.plugins.buildtriggerbadge.BuildTriggerBadgeAction, CannotResolveClassException: com.sonyericsson.rebuild.RebuildAction, CannotResolveClassException: jenkins.plugins.buildhighlights.BHSummaryAction, CannotResolveClassException: org.jvnet.hudson.plugins.DownstreamBuildViewAction
  * Problematic object: `hudson.model.FreeStyleProject@2da1c45f[tests-thefactory-git_repo-edit]`
    - CannotResolveClassException: hudson.plugins.buildblocker.BuildBlockerProperty, CannotResolveClassException: com.sonyericsson.rebuild.RebuildSettings, CannotResolveClassException: com.yahoo.yhudson.plugins.jobmetadata.JobMetadataProperty

`jenkins.diagnostics.PinningIsBlockingBundledPluginMonitor`
--------------
(active and enabled)

`jenkins.model.DownloadSettings$Warning`
--------------
(active and enabled)

`jenkins.security.s2m.MasterKillSwitchWarning`
--------------
(active and enabled)

Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 80
    - Number of builds per job: 0.85 [n=80, s=1.0]

Total job statistics
======================

  * Number of jobs: 80
  * Number of builds per job: 0.85 [n=80, s=1.0]

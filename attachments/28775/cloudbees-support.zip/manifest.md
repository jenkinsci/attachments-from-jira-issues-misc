CloudBees Support Bundle Manifest
=================================

Generated on 2015-03-19 04:09:08 +0000

Requested components:

  * Log Recorders

      - `nodes/master/logs/all_2015-03-18_17.31.15.log`

      - `nodes/master/logs/all_2015-03-18_17.41.19.log`

      - `nodes/master/logs/all_2015-03-18_17.49.34.log`

      - `nodes/master/logs/all_2015-03-18_19.48.07.log`

      - `nodes/master/logs/all_2015-03-18_20.28.08.log`

      - `nodes/master/logs/all_2015-03-18_22.03.34.log`

      - `nodes/master/logs/all_2015-03-18_23.03.00.log`

      - `nodes/master/logs/all_2015-03-18_23.14.55.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/custom/Investigating AD Security Realm Issues.log`

      - `nodes/master/logs/custom/Investigating Active Directory connection issues.log`

      - `nodes/master/logs/jenkins.log`

      - `nodes/slave/DMP Slave/jenkins.log`

      - `nodes/slave/DMP Slave/launchLogs/slave.log`

      - `nodes/slave/DMP Slave/launchLogs/slave.log.1`

      - `nodes/slave/DMP Slave/launchLogs/slave.log.10`

      - `nodes/slave/DMP Slave/launchLogs/slave.log.2`

      - `nodes/slave/DMP Slave/launchLogs/slave.log.3`

      - `nodes/slave/DMP Slave/launchLogs/slave.log.4`

      - `nodes/slave/DMP Slave/launchLogs/slave.log.5`

      - `nodes/slave/DMP Slave/launchLogs/slave.log.6`

      - `nodes/slave/DMP Slave/launchLogs/slave.log.7`

      - `nodes/slave/DMP Slave/launchLogs/slave.log.8`

      - `nodes/slave/DMP Slave/launchLogs/slave.log.9`

      - `nodes/slave/DMP Slave/logs/all_2015-03-18_17.33.04.log`

      - `nodes/slave/DMP Slave/logs/all_2015-03-18_17.43.07.log`

      - `nodes/slave/DMP Slave/logs/all_2015-03-18_17.51.24.log`

      - `nodes/slave/DMP Slave/logs/all_2015-03-18_19.49.58.log`

      - `nodes/slave/DMP Slave/logs/all_2015-03-18_20.29.56.log`

      - `nodes/slave/DMP Slave/logs/all_2015-03-18_22.05.51.log`

      - `nodes/slave/DMP Slave/logs/all_2015-03-18_23.05.15.log`

      - `nodes/slave/DMP Slave/logs/all_2015-03-18_23.16.45.log`

      - `nodes/slave/DMP Slave/logs/all_memory_buffer.log`

      - `nodes/slave/WFS Windows Slave/jenkins.log`

      - `nodes/slave/WFS Windows Slave/logs/all_memory_buffer.log`

      - `other-logs/Download metadata.log`

      - `other-logs/jenkins.metrics.api.Metrics$HealthChecker.log`

      - `other-logs/scm-sync-configuration.success.log`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/DMP Slave/checksums.md5`

      - `nodes/slave/WFS Windows Slave/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/DMP Slave/environment.txt`

      - `nodes/slave/WFS Windows Slave/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/DMP Slave/file-descriptors.txt`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/DMP Slave/metrics.json`

      - `nodes/slave/WFS Windows Slave/metrics.json`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/DMP Slave/system.properties`

      - `nodes/slave/WFS Windows Slave/system.properties`

  * Slow Request Records

      - `slow-requests/20150302-223959.536.txt`

      - `slow-requests/20150302-230817.535.txt`

      - `slow-requests/20150303-202450.242.txt`

      - `slow-requests/20150303-202532.242.txt`

      - `slow-requests/20150303-202611.242.txt`

      - `slow-requests/20150303-202714.242.txt`

      - `slow-requests/20150303-202738.242.txt`

      - `slow-requests/20150303-202805.241.txt`

      - `slow-requests/20150303-202856.241.txt`

      - `slow-requests/20150303-203014.242.txt`

      - `slow-requests/20150304-160830.553.txt`

      - `slow-requests/20150304-161935.666.txt`

      - `slow-requests/20150304-170953.440.txt`

      - `slow-requests/20150304-233526.555.txt`

      - `slow-requests/20150304-233529.555.txt`

      - `slow-requests/20150305-173826.554.txt`

      - `slow-requests/20150305-214038.554.txt`

      - `slow-requests/20150305-214041.556.txt`

      - `slow-requests/20150305-214117.530.txt`

      - `slow-requests/20150311-223627.495.txt`

      - `slow-requests/20150312-171210.435.txt`

      - `slow-requests/20150312-185858.435.txt`

      - `slow-requests/20150313-215919.434.txt`

      - `slow-requests/20150316-143801.434.txt`

      - `slow-requests/20150316-151947.467.txt`

      - `slow-requests/20150316-152319.620.txt`

      - `slow-requests/20150316-201556.678.txt`

      - `slow-requests/20150316-204753.679.txt`

      - `slow-requests/20150316-221308.679.txt`

      - `slow-requests/20150316-221341.678.txt`

      - `slow-requests/20150317-150111.678.txt`

      - `slow-requests/20150317-203427.928.txt`

      - `slow-requests/20150317-204712.929.txt`

      - `slow-requests/20150317-204954.928.txt`

      - `slow-requests/20150317-205557.929.txt`

      - `slow-requests/20150318-171311.206.txt`

      - `slow-requests/20150318-172532.204.txt`

      - `slow-requests/20150318-173044.205.txt`

      - `slow-requests/20150318-173359.717.txt`

      - `slow-requests/20150318-173805.723.txt`

      - `slow-requests/20150318-174020.718.txt`

      - `slow-requests/20150318-174603.915.txt`

      - `slow-requests/20150318-175138.334.txt`

      - `slow-requests/20150318-195124.492.txt`

      - `slow-requests/20150318-200045.490.txt`

      - `slow-requests/20150318-202436.491.txt`

      - `slow-requests/20150318-203007.783.txt`

      - `slow-requests/20150318-224635.406.txt`

      - `slow-requests/20150318-230530.258.txt`

      - `slow-requests/20150319-040447.090.txt`

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/DMP Slave/thread-dump.txt`

      - `nodes/slave/WFS Windows Slave/thread-dump.txt`


Node statistics
===============

  * Total number of nodes
      - Sample size:        1171
      - Average (mean):     3.0
      - Average (median):   3.0
      - Standard deviation: 0.0
      - Minimum:            3
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of nodes online
      - Sample size:        1171
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        1171
      - Average (mean):     8.0
      - Average (median):   8.0
      - Standard deviation: 0.0
      - Minimum:            8
      - Maximum:            8
      - 95th percentile:    8.0
      - 99th percentile:    8.0
  * Total number of executors in use
      - Sample size:        1171
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      8
      - FS root:        `/var/lib/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Java
          + Home:           `/dg/local/cots/jdk1.7.0_51_x64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_51
          + Maximum memory:   1.73 GB (1860698112)
          + Allocated memory: 850.50 MB (891813888)
          + Free memory:      335.94 MB (352259792)
          + In-use memory:    514.56 MB (539554096)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.51-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.18-398.el5
          + Distribution: "Red Hat Enterprise Linux Server release 5.11 (Tikanga)"
          + LSB Modules:  `:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
      - Process ID: 11134 (0x2b7e)
      - Process started: 2015-03-18 23:14:42.539+0000
      - Process uptime: 4 hr 54 min
      - JVM startup parameters:
          + Boot classpath: `/dg/local/cots/jdk1.7.0_51_x64/jre/lib/resources.jar:/dg/local/cots/jdk1.7.0_51_x64/jre/lib/rt.jar:/dg/local/cots/jdk1.7.0_51_x64/jre/lib/sunrsasign.jar:/dg/local/cots/jdk1.7.0_51_x64/jre/lib/jsse.jar:/dg/local/cots/jdk1.7.0_51_x64/jre/lib/jce.jar:/dg/local/cots/jdk1.7.0_51_x64/jre/lib/charsets.jar:/dg/local/cots/jdk1.7.0_51_x64/jre/lib/jfr.jar:/dg/local/cots/jdk1.7.0_51_x64/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
          + arg[1]: `-Djava.awt.headless=true`
          + arg[2]: `-XX:MaxPermSize=256M`
          + arg[3]: `-DJENKINS_HOME=/var/lib/jenkins`

  * WFS Windows Slave (`hudson.slaves.DumbSlave`)
      - Description:    _CatalogWFSProxy Windows Build Server_
      - Executors:      1
      - Remote FS root: `C:\Program Files (x86)\Jenkins`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * DMP Slave (`hudson.slaves.DumbSlave`)
      - Description:    _Slave execution node for DMP Testing_
      - Executors:      1
      - Remote FS root: `/dg/local/projects/current/dmp`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.49
      - Java
          + Home:           `/dg/local/cots/java/jdk1.6.0_27_x64/jre`
          + Vendor:           Sun Microsystems Inc.
          + Version:          1.6.0_27
          + Maximum memory:   853.38 MB (894828544)
          + Allocated memory: 56.88 MB (59637760)
          + Free memory:      47.64 MB (49950472)
          + In-use memory:    9.24 MB (9687288)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.6
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Sun Microsystems Inc.
          + Version: 20.2-b06
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.6 (Santiago)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 22260 (0x56f4)
      - Process started: 2015-03-18 23:16:43.383+0000
      - Process uptime: 4 hr 52 min
      - JVM startup parameters:
          + Boot classpath: `/dg/local/cots/java/jdk1.6.0_27_x64/jre/lib/resources.jar:/dg/local/cots/java/jdk1.6.0_27_x64/jre/lib/rt.jar:/dg/local/cots/java/jdk1.6.0_27_x64/jre/lib/sunrsasign.jar:/dg/local/cots/java/jdk1.6.0_27_x64/jre/lib/jsse.jar:/dg/local/cots/java/jdk1.6.0_27_x64/jre/lib/jce.jar:/dg/local/cots/java/jdk1.6.0_27_x64/jre/lib/charsets.jar:/dg/local/cots/java/jdk1.6.0_27_x64/jre/lib/modules/jdk.boot.jar:/dg/local/cots/java/jdk1.6.0_27_x64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/dg/local/cots/java/jdk1.6.0_27_x64/jre/lib/amd64/server:/dg/local/cots/java/jdk1.6.0_27_x64/jre/lib/amd64:/dg/local/cots/java/jdk1.6.0_27_x64/jre/../lib/amd64:/dg/local/cots/oracle/default/lib:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`


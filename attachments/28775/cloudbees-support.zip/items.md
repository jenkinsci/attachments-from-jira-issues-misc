Item statistics
===============

  * `com.cloudbees.hudson.plugins.modeling.impl.jobTemplate.JobTemplate`
    - Number of items: 6
  * `hudson.maven.MavenModule`
    - Number of items: 45
    - Number of builds per job: 33.955555555555556 [n=45, s=40.0]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 3
    - Number of builds per job: 34.333333333333336 [n=3, s=50.0]
    - Number of items per container: 15.0 [n=3, s=0.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 23
    - Number of builds per job: 8.91304347826087 [n=23, s=9.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 1
    - Number of builds per job: 7 [n=1]

Total job statistics
======================

  * Number of jobs: 72
  * Number of builds per job: 25.59722222222222 [n=72, s=30.0]

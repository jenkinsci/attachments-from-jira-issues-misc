Jenkins
=======

Version details
---------------

  * Version: `1.605`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/dg/local/cots/jdk1.7.0_51_x64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_51
      - Maximum memory:   1.73 GB (1860698112)
      - Allocated memory: 850.50 MB (891813888)
      - Free memory:      339.40 MB (355887088)
      - In-use memory:    511.10 MB (535926800)
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.51-b03
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      2.6.18-398.el5
      - Distribution: "Red Hat Enterprise Linux Server release 5.11 (Tikanga)"
      - LSB Modules:  `:core-4.0-amd64:core-4.0-ia32:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-ia32:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-ia32:printing-4.0-noarch`
  * Process ID: 11134 (0x2b7e)
  * Process started: 2015-03-18 23:14:42.539+0000
  * Process uptime: 4 hr 54 min
  * JVM startup parameters:
      - Boot classpath: `/dg/local/cots/jdk1.7.0_51_x64/jre/lib/resources.jar:/dg/local/cots/jdk1.7.0_51_x64/jre/lib/rt.jar:/dg/local/cots/jdk1.7.0_51_x64/jre/lib/sunrsasign.jar:/dg/local/cots/jdk1.7.0_51_x64/jre/lib/jsse.jar:/dg/local/cots/jdk1.7.0_51_x64/jre/lib/jce.jar:/dg/local/cots/jdk1.7.0_51_x64/jre/lib/charsets.jar:/dg/local/cots/jdk1.7.0_51_x64/jre/lib/jfr.jar:/dg/local/cots/jdk1.7.0_51_x64/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
      - arg[1]: `-Djava.awt.headless=true`
      - arg[2]: `-XX:MaxPermSize=256M`
      - arg[3]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `hudson.plugins.active_directory.ActiveDirectorySecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`

Active Plugins
--------------

  * active-directory:1.39 'Jenkins Active Directory plugin'
  * all-changes:1.3 'All changes plugin'
  * analysis-core:1.71 'Static Analysis Utilities'
  * ansicolor:0.4.1 'AnsiColor'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * artifactdeployer:0.33 'Jenkins Artifact Deployer Plug-in'
  * artifactory:2.2.7 'Jenkins Artifactory Plugin'
  * async-http-client:1.7.8 'Async Http Client'
  * audit-trail:2.1 'Audit Trail'
  * awseb-deployment-plugin:0.0.3 'AWS Elastic Beanstalk Deployment Plugin'
  * build-flow-plugin:0.17 'CloudBees Build Flow plugin'
  * build-metrics:1.0 'build-metrics'
  * build-monitor-plugin:1.6+build.140 'Build Monitor View'
  * build-name-setter:1.3 'build-name-setter'
  * build-pipeline-plugin:1.4.6 'Build Pipeline Plugin'
  * build-publisher:1.20 'Hudson Build-Publisher plugin'
  * build-timeout:1.14.1 'Jenkins build timeout plugin'
  * build-view-column:0.2 'Build View Column Plugin'
  * capitomcat:0.1.0 'Capitomcat Plugin'
  * claim:2.6 'Jenkins Claim Plugin'
  * cloudbees-aborted-builds:1.6 'CloudBees Restart Aborted Builds Plugin'
  * cloudbees-aws-credentials:1.2 'CloudBees Amazon Web Services Credentials Plugin'
  * cloudbees-aws-deployer:1.9 'CloudBees Amazon Web Services Deploy Engine Plugin'
  * cloudbees-cloud-backup:3.3 'CloudBees Back-up Cloud Plugin'
  * cloudbees-cloudfoundry-cli:1.0 'Cloud Foundry CLI Plugin'
  * cloudbees-consolidated-build-view:1.3 'CloudBees Consolidated Build View Plugin'
  * cloudbees-credentials:3.3 'CloudBees Credentials Plugin'
  * cloudbees-deployer-plugin:6.0 'CloudBees Deployer Plugin'
  * cloudbees-enterprise-plugins:14.11.0 'Install Jenkins Enterprise by CloudBees'
  * cloudbees-even-scheduler:3.5 'CloudBees Even Scheduler Plugin'
  * cloudbees-folder:4.7 'CloudBees Folders Plugin'
  * cloudbees-folders-plus:2.10 'CloudBees Folders Plus Plugin'
  * cloudbees-groovy-view:1.4 'CloudBees Groovy View Plugin'
  * cloudbees-ha:4.4 'CloudBees High Availability Management plugin'
  * cloudbees-jsync-archiver:5.3 'CloudBees Fast Archiving Plugin'
  * cloudbees-label-throttling-plugin:3.4 'CloudBees Label Throttling Plugin'
  * cloudbees-license:6.0 'CloudBees License Manager'
  * cloudbees-monitoring:1.7 'CloudBees Monitoring Plugin'
  * cloudbees-nodes-plus:1.10 'CloudBees Nodes Plus Plugin'
  * cloudbees-plugin-gateway:5.0 'CloudBees Free Enterprise Plugins'
  * cloudbees-plugin-usage:1.4 'CloudBees Plugin Usage Plugin'
  * cloudbees-quiet-start:1.1 'CloudBees Quiet Start Plugin'
  * cloudbees-registration:3.14 'CloudBees Registration Plugin'
  * cloudbees-secure-copy:3.7 'CloudBees Secure Copy Plugin'
  * cloudbees-ssh-slaves:1.2 'CloudBees SSH Slaves Plugin'
  * cloudbees-support:3.1 'CloudBees Support Plugin'
  * cloudbees-template:4.16 'CloudBees Template Plugin'
  * cloudbees-update-center-plugin:4.15 'CloudBees Update Center Plugin'
  * cloudbees-view-creation-filter:1.1 'CloudBees View Creation Filter Plugin'
  * cloudbees-wasted-minutes-tracker:3.7 'CloudBees Wasted Minutes Tracker Plugin'
  * cloudbees-workflow-aggregator:1.2 'CloudBees Workflow: Aggregator'
  * cloudbees-workflow-rest-api:1.2 'CloudBees Workflow: REST API Plugin'
  * cloudbees-workflow-template:1.2 'CloudBees Workflow: Templates'
  * cloudbees-workflow-ui:1.2 'CloudBees Workflow: UI Plugin'
  * cloudfoundry:1.3 'Cloud Foundry Plugin'
  * cloudfoundry-bosh-cli:1.0 'Cloud Foundry BOSH CLI Plugin'
  * cobertura:1.9.7 'Jenkins Cobertura Plugin'
  * conditional-buildstep:1.3.3 'conditional-buildstep'
  * config-file-provider:2.7.5 'Config File Provider Plugin'
  * console-column-plugin:1.5 'Console Column Plugin'
  * copyartifact:1.35 'Copy Artifact Plugin'
  * credentials:1.22 'Credentials Plugin'
  * credentials-binding:1.3 'Credentials Binding Plugin'
  * dac-cloud-config:1.1 'DEV@cloud Cloud Configuration'
  * dac-extensions:1.7 'DEV@cloud Extensions Plugin'
  * dac-security-plugin:0.2 'dac-security-plugin'
  * dashboard-view:2.9.4 'Dashboard View'
  * delivery-pipeline-plugin:0.8.10 'Delivery Pipeline Plugin'
  * depgraph-view:0.11 'Dependency Graph Viewer Plugin'
  * deployed-on-column:1.7 'Deployed On Column Plugin'
  * deployer-framework:1.0 'Deployer Framework Plugin'
  * deployit-plugin:4.5.2 'XebiaLabs XL Deploy Plugin'
  * description-column:1.0 'Description Column Plugin'
  * description-column-plugin:1.3 'Description Column Plugin'
  * description-setter:1.9 'Jenkins description setter plugin'
  * devstack:0.0.6 'DevStack Plugin'
  * diskcheck:0.26 'diskcheck'
  * docker-build-publish:0.12 'Docker Build and Publish plugin'
  * docker-build-step:1.21 'docker-build-step'
  * docker-plugin:0.8 'Docker plugin'
  * downstream-buildview:1.9 'Downstream build view'
  * durable-task:1.4 'Durable Task Plugin'
  * email-ext:2.39 'Email Extension Plugin'
  * envinject:1.91.1 'Environment Injector Plugin'
  * environment-script:1.1.2 'Environment Script Plugin'
  * extended-choice-parameter:0.34 'Extended Choice Parameter Plug-In'
  * extensible-choice-parameter:1.2.2 'Extensible Choice Parameter plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * extra-columns:1.15 'Extra Columns Plugin'
  * findbugs:4.60 'FindBugs Plug-in'
  * fortify360:3.81 'Fortify 360 Plugin'
  * free-license:4.2 'CloudBees Free Plugins License'
  * ghprb:1.16-8 'GitHub Pull Request Builder'
  * git:2.3.5 'Jenkins GIT plugin'
  * git-client:1.16.1 'Jenkins GIT client plugin'
  * git-notes:0.0.4 'git-notes Plugin'
  * git-parameter:0.4.0 'Git Parameter Plug-In'
  * git-server:1.6 'Git server plugin'
  * git-tag-message:1.2 'Git Tag Message Plugin'
  * git-validated-merge:3.18 'CloudBees Git Validated Merge Plugin'
  * github:1.11 'GitHub plugin'
  * github-api:1.63 'GitHub API Plugin'
  * github-pull-request-build:1.5 'CloudBees Pull Request Builder for GitHub'
  * global-build-stats:1.3 'Hudson global-build-stats plugin'
  * gradle:1.24 'Jenkins Gradle plugin'
  * greenballs:1.14 'Green Balls'
  * groovy:1.24 'Hudson Groovy builder'
  * groovy-postbuild:2.2 'Groovy Postbuild'
  * htmlpublisher:1.3 'HTML Publisher plugin'
  * infradna-backup:3.20 'CloudBees Back-up Plugin'
  * instant-messaging:1.33 'Jenkins instant-messaging plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * jenkins-flowdock-plugin:1.1.7 'Flowdock plugin'
  * jobConfigHistory:2.10 'Jenkins Job Configuration History Plugin'
  * jquery:1.7.2-1 'Jenkins jQuery plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * junit:1.5 'JUnit Plugin'
  * lastsuccessdescriptioncolumn:1.0 'Last Success Description Column'
  * ldap:1.11 'LDAP Plugin'
  * ldapemail:0.8 'LDAP Email Plugin'
  * log-parser:1.0.8 'Log Parser Plugin'
  * logstash:1.0.3 'Logstash'
  * m2release:0.14.0 'Jenkins Maven Release Plug-in Plug-in'
  * mailer:1.15 'Jenkins Mailer Plugin'
  * mansion-cloud:1.22 'CloudBees Cloud Connector'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * mask-passwords:2.7.2 'Mask Passwords Plugin'
  * matrix-auth:1.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.4.1 'Matrix Project Plugin'
  * maven-dependency-update-trigger:1.4 'Maven Dependency Update Trigger'
  * maven-deployment-linker:1.5.1 'Maven Deployment Linker'
  * maven-info:0.2.0 'Jenkins Maven Info Plugin'
  * maven-metadata-plugin:1.2.0 'Maven Metadata Plugin for Jenkins CI server'
  * maven-plugin:2.9 'Maven Integration plugin'
  * mercurial:1.51 'Jenkins Mercurial plugin'
  * metrics:3.0.9 'Metrics Plugin'
  * monitoring:1.55.0 'Monitoring'
  * nectar-license:6.0 'Jenkins Enterprise License Entitlement Check'
  * nectar-rbac:4.13 'CloudBees Role-Based Access Control Plugin'
  * nectar-vmware:4.3.2 'CloudBees VMWare Autoscaling Plugin'
  * node-iterator-api:1.5 'Node Iterator API Plugin'
  * openid:2.1.1 'openid'
  * openid4java:0.9.8.0 'OpenID4Java API'
  * openstack-cloud:1.7 'Openstack Cloud Plugin'
  * openstack-plugin:1.4 'Openstack Jenkins Plugin'
  * pam-auth:1.2 'PAM Authentication plugin'
  * Parameterized-Remote-Trigger:2.1.3 'Parameterized Remote Trigger Plugin'
  * parameterized-trigger:2.26 'Jenkins Parameterized Trigger plugin'
  * plain-credentials:1.1 'Plain Credentials Plugin'
  * postbuild-task:1.8 'Hudson Post build task'
  * promoted-builds:2.20 'Jenkins promoted builds plugin'
  * python:1.2 'Python Plugin'
  * qc:1.2.1 'Quality Center Plugin'
  * rally-update-plugin-1:1.3 'Rally Update Plugin'
  * rallyBuild:1.2 'rallyBuild'
  * rebuild:1.22 'Rebuilder'
  * rhnpush-plugin:0.4.1 'rhnpush-plugin'
  * role-strategy:2.2.0 'Role-based Authorization Strategy'
  * ruby:1.2 'Hudson Ruby Plugin'
  * ruby-runtime:0.12 'ruby-runtime'
  * run-condition:1.0 'Run Condition Plugin'
  * s3:0.7 'Jenkins S3 publisher plugin'
  * scis-ad:1.2 'Hudson Support Subscription Notification Plugin'
  * scm-api:0.2 'SCM API Plugin'
  * scp:1.8 'Hudson SCP publisher plugin'
  * script-security:1.13 'Script Security Plugin'
  * sidebar-link:1.6 'Sidebar Link'
  * simple-parameterized-builds-report:1.4 'Simple Parameterized Builds Report Plugin'
  * skip-plugin:3.6 'CloudBees Skip Next Build Plugin'
  * sonar:2.1 'Jenkins Sonar Plugin'
  * sonargraph-plugin:1.6.3 'Sonargraph Plugin'
  * ssh:2.4 'Jenkins SSH plugin'
  * ssh-agent:1.5 'SSH Agent Plugin'
  * ssh-credentials:1.10 'SSH Credentials Plugin'
  * ssh-slaves:1.9 'Jenkins SSH Slaves plugin'
  * subversion:2.5 'Jenkins Subversion Plug-in'
  * support-core:2.20 'Support Core Plugin'
  * suppress-stack-trace:1.3 'Stack Trace Suppression Plugin'
  * text-finder:1.10 'Jenkins TextFinder plugin'
  * token-macro:1.10 'Token Macro Plugin'
  * tracking-git:1.0 'Tracking Git Plugin'
  * translation:1.12 'Jenkins Translation Assistance plugin'
  * vagrant-plugin:0.1.1 'Vagrant Plugin'
  * versionnumber:1.5 'Version Number Plug-In'
  * view-job-filters:1.26 'View Job Filters'
  * warnings:4.47 'Warnings Plug-in'
  * wikitext:3.6 'CloudBees WikiText Security Plugin'
  * windows-slaves:1.0 'Windows Slaves Plugin'
  * workflow-aggregator:1.4 'Workflow: Aggregator'
  * workflow-api:1.4 'Workflow: API'
  * workflow-basic-steps:1.4 'Workflow: Basic Steps'
  * workflow-cps:1.4 'Workflow: Groovy CPS Execution'
  * workflow-cps-checkpoint:1.2 'CloudBees Workflow: Groovy Checkpoint'
  * workflow-cps-global-lib:1.4 'Workflow: Global Shared Library for CPS workflow'
  * workflow-durable-task-step:1.4 'Workflow: Durable Task Step'
  * workflow-job:1.4 'Workflow: Job'
  * workflow-scm-step:1.4 'Workflow: SCM Step'
  * workflow-step-api:1.4 'Workflow: Step API'
  * workflow-support:1.4 'Workflow: Execution Support'
  * xlrelease-plugin:4.5.1 'XebiaLabs XL Release Plugin'

License details
---------------

 * Jenkins Instance ID: `7919088f10d1ea07af9a48ecb07b09ef`
 * Expires:             Jan 25, 2016
 * Issued to:           digitalglobe
 * Organization:        Hudson Customer:version=2,company=digitalglobe,serverKey=7919088f10d1ea07af9a48ecb07b09ef,executors=10
 * Entitlements:
     - com.cloudbees.jenkins.plugins.license.free.FreeEntitlement@49f8ff1b
     - Jenkins Enterprise license with 10 executors

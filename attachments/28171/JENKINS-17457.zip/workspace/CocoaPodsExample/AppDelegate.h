//
//  AppDelegate.h
//  CocoaPodsExample
//
//  Created by Jerome Lacoste on 12/12/14.
//  Copyright (c) 2014 Jenkins-ci. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


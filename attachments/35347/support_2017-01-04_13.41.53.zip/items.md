Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 1
    - Number of items per container: 1 [n=1]
  * `com.cloudbees.plugins.flow.BuildFlow`
    - Number of items: 1
    - Number of builds per job: 162 [n=1]
  * `hudson.maven.MavenModule`
    - Number of items: 233
    - Number of builds per job: 42.128755364806864 [n=233, s=91.0]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 134
    - Number of builds per job: 47.865671641791046 [n=134, s=93.0]
    - Number of items per container: 1.7388059701492538 [n=134, s=2.5]
  * `hudson.model.FreeStyleProject`
    - Number of items: 5
    - Number of builds per job: 60.4 [n=5, s=90.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 2
    - Number of builds per job: 74.5 [n=2, s=100.0]

Total job statistics
======================

  * Number of jobs: 375
  * Number of builds per job: 44.91466666666667 [n=375, s=91.0]

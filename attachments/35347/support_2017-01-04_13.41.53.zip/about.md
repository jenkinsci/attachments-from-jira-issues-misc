Jenkins
=======

Version details
---------------

  * Version: `2.39`
  * Mode:    WAR
  * Url:     http://jenkins.afrozaar.com:8080/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_111
      - Maximum memory:   910.62 MB (954859520)
      - Allocated memory: 174.96 MB (183463936)
      - Free memory:      66.91 MB (70165000)
      - In-use memory:    108.05 MB (113298936)
      - GC strategy:      SerialGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.111-b15
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.4.19-29.55.amzn1.x86_64
  * Process ID: 4290 (0x10c2)
  * Process started: 2017-01-04 11:17:02.086+0000
  * Process uptime: 2 hr 24 min
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
      - arg[1]: `-Djava.awt.headless=true`
      - arg[2]: `-Dorg.apache.commons.jelly.tags.fmt.timeZone=Africa/Johannesburg`
      - arg[3]: `-Xdebug`
      - arg[4]: `-Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=0`
      - arg[5]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `org.jenkinsci.plugins.googlelogin.GoogleOAuth2SecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * amazon-ecr:1.4 'Amazon ECR plugin'
  * amazon-ecs:1.7 'Amazon EC2 Container Service plugin'
  * ant:1.4 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * artifact-promotion:0.4.0 'artifact-promotion'
  * artifactdeployer:0.33 'Jenkins Artifact Deployer Plug-in'
  * artifactory:2.8.2 'Jenkins Artifactory Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * avatar:1.2 'Avatar Plugin'
  * aws-beanstalk-publisher-plugin:1.7.2 'AWS Elastic Beanstalk Publisher Plugin'
  * aws-credentials:1.16 'CloudBees Amazon Web Services Credentials Plugin'
  * aws-java-sdk:1.11.68 'Amazon Web Services SDK'
  * batch-task:1.19 'Jenkins batch task plugin'
  * bitbucket:1.1.5 'Jenkins Bitbucket Plugin'
  * bitbucket-build-status-notifier:1.3.1 'Bitbucket Build Status Notifier Plugin'
  * bouncycastle-api:2.16.0 'bouncycastle API Plugin'
  * branch-api:1.11.1 'Branch API Plugin'
  * build-flow-extensions-plugin:0.1.1 'Build Flow Extensions'
  * build-flow-plugin:0.20 'Build Flow plugin'
  * build-flow-test-aggregator:1.2 'Build flow test aggregator'
  * build-flow-toolbox-plugin:0.1 'Build Flow Toolbox'
  * build-with-parameters:1.3 'Build With Parameters'
  * buildgraph-view:1.4 'buildgraph-view'
  * cloudbees-credentials:3.3 'CloudBees Credentials Plugin'
  * cloudbees-folder:5.15 'Folders Plugin'
  * conditional-buildstep:1.3.5 'Conditional BuildStep'
  * config-file-provider:2.15.1 'Config File Provider Plugin'
  * copyartifact:1.38.1 'Copy Artifact Plugin'
  * credentials:2.1.10 'Credentials Plugin'
  * credentials-binding:1.10 'Credentials Binding Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * deploy:1.10 'Deploy to container Plugin'
  * description-column-plugin:1.3 'Description Column Plugin'
  * description-setter:1.10 'Jenkins description setter plugin'
  * display-url-api:0.5 'Display URL API'
  * docker-build-publish:1.3.2 'CloudBees Docker Build and Publish plugin'
  * docker-commons:1.5 'Docker Commons Plugin'
  * durable-task:1.12 'Durable Task Plugin'
  * ec2:1.36 'Amazon EC2 plugin'
  * ec2-cloud-axis:1.2 'ec2-cloud-axis'
  * ec2-deployment-dashboard:1.0.10 'Deployment Dashboard Plugin for Jenkins'
  * envinject:1.93.1 'Environment Injector Plugin'
  * external-monitor-job:1.6 'External Monitor Job Type Plugin'
  * ez-templates:1.2.5 'EZ Templates'
  * flow:1.3 'FLOW Plugin'
  * git:3.0.1 'Jenkins Git plugin'
  * git-changelog:1.41 'Git Changelog'
  * git-client:2.2.0 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.25.0 'GitHub plugin'
  * github-api:1.82 'GitHub API Plugin'
  * github-branch-source:1.10.1 'GitHub Branch Source Plugin'
  * google-login:1.3 'Google Login Plugin'
  * gradle:1.25 'Gradle Plugin'
  * gravatar:2.1 'Jenkins Gravatar plugin'
  * greenballs:1.15 'Green Balls'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * ivy:1.26 'Ivy Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jenkins-jira-issue-updater:1.18 'Jenkins Jira Issue Updater'
  * jenkins-multijob-plugin:1.23 'Jenkins Multijob plugin'
  * jira:2.3 'Jenkins JIRA plugin'
  * JiraTestResultReporter:2.0.3 'Jenkins JiraTestResultReporter plugin'
  * job-dsl:1.54 'Job DSL'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.19 'JUnit Plugin'
  * ldap:1.13 'LDAP Plugin'
  * m2release:0.14.0 'Jenkins Maven Release Plug-in Plug-in'
  * mailer:1.18 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.4 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.7.1 'Matrix Project Plugin'
  * maven-info:0.2.0 'Jenkins Maven Info Plugin'
  * maven-plugin:2.14 'Maven Integration plugin'
  * mercurial:1.57 'Jenkins Mercurial plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * multiple-scms:0.6 'Jenkins Multiple SCMs plugin'
  * next-build-number:1.4 'Next Build Number Plugin'
  * node-iterator-api:1.5 'Node Iterator API Plugin'
  * openJDK-native-plugin:1.1 'openJDK-native-plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.32 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.4 'Pipeline: Build Step'
  * pipeline-graph-analysis:1.3 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.5 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3 'Pipeline: Milestone Step'
  * pipeline-rest-api:2.4 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-view:2.4 'Pipeline: Stage View Plugin'
  * plain-credentials:1.3 'Plain Credentials Plugin'
  * project-description-setter:1.1 'Project Description Setter'
  * promoted-builds:2.28 'Jenkins promoted builds plugin'
  * release:2.6.1 'Jenkins Release Plugin'
  * repository-connector:1.1.3 'Repository Connector'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:1.3 'SCM API Plugin'
  * script-security:1.24 'Script Security Plugin'
  * slack:2.1 'Slack Notification Plugin'
  * sonar:2.5 'Jenkins SonarQube Plugin'
  * ssh-credentials:1.12 'SSH Credentials Plugin'
  * ssh-slaves:1.12 'Jenkins SSH Slaves plugin'
  * structs:1.5 'Structs Plugin'
  * subversion:2.7.1 'Jenkins Subversion Plug-in'
  * support-core:2.38 'Support Core Plugin'
  * throttle-concurrents:1.9.0 'Jenkins Throttle Concurrent Builds Plug-in'
  * token-macro:2.0 'Token Macro Plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * vagrant:1.0.2 'vagrant'
  * windows-slaves:1.2 'Windows Slaves Plugin'
  * workflow-aggregator:2.4 'Pipeline'
  * workflow-api:2.8 'Pipeline: API'
  * workflow-basic-steps:2.3 'Pipeline: Basic Steps'
  * workflow-cps:2.23 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.5 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.5 'Pipeline: Nodes and Processes'
  * workflow-job:2.9 'Pipeline: Job'
  * workflow-multibranch:2.9.2 'Pipeline: Multibranch'
  * workflow-scm-step:2.3 'Pipeline: SCM Step'
  * workflow-step-api:2.6 'Pipeline: Step API'
  * workflow-support:2.11 'Pipeline: Supporting APIs'
  * yet-another-docker-plugin:0.1.0-rc30 'Yet Another Docker Plugin'
  * zephyr-for-jira-test-management:1.3 'Zephyr for JIRA Test Management plugin'

Support Bundle Manifest
=======================

Generated on 2017-01-04 13:41:53.233+0000

Requested components:

  * Garbage Collection Logs

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/com.thed.zephyr.jenkins.reporter.ZfjReporter.xml`

      - `jenkins-root-configuration-files/com.tikal.jenkins.plugins.multijob.PhaseJobsConfig.xml`

      - `jenkins-root-configuration-files/custom-config-files.xml`

      - `jenkins-root-configuration-files/de.codecentric.jenkins.dashboard.DashboardView.xml`

      - `jenkins-root-configuration-files/envInject.xml`

      - `jenkins-root-configuration-files/envinject-plugin-configuration.xml`

      - `jenkins-root-configuration-files/github-plugin-configuration.xml`

      - `jenkins-root-configuration-files/groovy-config-files.xml`

      - `jenkins-root-configuration-files/hudson.ivy.IvyBuildTrigger.xml`

      - `jenkins-root-configuration-files/hudson.ivy.IvyModuleSet.xml`

      - `jenkins-root-configuration-files/hudson.maven.MavenModuleSet.xml`

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.plugins.copyartifact.TriggeredBuildSelector.xml`

      - `jenkins-root-configuration-files/hudson.plugins.disk_usage.DiskUsageProjectActionFactory.xml`

      - `jenkins-root-configuration-files/hudson.plugins.disk_usage.DiskUsageProperty.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitSCM.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/hudson.plugins.gradle.Gradle.xml`

      - `jenkins-root-configuration-files/hudson.plugins.jira.JiraProjectProperty.xml`

      - `jenkins-root-configuration-files/hudson.plugins.mercurial.MercurialInstallation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.promoted_builds.GlobalBuildPromotedBuilds.xml`

      - `jenkins-root-configuration-files/hudson.plugins.sonar.MsBuildSQRunnerInstallation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.sonar.SonarGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/hudson.plugins.sonar.SonarRunnerInstallation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.throttleconcurrents.ThrottleJobProperty.xml`

      - `jenkins-root-configuration-files/hudson.scm.CVSSCM.xml`

      - `jenkins-root-configuration-files/hudson.scm.SubversionSCM.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Ant.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Mailer.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Maven.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Shell.xml`

      - `jenkins-root-configuration-files/hudson.tools.JDKInstaller.xml`

      - `jenkins-root-configuration-files/hudson.triggers.SCMTrigger.xml`

      - `jenkins-root-configuration-files/jenkins.model.ArtifactManagerConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.model.DownloadSettings.xml`

      - `jenkins-root-configuration-files/jenkins.model.JenkinsLocationConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.mvn.GlobalMavenConfig.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.maveninfo.config.MavenInfoGlobalConfig.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.slack.SlackNotifier.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.slack.webhook.GlobalConfig.xml`

      - `jenkins-root-configuration-files/jenkins.security.QueueItemAuthenticatorConfiguration.xml`

      - `jenkins-root-configuration-files/maven-global-settings-files.xml`

      - `jenkins-root-configuration-files/maven-settings-files.xml`

      - `jenkins-root-configuration-files/net.nemerosa.jenkins.seed.SeedPlugin.xml`

      - `jenkins-root-configuration-files/net.nemerosa.seed.SeedPlugin.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/org.jenkinsCi.plugins.projectDescriptionSetter.DescriptionSetterWrapper.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.awsbeanstalkpublisher.AWSEBPublisher.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.bitbucket.BitbucketBuildStatusNotifier.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.conditionalbuildstep.singlestep.SingleConditionalBuilder.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.configfiles.GlobalConfigFiles.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.docker.commons.tools.DockerTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.flow_plugin.FlowGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.flow.FlowExecutionList.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.libs.GlobalLibraries.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.support.steps.StageStep.xml`

      - `jenkins-root-configuration-files/org.jfrog.hudson.ArtifactoryBuilder.xml`

      - `jenkins-root-configuration-files/org.jvnet.hudson.plugins.m2release.M2ReleaseBuildWrapper.xml`

      - `jenkins-root-configuration-files/org.jvnet.hudson.plugins.repositoryconnector.RepositoryConfiguration.xml`

      - `jenkins-root-configuration-files/scriptApproval.xml`

      - `jenkins-root-configuration-files/support-core.xml`

      - `jenkins-root-configuration-files/xml-config-files.xml`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/chuck-slave-1/checksums.md5`

      - `nodes/slave/chuck-slave-2/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/chuck-slave-1/exportTable.txt`

      - `nodes/slave/chuck-slave-2/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/chuck-slave-1/environment.txt`

      - `nodes/slave/chuck-slave-2/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/chuck-slave-1/file-descriptors.txt`

      - `nodes/slave/chuck-slave-2/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/chuck-slave-2/proc/meminfo.txt`

      - `nodes/slave/chuck-slave-2/proc/self/cmdline`

      - `nodes/slave/chuck-slave-2/proc/self/environ`

      - `nodes/slave/chuck-slave-2/proc/self/limits.txt`

      - `nodes/slave/chuck-slave-2/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/all/gnuplot`

      - `load-stats/label/all/hour.csv`

      - `load-stats/label/all/min.csv`

      - `load-stats/label/all/sec10.csv`

      - `load-stats/label/chuck-slave-1/gnuplot`

      - `load-stats/label/chuck-slave-1/hour.csv`

      - `load-stats/label/chuck-slave-1/min.csv`

      - `load-stats/label/chuck-slave-1/sec10.csv`

      - `load-stats/label/chuck-slave-2/gnuplot`

      - `load-stats/label/chuck-slave-2/hour.csv`

      - `load-stats/label/chuck-slave-2/min.csv`

      - `load-stats/label/chuck-slave-2/sec10.csv`

      - `load-stats/label/linux/gnuplot`

      - `load-stats/label/linux/hour.csv`

      - `load-stats/label/linux/min.csv`

      - `load-stats/label/linux/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/slaves/gnuplot`

      - `load-stats/label/slaves/hour.csv`

      - `load-stats/label/slaves/min.csv`

      - `load-stats/label/slaves/sec10.csv`

      - `load-stats/label/vagrant/gnuplot`

      - `load-stats/label/vagrant/hour.csv`

      - `load-stats/label/vagrant/min.csv`

      - `load-stats/label/vagrant/sec10.csv`

      - `load-stats/label/wordpress/gnuplot`

      - `load-stats/label/wordpress/hour.csv`

      - `load-stats/label/wordpress/min.csv`

      - `load-stats/label/wordpress/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/chuck-slave-1/metrics.json`

      - `nodes/slave/chuck-slave-2/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/chuck-slave-1/networkInterface.md`

      - `nodes/slave/chuck-slave-2/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/chuck-slave-1/dmesg.txt`

      - `nodes/slave/chuck-slave-1/dmi.txt`

      - `nodes/slave/chuck-slave-1/proc/cpuinfo.txt`

      - `nodes/slave/chuck-slave-1/proc/mounts.txt`

      - `nodes/slave/chuck-slave-1/proc/swaps.txt`

      - `nodes/slave/chuck-slave-1/proc/system-uptime.txt`

      - `nodes/slave/chuck-slave-1/sysctl.txt`

      - `nodes/slave/chuck-slave-1/userid.txt`

      - `nodes/slave/chuck-slave-2/dmesg.txt`

      - `nodes/slave/chuck-slave-2/dmi.txt`

      - `nodes/slave/chuck-slave-2/proc/cpuinfo.txt`

      - `nodes/slave/chuck-slave-2/proc/mounts.txt`

      - `nodes/slave/chuck-slave-2/proc/swaps.txt`

      - `nodes/slave/chuck-slave-2/proc/system-uptime.txt`

      - `nodes/slave/chuck-slave-2/sysctl.txt`

      - `nodes/slave/chuck-slave-2/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/chuck-slave-1/system.properties`

      - `nodes/slave/chuck-slave-2/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/chuck-slave-1/thread-dump.txt`

      - `nodes/slave/chuck-slave-2/thread-dump.txt`


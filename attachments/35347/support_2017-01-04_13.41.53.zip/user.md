User
====

Authentication
--------------

  * Authenticated: true
  * Name: michael.wiles@afrozaar.com
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@79e86a47: Username: michael.wiles@afrozaar.com; Password: [PROTECTED]; Authenticated: true; Details: null; Granted Authorities: authenticated`


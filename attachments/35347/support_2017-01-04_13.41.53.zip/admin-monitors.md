Monitors
========

`OldData`
--------------
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@7c817881[Baobab-support Package for Release Develop/promotion/Deploy to ANA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-core interface #291`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@2acae2ce[Baobab-web Web/com.afrozaar.ashes:ashes-deploy-web][Baobab-web Web/com.afrozaar.ashes:ashes-deploy-web][relativePath:deploy-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@7bdd73cc[Baobab-support Package for Release 4.16/promotion/Deploy to CAX]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@29076d16[Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-shared][Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-shared][relativePath:ashes-shared]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@74e9b4fa[Baobab-web Package for Release 4.14/promotion/Deploy to ANA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@10b251c[Baobab-web Package for Release 4.15]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@60f4e0ed[Baobab-support Package for Release 4.21/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@2ec022db[Baobab-web Web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@6bcddfd0[util-graphicsmagick/com.afrozaar.util:util-graphicsmagick][util-graphicsmagick/com.afrozaar.util:util-graphicsmagick][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@49e721c7[Baobab-support Package for Release 4.16/promotion/Deploy to ANA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@72d97efa[Baobab-support Package for Release 4.17/com.afrozaar.ashes:ashes-support-deploy][Baobab-support Package for Release 4.17/com.afrozaar.ashes:ashes-support-deploy][relativePath:support-deploy]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@6ee686c3[Baobab-support Package for Release 4.16/com.afrozaar.ashes:ashes-support-deploy][Baobab-support Package for Release 4.16/com.afrozaar.ashes:ashes-support-deploy][relativePath:support-deploy]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@58d870f0[Sonar - Baobab Module - Wordpress]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModuleSet@9231108[Content API - Client]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModuleSet@76545a[util-gwt]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@9a5dd8b[Baobab-support Package for Release 4.14/promotion/Deploy to INM]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@168016b1[Baobab-web Package for Release 4.15/promotion/Deploy to AZ]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@54026430[Baobab-core kernel/com.afrozaar.ashes:ashes-core-pom][Baobab-core kernel/com.afrozaar.ashes:ashes-core-pom][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@5669152[Baobab Module - Renew-subscriptions/com.afrozaar.ashes.module:ashes-renew-subscriptions][Baobab Module - Renew-subscriptions/com.afrozaar.ashes.module:ashes-renew-subscriptions][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@bb76383[Baobab-web Package for Release Develop/com.afrozaar.ashes:ashes-deploy-web][Baobab-web Package for Release Develop/com.afrozaar.ashes:ashes-deploy-web][relativePath:deploy-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@2f142f22[Baobab-support Package for Release 4.13]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@4a591a61[Baobab Module - Worldnet/com.afrozaar.ashes.module:ashes-worldnet][Baobab Module - Worldnet/com.afrozaar.ashes.module:ashes-worldnet][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@3bc093f8[Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-extractor-json-v3][Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-extractor-json-v3][relativePath:ashes-extractor-json-v3]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@5fdd8be6[Baobab-support Package for Release 4.17/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@87b2047[Sonar - Baobab Module - Polopoly/com.afrozaar.ashes.ingest:ashes-polopoly][Sonar - Baobab Module - Polopoly/com.afrozaar.ashes.ingest:ashes-polopoly][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@519f45a2[Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-test][Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-test][relativePath:ashes-test]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@7e4cb671[Baobab-web Package for Release 4.13]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@2070cc4e[Baobab-meta Shared/com.afrozaar.util:baobab-meta][Baobab-meta Shared/com.afrozaar.util:baobab-meta][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@7403dc3d[Baobab-web Package for Release 4.16/com.afrozaar.ashes:ashes-deploy-web][Baobab-web Package for Release 4.16/com.afrozaar.ashes:ashes-deploy-web][relativePath:deploy-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@f694356[Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-support-dto][Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-support-dto][relativePath:ashes-support-dto]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@5fccf38d[Sonar - Baobab Module - Daily Mail]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModuleSet@536e532b[module-testX]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@75ee29a8[Baobab-web Package for Release 4.13/com.afrozaar.ashes:ashes-deploy-web][Baobab-web Package for Release 4.13/com.afrozaar.ashes:ashes-deploy-web][relativePath:deploy-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@66251a6d[Baobab-core ALL]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@551efd51[Baobab-web Package for Release 4.15/com.afrozaar.ashes:ashes-deploy-web][Baobab-web Package for Release 4.15/com.afrozaar.ashes:ashes-deploy-web][relativePath:deploy-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@77d34380[Baobab-meta Test/com.afrozaar.ashes:ashes-common-model-v0][Baobab-meta Test/com.afrozaar.ashes:ashes-common-model-v0][relativePath:ashes-common-model-v0]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@3d61ed35[Baobab-support Package for Release 4.16/promotion/Deploy to AZ]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@7cc59491[Baobab Module - Renew-subscriptions]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-web Package for Release Develop #228`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@18c57893[Sonar - Baobab Module - Rossiya/com.afrozaar.ashes.module.ingestor:ashes-rossiya][Sonar - Baobab Module - Rossiya/com.afrozaar.ashes.module.ingestor:ashes-rossiya][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@2194edc2[Baobab Module - Reuters]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@234dcb14[Baobab-meta Shared/com.afrozaar.ashes:ashes-common-model-v1][Baobab-meta Shared/com.afrozaar.ashes:ashes-common-model-v1][relativePath:ashes-common-model-v1]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@afa4f6[Baobab-support Package for Release 4.14/promotion/Deploy to AZ]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@49eec9b7[Baobab Module - Independent]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@5299e2c5[Baobab Module - Daily Mail/com.afrozaar.ashes.module:ashes-daily-mail][Baobab Module - Daily Mail/com.afrozaar.ashes.module:ashes-daily-mail][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@40f62495[Baobab-web Package for Release 4.21/promotion/Deploy to CAXTON]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@76251a4d[Baobab-support Package for Release Develop/com.afrozaar.ashes:ashes-support-deploy][Baobab-support Package for Release Develop/com.afrozaar.ashes:ashes-support-deploy][relativePath:support-deploy]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@1da871c0[Baobab-support Package for Release 4.10/com.afrozaar.ashes:ashes-support-deploy][Baobab-support Package for Release 4.10/com.afrozaar.ashes:ashes-support-deploy][relativePath:support-deploy]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@3137495d[Baobab-core kernel/com.afrozaar.ashes:ashes-model][Baobab-core kernel/com.afrozaar.ashes:ashes-model][relativePath:model]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@42182a72[Baobab-web Package for Release 4.10/com.afrozaar.ashes:ashes-deploy-web][Baobab-web Package for Release 4.10/com.afrozaar.ashes:ashes-deploy-web][relativePath:deploy-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@1a448628[util-flyway]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@6e75ae1b[Baobab Module - Polopoly]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@10ff3891[Baobab-support Support]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@47cd1bbd[Baobab Module - User Preferences/com.afrozaar.ashes.service:user-preferences-core][Baobab Module - User Preferences/com.afrozaar.ashes.service:user-preferences-core][relativePath:core]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@50e05891[Baobab-meta Shared/com.afrozaar.ashes:ashes-extractor-json-v3][Baobab-meta Shared/com.afrozaar.ashes:ashes-extractor-json-v3][relativePath:ashes-extractor-json-v3]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@5ee59e94[Baobab-web Package for Release 4.16]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModuleSet@3f6fcf1c[module-ashes-slack]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@344be431[Stabilise Module]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@43b92fc2[Baobab-support Package for Release 4.21/com.afrozaar.ashes:ashes-support-deploy][Baobab-support Package for Release 4.21/com.afrozaar.ashes:ashes-support-deploy][relativePath:support-deploy]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@6be2a39c[Sonar - Baobab Module - Search]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@401d4c62[Baobab Module - Test]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@6112ad6d[util-test]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@132823a9[Baobab Module - Rossiya/com.afrozaar.ashes.module.ingestor:ashes-rossiya][Baobab Module - Rossiya/com.afrozaar.ashes.module.ingestor:ashes-rossiya][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@5b0d678c[Baobab Module - Content API/com.afrozaar.ashes.content:ashes-content-api-core][Baobab Module - Content API/com.afrozaar.ashes.content:ashes-content-api-core][relativePath:core]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@22f99e7b[Support Module - Apple]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@2f99b31a[Baobab Module - Push Notifications/com.afrozaar.ashes.module:ashes-push-subscribe][Baobab Module - Push Notifications/com.afrozaar.ashes.module:ashes-push-subscribe][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@5496d412[Sonar - Baobab Module - AP/com.afrozaar.ashes.module:ashes-ap][Sonar - Baobab Module - AP/com.afrozaar.ashes.module:ashes-ap][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@265b4ade[util-moduleloader/com.afrozaar.util:util-moduleloader][util-moduleloader/com.afrozaar.util:util-moduleloader][relativePath:util-moduleloader]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@643bccbd[Baobab Module - Search]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-web Package for Release Develop #225`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `Sonar - Baobab Module - Prestige #17`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@6d9b610a[Sonar - Baobab Module - S3 Common/com.afrozaar.ashes.s3:ashes-s3-module-common][Sonar - Baobab Module - S3 Common/com.afrozaar.ashes.s3:ashes-s3-module-common][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@54fecc6a[Baobab Module - SP - Free Trial]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.model.FreeStyleProject@6398e70e[Compost]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@5c98d40f[Baobab-meta Shared/com.afrozaar.ashes:ashes-extractor-json-v1][Baobab-meta Shared/com.afrozaar.ashes:ashes-extractor-json-v1][relativePath:ashes-extractor-json-v1]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@5fe6937a[Baobab Module - ANA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@8c58c58[Baobab Module - Twitter Extractor/com.afrozaar.ashes.module:ashes-twitter-extractor][Baobab Module - Twitter Extractor/com.afrozaar.ashes.module:ashes-twitter-extractor][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@13e08d[util-test/com.afrozaar.util:util-test][util-test/com.afrozaar.util:util-test][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@71e1517f[Baobab-meta Test/com.afrozaar.ashes.support:ashes-support-management-web][Baobab-meta Test/com.afrozaar.ashes.support:ashes-support-management-web][relativePath:ashes-support-management-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@6f337bac[Baobab-support Deploy to Local Tomcat/com.afrozaar.ashes:ashes-support-deploy][Baobab-support Deploy to Local Tomcat/com.afrozaar.ashes:ashes-support-deploy][relativePath:support-deploy]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@5fa33b00[Sonar - Baobab Module - Prestige]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@4fcfbf6c[Baobab-meta Shared/com.afrozaar.ashes:ashes-server][Baobab-meta Shared/com.afrozaar.ashes:ashes-server][relativePath:ashes-server]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@53bedb1b[Baobab-web Web GWT 2.8/com.afrozaar.ashes:ashes-deploy-web][Baobab-web Web GWT 2.8/com.afrozaar.ashes:ashes-deploy-web][relativePath:deploy-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@770d37a7[Baobab-support Package for Release Develop/promotion/Deploy to Caxton]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@6c9ef831[Stabilise Module/com.afrozaar.ashes.module:ashes-loremipsum][Stabilise Module/com.afrozaar.ashes.module:ashes-loremipsum][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@4c2af898[module-com.afrozaar.ashes.twitter]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@2fdd4b69[Baobab Module - Polopoly/com.afrozaar.ashes.ingest:ashes-polopoly][Baobab Module - Polopoly/com.afrozaar.ashes.ingest:ashes-polopoly][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@67f6b340[Baobab Module - Xinhua/com.afrozaar.ashes.module:ashes-xinhua][Baobab Module - Xinhua/com.afrozaar.ashes.module:ashes-xinhua][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@8e4a052[Sonar - Video Service]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab Module - Baboab to Baobab Ingestor #15`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@6ad94a1a[WP-API v2 Client - Java/com.afrozaar.wordpress:wp-api-v2-client-java][WP-API v2 Client - Java/com.afrozaar.wordpress:wp-api-v2-client-java][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@a468e80[Baobab-web Package for Release 4.14/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab Module - S3 Common #16`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@750145d0[Baobab-support Package for Release 4.21/promotion/Deploy to CAX]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@6d2f09fa[Baobab-support Package for Release 4.21]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@747824af[Baobab Module - Facebook Extractor/com.afrozaar.ashes.module:ashes-facebook-extractor][Baobab Module - Facebook Extractor/com.afrozaar.ashes.module:ashes-facebook-extractor][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@301338cb[Sonar - Baobab Module - Reuters]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@2c47e49e[Image Resizer/com.afrozaar.ashes:ashes-image-server][Image Resizer/com.afrozaar.ashes:ashes-image-server][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab Module - ANA #35`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModuleSet@f327fd2[Baobab Module - Free trial SP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@6edc2a3c[Baobab-web Web/com.afrozaar.ashes:ashes-web-server][Baobab-web Web/com.afrozaar.ashes:ashes-web-server][relativePath:web-server]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@7592b970[Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-test][Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-test][relativePath:ashes-test]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@71703996[Baobab-meta Test/com.afrozaar.ashes:ashes-server][Baobab-meta Test/com.afrozaar.ashes:ashes-server][relativePath:ashes-server]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab Module - Tag Filter #29`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@edf5e35[baobab-aws-lambdas/1:baobab-aws-lambdas][baobab-aws-lambdas/1:baobab-aws-lambdas][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@4ef5d21f[Baobab Module - AI/com.afrozaar.ashes.module:ashes-ai][Baobab Module - AI/com.afrozaar.ashes.module:ashes-ai][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@225f66b5[MWeb/promotion/INM Test]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@306af09b[Baobab-web Package for Release 4.17/promotion/Deploy to INM]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@e899678[Sonar - Baobab Module - Scheduler]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@683394cb[Baobab-web Package for Release 4.14/com.afrozaar.ashes:ashes-deploy-web][Baobab-web Package for Release 4.14/com.afrozaar.ashes:ashes-deploy-web][relativePath:deploy-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@654819b1[Baobab Module - SAPA ingest/com.afrozaar.ashes.module:baobab-module-sapa-ingest][Baobab Module - SAPA ingest/com.afrozaar.ashes.module:baobab-module-sapa-ingest][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@66310eca[util-java/com.afrozaar.util:util-flyway][util-java/com.afrozaar.util:util-flyway][relativePath:flyway]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@13c0f2c1[Baobab-meta module-parent]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@44640d65[Sonar - Baobab Module - Webhook Extractor/com.afrozaar.ashes.module:ashes-webhook-extractor][Sonar - Baobab Module - Webhook Extractor/com.afrozaar.ashes.module:ashes-webhook-extractor][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@92cf42e[TemplateModule]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@3fe972ea[Baobab-support Package for Release 4.16/promotion/Deploy to INM]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@2d1ee01a[Baobab-meta Extractor JSON V1]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@5113a815[Baobab Module - S3 Common/com.afrozaar.ashes.s3:ashes-s3-module-common][Baobab Module - S3 Common/com.afrozaar.ashes.s3:ashes-s3-module-common][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@1485a58e[Baobab-web Pom/com.afrozaar.ashes:ashes-web-pom][Baobab-web Pom/com.afrozaar.ashes:ashes-web-pom][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab Module - SAPA ingest #39`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModuleSet@7d256429[Baboab Module - Sessions Tasks]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@60e331ef[Baobab Module - Daily Voice Schedule]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@63cf4ade[Amazon SNS]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@6f42a250[Baobab-support Package for Release Develop/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@736762c[util-java/com.afrozaar.maven.plugins:azure-afrozaar-maven-plugin][util-java/com.afrozaar.maven.plugins:azure-afrozaar-maven-plugin][relativePath:afrozaar-plugins]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@f0cb617[Sonar - Baobab Module - Independent]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@187e955e[Baobab Module - Extractors/com.afrozaar.ashes.module:ashes-json-extractors][Baobab Module - Extractors/com.afrozaar.ashes.module:ashes-json-extractors][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@49193c38[Baobab-web Package for Release 4.16/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@bdcbef9[Baobab Module - Service]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@3204c321[Baobab-web Package for Release 4.10/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@30a58582[Baobab-web Server]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@354aa461[Baobab-meta Shared/com.afrozaar.ashes:ashes-subscriptions][Baobab-meta Shared/com.afrozaar.ashes:ashes-subscriptions][relativePath:ashes-subscriptions]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@59eba0c0[Image Resizer]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@3c656149[Baobab Module - Baboab to Baobab Ingestor/com.afrozaar.ashes.module.ingestor:ashes-inter-baobab-ingestor][Baobab Module - Baboab to Baobab Ingestor/com.afrozaar.ashes.module.ingestor:ashes-inter-baobab-ingestor][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@459b50b5[Baobab Module - Reuters/com.afrozaar.ashes.module:ashes-reuters][Baobab Module - Reuters/com.afrozaar.ashes.module:ashes-reuters][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@1fea6ec5[Baobab-meta ModuleFramework/com.afrozaar.ashes.module:ashes-module-framework][Baobab-meta ModuleFramework/com.afrozaar.ashes.module:ashes-module-framework][relativePath:modules/framework]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@3eb54385[Baobab-web Package for Release 4.16/promotion/Deploy to CAXTON]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@14217115[Baobab Module - Tag Filter/com.afrozaar.ashes.module:ashes-tag-filter][Baobab Module - Tag Filter/com.afrozaar.ashes.module:ashes-tag-filter][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@763adf0e[Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-shared][Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-shared][relativePath:ashes-shared]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@59256413[Baobab Module - Rossiya]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `Baobab-web Web #430`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@2899d9a0[Baobab Module - Polopoly/com.afrozaar.ashes.module.ingestor:ashes-polopoly][Baobab Module - Polopoly/com.afrozaar.ashes.module.ingestor:ashes-polopoly][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@4b88b6b2[module-baobab-module-service]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-core Content API Rest #46`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@63de5a98[Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-subscriptions][Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-subscriptions][relativePath:ashes-subscriptions]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@2b50d218[Sonar - Baobab Module - Webhook Extractor]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@34e4d1a8[Baobab-web Package for Release 4.17/com.afrozaar.ashes:ashes-web-pom][Baobab-web Package for Release 4.17/com.afrozaar.ashes:ashes-web-pom][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-core Content API Rest #47`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `Baobab-web Web GWT 2.8 #9`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@3ff3d6a2[Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-extractor-json-v3][Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-extractor-json-v3][relativePath:ashes-extractor-json-v3]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@5fe12eb3[Baobab Module - Extractors]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@4132046a[Baobab-support Package for Release 4.14]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModuleSet@7a19ac5[Baobab Module - SBP Publish]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@3a115e[Baobab-core Content API Rest/com.afrozaar.ashes.support:ashes-content-api][Baobab-core Content API Rest/com.afrozaar.ashes.support:ashes-content-api][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@73e9f28e[WP-API v2 Client - Java]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@3cdd75b7[Baobab Module - Search Extractor]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@2863a50f[Baobab Module - Baboab to Baobab Ingestor]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@79ea6f3[Baobab-support Package for Release 4.10/promotion/Deploy to AZ]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@511c1872[Baobab-support Package for Release 4.16]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@15e43494[Baobab-meta Test/com.afrozaar.ashes:ashes-extractor-json-v2][Baobab-meta Test/com.afrozaar.ashes:ashes-extractor-json-v2][relativePath:ashes-extractor-json-v2]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.model.FreeStyleProject@4c69b918[Baobab-web/X]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@62ff8b8c[Baobab-meta Test/com.afrozaar.util:baobab-meta][Baobab-meta Test/com.afrozaar.util:baobab-meta][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@4d0dfc76[Baobab-support Package for Release 4.10]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@2b3abcf[Baobab-meta Extractor JSON V3/com.afrozaar.ashes:ashes-extractor-json-v3][Baobab-meta Extractor JSON V3/com.afrozaar.ashes:ashes-extractor-json-v3][relativePath:ashes-extractor-json-v3]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@5a303bae[Util - Queue Cleanup]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@17ea8249[Baobab Module - Scheduled Jobs]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@7b3c9a9f[Baobab-web Package for Release 4.17/promotion/Deploy to CAXTON]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@7fbaf61e[Baobab-web Package for Release 4.13/promotion/Deploy to AZ]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@78efc54b[Baobab-core Content API Rest/com.afrozaar.ashes.content:ashes-content-api-rest][Baobab-core Content API Rest/com.afrozaar.ashes.content:ashes-content-api-rest][relativePath:rest]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@6748beee[util-java/com.afrozaar.util:util-java][util-java/com.afrozaar.util:util-java][relativePath:java]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@5083452d[Baobab-support Package for Release 4.17]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@5d00d0ae[MWeb/com.afrozaar.ashes.support:ashes-support-management-web][MWeb/com.afrozaar.ashes.support:ashes-support-management-web][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-web Package for Release Develop #234`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@5166a0d3[Baobab Module - S3 Common/com.afrozaar.ashes.module:ashes-daily-mail][Baobab Module - S3 Common/com.afrozaar.ashes.module:ashes-daily-mail][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@4d94a02c[Baobab Module - Social Common]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@289590[Baobab Module - Daily Voice Schedule/com.afrozaar.ashes.module:ashes-daily-voice][Baobab Module - Daily Voice Schedule/com.afrozaar.ashes.module:ashes-daily-voice][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@311190a9[Baobab-core model]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModuleSet@e722fca[Baobab-web Web GWT 2.8]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@2a89fb30[Baobab-core kernel]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModuleSet@3c19eda2[Baobab Module - User Preferences]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@1dbc060[Baobab-meta Extractor JSON V2]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@233b86fa[Sonar - Baobab Module - Search/com.afrozaar.ashes.module:ashes-search][Sonar - Baobab Module - Search/com.afrozaar.ashes.module:ashes-search][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@4a06abc3[Baobab-meta ModuleFramework/com.afrozaar.ashes.module:ashes-modules][Baobab-meta ModuleFramework/com.afrozaar.ashes.module:ashes-modules][relativePath:modules]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@412204e9[Baobab-support Package for Release 4.21/promotion/Deploy to INM]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@dc9b407[Sonar - Baobab-core IT]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@4307bac8[Baobab-web Package for Release 4.14/promotion/Deploy to AZ]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@54267df6[Baobab-core kmi]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@5d5d688f[Baobab-support Package for Release 4.13/promotion/Deploy to INM]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@6fd30601[Baobab-meta ModuleFramework/com.afrozaar.util:baobab-meta][Baobab-meta ModuleFramework/com.afrozaar.util:baobab-meta][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@22d8070b[util-java/com.afrozaar.util:util-scheduler][util-java/com.afrozaar.util:util-scheduler][relativePath:util-scheduler]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@6acc371f[util-java]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@410ea4db[Baobab-web Package for Release 4.10/promotion/Deploy to AZ]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@373c52ea[Baobab-meta Test/com.afrozaar.ashes:ashes-subscriptions][Baobab-meta Test/com.afrozaar.ashes:ashes-subscriptions][relativePath:ashes-subscriptions]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@33d7ba01[Baobab Module - DPA/com.afrozaar.ashes.module:ashes-dpa][Baobab Module - DPA/com.afrozaar.ashes.module:ashes-dpa][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@521c7bc5[Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-extractor-json-v1][Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-extractor-json-v1][relativePath:ashes-extractor-json-v1]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@3de20439[Baobab-meta Shared/com.afrozaar.ashes:ashes-common-model-v0][Baobab-meta Shared/com.afrozaar.ashes:ashes-common-model-v0][relativePath:ashes-common-model-v0]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.model.FreeStyleProject@6aa5bf7e[Deploy Web (Internal Config)]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@2f2622fb[Baobab-web Package for Release 4.21/promotion/Deploy to ANA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@1ce3d13d[Baobab-web Package for Release 4.16/promotion/Deploy to AZ]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@667a27a4[Support Module - Peaches/com.afrozaar.ashes.module:ashes-peaches][Support Module - Peaches/com.afrozaar.ashes.module:ashes-peaches][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@7a6c338c[Baobab-meta Test/com.afrozaar.ashes:ashes-support-dto][Baobab-meta Test/com.afrozaar.ashes:ashes-support-dto][relativePath:ashes-support-dto]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@4653cfb1[Baobab Module - Auto Publish/com.afrozaar.ashes.module:ashes-auto-publish][Baobab Module - Auto Publish/com.afrozaar.ashes.module:ashes-auto-publish][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-web Pom #21`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModuleSet@815ddf0[Baobab-meta Server]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@df4101e[Baobab-meta Shared/com.afrozaar.ashes.support:ashes-support-management-web][Baobab-meta Shared/com.afrozaar.ashes.support:ashes-support-management-web][relativePath:ashes-support-management-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@4bf1661f[Baobab-web Package for Release 4.16/promotion/Deploy to ANA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@1403e5ed[Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-server][Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-server][relativePath:ashes-server]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@56dd499[Baobab-support Package for Release Develop/promotion/Deploy to AZ]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@144da9b5[Baobab Module - Loremipsum]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@1777b68d[Polopoly Service]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@3e68e792[Sonar - Baobab Module - AP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@184d0db0[Sonar - Baobab Module - Reuters/com.afrozaar.ashes.module:ashes-reuters][Sonar - Baobab Module - Reuters/com.afrozaar.ashes.module:ashes-reuters][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@39378337[Baobab-web Package for Release 4.17]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.model.FreeStyleProject@437b9d7a[Deploy Web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@1a015803[Baobab-web Server/com.afrozaar.ashes:ashes-web-server][Baobab-web Server/com.afrozaar.ashes:ashes-web-server][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@6a35e031[Baobab-web Web/com.afrozaar.ashes:ashes-web-pom][Baobab-web Web/com.afrozaar.ashes:ashes-web-pom][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@220a3c0d[Baobab Module - SAPA ingest/com.afrozaar.ashes.module:ashes-sapa-ingest][Baobab Module - SAPA ingest/com.afrozaar.ashes.module:ashes-sapa-ingest][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@16e94ce5[Baobab Module - Push Notifications]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModuleSet@59785776[Sonar - Baobab Module - Daily Voice Schedule]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@2e4e205e[util-moduleloader]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@6f844595[Baobab Module - ANA/com.afrozaar.ashes.module:ashes-ana][Baobab Module - ANA/com.afrozaar.ashes.module:ashes-ana][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@76046015[Baobab-web Package for Release 4.10/promotion/Deploy to ANA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@4c1a8e08[Baobab-web Package for Release 4.17/promotion/Deploy to ANA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@5b77ad64[Baobab-web Package for Release 4.21/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@7e1e1c0a[Baobab Module - SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@4cf53ae0[Baobab-web Web/com.afrozaar.ashes:ashes-web][Baobab-web Web/com.afrozaar.ashes:ashes-web][relativePath:web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@fd7e5c0[Baobab Module - DPA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@4e371020[Baobab-core interface/com.afrozaar.ashes:ashes-model][Baobab-core interface/com.afrozaar.ashes:ashes-model][relativePath:model]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-web Web #429`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModuleSet@4a1a8405[Baobab-web Package for Release 4.21]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@153d071d[Baobab-support Package for Release 4.17/promotion/Deploy to CAX]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@5b88d1a9[Baobab-support Package for Release 4.14/com.afrozaar.ashes:ashes-support-deploy][Baobab-support Package for Release 4.14/com.afrozaar.ashes:ashes-support-deploy][relativePath:support-deploy]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-meta Server #2`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@19477b65[Baobab Module - AP/com.afrozaar.ashes.module:ashes-ap][Baobab Module - AP/com.afrozaar.ashes.module:ashes-ap][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@2d286b0a[module-ashes-metrics]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@24e7b6c4[Baobab-support Package for Release 4.17/promotion/Deploy to ANA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@256c6749[Baobab Module - SBP-Scheduled/com.afrozaar.ashes.module:ashes-sbp-scheduled][Baobab Module - SBP-Scheduled/com.afrozaar.ashes.module:ashes-sbp-scheduled][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@e27d801[Baobab-web Deploy to Local Tomcat]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@10701657[MWeb]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@58129639[Baobab-meta ashes-support-dto/com.afrozaar.util:baobab-meta][Baobab-meta ashes-support-dto/com.afrozaar.util:baobab-meta][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@6fb32d9f[Baobab-web Package for Release 4.14/promotion/Deploy to INM]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@1b73855e[Baobab-web Package for Release 4.13/promotion/Deploy to INM]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@56fd3cd3[Baobab Module - Scheduler/com.afrozaar.ashes.module:ashes-scheduler][Baobab Module - Scheduler/com.afrozaar.ashes.module:ashes-scheduler][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@3a15cc3a[Baobab Module - Content API/com.afrozaar.ashes.module:ashes-content-api-core][Baobab Module - Content API/com.afrozaar.ashes.module:ashes-content-api-core][relativePath:core]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@142d761f[Baobab-support Support/com.afrozaar.ashes:ashes-support][Baobab-support Support/com.afrozaar.ashes:ashes-support][relativePath:support]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@7dc6bbf4[Baobab-web Package for Release Develop/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@3bcfa9fb[Baobab Module - AP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@45532367[Baobab-web Package for Release 4.21/promotion/Deploy to INM]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@4e541c62[Baobab Module - Daily Mail]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `Baobab-web Web GWT 2.8 #10`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@22e698da[Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-common-model-v1][Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-common-model-v1][relativePath:ashes-common-model-v1]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@f53b96e[Support Module - Baobab Authenticator/com.afrozaar.ashes.module:baobab-authenticator][Support Module - Baobab Authenticator/com.afrozaar.ashes.module:baobab-authenticator][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@39f94bc6[Sonar - Baobab Module - Polopoly]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@c8272c2[Baobab Module - Worldnet]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@7dc05f85[Baobab-core parent pom]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@63a961e3[Baobab-support Package for Release 4.14/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@319ac7d6[Baobab-web Server/com.afrozaar.ashes:ashes-web-pom][Baobab-web Server/com.afrozaar.ashes:ashes-web-pom][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@4e366c7b[Baobab Module - Facebook Extractor]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@5ec98c86[Baobab-meta ashes-support-dto/com.afrozaar.ashes.module:ashes-module-framework][Baobab-meta ashes-support-dto/com.afrozaar.ashes.module:ashes-module-framework][relativePath:modules/framework]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-core kernel #336`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@50237e73[Baobab Module - Independent/com.afrozaar.ashes.module:ashes-independent][Baobab Module - Independent/com.afrozaar.ashes.module:ashes-independent][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@128810d9[util-java/com.afrozaar.util:util-gwt][util-java/com.afrozaar.util:util-gwt][relativePath:util-gwt]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-meta Test #30`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@2e38506c[Baobab-web Package for Release 4.16/com.afrozaar.ashes:ashes-web][Baobab-web Package for Release 4.16/com.afrozaar.ashes:ashes-web][relativePath:web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@6ec62c92[Baobab Module - Free trial SP/com.afrozaar.ashes.module:ashes-free-trial-sp][Baobab Module - Free trial SP/com.afrozaar.ashes.module:ashes-free-trial-sp][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@5e764023[Baobab-support Package for Release 4.9/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@7a662830[Baobab Module - Auto Publish]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@b34a16c[Baobab-web Web GWT 2.8/com.afrozaar.ashes:ashes-web-pom][Baobab-web Web GWT 2.8/com.afrozaar.ashes:ashes-web-pom][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@4457860e[Baobab Module - Twitter Extractor]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@3729c173[Baobab-web Package for Release 4.17/promotion/Deploy to AZ]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@35c1e39a[Baobab-web Package for Release 4.17/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@23c2119f[Support Module - Apple/com.afrozaar.ashes.module:ashes-apple][Support Module - Apple/com.afrozaar.ashes.module:ashes-apple][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@34d72ab6[Baobab-meta Server/com.afrozaar.ashes:ashes-server][Baobab-meta Server/com.afrozaar.ashes:ashes-server][relativePath:ashes-server]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-core IT #449`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModuleSet@4e92bcf1[Baobab-core interface]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModuleSet@eac24c8[Baobab-meta Shared]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@61ee2389[Baobab-meta Test/com.afrozaar.ashes:ashes-extractor-json-v1][Baobab-meta Test/com.afrozaar.ashes:ashes-extractor-json-v1][relativePath:ashes-extractor-json-v1]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@7492aefc[Baobab Module - IndependentUK/com.afrozaar.ashes.module:ashes-independentuk][Baobab Module - IndependentUK/com.afrozaar.ashes.module:ashes-independentuk][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@1b9c55f3[Baobab-support Package for Release 4.13/promotion/Deploy to ANA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@40466a36[Sonar - Baobab Module - Extractors]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-support Package for Release 4.17 #4`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModuleSet@41f2238b[Baobab Module - SAPA ingest]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@75486f34[Baobab-meta Shared/com.afrozaar.ashes:ashes-test][Baobab-meta Shared/com.afrozaar.ashes:ashes-test][relativePath:ashes-test]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@54164a96[Baobab Module - AI]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@40fbee7e[Baobab-support Package for Release 4.13/com.afrozaar.ashes:ashes-support-deploy][Baobab-support Package for Release 4.13/com.afrozaar.ashes:ashes-support-deploy][relativePath:support-deploy]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@39d9275f[Baobab-support Package for Release 4.13/promotion/Deploy to AZ]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@462ee8a6[Baobab-support Package for Release 4.17/promotion/Deploy to AZ]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@64047e8f[Baobab Module - Webhook Extractor]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModuleSet@14fb7a75[Sonar - Baobab Module - Rossiya]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@51add73c[Baobab-meta Test/com.afrozaar.ashes:ashes-common-model-v1][Baobab-meta Test/com.afrozaar.ashes:ashes-common-model-v1][relativePath:ashes-common-model-v1]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@7c253eb6[util-exiftool]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@12dc384f[Baobab-support Package for Release Develop]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@7e1e9486[Baobab-support Package for Release Develop/promotion/Deploy to FIREBRAND]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@141eee86[Baobab Module - Elastic Search]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@5a5f54fc[Baobab-support Package for Release 4.21/promotion/Deploy to AZ]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@23c4099[Baobab-meta Shared/com.afrozaar.ashes.module:ashes-module-framework][Baobab-meta Shared/com.afrozaar.ashes.module:ashes-module-framework][relativePath:modules/framework]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@5d82bf27[Baobab Module - Xinhua]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@4719ed6[util-gwt/com.afrozaar.util:util-gwt][util-gwt/com.afrozaar.util:util-gwt][relativePath:util-gwt]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@547c42d5[Baobab Module - Scheduled Jobs/com.afrozaar.ashes.module:ashes-scheduled-jobs][Baobab Module - Scheduled Jobs/com.afrozaar.ashes.module:ashes-scheduled-jobs][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@637c31d7[Baobab-web Package for Release 4.21/com.afrozaar.ashes:ashes-deploy-web][Baobab-web Package for Release 4.21/com.afrozaar.ashes:ashes-deploy-web][relativePath:deploy-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@6e9c8437[Util - Queue Cleanup/com.afrozaar.util:util-queue-cleanup][Util - Queue Cleanup/com.afrozaar.util:util-queue-cleanup][relativePath:util-queue-cleanup]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@6441caed[Baobab Module - Prestige]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@5f93813f[Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-support-dto][Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-support-dto][relativePath:ashes-support-dto]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@7118d3b7[Baobab Module - Rossiya/com.afrozaar.ashes.module:ashes-rossiya][Baobab Module - Rossiya/com.afrozaar.ashes.module:ashes-rossiya][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-core kernel #337`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@710cc7b9[util-java/com.afrozaar.util:util-test][util-java/com.afrozaar.util:util-test][relativePath:util-test]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@2ed7e461[Baobab-meta Shared/com.afrozaar.ashes.module:ashes-modules][Baobab-meta Shared/com.afrozaar.ashes.module:ashes-modules][relativePath:modules]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@43bee109[Baobab Module - Content API]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `Baobab-core kmi #159`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModuleSet@6f48158a[Baobab Module - S3 Common]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@5149678c[Baobab-web Package for Release 4.21/com.afrozaar.ashes:ashes-web-pom][Baobab-web Package for Release 4.21/com.afrozaar.ashes:ashes-web-pom][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@2c9f0659[Baobab-meta Extractor JSON V3]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@979a3b0[Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-extractor-json-v2][Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-extractor-json-v2][relativePath:ashes-extractor-json-v2]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@73bab570[Sonar - Baobab Module - Polopoly/com.afrozaar.ashes.module:ashes-polopoly][Sonar - Baobab Module - Polopoly/com.afrozaar.ashes.module:ashes-polopoly][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@333639fa[Sonar - Baobab Module - Wordpress/com.afrozaar.ashes.module:ashes-wordpress][Sonar - Baobab Module - Wordpress/com.afrozaar.ashes.module:ashes-wordpress][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@44b78e67[Content API - Client/com.afrozaar.ashes.content:ashes-content-api-client][Content API - Client/com.afrozaar.ashes.content:ashes-content-api-client][relativePath:client]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@7afff82b[Baobab-web Pom]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@401b0ecd[Baobab Module - Search Extractor/com.afrozaar.ashes.module:ashes-search-extractor][Baobab Module - Search Extractor/com.afrozaar.ashes.module:ashes-search-extractor][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@4644ebc[Baobab-meta Test/com.afrozaar.ashes.module:ashes-modules][Baobab-meta Test/com.afrozaar.ashes.module:ashes-modules][relativePath:modules]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@d0453dd[Baobab-core UserPreferences API Rest]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@5384fd5d[Baobab-web Package for Release 4.10/promotion/Deploy to INM]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@ddb6704[Baobab-meta Test]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@1782799[Baobab-web Package for Release 4.21/com.afrozaar.ashes:ashes-web][Baobab-web Package for Release 4.21/com.afrozaar.ashes:ashes-web][relativePath:web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@55d90738[Baobab-support Package for Release 4.21/promotion/Deploy to ANA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@17d2d533[Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-common-model-v0][Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-common-model-v0][relativePath:ashes-common-model-v0]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@677eb196[Baobab-support Deploy to Local Tomcat]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-core model #433`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@4cf1be00[Baobab-meta Test/com.afrozaar.ashes:ashes-test][Baobab-meta Test/com.afrozaar.ashes:ashes-test][relativePath:ashes-test]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@63a72555[Baobab Module - Scheduler]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab Module - Reuters #32`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@6f1ecdeb[Baobab-meta ModuleFramework/com.afrozaar.ashes.support:ashes-support-management-web][Baobab-meta ModuleFramework/com.afrozaar.ashes.support:ashes-support-management-web][relativePath:ashes-support-management-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@3b2f39d8[Baobab Module - Social Common/com.afrozaar.ashes.module:ashes-social-common][Baobab Module - Social Common/com.afrozaar.ashes.module:ashes-social-common][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@262864d0[Baobab-support Package for Release 4.14/promotion/Deploy to CAX]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab Module - Facebook Extractor #39`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@16718c8b[Baobab-web Package for Release 4.17/com.afrozaar.ashes:ashes-deploy-web][Baobab-web Package for Release 4.17/com.afrozaar.ashes:ashes-deploy-web][relativePath:deploy-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@73c6353c[Polopoly Service/com.afrozaar.polopoly:polopoly-service][Polopoly Service/com.afrozaar.polopoly:polopoly-service][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@38b367b4[Sonar - Baobab Module - Scheduled Jobs/com.afrozaar.ashes.module:ashes-scheduled-jobs][Sonar - Baobab Module - Scheduled Jobs/com.afrozaar.ashes.module:ashes-scheduled-jobs][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab Module - Daily Mail #19`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@2af2b1fb[Baobab-web Deploy to Local Tomcat/com.afrozaar.ashes:ashes-deploy-web][Baobab-web Deploy to Local Tomcat/com.afrozaar.ashes:ashes-deploy-web][relativePath:deploy-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@4875ff78[Baobab-core Content API Rest/ashes-content-api:ashes-content-api-rest][Baobab-core Content API Rest/ashes-content-api:ashes-content-api-rest][relativePath:rest]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@65930682[Sonar - Baobab Module - Content API]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModuleSet@32e015f6[module-]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@1f39e022[Baobab-core interface/com.afrozaar.ashes:ashes-core-pom][Baobab-core interface/com.afrozaar.ashes:ashes-core-pom][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@26f5f9e9[Baboab Module - Sessions Tasks/com.afrozaar.ashes.module:ashes-sessions-tasks][Baboab Module - Sessions Tasks/com.afrozaar.ashes.module:ashes-sessions-tasks][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@6ef305ee[util-exiftool/com.afrozaar.util:util-exiftool][util-exiftool/com.afrozaar.util:util-exiftool][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@6b0f7412[Baobab-support Package for Release 4.13/promotion/Deploy to CAX]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@cd96fc6[Baobab-web Package for Release 4.15/promotion/Deploy to CAXTON]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@552c4e0d[Baobab Module - Loremipsum/com.afrozaar.ashes.module:ashes-loremipsum][Baobab Module - Loremipsum/com.afrozaar.ashes.module:ashes-loremipsum][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@26d5e5f7[Baobab Module - Tag Filter]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@308febab[Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-server][Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-server][relativePath:ashes-server]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@f612c44[Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-extractor-json-v2][Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-extractor-json-v2][relativePath:ashes-extractor-json-v2]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@5bddfcf7[Baobab-support Package for Release 4.14/promotion/Deploy to ANA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `com.cloudbees.plugins.flow.BuildFlow@389e7bb5[Flow Baobab Core 0]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@34d513f9[Baobab Module - Prestige/com.afrozaar.ashes.module:ashes-prestige][Baobab Module - Prestige/com.afrozaar.ashes.module:ashes-prestige][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@32aaa185[module-auto-publish]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@234b187a[Baobab Module - Ion Ingestor/com.afrozaar.ashes.module.ingestor:ashes-ion-ingestor][Baobab Module - Ion Ingestor/com.afrozaar.ashes.module.ingestor:ashes-ion-ingestor][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@63759c40[Baobab-support Package for Release 4.10/promotion/Deploy to INM]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@d86b6b0[util-graphicsmagick]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@1ad669b[Baobab-web Package for Release 4.14/promotion/Deploy to CAXTON]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@3f37d80e[Baobab-web Package for Release 4.17/com.afrozaar.ashes:ashes-web][Baobab-web Package for Release 4.17/com.afrozaar.ashes:ashes-web][relativePath:web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@2ce947d6[Baobab Module - Push Notifications/com.afrozaar.ashes.module:ashes-rossiya][Baobab Module - Push Notifications/com.afrozaar.ashes.module:ashes-rossiya][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@28355b65[Baobab-web Package for Release 4.13/promotion/Deploy to ANA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@25736e23[Baobab-web Package for Release Develop/promotion/Deploy to CAXTON]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@2ed8658d[util-java/com.afrozaar.util:util-ringfence-on][util-java/com.afrozaar.util:util-ringfence-on][relativePath:util-ringfence-on]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@224d3d18[Sonar - Baobab Module - Independent/com.afrozaar.ashes.module:ashes-independent][Sonar - Baobab Module - Independent/com.afrozaar.ashes.module:ashes-independent][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@220b8953[Baobab Module - IndependentUK]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `Baobab-web Package for Release 4.14 #6`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModuleSet@51cf6292[Baobab-support IT]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@76c4819a[Baobab-core IT]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@65ec2ab2[Baobab-support Package for Release 4.13/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@1a62e503[Baobab-core UserPreferences API Rest/com.afrozaar.ashes.service:user-preferences-rest][Baobab-core UserPreferences API Rest/com.afrozaar.ashes.service:user-preferences-rest][relativePath:rest]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@55f163d[Baobab Module - SBP Publish/com.afrozaar.ashes.module:ashes-sbp-publish][Baobab Module - SBP Publish/com.afrozaar.ashes.module:ashes-sbp-publish][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@5a34d551[Sonar - Baobab Module - Prestige/com.afrozaar.ashes.module:ashes-prestige][Sonar - Baobab Module - Prestige/com.afrozaar.ashes.module:ashes-prestige][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@4ed055b6[Baobab-meta ashes-support-dto]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@17577f[Baobab-web Package for Release 4.13/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@1ff9e088[Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-extractor-json-v1][Baobab-meta ModuleFramework/com.afrozaar.ashes:ashes-extractor-json-v1][relativePath:ashes-extractor-json-v1]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@180a6b78[Sonar - Baobab Module - Scheduled Jobs]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@75220657[Baobab-web Package for Release 4.14]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModuleSet@513c4245[Baobab Module - Wordpress Ingest]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModuleSet@50cab7b3[Baobab-meta Common Model V1]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@23b548cc[MWeb/promotion/ANA Test]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@7bf53c8e[Baobab Module - Webhook Extractor/com.afrozaar.ashes.module:ashes-webhook-extractor][Baobab Module - Webhook Extractor/com.afrozaar.ashes.module:ashes-webhook-extractor][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@2bce8cb2[Baobab Module - Ion Ingestor]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModule@37c4403[Baobab-support Package for Release 4.9/com.afrozaar.ashes:ashes-support-deploy][Baobab-support Package for Release 4.9/com.afrozaar.ashes:ashes-support-deploy][relativePath:support-deploy]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@1949eac9[Baobab-meta module-parent/com.afrozaar.util:baobab-meta][Baobab-meta module-parent/com.afrozaar.util:baobab-meta][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@1c63c3e0[Baobab-web Package for Release 4.15/promotion/Deploy to ANA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@89a8b1e[util-java/com.afrozaar.util:util-ringfence-off][util-java/com.afrozaar.util:util-ringfence-off][relativePath:util-ringfence-off]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@69f09675[Baobab-core Content API Rest]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@3b7a14fd[Baobab-web Package for Release 4.16/promotion/Deploy to INM]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@39af8623[Baobab-meta Shared/com.afrozaar.ashes:ashes-support-dto][Baobab-meta Shared/com.afrozaar.ashes:ashes-support-dto][relativePath:ashes-support-dto]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@34fa9777[Baobab-web Package for Release 4.16/com.afrozaar.ashes:ashes-web-pom][Baobab-web Package for Release 4.16/com.afrozaar.ashes:ashes-web-pom][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@1a3315a2[util-flyway/com.afrozaar.util:util-flyway][util-flyway/com.afrozaar.util:util-flyway][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@228cc915[Baobab-web Package for Release 4.10]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@26741fc[Baobab-support Package for Release 4.10/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@26a1953d[baobab-aws-lambdas]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@203d1fa1[Baobab-web Server/com.afrozaar.ashes:ashes-web][Baobab-web Server/com.afrozaar.ashes:ashes-web][relativePath:web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab Module - Prestige #32`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@3a81991c[Baobab-meta ashes-support-dto/com.afrozaar.ashes.support:ashes-support-management-web][Baobab-meta ashes-support-dto/com.afrozaar.ashes.support:ashes-support-management-web][relativePath:ashes-support-management-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@87d63dd[Baobab-meta Test/com.afrozaar.ashes:ashes-extractor-json-v3][Baobab-meta Test/com.afrozaar.ashes:ashes-extractor-json-v3][relativePath:ashes-extractor-json-v3]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@64edfb4c[Content API - Client/com.afrozaar.ashes.content-api:ashes-content-api-client][Content API - Client/com.afrozaar.ashes.content-api:ashes-content-api-client][relativePath:client]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@202be38a[Baobab-support Package for Release 4.10/promotion/Deploy to ANA]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@6b32c490[Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-common-model-v1][Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-common-model-v1][relativePath:ashes-common-model-v1]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@7d5a12fe[Sonar - Baobab Module - S3 Common]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@e1981bc[Baobab-support Package for Release 4.9]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@4e07749[Baobab-support Package for Release Develop/promotion/Deploy to INM]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@7db45a1e[Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-common-model-v0][Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-common-model-v0][relativePath:ashes-common-model-v0]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@5c6da7c1[Video Service]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@298e6a3c[Baobab-web Package for Release 4.13/promotion/Deploy to CAXTON]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@52bb9509[Baobab-web Package for Release 4.15/promotion/Deploy to INM]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.model.FreeStyleProject@708e4f3d[Deploy Support]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'
  * Problematic object: `hudson.maven.MavenModuleSet@1c053bb1[Baobab Module - SBP-Scheduled]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@4c9d77e[Sonar - Baobab Module - Daily Mail/com.afrozaar.ashes.module:ashes-daily-mail][Sonar - Baobab Module - Daily Mail/com.afrozaar.ashes.module:ashes-daily-mail][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@291e82a4[Baobab Module - Wordpress/com.afrozaar.ashes.module:ashes-wordpress][Baobab Module - Wordpress/com.afrozaar.ashes.module:ashes-wordpress][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@111d82a0[Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-subscriptions][Baobab-meta ashes-support-dto/com.afrozaar.ashes:ashes-subscriptions][relativePath:ashes-subscriptions]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@616be6aa[Baobab-core interface/com.afrozaar.ashes:ashes-kernel][Baobab-core interface/com.afrozaar.ashes:ashes-kernel][relativePath:kernel]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@3cc0ff02[Support Module - Baobab Authenticator]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@64903f55[Baobab-support Package for Release 4.17/promotion/Deploy to INM]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@3c2fcfe9[Baobab-web Server/com.afrozaar.ashes:ashes-deploy-web][Baobab-web Server/com.afrozaar.ashes:ashes-deploy-web][relativePath:deploy-web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@3f0e94c9[Sonar - Baobab Module - Content API/com.afrozaar.ashes.content:ashes-content-api-core][Sonar - Baobab Module - Content API/com.afrozaar.ashes.content:ashes-content-api-core][relativePath:core]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@a407987[Baobab-web Package for Release 4.15/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@34ff6b38[Video Service/com.afrozaar.service:video-service][Video Service/com.afrozaar.service:video-service][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@6e65d2f[Baobab-web Package for Release 4.21/promotion/Deploy to AZ]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@2a8fc543[Baobab-meta Shared/com.afrozaar.ashes:ashes-extractor-json-v2][Baobab-meta Shared/com.afrozaar.ashes:ashes-extractor-json-v2][relativePath:ashes-extractor-json-v2]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@451e5ecd[Baobab-web Server/com.afrozaar.util:ashes-web-server][Baobab-web Server/com.afrozaar.util:ashes-web-server][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.plugins.promoted_builds.PromotionProcess@4ab32d60[Baobab-support Package for Release 4.16/promotion/Deploy to SBP]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@51522c1[Baobab Module - SBP/com.afrozaar.ashes.module:ashes-sbp][Baobab Module - SBP/com.afrozaar.ashes.module:ashes-sbp][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@36ecb534[Baobab Module - Service/com.afrozaar.ashes.module:ashes-service][Baobab Module - Service/com.afrozaar.ashes.module:ashes-service][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@104e3393[Baobab Module - Baboab to Baobab Ingestor/com.afrozaar.ashes.module:ashes-inter-baobab-ingestor][Baobab Module - Baboab to Baobab Ingestor/com.afrozaar.ashes.module:ashes-inter-baobab-ingestor][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@70093bd4[Baobab-meta Test/com.afrozaar.ashes:ashes-shared][Baobab-meta Test/com.afrozaar.ashes:ashes-shared][relativePath:ashes-shared]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@2d3116ef[Support Module - Peaches]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@7f05b0db[Baobab-meta ashes-support-dto/com.afrozaar.ashes.module:ashes-modules][Baobab-meta ashes-support-dto/com.afrozaar.ashes.module:ashes-modules][relativePath:modules]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@9a59e45[Baobab Module - Polopoly/com.afrozaar.ashes.module:ashes-polopoly][Baobab Module - Polopoly/com.afrozaar.ashes.module:ashes-polopoly][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-core Content API Rest #57`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@48fadf1b[Sonar - Video Service/com.afrozaar.service:video-service][Sonar - Video Service/com.afrozaar.service:video-service][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@55095ee8[Baobab-web Web GWT 2.8/com.afrozaar.ashes:ashes-web][Baobab-web Web GWT 2.8/com.afrozaar.ashes:ashes-web][relativePath:web]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@12fe651d[Baobab Module - Test/com.afrozaar.ashes.module:ashes-test-module][Baobab Module - Test/com.afrozaar.ashes.module:ashes-test-module][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-meta ashes-support-dto #15`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@6e6e103[util-java/com.afrozaar.util:util-graphicsmagick][util-java/com.afrozaar.util:util-graphicsmagick][relativePath:util-graphicsmagick]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@27cf5c29[Baobab-meta Test/com.afrozaar.ashes.module:ashes-module-framework][Baobab-meta Test/com.afrozaar.ashes.module:ashes-module-framework][relativePath:modules/framework]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@7071eb96[Baobab-support IT/com.afrozaar.ashes:ashes-support][Baobab-support IT/com.afrozaar.ashes:ashes-support][relativePath:support]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@64a1c349[Baobab-meta Extractor JSON V2/com.afrozaar.ashes:ashes-extractor-json-v2][Baobab-meta Extractor JSON V2/com.afrozaar.ashes:ashes-extractor-json-v2][relativePath:ashes-extractor-json-v2]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@682233ca[Sonar - Baobab Module - Content API/com.afrozaar.ashes.module:ashes-content-api-core][Sonar - Baobab Module - Content API/com.afrozaar.ashes.module:ashes-content-api-core][relativePath:core]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@203a87d6[util-java/com.afrozaar.util:build-all][util-java/com.afrozaar.util:build-all][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@6598fe75[Sonar - Baobab Module - Scheduler/com.afrozaar.ashes.module:ashes-scheduler][Sonar - Baobab Module - Scheduler/com.afrozaar.ashes.module:ashes-scheduler][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@a1f09f2[Baobab Module - Wordpress Ingest/com.afrozaar.ashes.module:ashes-wordpress-ingest][Baobab Module - Wordpress Ingest/com.afrozaar.ashes.module:ashes-wordpress-ingest][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `Baobab-core kmi #160`
    - CannotResolveClassException: hudson.plugins.jira.JiraIssue, CannotResolveClassException: hudson.plugins.jira.JiraIssue
  * Problematic object: `hudson.maven.MavenModule@5d844275[Baobab-core kernel/com.afrozaar.ashes:ashes-interface][Baobab-core kernel/com.afrozaar.ashes:ashes-interface][relativePath:interface]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModule@2d01a6f5[Baobab Module - SP - Free Trial/com.afrozaar.ashes.module:ashes-free-trial-sp][Baobab Module - SP - Free Trial/com.afrozaar.ashes.module:ashes-free-trial-sp][relativePath:]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@16231dda[Baobab-meta ModuleFramework]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty
  * Problematic object: `hudson.maven.MavenModuleSet@3f0bbcf5[Baobab Module - Wordpress]`
    - CannotResolveClassException: hudson.plugins.disk_usage.DiskUsageProperty, MissingFieldException: No field 'buildServerUrl' found in class 'jenkins.plugins.slack.SlackNotifier'

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)

`jenkins.security.s2m.MasterKillSwitchWarning`
--------------
(active and enabled)

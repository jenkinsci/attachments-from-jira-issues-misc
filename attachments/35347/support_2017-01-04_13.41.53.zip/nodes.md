Node statistics
===============

  * Total number of nodes
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of nodes online
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors in use
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/var/lib/jenkins`
      - Labels:         all
      - Usage:          `NORMAL`
      - Slave Version:  3.4
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_111
          + Maximum memory:   910.62 MB (954859520)
          + Allocated memory: 174.96 MB (183463936)
          + Free memory:      84.56 MB (88668704)
          + In-use memory:    90.40 MB (94795232)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.111-b15
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.4.19-29.55.amzn1.x86_64
      - Process ID: 4290 (0x10c2)
      - Process started: 2017-01-04 11:17:02.086+0000
      - Process uptime: 2 hr 24 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.111-1.b15.25.amzn1.x86_64/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
          + arg[1]: `-Djava.awt.headless=true`
          + arg[2]: `-Dorg.apache.commons.jelly.tags.fmt.timeZone=Africa/Johannesburg`
          + arg[3]: `-Xdebug`
          + arg[4]: `-Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=0`
          + arg[5]: `-DJENKINS_HOME=/var/lib/jenkins`

  * chuck-slave-1 (`hudson.slaves.DumbSlave`)
      - Description:    _On Afrozaar Network (on chuck)_
      - Executors:      2
      - Remote FS root: `/home/jenkins-cloud`
      - Labels:         slaves linux all
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        (timeout with no cache available)

  * chuck-slave-2 (`hudson.slaves.DumbSlave`)
      - Description:    _On Afrozaar Network (on chuck)_
      - Executors:      2
      - Remote FS root: `/home/jenkins`
      - Labels:         slaves linux all wordpress vagrant
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.57


Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * chuck-slave-1: Linux (amd64)
   * chuck-slave-2: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * chuck-slave-1: In sync
   * chuck-slave-2: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 8.331GB left on /var/lib/jenkins.
   * chuck-slave-1: Disk space is too low. Only 16.999GB left on /home/jenkins-cloud.
   * chuck-slave-2: Disk space is too low. Only 141.501GB left on /home/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:935/3767MB  Swap:0/0MB
   * chuck-slave-1: Memory:5673/9763MB  Swap:1939/2047MB
   * chuck-slave-2: Memory:8632/9761MB  Swap:2019/2045MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 8.331GB left on /tmp.
   * chuck-slave-1: Disk space is too low. Only 16.999GB left on /tmp.
   * chuck-slave-2: Disk space is too low. Only 141.501GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * chuck-slave-1: 2209ms
   * chuck-slave-2: 2207ms

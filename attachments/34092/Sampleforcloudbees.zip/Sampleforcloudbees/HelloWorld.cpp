#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>


int main()
{
  std::cout << "Hello World!\n";
  kill(getpid(), SIGINT);
}
#!/usr/bin/python

import os, sys
import scandump
import argparse
import ntpath
import posixpath

from configuration import ConfigurationParser

class MemoryScannerWrapper:

    def __init__(self, configuration):
        """
        configuration - The configuration used to control the tests.
        """
        self.executableFilename = configuration.filename
        self.isRunning = configuration.isRunning
        self.verbose = configuration.verbose
        self.arguments = configuration.testArgument
        self.terminateProcess = configuration.terminate
        self.platform = configuration.platform
        self.projectDir = configuration.projectdir
        self.appdir = configuration.appdir
        self.deviceid = configuration.deviceid
        self.devicetype = configuration.devicetype
        self.sdkversion = configuration.sdkversion
        self.envVars = configuration.envVars

    # The prefix for executing a specific test.
    def addArguments(self, test_case):
        if self.arguments is None:
            testargs = str("--gtest_filter=" + test_case)
        else:
            testargs = str(self.arguments + " " + "--gtest_filter=" + test_case)
            #allow substitution of the placeholder {$CWD} with the current working dir
            #to allow the log file to be correctly configured as an argument on iOS
            testargs = testargs.replace("{$CWD}", os.getcwd())
        
        return testargs

    # Get the filename for a dump file given a test name.
    def generateMemoryDmpFileName(self, testCaseName):
        name = testCaseName.replace(".", "_")
        # Set file name based on target platform not Host OS.
        if self.platform == "windows":
            name = str("windbgdump_" + name + ".dmp")
        elif self.platform == "osx":
            name = str("lldbdump_" + name + ".core")
        elif self.platform == "android":
            name = str("gdbdump_" + name + ".core")
        elif self.platform == "ios" or self.platform == "iossim":
            name = str("lldbdump_" + name + ".core")

        return name

    def generateMemoryDmpFilePath(self, testCase):
        if self.platform == "android":
            # Android requires the projectdir to be prepended.
            dmpFile = os.path.abspath(self.projectDir + "/"
                                      + self.generateMemoryDmpFileName(testCase.name))
        else:
            dmpFile = self.generateMemoryDmpFileName(testCase.name)
        
        return dmpFile
        
    # Get the filename for a results file given a test name.
    def generateResultFileName(self, testCaseName):
        name = testCaseName.replace(".", "_")
        # Set file name based on target platform not Host OS.
        if self.platform == "windows":
            name = str("windows-gtest-results_" + name + ".xml")
        elif self.platform == "osx":
            name = str("osx-gtest-results_" + name + ".xml")
        elif self.platform == "android":
            name = str("android-gtest-results_" + name + ".xml")
        elif self.platform == "ios":
            name = str("ios-gtest-results_" + name + ".xml")
        elif self.platform == "iossim":
            name = str("iossim-gtest-results_" + name + ".xml")

        return name
        
    # The prefix for sending output to a specific file.
    # Only expected to be called for Android and iOS.
    def addResultFileArgument(self, testCaseName):
        name = self.generateResultFileName(testCaseName)

        # Set path based on platform not host OS.
        if self.platform == "windows":
            dest = ntpath.abspath(self.appdir + "/" + name)
        else:
            dest = posixpath.abspath(self.appdir + "/" + name)

        if self.arguments is None:
            testargs = str("--gtest_output=xml:" + dest)
        else:
            testargs = str(self.arguments + " " + "--gtest_output=xml:" + dest)
        
        return testargs

    # Execute the test case and generate a dump file at the point of the
    # execution break. Debugger-specific imports have been moved to this method
    # since they depend on the platform command-line argument which is no longer
    # known in the global scope.
    def createMemoryDmpFile(self, testCase):
        """
        Creates a memory dmp file for a test executable & filter for all supported platforms.
        """
        if self.platform == "windows":
            import winDbgProcessDump as processDump
            DbgExec = processDump.WinDbgExecution(self.executableFilename,
                                                  [self.addArguments(testCase.name)],
                                                  self.generateMemoryDmpFileName(testCase.name),
                                                  self.terminateProcess)
        elif self.platform == "osx":
            import lldbProcessDump as processDump
            DbgExec = processDump.LldbExecutor(self.executableFilename,
                                               self.addArguments(testCase.name),
                                               self.generateMemoryDmpFileName(testCase.name),
                                               self.terminateProcess, 
                                               self.envVars)
        elif self.platform == "android":
            import gdbProcessDump as processDump
            DbgExec = processDump.GdbExecutor(self.executableFilename,
                                              [self.addResultFileArgument(testCase.name),
                                              self.addArguments(testCase.name)],
                                              self.generateMemoryDmpFileName(testCase.name),
                                              self.terminateProcess,
                                              self.verbose,
                                              self.projectDir,
                                              self.deviceid)
        elif self.platform == "ios" or self.platform == "iossim":
            import iosProcessDump as processDump
            DbgExec = processDump.IosExecutor(self.executableFilename,
                                              [self.addArguments(testCase.name)],
                                              self.generateMemoryDmpFileName(testCase.name),
                                              self.terminateProcess,
                                              self.platform,
                                              self.verbose,
                                              self.sdkversion,
                                              self.devicetype)
        if self.isRunning:
            DbgExec.dumpProcessAndDetach()
        else:
            DbgExec.run()

    # Scan the dump file generated for a particular string.
    def scanMemoryDmpFiles(self, testCase):
        """
        Scans all dmp files in the current directory for a given secret.
        """
        dmpFile = self.generateMemoryDmpFilePath(testCase)
        
        scanner = scandump.Scanner(dmpFile, self.verbose)
        occurrences = scanner.scan(testCase.secret)
        scanner.print_matches()

        return occurrences

    def analyseAllTestCases(self, testCasesList):
        for testCase in testCasesList:
            expectedOccurrences = testCase.expectedOccurrences

            # If there is a dependency on another test case.
            if testCase.useResultFrom != "":
                # Search through all the test cases.
                for dependantTestCase in testCasesList:
                    if testCase.useResultFrom == dependantTestCase.name:
                        # Run that test case first.
                        self.analyseTestCase(dependantTestCase)
                        # Then get the result from it as the current expected result.
                        testCase.expectedOccurrences = dependantTestCase.actualOccurrences
            
            self.analyseTestCase(testCase)

    def analyseTestCase(self, testCase):
        # Don't run the same test case twice.
        if testCase.completed == True:
            return

        print "\n*--------------------- Analysing Dump File ---------------------*"
        print "\t\t" + testCase.name + "\n"
        print "\t\t" + "Secret=" + testCase.secret
        print "\t\t" + "Expected Occurrences=" + str(testCase.expectedOccurrences) + "\n"
        testCase.actualOccurrences = self.scanMemoryDmpFiles(testCase)
        
        if testCase.expectedOccurrences == None and testCase.maxExpectedOccurrences == None:
            testCase.isSuccess = True
        if testCase.actualOccurrences == testCase.expectedOccurrences:
            testCase.isSuccess = True
        if testCase.actualOccurrences <= testCase.maxExpectedOccurrences:
            testCase.isSuccess = True
        
        testCase.completed = True

    def deleteAllSuccessfulTestCaseDumps(self, testCasesList):
        # Scan all the test cases for success, delete their dumps if found.
        for testCase in testCasesList:
            self.deleteTestCaseDumpIfSuccessful(testCase)
        
    def deleteTestCaseDumpIfSuccessful(self, testCase):
        # Delete the dump file associated with a test case if found, only if the test was successful.
        
        dmpFile = self.generateMemoryDmpFilePath(testCase)
        
        if testCase.isSuccess :
            if os.path.exists(dmpFile):
                os.remove(dmpFile)
                print "Deleted File... " + dmpFile
            else:
                print "Tried to delete core dump, but could not find it... " + dmpFile     
        else :
            print "Do not Delete File for failed Test... " + dmpFile
            
# ------------------------------------ 
# main 

def createJUnitResult(testCasesList, filename="executeMemoryScannerResults.xml") :
    """
    Create a the simplest possible results file readable by jenkins,
    without importing additional libraries.
    """
    output = "<testsuite tests=\"" + str(len(testCasesList)) + "\">\n"
    for testCase in testCasesList:
        
        if len(testCase.name.split('.')) == 2 :
            testCaseClass = testCase.name.split('.')[0] + "_MEMORYSCAN"
            testCaseName = testCase.name.split('.')[1]
        else :
            testCaseClass = testCase.name
            testCaseName = testCase.name
        
        if testCase.expectedOccurrences == None and testCase.maxExpectedOccurrences == None:
            output += '<testcase classname="' + testCaseClass + '" name="' + testCaseName + '">\n' \
                        '  <skipped/>\n' \
                        '</testcase>\n'
        elif testCase.isSuccess == True:
            output += '<testcase classname="' + testCaseClass + '" name="' + testCaseName + '"/>\n'
        else:
            output +=   '<testcase classname="' + testCaseClass + '" name="' + testCaseName + '">\n' \
                            '  <failure type="Failure">\n' \
                            '    secret:' + str(testCase.secret) + '\n'\
                            '    expectedOccurrences:' + str(testCase.expectedOccurrences) + '\n'\
                            '    actualOccurrences:' + str(testCase.actualOccurrences) + '\n'\
                            '  </failure>\n' \
                        '</testcase>\n'
    output += "</testsuite>"
    
    resultFile = open(filename, 'w')
    resultFile.write(output)
    resultFile.close()

def parseArguments():    
    """
    New parser code added to support --platform switch.

    Parser requires the XML configuration file as the first positional argument.
    Result file can either be the second positional argument,
    or specified with the -r/--result switch.
    
    -h/--help will show usage.
    -p/--platform optionally specifies the platform under test.
    """
    parser = argparse.ArgumentParser(description="Memory Scanner Tool",
                                     epilog="Note: Use only one method of specifying the XML \
                                     results file. Specifying both will cause an error.")
    parser.add_argument("-p", "--platform",
                        help="Destination platform {android,windows,osx,ios}",
                        metavar="PLATFORM",
                        choices=["android","windows","osx","ios","iossim"])
    parser.add_argument("configfile",
                        help="XML configuration file, e.g. configurationFile.xml")
    parser.add_argument("-d","--projectdir",
                        help="Android project directory",
                        metavar="DIRECTORY", default=None)
    parser.add_argument("-a","--appdir",
                        help="Android application directory",
                        default=None)
    parser.add_argument("-i","--deviceid",
                        help="Target Android device ID (emulator, device, or serial number)",
                        default=None)
    parser.add_argument("-s","--sdkversion",
                        help="Target iOS SDK version, e.g. '9.0'",
                        metavar="VERSION", default=None)
    parser.add_argument("-t","--devicetype",
                        help="Target iOS device type, e.g. 'iPhone 6'",
                        default=None)
    parser.add_argument("-z","--alwaysReturnZero",
                        action='store_true',
                        default=False, 
                        help="Return a zero exit code, regardless of test failure.")
    parser.add_argument("-x","--removeDumpsForSuccessfulTests",
                        action='store_true',
                        default=False, 
                        help="If a test is successful delete the dump file after memory analysis (saves space).")
    parser.add_argument("-y","--analyzeImmediately",
                        action='store_true',
                        default=False, 
                        help="Analyze core dumps immediately after a test finishes, instead of analyzing them all at the end.")
    parser.add_argument("-e", "--envVars", 
                        default=None, 
                        help="Set environment variables that last for the lifetime of the process being debugged. OSX Only.")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("-r", "--result",
                        help="XML results file, e.g. executeMemoryScannerResults.xml",
                        dest="resultfile", metavar="FILENAME")
    group.add_argument("resultfile",
                        help="XML results file, e.g. executeMemoryScannerResults.xml",
                        nargs="?", default=None)

    args = parser.parse_args()
    
    # If platform wasn't passed in, assume we want to run the tests on the same
    # platform as the script. This logic is here for legacy calls that don't use
    # the new command-line method of specifying the platform.
    if (args.platform) is None:
        if os.name == "nt":
            args.platform = "windows"
        elif os.name == "posix":
            args.platform = "osx"

    if args.platform == "android":
        if args.projectdir is None:
            print ("Error: Android platform requires specification of a project directory.")
            sys.exit(1)
        else:
            args.projectdir = os.path.abspath(args.projectdir)
    
    if args.platform == "android":
        if args.appdir is None:
            if os.environ.get("APPDIR") is None:
                print ("Error: Android platform requires specification of application directory.")
                sys.exit(1)
            else:
                # Our internal appdir mus match the APPDIR environment variable for Google Test.
                args.appdir = os.environ.get("APPDIR")
        else:
            # Google Test expects APPDIR environment variable to be set.
            os.environ["APPDIR"] = args.appdir
    
    return args

def runAllThenAnalyzeAll(configuration):
    # Run all the tests and save each dump.
    # Analyze all the dumps.
    # If the removeDumpsForSuccessfulTests switch is set, remove all dumps from successful tests.

    memoryScannerWrapper = MemoryScannerWrapper(configuration)

    # First we will execute all test cases, creating a dump file at the break
    # execution instruction in each.
    for testCase in configuration.testCasesList:
        print "\n*--------------------- Executing Process ---------------------*"
        print "\t\t" + testCase.name + "\n"
        try :
            memoryScannerWrapper.createMemoryDmpFile(testCase)
        except Exception as e:
            # The above line throws an exception, continue on
            print "\n*--------------------- DUMP CREATION FAILED! ---------------------*"
            print e
            print "\n*--------------------- DUMP CREATION FAILED! ---------------------*"          
            
    # Next, we will search each test case for a given string / secret.
    memoryScannerWrapper.analyseAllTestCases(configuration.testCasesList)
    
    if (configuration.removeDumpsForSuccessfulTests) :
        memoryScannerWrapper.deleteAllSuccessfulTestCaseDumps(configuration.testCasesList)
    
def runOneThenAnalyzeAndRepeat(configuration):
    # Run an individual test, then analyze the dump immediately. 
    # If the removeDumpsForSuccessfulTests switch is set, remove the dump if the test was successful.
    # Then repeat the above for all the other tests.
    
    memoryScannerWrapper = MemoryScannerWrapper(configuration)

    # First we will execute all test cases, creating a dump file at the break
    # execution instruction in each.
    for testCase in configuration.testCasesList:
        print "\n*--------------------- Executing Process ---------------------*"
        print "\t\t" + testCase.name + "\n"
        try :
            memoryScannerWrapper.createMemoryDmpFile(testCase)
        except Exception as e:
            # The above line throws an exception, continue on
            print "\n*--------------------- DUMP CREATION FAILED! ---------------------*"
            print e
            print "\n*--------------------- DUMP CREATION FAILED! ---------------------*"          
            
        # Next, we will search each test case for a given string / secret.
        memoryScannerWrapper.analyseTestCase(testCase)
        
        if (configuration.removeDumpsForSuccessfulTests) :
            memoryScannerWrapper.deleteTestCaseDumpIfSuccessful(testCase)

def main():
    # Call new argument parser.
    options = parseArguments()
    print "Memory Scanner Tool"
    print "Selected Platform: %s" % options.platform
    # This variable will determine if the run was completely successful, if it
    # wasn't then we will return a non zero return code indicating a failure on
    # Jenkins.
    successfulRun = True

    # Send the configfile argument to the parser treating it as filename
    # that has an XML document.
    configurationParser = ConfigurationParser(options.configfile)
    try:
        configuration = configurationParser.parseConfiguration()
    except:
        successfulRun = False
        print ("Error: Configuration file could not be read.")
        return successfulRun

    if options.platform == "android":
        print "Android Project Directory: %s" % options.projectdir

    # MemoryScannerWrapper class needs to know these arguments, so add them to
    # configuration.
    configuration.projectdir = options.projectdir
    configuration.platform = options.platform
    configuration.appdir = options.appdir
    configuration.deviceid = options.deviceid
    configuration.devicetype = options.devicetype
    configuration.sdkversion = options.sdkversion
    configuration.removeDumpsForSuccessfulTests = options.removeDumpsForSuccessfulTests
    configuration.envVars = options.envVars

    if options.analyzeImmediately :
        runOneThenAnalyzeAndRepeat(configuration)
    else :
        runAllThenAnalyzeAll(configuration)
    
    # Finally, display the results.
    print "\n*--------------------- Results ---------------------*\n"

    for testCase in configuration.testCasesList:
        if testCase.expectedOccurrences == None and testCase.maxExpectedOccurrences == None:
            print "Test Case " + testCase.name + ": Result ignored."
        elif testCase.isSuccess == True:
            print "Test Case " + testCase.name + ": SUCCESS."
        else:
            print "Test Case " + testCase.name + ": FAILED."
            successfulRun = False

    print "\n"

    # Create a JUnit style report, use the resultfile argument if available.
    if options.resultfile is None:
        createJUnitResult(configuration.testCasesList)
    else:
        createJUnitResult(configuration.testCasesList, options.resultfile)

    if options.alwaysReturnZero :
        return True 
    else :
        return successfulRun

if __name__ == "__main__":
    if main():
        os._exit(0)

    os._exit(1)
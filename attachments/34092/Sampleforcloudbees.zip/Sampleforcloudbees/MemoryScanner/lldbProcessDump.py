#!/usr/bin/python

import os
import sys
import subprocess

# Specify location of the lldb module (or add this to PYTHONPATH environment variable)
python_path_to_lldb = '/Applications/Xcode.app/Contents/SharedFrameworks/LLDB.framework/Resources/Python'
sys.path.append(python_path_to_lldb)
import lldb

class LldbExecutor:
    def __init__(self, executable, arguments, core_file_name, terminate_process, env_vars):
        """
        executable - The executable file of the process under debug
        arguments - The argv array for the process under debug
        core_file_name - The name of the core file to generate
        """
        self.executable = executable
        
        # arguments is a single string that represents all args.  Make a list of strings.
        # Assume there is at least one argument, of the form --gtest_filter="testname"
        self.argv = arguments.split(' ') 

        # env_vars is a single string that represents all vars.  Make a list of strings.
        self.env_vars = env_vars.split(' ') if env_vars else [] 
        
        self.core_file_name = core_file_name
        self.terminate = terminate_process
        print 'LldbExecutor: module lldb version:', lldb.SBDebugger.GetVersionString()
        self.lldb_debugger = lldb.SBDebugger().Create()
        self.lldb_debugger.SetAsync(False)
        self.lldb_target = self._create_target()

    def _create_target(self):
        """
        Creates a debugger target and starts it running in the debugger,
        and expects to regain control when a breakpoint occurs.
        """
        # Create the target.  Accept either 64-bit or 32-bit, preferring 64.
        lldb_target = self.lldb_debugger.CreateTargetWithFileAndArch(self.executable, lldb.LLDB_ARCH_DEFAULT_64BIT)
        if lldb_target:
            print 'LldbExecutor: Created lldb target with LLDB_ARCH_DEFAULT_64BIT'
        else:
            lldb_target = self.lldb_debugger.CreateTargetWithFileAndArch(self.executable, lldb.LLDB_ARCH_DEFAULT_32BIT)
            if lldb_target:
                print 'LldbExecutor: Created lldb target with LLDB_ARCH_DEFAULT_32BIT'
            else:
                raise Exception('LldbExecutor: Could not create lldb target for executable %s' % self.executable)

        return lldb_target

    def _start_process(self):
        # Launch the process in the debugger
        # main_bp = target.BreakpointCreateByName("main", target.GetExecutable().GetFilename())
        print self.executable, self.argv
        self.lldb_process = self.lldb_target.LaunchSimple(self.argv, self.env_vars, os.getcwd())       
        if not self.lldb_process:
            raise Exception('LldbExecutor: Could not launch debug process for target %s' % self.lldb_target)

        # Regain flow control here after debugger process hits a break
        process_under_debug_state = self.lldb_process.GetState() # StateType
        if process_under_debug_state == lldb.eStateExited:
            raise Exception('LldbExecutor: Expected to find debugger target process in state stopped, but process has exited.  Executable was %s and argument array was %s' %
                (self.executable, self.argv))
        elif process_under_debug_state != lldb.eStateStopped:
            state = self.lldb_debugger.StateAsCString(process_under_debug_state)
            raise Exception('LldbExecutor: Unexpected state for debugger target process: %s' % state)

        # Print stack trace seen in debugger
        self._print_stack_trace_for_selected_thread()
        # TODO: Consider verifying the bottom frame or two.  For tests using 
        # GTestHelpers::debugBreakTestExecution(), frame 0 is kill().

    def _attach_to_process(self):
        error = lldb.SBError()
        self.lldb_process = self.lldb_target.AttachToProcessWithID(lldb.SBListener(), self._get_process_id_from_name(self.lldb_target.GetExecutable().GetFilename()), error)
        if error.Fail():
            print "Unable to attach to process: " + error.GetCString()
            return False
        else:
            print "Successfully attached to process, current state: " + self.lldb_debugger.StateAsCString(self.lldb_process.GetState())
            self._print_stack_trace_for_all_threads()
            return True

    def _detach_from_process(self):
        self.lldb_process.Detach()

    def _print_stack_trace_for_selected_thread(self):
        "Prints the stack trace for the currently selected thread."
        selected_thread = self.lldb_process.GetSelectedThread()
        print 'LldbExecutor: Stack trace for currently selected thread: (%d)' % selected_thread.GetIndexID()
        for frame in selected_thread:
            print frame

    def _print_stack_trace_for_all_threads(self):
        "Prints the stack trace for all threads in the process."
        for thread in self.lldb_process:
            print 'LldbExecutor: Stack trace for thread: (%d)' % thread.GetIndexID()
            for frame in thread:
                print frame

    def _generate_core_file(self):
        """
        Generates a core file for the process running in the debugger.
        Module lldb does not directly support writing a core file, but it has
        HandleCommand() which is like typing into the lldb command line.
        """
        abs_core_file_path = os.path.abspath(self.core_file_name)
        print 'LldbExecutor: Will generate core file at', abs_core_file_path
        lldb_save_core_command = 'process save-core %s' % (self.core_file_name)
        lldb_command_return = lldb.SBCommandReturnObject()
        lldb_command_interpreter = self.lldb_debugger.GetCommandInterpreter()
        lldb_command_interpreter.HandleCommand(lldb_save_core_command, lldb_command_return)
        print 'LldbExecutor: command to save core file returns:', lldb_command_return
        if not lldb_command_return.Succeeded():
            raise Exception('Tried to save core file but lldb command did not succeed: %s' % (lldb_save_core_command))
        if not os.path.exists(abs_core_file_path):
            raise Exception('Tried to save core file but not found at path %s' % (abs_core_file_path))

    def _continue_process_to_completion(self):
        """
        Continues running a process that has stopped in the debugger, expecting
        it to exit cleanly.
        """
        while self.lldb_process.GetState() != lldb.eStateExited:
            print "Current state: " + self.lldb_debugger.StateAsCString(self.lldb_process.GetState()) + ", about to attempt to continue..."
            sberror = self.lldb_process.Continue() # SBError
            self._print_stack_trace_for_all_threads()

        # Capture the final stdout content from the process under debug, and its return value.
        remaining_stdout = self.lldb_process.GetSTDOUT(1000)
        print remaining_stdout
        exit_status = self.lldb_process.GetExitStatus()
        print 'LldbExecutor: Exit status from process under debug is', exit_status
        self.lldb_process.Destroy()

    def _terminateProcess(self):
        remaining_stdout = self.lldb_process.GetSTDOUT(1000)
        print remaining_stdout
        exit_status = self.lldb_process.GetExitStatus()
        print 'LldbExecutor: Exit status from process under debug is', exit_status
        self.lldb_process.Destroy()

    def _get_process_id_from_name(self, executableName):
        processId = 0
        try:
            processId = subprocess.check_output('pgrep ' + executableName, shell=True)
            print executableName + " process ID is: " + processId
        except subprocess.CalledProcessError:
            print "[ERROR] Unable to find the process " + executableName
        return int(processId)

    def run(self):
        self._start_process()
        self._generate_core_file()
        if self.terminate == True:
            self._terminateProcess()
        else:
            self._continue_process_to_completion()

    def dumpProcessAndDetach(self):
        if self._attach_to_process():
            self._generate_core_file()
            self._detach_from_process()
            return True
        else:
            return False

# ----
# main

if __name__ == '__main__':
    print sys.argv
    if len(sys.argv) < 2:
        # Example: python lldbProcessDump.py ./a.out a b c
        # Example: python lldbProcessDump.py ../../../../out/macosx-10.9-x86_64-rel/bin/csf2g-testutilsTest --gtest_also_run_disabled_tests --gtest_filter=\*DebugBreak
        print "Usage: lldbProcessDump.py executable [args]"
        sys.exit(1)
 
    executable = sys.argv[1]
    executable_basename = os.path.basename(executable)
    core_file_name = executable_basename + '.core'
    executor = LldbExecutor(executable, sys.argv[2:], core_file_name)
    executor.run()

# end

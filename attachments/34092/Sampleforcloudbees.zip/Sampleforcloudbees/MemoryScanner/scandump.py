#!/usr/bin/python
# scandump.py

import sys, os
import time

class Scanner:
    """
    Scans a binary file for matches against a target string.
    Finds sequences where the characters in the target string are
    separated by zero, one, or three spacing bytes.
    Intended for use with Windows .dmp files and Unix core files,
    to look for secrets in the memory image of a process.
    """
    def __init__(self, filename, verbose):
        self.filename = filename
        self.matches = []
        self.previousPercentage = -1
        self.verbose = verbose
        self.termwidth = 80


    def printPercentage(self, currentBlock, maxBlocks):
        # Increment the last percentage value.
        currentPercentage = self.previousPercentage + 1

        # Return the carriage to the start of the line so that it can overwrite the
        # previous buffer.
        sys.stdout.write('\r')

        # Create the bar that visually shows the progress.
        progressBarWidth = self.termwidth - 8
        currentWidth = (progressBarWidth * currentPercentage) / 100
        progressBarStr = "["
        for currentBar in range(progressBarWidth):
            if currentBar < currentWidth:
                progressBarStr += "="
            else:
                progressBarStr += "."
        progressBarStr += "]"

        # Write both the progress bar and the percentage count to the buffer.
        sys.stdout.write("%s %3d%%" % (progressBarStr, currentPercentage))

        # Store the percentage for the next iteration.
        self.previousPercentage = currentPercentage
        sys.stdout.flush()

    def scan(self, target):
        """
        Scans the file content for matches of the target string,
        recording matches in self.matches as tuples (offset, string at offset).
        Returns the count of matches that were found.
        """
        # Read entire binary file into memory
        if os.path.exists(self.filename) == False:
            print "Error the file " + self.filename + " does not exist, cannot continue."
            return -1
            
        with open(self.filename, 'rb') as f:
            file_content = f.read()
            f.close()

        self.matches = []
        self.target = target
        len_file = len(file_content)
        len_target = len(target)
        print "Scanning dumpfile %s (%d bytes) for target '%s'\n" % (self.filename, len_file, self.target)
        start = time.time()

        # Calcuate the block length used for the progress bar.
        progress_len = int(float(len_file) / float(100))
        
        # Look for matches of the pattern at each file offset.
        # For each match, record the file offset and the matching content.
        partial_matches = {}

        # Reuse the target_char_offsets range object at each file offset
        self.target_char_offsets = range(0, len_target)
        # Use generated range for file offsets, instead of precomputing a giant range
        for file_offset in xrange(0, len_file):
            current_byte = file_content[file_offset]
            candidates_to_delete = []

            # Examine each candidate match in progress. Decide to discard it,
            # keep it as a candidate, or record it as a full match.
            for key in partial_matches:
                (starting_file_offset, spacing) = partial_matches[key]
                distance_from_start = file_offset - starting_file_offset

                # If this candidate match has spacing 4 (three extra bytes between target characters),
                # and the current file offset is aligned to that spacing
                if spacing == 4 and (distance_from_start % 4 == 0):
                    target_offset = distance_from_start/4
                    if current_byte == target[target_offset]:
                        # This candidate match remains viable
                        if target_offset == len_target-1:
                            # This match is now complete, so record it
                            self.matches.append([starting_file_offset, 
                                str(file_content[starting_file_offset : starting_file_offset+4*len_target]),])
                            candidates_to_delete.append(key)
                    else:
                        # This candidate match has failed
                        candidates_to_delete.append(key)

                # If this candidate match has spacing 2 (one extra byte between target characters),
                # and the current file offset is aligned to that spacing
                elif spacing == 2 and (distance_from_start % 2 == 0):
                    target_offset = distance_from_start/2
                    if current_byte == target[target_offset]:
                        # This candidate match remains viable
                        if target_offset == len_target-1:
                            # This match is now complete, so record it
                            self.matches.append([starting_file_offset, 
                                str(file_content[starting_file_offset : starting_file_offset+2*len_target]),])
                            candidates_to_delete.append(key)
                    else:
                        # This candidate match has failed
                        candidates_to_delete.append(key)

                # If this candidate match has normal spacing (zero extra bytes between target characters)
                elif spacing == 1:
                    target_offset = distance_from_start
                    if current_byte == target[target_offset]:
                        # This candidate match remains viable
                        if target_offset == len_target-1:
                            # This match is now complete, so record it
                            self.matches.append([starting_file_offset, 
                                str(file_content[starting_file_offset : starting_file_offset+len_target]),])
                            candidates_to_delete.append(key)
                    else:
                        # This candidate match has failed
                        candidates_to_delete.append(key)

            # Done iterating over partial matches. Clean out failures.
            for key in candidates_to_delete:
                del partial_matches[key]

            # Begin new candidates if current byte matches first byte in target.
            # One candidate for each spacing variant.
            if current_byte == target[0]:
                key = "%d.%d" % (file_offset, 1)
                partial_matches[key] = (file_offset, 1)
                key = "%d.%d" % (file_offset, 2)
                partial_matches[key] = (file_offset, 2)
                key = "%d.%d" % (file_offset, 4)
                partial_matches[key] = (file_offset, 4)

            # If there are partial matches leftover when this loop ends,
            # just discard them.

            if self.verbose == True:
                if ((file_offset % progress_len) == 0):
                    # Print the percentage complete of the analysis so far to allow the user to see progress.
                    self.printPercentage(file_offset, len_file)

        if self.verbose == True:
            # Clear the stdout buffer on exit of the method (remove the progress bar).
            sys.stdout.write('\r%s\n' % (" " * 120))
            sys.stdout.flush()
        
        end = time.time()
        elapsed = end - start
        if self.verbose:
            print("Scan completed, elapsed time %s seconds." % round(elapsed,1))

        return len(self.matches)

    def print_matches(self):
        """
        Prints the list of matches to standard output.
        To be called after self.scan().
        """
        print "Found %d matches" % (len(self.matches))
        for match in self.matches:
            print "%d: '%s'" % (match[0], match[1])

# ------------------------------------
# main

if __name__ == "__main__":
    if len(sys.argv) != 3:
        # Example: python scandump.py c:\users\kennward\t.dmp password
        print "Usage: scandump.py filename target"
        sys.exit(1)

    scanner = Scanner(sys.argv[1])
    scanner.scan(sys.argv[2])
    scanner.print_matches()

# end

#!/usr/local/bin/python

"""
This is a library for getting a core dump from an iOS app.

On an iPhone or iPad:
    This library uses the a third party utility "ios-deploy" to install the
    app on an iPhone or iPad, launch the app and attach the lldb debugger.
    https://github.com/waruqi/ios-deploy

    GtestSuite is not currently built for iPhone/iPad. A simple test app was
    used to verify this library.  When the GtestSuite app can be built, we
    can just change the executable in the XML file and it should work.

On the iOS Simulator:
    Launching the GtestSuite.app from inside lldb is not working.  Instead we
    tell lldb to wait for the app to be launched externally, then attach to it.
    Apple's simctl utility is used to launch the app.  Command line parameters
    are passed to GtestSuite.app via simctl to tell GtestSuite.app which unit
    test to run.

To use this library, instantiate the class, then call the run method.

    Steps performed by the run method:

    1. Pexpect is used to launch ios-deploy (iPhone/iPad) or lldb (simulator)
       and control the resulting lldb session.

    2. Wait for interrupts (SIGSTOP/SIGINT).

    3. Print backtrace(s).

    4. Save core dump to a file.
"""

import datetime
import multiprocessing
import os
import pexpect
import psutil
import subprocess
import sys
import time
import uuid

pexpectLog = None


def _ts():
    t = datetime.datetime.now()
    return '{0}.{1:06}'.format(t.strftime('%T'), t.microsecond)


def _startLog(method):
    """
    Decorator to log the start of each decorated method.
    """
    def loggedMethod(*args, **kwargs):
        print("{0} IosExecutor: STARTING {1} WITH {2}{3}".format(_ts(), method.__name__, args[1:], kwargs))
        return method(*args, **kwargs)
    return loggedMethod


def _app_launch(root, args):
    """
    root - the root name of the app (minus path and minus extension)
    args - a string containing the arguments to pass to the app

    Wait a bit to allow the parent process to be ready.
    Launch the app.
    """
    print '{0} Forked IosExecutor: Waiting'.format(_ts())
    time.sleep(5)
    print '{0} Forked IosExecutor: launching app with arguments: {1}'.format(_ts(), args)
    escaped_args = args.replace('--', r'\-\-')
    buf = pexpect.run('xcrun simctl launch booted com.cisco.{0} {1}'.format(root, escaped_args))
    if 'error' in buf.lower():
        raise Exception('{0}: {1:*^60}\n{2}\n{0}: {1:*^60}'.format(
            'Forked IosExecutor', ' ERROR ', buf))
    print '{0} Forked IosExecutor: Launch complete - {1}'.format(_ts(), buf)


class IosExecutor:

    def __init__(self, executable, arguments, core_file_name, terminate_process,
                 platform, verbose, sdk_version, device_type):
        """
        executable - The executable file of the process under debug
        arguments - The argv list for the process under debug
        core_file_name - The name of the core file to generate
        terminate_process - True to terminate without backtraces
        platform - 'ios' or 'iossim'
        verbose - True to get additional output from this module
        sdk_version - iOS SDK version for the iOS simulator
        device_type - iOS device type for the iOS simulator
        """
        self.executable = executable
        self.args = ' '.join(arguments)
        self.core_file_name = core_file_name
        self.terminate = terminate_process
        self.platform = platform
        self.verbose = verbose
        self.sdk_version = sdk_version
        self.device_type = device_type
        self.root, ext = os.path.splitext(os.path.basename(self.executable))
        self.sim_uuid=''
        if self.verbose:
            pexpectLog = sys.stdout
            print 'IosExecutor: self.executable =', self.executable
            print 'IosExecutor: self.args =', self.args
            print 'IosExecutor: self.core_file_name =', self.core_file_name
            print 'IosExecutor: self.terminate =', self.terminate
            print 'IosExecutor: self.platform =', self.platform
            print 'IosExecutor: self.verbose =', self.verbose
            print 'IosExecutor: self.sdk_version =', self.sdk_version
            print 'IosExecutor: self.device_type =', self.device_type
            print 'IosExecutor: self.root =', self.root


    def _extract_uuid(self, sdk_version, device_type):
        """
        Extract the UUID of a specific simulator.
        Returns the UUID as a string, or an empty string if the UUID is not found.

        sdk_version - Xcode SDK version, example: "iOS 9.0"
        device_type - Simulated device, example: "iPhone 6"
        See the output of 'xcrun simctl list devices' for the exact strings to use as inputs.

        If more than one UUID matches both the SDK version and device type, the
        first one envountered will be returned.  But this situation should not occur.
        """

        cmd = 'xcrun simctl list devices'
        buf = self._prunner(cmd, out=False)

        if sdk_version == None:
            # find the latest SDK version available
            result = []
            test_str = '-- iOS'
            for line in buf.splitlines():
                if test_str in line:
                    result.append(line)
            if len(result) == 0:
                raise Exception('IosExecutor: Unable to find SDK versions in output of "{0}"'.format(cmd))
            sdk_version = sorted(result)[-1].split()[2]
            if self.verbose:
                print '{0} IosExecutor: found sdk version {1}'.format(_ts(), sdk_version)

        if device_type == None:
            device_type = 'iPhone 6'

        dev='{} ('.format(device_type)
        found_block=False
        uuid = ''

        for line in buf.splitlines():
            if found_block and dev in line:
                try:
                    str = line.split('(')[1]
                    uuid = str.split(')')[0]
                    break
                except:
                    raise Exception('Error parsing UUID in "{0}"'.format(line))
            if found_block and '--' in line:
                raise Exception('Error finding UUID for sdk="{0}", device="{1}"'.format(sdk_version, device_type))
            if (not found_block) and (sdk_version in line):
                found_block=True
        print '{0} IosExecutor: Using simulator: sdk={1}, dev={2}, uuid={3}'.format(_ts(), sdk_version, device_type, uuid)
        return uuid


    def _prunner(self, cmd, out=True):
        """
        Runs a command in pexpect.run(), checks for error, print and return output.
        """
        buf = pexpect.run(cmd)
        buf_lower = buf.lower()
        if ('error' in buf_lower) or ('invalid' in buf_lower):
            raise Exception('{0}: {1:*^60}\n{2}\n{0}: {1:*^60}'.format(
                'IosExecutor', ' ERROR ', buf))
        if out and len(buf) > 0:
            print '{0} IosExecutor: {1:-^60}'.format(_ts(), ' output ')
            print buf
            print '{0} IosExecutor: {1:-^60}'.format(_ts(), ' output ')
        return buf


    def _sim_status(self):
        """
        Return current status of simulator.
        """
        result = ''
        cmd = 'xcrun simctl list devices'
        buf = self._prunner(cmd, out=False)
        for line in buf.splitlines():
            if self.sim_uuid in line:
                try:
                    result = line.split()[-1]
                    return result
                except:
                    break
        return result


    @_startLog
    def _communicate(self, send, response, exact=True, timeout=60):
        """
        Send a string to the spawned process and wait for a response.

        Start by waiting for an (lldb) prompt to make sure the expect buffers
        have been flushed before we send our string.

        send - a string to send, or None to only wait
        response - wait for this string, usually '(lldb)'
        exact - set to False to use a regex in response
        timeout - number of seconds to wait
        """
        t1 = '==============='

        if send:
            self.process.expect_exact(['(lldb)', pexpect.TIMEOUT,
                                      pexpect.EOF], timeout=5)
            t1 = _ts()
            self.process.sendline(send)

        if exact:
            rv = self.process.expect_exact([response, pexpect.TIMEOUT,
                                           pexpect.EOF], timeout=timeout)
        else:
            rv = self.process.expect([response, pexpect.TIMEOUT,
                                     pexpect.EOF], timeout=timeout)
        t2 = _ts()
        before, after = self.process.before, self.process.after

        if rv == 0:
            if self.verbose:
                print '{0} IosExecutor: {1:=^60} timeout={2}'.format(t1, ' sent ', timeout)
                print send
                print '{0} IosExecutor: {1:-^60}'.format(t2, ' before ')
                print before
                print '{0} IosExecutor: {1:-^60}'.format(t2, ' after ')
                print after
                print '=============== IosExecutor: {0:=^60}'.format(' end ')
            return before, after
        elif rv == 1:
            print '{0} IosExecutor: {1:=^60}'.format(_ts(), ' Exception ')
            print '{0} IosExecutor: {1:-^60}'.format(_ts(), ' before ')
            print before
            print '{0} IosExecutor: {1:-^60}'.format(_ts(), ' after ')
            print after
            print '=============== IosExecutor: {0:=^60}'.format(' end ')
            raise Exception('{0} IosExecutor: TIMEOUT waiting for "{1}" after sending "{2}"'.format(_ts(), response, send))
        elif rv == 2:
            print '{0} IosExecutor: {1:=^60}'.format(_ts(), ' Exception ')
            print '{0} IosExecutor: {1:-^60}'.format(_ts(), ' before ')
            print before
            print '{0} IosExecutor: {1:-^60}'.format(_ts(), ' after ')
            print after
            print '=============== IosExecutor: {0:=^60}'.format(' end ')
            raise Exception('{0} IosExecutor: EOF waiting for "{1}" after sending "{2}"'.format(_ts(), response, send))
        else:
            print '{0} IosExecutor: {1:=^60}'.format(_ts(), ' Exception ')
            print '{0} IosExecutor: {1:-^60}'.format(_ts(), ' before ')
            print before
            print '{0} IosExecutor: {1:-^60}'.format(_ts(), ' after ')
            print after
            print '=============== IosExecutor: {0:=^60}'.format(' end ')
            raise Exception('{0} IosExecutor: Error waiting for "{1}" after sending "{2}"'.format(_ts(), response, send))


    @_startLog
    def _ios_deploy_launch(self):
        """
        Use pexpect to spawn ios-deploy.
        Ios-deploy will install our app onto a phone, launch the app, then
        attach the lldb debugger.
        """
        # iOS needs args contained in quotes.
        escaped_args = '"' + self.args + '"'
        cmd = "ios-deploy --debug --bundle {0} --args={1}".format(self.executable, escaped_args)
        if self.verbose:
            print '{0} IosExecutor: self.args = {1}'.format(_ts(), self.args)
            print '{0} IosExecutor: escaped_args = {1}'.format(_ts(), escaped_args)
            print '{0} IosExecutor: cmd = {1}'.format(_ts(), cmd)
        self.process = pexpect.spawn(cmd, logfile=pexpectLog)


    @_startLog
    def _ios_deploy_attach(self):
        """
        Use pexpect to spawn ios-deploy.
        Ios-deploy will run and attach the lldb debugger to our app, which
        was previously installed on a phone.
        """
        if self.verbose:
            print '{0} IosExecutor: self.args = {1}'.format(_ts(), self.args)
        escaped_args = self.args.replace('--', r'\-\-')
        if self.verbose:
            print '{0} IosExecutor: escaped_args = {1}'.format(_ts(), escaped_args)
        cmd = "ios-deploy --noinstall --bundle {0} --args {1}".format(self.executable, args)
        self.process = pexpect.spawn(cmd, logfile=pexpectLog)


    @_startLog
    def _lldb_launch(self):
        """
        Make sure there is no simulator already running.
        Launch the iOS simulator.
        Install the app on the simulator.
        Fork a process to launch the app.
        Launch lldb debugger.
        Connect lldb to the simulator.
        Tell lldb to wait for the app to be launched, then attach to the app.
        """

        self.sim_uuid = self._extract_uuid(self.sdk_version, self.device_type)
        if self.verbose:
            print 'IosExecutor: self.sim_uuid =', self.sim_uuid
        self._sim_shutdown()

        print '{0} IosExecutor: Starting iOS Simulator'.format(_ts())
        cmd = 'open -a Simulator --args -CurrentDeviceUDID {0}'.format(self.sim_uuid)
        self._prunner(cmd)

        status = ''
        while status != '(Booted)':
            status = self._sim_status()

        print '{0} IosExecutor: Installing {1}'.format(_ts(), self.executable)
        cmd = 'xcrun simctl install {0} {1}'.format(self.sim_uuid, self.executable)
        self._prunner(cmd)

        # temp file containing lldb commands to be executed when lldb starts
        tmp_filename = '/tmp/lldbinit-iosExecutor-{0}'.format(str(uuid.uuid4()))
        f = open(tmp_filename, 'w')
        f.write('platform select ios-simulator\n')
        f.write('platform connect {0}\n'.format(self.sim_uuid))
        last_cmd_match = "process attach -n '{0}' --waitfor".format(self.root)
        f.write(last_cmd_match + '\n')
        f.close()

        print '{0} IosExecutor: Forking app launcher'.format(_ts())
        p = multiprocessing.Process(target=_app_launch, args=(self.root, self.args))
        p.start()
        print '{0} IosExecutor: Spawning lldb --source {1}'.format(_ts(), tmp_filename)
        self.process = pexpect.spawn('lldb --source {0}'.format(tmp_filename),
                                     logfile=pexpectLog)
        self._communicate(None, last_cmd_match)
        p.join()
        print '{0} IosExecutor: Forked app launcher process complete'.format(_ts())
        os.remove(tmp_filename)


    @_startLog
    def _lldb_attach(self):
        """
        Not implemented.
        """
        return


    def _look_for_string(self, str, count=3, timeout=60):
        """
        Loop looking for a string to be output by lldb.
        Sometimes we get extra prompts from lldb and we need to retry.
        """
        print '{0} IosExecutor: looking for {1}'.format(_ts(), str)
        for i in range(count):
            before, after = self._communicate(None, '(lldb)', timeout=timeout)
            if str in before:
                return
        raise Exception('IosExecutor: Did not receive {0} from test app.'.format(str))


    @_startLog
    def _wait_for_interrupts(self):
        """
        Wait for the test to hit our interrupts.  It may take a while.

        For iossim, the first interrupt occurs before the test case runs.
        The second interrupt occurs after the test case has been run
        and we are ready to get our core dump.

        For ios, the first interrupt occurs after the test case has been
        run and we are ready to get our core dump.  We increase the loop
        count to collect all the output from lldb/ios-deploy initialization.
        """
        if 'iossim' == self.platform:
            self._look_for_string('signal SIGSTOP', count=3)
            self._communicate('process continue', '(lldb)')
            self._look_for_string('signal SIGINT')
        else:
            self._look_for_string('signal SIGINT', count=25)


    @_startLog
    def _generate_core_file(self):
        """
        Remove old core file.
        Generates a core file for the process running in the debugger.
        This can takes several minutes over USB from an iPhone/iPad.
        """
        if os.path.exists(self.core_file_name):
            os.remove(self.core_file_name)
        save_core_command = "process save-core %s" % (self.core_file_name)
        print '{0} IosExecutor: Beginning core dump.'.format(_ts())
        start = time.time()
        before, after = self._communicate(save_core_command, '(lldb)', timeout=1200)
        if 'error' in before.lower():
            raise Exception('{0}: {1:*^60}\n{2}\n{0}: {1:*^60}'.format('IosExecutor', ' ERROR ', before))
        if not os.path.exists(self.core_file_name):
            raise Exception('IosExecutor: Core file not found after core dump: {0}'.format(self.core_file_name))
        else:
            end = time.time()
            elapsed = end - start
            print '{0} IosExecutor: Core dump successful to file {1}'.format(_ts(), self.core_file_name)
            print '{0} IosExecutor: Elapsed time {1} seconds.'.format(_ts(), round(elapsed,1))


    @_startLog
    def _print_stack_trace_for_selected_thread(self):
        """
        Prints the stack trace for the currently selected thread.
        """
        before, after = self._communicate('thread backtrace', '(lldb)')
        # if verbose is true, the backtrace gets printed in _communicate()
        # when verbose is false, print it here
        if not self.verbose:
            print '{0} IosExecutor: {1:-^60}'.format(_ts(), ' thread backtrace start ')
            print before
            print '{0} IosExecutor: {1:-^60}'.format(_ts(), ' thread backtrace end ')


    @_startLog
    def _print_stack_trace_for_all_threads(self):
        """
        Prints the stack trace for all threads in the process.
        """
        before, after = self._communicate('thread backtrace all', '(lldb)')
        # if verbose is true, the backtrace gets printed in _communicate()
        # when verbose is false, print it here
        if not self.verbose:
            print '{0} IosExecutor: {1:-^60}'.format(_ts(), ' thread backtrace all start ')
            print before
            print '{0} IosExecutor: {1:-^60}'.format(_ts(), ' thread backtrace all end ')


    def _on_terminate(self, proc):
        print '{0} IosExecutor: Simulator terminated with return code "{1}"'.format(_ts(), proc.returncode)

    def _sim_shutdown(self):
        """
        Shut down the simulator, then if it is running, terminate the process.
        """
        if self._sim_status() != '(Shutdown)':
            print '{0} IosExecutor: Shutting down simulator'.format(_ts())
            self._prunner('xcrun simctl shutdown {0}'.format(self.sim_uuid))
        for proc in psutil.process_iter():
            pinfo = proc.as_dict(attrs=['name', 'status'])
            if 'Simulator' == pinfo['name'] and 'running' == pinfo['status']:
                print '{0} IosExecutor: Quitting simulator'.format(_ts())
                proc.terminate()
                gone, alive = psutil.wait_procs([proc], timeout=5, callback=self._on_terminate)
                for p in alive:
                    p.kill()
                break


    @_startLog
    def _terminate_process(self):
        """
        Quit lldb.
        Capture and print anything left in the pexpect buffers.
        Close the pexpect procces.
        Shutdown and quit the simulator.
        """
        try:
            self._communicate('quit', '[$#]', exact=False)
        except:
            pass
        self.process.close()
        if self.platform == 'iossim':
            self._sim_shutdown()


    @_startLog
    def _continue_process_to_completion(self):
        """
        Continues running a process that has stopped in the debugger,
        expecting it to exit cleanly.
        """
        self._communicate('process status', '(lldb)')
        self._communicate('process continue', '(lldb)')
        self._terminate_process()


    @_startLog
    def run(self):
        """
        Install the app, launch the app, attach lldb, wait for the interrupt,
        save a core dump, clean up and exit.

        The backtrace happens affter the core dump because lldb errors out
        trying to to a core dump after the backtrace all.  This problem does
        not happen when doing a backtrace for a single thread.
        """
        if self.platform == 'iossim':
            self._lldb_launch()
        else:
            self._ios_deploy_launch()
        self._wait_for_interrupts()
        self._generate_core_file()
        self._print_stack_trace_for_all_threads()
        if self.terminate == True:
            self._terminate_process()
        else:
            self._continue_process_to_completion()


    @_startLog
    def dumpProcessAndDetach(self):
        """
        for iossim:
            Since lldb needs to be waiting for the process to launch before the
            process gets launched, not sure how this could be implemented.
        for ios:
            Skip installing the app.
            Run the app, attach lldb, wait for the interrupt, save a
            core dump, clean up and exit.
        """
        if self.platform == 'iossim':
            raise Exception('IosExecutor: Not implemented for platform iossim.')
        else:
            self._ios_deploy_attach()
            self._wait_for_interrupts()
            self._print_stack_trace_for_all_threads()
            self._generate_core_file()
            if self.terminate == True:
                self._terminate_process()
            else:
                self._continue_process_to_completion()


def _prepare_app(dir, app):
    """
    Change to and verify the app directory.
    Verify that the app exists.
    """
    os.chdir(dir)
    if os.getcwd() != dir:
        raise Exception('Unable to change to directory {0}'.format(dir))
    print 'dir =', os.getcwd()

    if not os.path.exists(app):
        raise Exception('Unable to find target app {0}'.format(app))
    print 'app =', app


# ----
# main

if __name__ == '__main__':
    print sys.argv
    if len(sys.argv) < 2:
        # Example: python iosProcessDump.py ./a.out a b c
        # Example: python iosProcessDump.py trunk/foo/bar/GtesSuite.app --gtest_also_run_disabled_tests --gtest_filter=\*DebugBreak
        print "Usage: iosProcessDump.py executable [args]"
        sys.exit(1)

    executable = sys.argv[1]
    print 'exe =', executable
    executable_dir, executable_basename = os.path.split(executable)
    _prepare_app(executable_dir, executable_basename)
    core_file_name = executable_basename + '.core'
    print 'sys.argv[2:] =', sys.argv[2:]
    executor = IosExecutor(executable, sys.argv[2:], core_file_name, False, 'iossim', False, '9.0', 'iPhone 6')
    executor.run()
    #executor = IosExecutor(executable, sys.argv[2:], core_file_name, False, 'ios', True, None, None)
    #executor.run()

# end

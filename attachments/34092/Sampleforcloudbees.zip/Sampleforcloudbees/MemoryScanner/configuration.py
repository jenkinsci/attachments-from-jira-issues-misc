#!/usr/bin/python

import os, sys
import xml.etree.ElementTree as xmlElementTree

#
# This class governs the memory scanner configuration,
# all script wide settings will go in this class.
#
class Configuration():
	def __init__(self):
		self.filename = ""
		self.isRunning = False
		self.testCasesList = []
		self.verbose = False
		self.terminate = False
		self.arguments = None

#
# This represents an individual test case and all
# properties within it.
#
class TestCase():
	def __init__(self):
		self.name = ""
		self.secret = ""
		self.expectedOccurrences = None
		self.maxExpectedOccurrences = None
		self.actualOccurrences = 0
		self.useResultFrom = ""
		self.isSuccess = False
		self.completed = False
		
#
# The parser will accept a filename and parse the XML
# document at that file. Returning a Configuration object
# containing all the tests.
#
class ConfigurationParser:
	def __init__(self, filename):
		self.filename = filename

	def parseConfiguration(self):
		configuration = Configuration()
		tree = xmlElementTree.parse(self.filename)

		# The root is memoryscanner
		root = tree.getroot()

		# This is executable filename.
		executable = root.find('executable')
		configuration.filename = executable.text
		isRunning = executable.get("isrunning")
		if isRunning != None and isRunning.lower() == "true":
			configuration.isRunning = True

		arguments = root.find('arguments')
		if arguments != None:
			configuration.testArgument = arguments.text
		else:
			configuration.testArgument = None

		verboseElement = root.find('verbose')
		if verboseElement != None:
			verboseStr = verboseElement.text
			if verboseStr != None and verboseStr.lower() == "true":
				configuration.verbose = True

		terminateProcessElement = root.find('terminateprocess')
		if terminateProcessElement != None:
			terminateProcessStr = terminateProcessElement.text
			if terminateProcessStr !=None and terminateProcessStr.lower() == "true":
				configuration.terminate = True

		# The parent tests element
		tests = root.find('tests')
		for testCaseIter in tests.findall('testcase'):
			# Individual test cases.
			testCase = TestCase()

			# Test case name
			testCase.name = testCaseIter.get("name")

			# Iterate the children, extracting the properties of the test case.
			for testProperty in testCaseIter:
				if testProperty.tag == "expectedoccurrences":
					testCase.expectedOccurrences = int(testProperty.text)
				if testProperty.tag == "maxexpectedoccurrences":
					testCase.maxExpectedOccurrences = int(testProperty.text)
				if testProperty.tag == "useresultfrom":
					testCase.useResultFrom = testProperty.text
				if testProperty.tag == "secret":
					testCase.secret = testProperty.text
				
			configuration.testCasesList.append(testCase)
		
		return configuration
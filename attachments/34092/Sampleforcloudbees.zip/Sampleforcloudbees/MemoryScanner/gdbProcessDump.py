#!/usr/bin/python

import os
import errno
import sys
import subprocess
import string
import pexpect
import time
import signal
from pexpect import popen_spawn


class GdbExecutor:
    def __init__(self, executable, arguments, core_file_name, terminate_process, verbose, project_dir, device_id):
        """
        executable - The executable file of the process under debug
        arguments - The argv array for the process under debug
        core_file_name - The name of the core file to generate
        terminate_process - Whether the process should be terminated when complete
        project_dir - The path to the android project directory
        device_id - The type of device to run the process on
        """
        self.executable = executable
        self.argv = arguments
        self.core_file_name = core_file_name
        self.terminate = terminate_process
        self.projectdir = project_dir
        self.verbose = verbose
        self.deviceid = device_id

        # Filters for skipping regions of memory in _dump_memory_by_region()
        # Set here in case it is ever necessary to set by test case in the configuration file.
        self.skip_regions = [r"/system/", r"/vendor/", r"/dev/ashmem/dalvik-main"]

        # Get SDK path.
        if os.environ.get("ANDROID_SDK_ROOT") is None:
            if os.environ.get("ANDROID_HOME") is None:
                raise Exception("GdbExecutor: At least one of ANDROID_SDK_ROOT or ANDROID_HOME must be set in the environment.")
            else:
                self.sdk_root = os.environ.get("ANDROID_HOME")
        else:
            self.sdk_root = os.environ.get("ANDROID_SDK_ROOT")

        # Get NDK path.
        if os.environ.get("ANDROID_NDK_ROOT") is None:
            if os.environ.get("ANDROID_NDK_HOME") is None:
                if os.environ.get("NDK_ROOT") is None:
                    raise Exception("GdbExecutor: At least one of ANDROID_NDK_ROOT, ANDROID_NDK_HOME, or NDK_ROOT must be set in the environment.")
                else:
                    self.ndk_root = os.environ.get("NDK_ROOT")
            else:
                self.ndk_root = os.environ.get("ANDROID_NDK_HOME")
        else:
            self.ndk_root = os.environ.get("ANDROID_NDK_ROOT")

        # Set the absolute path to the ndk-gdb script and adb executable based on Host OS.
        if os.name == "nt":
            # Host OS is Windows
            self.ndk_gdb = os.path.abspath(self.ndk_root + "/ndk-gdb-py.cmd")
            self.adb = os.path.abspath(self.sdk_root + "/platform-tools/adb.exe")
            self.eol = "\n"
        else:
            # Host OS is not Windows
            self.ndk_gdb = os.path.abspath(self.ndk_root + "/ndk-gdb")
            self.adb = os.path.abspath(self.sdk_root + "/platform-tools/adb")
            self.eol = "\r\n"

        if self.deviceid is None:
            self.device = ""
        elif self.deviceid.lower() == "emulator":
            self.device = " -e"
        elif self.deviceid.lower() == "device":
            self.device = " -d"
        else:
            if os.name == "nt":
                self.device = " -s " + self.deviceid
            else:
                self.device = " -s=" + self.deviceid
                    
        # Note that GdbExecutor does not launch a debugger instance during the init.
        # This is because gdb is started from within the shell script itself,
        # and controlled via pExpect.
        if self.verbose:
            print 'GdbExecutor: Executable =', self.executable
            print 'GdbExecutor: Args =', self.argv
            print 'GdbExecutor: Core File Name =', self.core_file_name
            print 'GdbExecutor: Project Path =', self.projectdir
            print 'GdbExecutor: SDK Root Path =', self.sdk_root
            print 'GdbExecutor: NDK Root Path =', self.ndk_root
            print 'GdbExecutor: ADB Executable Path =', self.adb
            print 'GdbExecutor: Terminate =', self.terminate
            print 'GdbExecutor: Verbose =', self.verbose
            print 'GdbExecutor: Device =', self.device

    def _set_gdb_defaults(self):
        # Configure some default settings in gdb regardless of how it was started.
        # Both pagination and confirmations can interfere with automation.

        self.gdb_process.sendline("set confirm off")
        try:
            self.gdb_process.expect_exact("(gdb)")
        except:
            raise Exception("gdbExecutor: Never received gdb prompt after disabling confirmations")

        self.gdb_process.sendline("set pagination off")
        try:
            self.gdb_process.expect_exact("(gdb)")
        except:
            raise Exception("gdbExecutor: Never received gdb prompt after disabling pagination")

        # Newer versions of CiscoSSL trigger SIGILL.
        # These signals are handled by CiscoSSL and gdb must ignore them.
        self.gdb_process.sendline("handle SIGILL nostop noprint")
        try:
            self.gdb_process.expect_exact("(gdb)")
        except:
            raise Exception("gdbExecutor: Never received gdb prompt after disabling SIGILL")

        # Some tests (and the Jabber application itself) trigger SIG32 and SIG33.
        # These signals are thread-related and gdb must ignore them.
        self.gdb_process.sendline("handle SIG32 nostop noprint")
        try:
            self.gdb_process.expect_exact("(gdb)")
        except:
            raise Exception("gdbExecutor: Never received gdb prompt after disabling SIG32")

        self.gdb_process.sendline("handle SIG33 nostop noprint")
        try:
            self.gdb_process.expect_exact("(gdb)")
        except:
            raise Exception("gdbExecutor: Never received gdb prompt after disabling SIG33")

    def _start_process(self):
        # Launch the process in the debugger
        # main_bp = target.BreakpointCreateByName("main", target.GetExecutable().GetFilename())

        # Log all debugger output if verbose is on.
        if self.verbose:
            pexpectLog = sys.stdout
        else:
            pexpectLog = None

        # Call pExpect properly based on Host OS.
        # Turn argv into a string that can be passed as extras to Google Test.
        # argv should contain both --gtest_filter and --gtest_output switches.
        if os.name == "nt":
            launch = '.CallTests -a android.intent.action.MAIN --es gtest \\"{0}\\"'.format(' '.join(self.argv))
            gdb_cmd = '"{0}" --verbose --adb "{1}" --project "{2}" --launch "{3}"{4}'.format(self.ndk_gdb, self.adb, self.projectdir, launch, self.device)
            if self.verbose:
                print 'GdbExecutor: Command =', gdb_cmd
            self.gdb_process = pexpect.popen_spawn.PopenSpawn(gdb_cmd, logfile=pexpectLog, cwd=self.projectdir)
        else:
            launch = '.CallTests -a android.intent.action.MAIN --es gtest "{0}"'.format(' '.join(self.argv))
            gdb_cmd = "'{0}' --verbose --adb='{1}' --project='{2}' --launch='{3}'{4}".format(self.ndk_gdb, self.adb, self.projectdir, launch, self.device)
            if self.verbose:
                print 'GdbExecutor: Command =', gdb_cmd
            self.gdb_process = pexpect.spawn(gdb_cmd, logfile=pexpectLog, cwd=self.projectdir)
            # The gdb_process.wait() process -in self._exit- will block forever if anything is left
            # in the buffer. Turning off echo will keep the buffer clean.
            # This is not needed on Windows because it does not appear to echo.
            self.gdb_process.setecho(False)

        if not self.gdb_process:
            raise Exception("gdbExecutor: Could not launch debug process %s" % gdb_cmd)

        # gdb on android always goes to a prompt when first launched, prior to jdb attaching.
        # It is necessary to continue at that prompt to hit any breakpoints. This can take some
        # time, especially on a slow machine.
        try:
            found = self.gdb_process.expect_exact(["Non-debuggable application", "more than one device" + self.eol, "more than one emulator" + self.eol,
                                                  "more than one device/emulator" + self.eol, "(gdb)"], timeout=120)
        except:
            raise Exception("gdbExecutor: Did not get gdb prompt after launching debug process")

        # Either we didn't pass in a device ID, or our device ID wasn't enough to select only one
        # device/emulator.
        if found == 0:
            raise Exception("gdbExecutor: Unable to launch debuggable application on target device.")
        elif found == 1:
            raise Exception("gdbExecutor: Multiple devices present. Use -i to select by device serial number.")
        elif found == 2:
            raise Exception("gdbExecutor: Multiple emulators present. Use -i to select by device serial number.")
        elif found == 3:
            raise Exception("gdbExecutor: Multiple devices/emulators present. Use -i to select a single device.")
        
        # Set some automation-friendly defaults.
        self._set_gdb_defaults()

        # After setting defaults, send continue to let the program return to normal execution.
        self.gdb_process.sendline("continue")

        # Wait for breakpoint to be hit. This can take some time depending on host machine
        # and android device speed.
        try:
            self.gdb_process.expect_exact("SIGINT", timeout=120)
        except:
            raise Exception("gdbExecutor: Never received SIGINT, target may have failed to hit breakpoint")

        # After breakpoint, gdb prompt should return, very quickly.
        try:
            self.gdb_process.expect_exact("(gdb)")
        except:
            raise Exception("gdbExecutor: Did not receive gdb prompt after breakpoint")
            

    def _attach_to_process(self):
        # Attach to an already running process by launching the debugger. Determines which process
        # based on the projectdir rather than PID.

        # Log all debugger output if verbose is on.
        if self.verbose:
            pexpectLog = sys.stdout
        else:
            pexpectLog = None

        # Call pExpect properly based on Host OS.
        if os.name == "nt":
            gdb_cmd = '"{0}" --verbose --adb "{1}" --project "{2}"'.format(self.ndk_gdb, self.adb, self.projectdir)
            if self.verbose:
                print 'GdbExecutor: Command =', gdb_cmd
            self.gdb_process = pexpect.popen_spawn.PopenSpawn(gdb_cmd, logfile=pexpectLog, cwd=self.projectdir)
        else:
            gdb_cmd = "'{0}' --verbose --adb='{1}' --project='{2}'".format(self.ndk_gdb, self.adb, self.projectdir)
            if self.verbose:
                print 'GdbExecutor: Command =', gdb_cmd
            self.gdb_process = pexpect.spawn(gdb_cmd, logfile=pexpectLog, cwd=self.projectdir)
            # The gdb_process.wait() process -in self._exit- will block forever if anything is left
            # in the buffer. Turning off echo will keep the buffer clean.
            # This is not needed on Windows because it does not appear to echo.
            self.gdb_process.setecho(False)

        if not self.gdb_process:
            raise Exception("gdbExecutor: Could not launch debug process %s" % gdb_cmd)

        # Set some automation-friendly defaults.
        self._set_gdb_defaults()

    def _detach_from_process(self):
        # Detach from already attached process.
        self.gdb_process.sendline("detach")
        try:
            self.gdb_process.expect_exact("(gdb)")
        except:
            raise Exception("gdbExecutor: Did not receive gdb prompt after detach")

    def _print_stack_trace_for_selected_thread(self):
        # Prints the stack trace for the currently selected thread.
        self.gdb_process.sendline("backtrace")
        try:
            self.gdb_process.expect_exact("(gdb)")
            if not self.verbose:
                print "\n*--------------------- Stack Trace ---------------------*"
                print self.gdb_process.before
        except:
            raise Exception("gdbExecutor: Did not receive gdb prompt after backtrace")

    def _print_stack_trace_for_all_threads(self):
        # Prints the stack trace for all threads in the process.
        self.gdb_process.sendline("thread apply all backtrace")
        try:
            # It can take more than the default timeout to print all threads.
            self.gdb_process.expect_exact("(gdb)", timeout=60)
            if not self.verbose:
                print "\n*--------------------- Stack Trace ---------------------*"
                print self.gdb_process.before
        except:
            raise Exception("gdbExecutor: Did not receive gdb prompt after backtrace")

    def _generate_core_file_path(self):        
        filepath = os.path.abspath(self.projectdir + "/" + self.core_file_name)
        return filepath

    def _dump_memory_by_region(self):
        # Dumps memory regions, skipping regions in self.skip_regions.
        # The core file will save in the current directory of the gdb process.
        gdb_dump_memory_command = "append memory %s" % (self.core_file_name)
        abs_core_file_path = self._generate_core_file_path()

        print("gdbExecutor: Beginning memory dump by region.")

        # Read the memory mappings in /proc through gdb.
        self.gdb_process.sendline("info proc mappings")
        try:
            self.gdb_process.expect_exact("(gdb)")
        except:
            raise Exception("gdbExecutor: Did not receive gdb prompt after listing memory mappings.")
        
        start = time.time()
        for mapping in self.gdb_process.before.splitlines():
            map = mapping.split(None,3)
            try:
                mem_begin, mem_end = map[:2]
                mem_rest = map[-1]
            except ValueError:
                continue
                
            if ("0x" in mem_begin) and ("0x" in mem_end):
                # Don't dump memory regions in skip_regions.
                skip = False
                for match in self.skip_regions:
                    if match in mem_rest:
                        skip = True
                        if self.verbose:
                            print("Not dumping region %s - %s; filtered by %s" % (mem_begin, mem_end, match))
                if skip:
                    continue

                self.gdb_process.sendline("%s %s %s" % (gdb_dump_memory_command, mem_begin, mem_end))
                try:
                    self.gdb_process.expect_exact("(gdb)", timeout=240)
                except:
                    raise Exception("gdbExecutor: Did not receive gdb prompt after dumping memory range.")
        
        if not os.path.exists(abs_core_file_path):
            raise Exception("gdbExecutor: Core file not found after memory dump to %s" % abs_core_file_path)
        else:
            end = time.time()
            elapsed = end - start
            print("gdbExecutor: Memory dump successful to file %s" % abs_core_file_path)
            print("gdbExecutor: Elapsed time %s seconds." % round(elapsed,1))
        
    def _dump_core_file(self):
        # Generates a core file for the process running in the debugger.
        # The core file will save in the current directory of the gdb process.
        gdb_save_core_command = "generate-core-file %s" % (self.core_file_name)
        abs_core_file_path = self._generate_core_file_path()

        print("gdbExecutor: Beginning core dump.")
        self.gdb_process.sendline(gdb_save_core_command)
        start = time.time()
        try:
            self.gdb_process.expect_exact("(gdb)", timeout=1200)
        except:
            raise Exception("gdbExecutor: Did not receive gdb prompt after core dump")
        if not os.path.exists(abs_core_file_path):
            raise Exception("gdbExecutor: Core file not found after core dump to %s" % abs_core_file_path)
        else:
            end = time.time()
            elapsed = end - start
            print("gdbExecutor: Core dump successful to file %s" % abs_core_file_path)
            print("gdbExecutor: Elapsed time %s seconds." % round(elapsed,1))


    def _generate_core_file(self):
        # This is a stub function. All it does right now is call _dump_memory_by_region().
        # Left in place case it is ever needed to call _dump_core_file().
        self._dump_memory_by_region()

    def _continue_process_to_completion(self):
        # Continues a process that has stopped in the debugger, expecting it to exit cleanly.
        self.gdb_process.sendline("continue")
        try:
            self.gdb_process.expect_exact("(gdb)", timeout=120)
        except:
            raise Exception("gdbExecutor: Did not receive gdb prompt after continue command")

    def _terminateProcess(self):
        self.gdb_process.sendline("kill")
        try:
            self.gdb_process.expect_exact("(gdb)")
        except:
            raise Exception("gdbExecutor: Did not receive gdb prompt after kill command")

    def _exit(self):
        # Exits the debugger. Do not try to access gdb_process after calling this, it will fail.
        self.gdb_process.sendline("quit")
        exitcode = self.gdb_process.wait()
        if exitcode == 0:
            print("gdbExecutor: Debugger exited cleanly with exit code %s" % exitcode)
        else:
            print("gdbExecutor: Debugger did not exit cleanly; exit code %s" % exitcode)

    def run(self):
        # Delete the core file first, then start the process.
        corefile = self._generate_core_file_path()
        try:
            os.remove(corefile)
        except OSError as e:
            if e.errno != errno.ENOENT:
                raise Exception("gdbExecutor: While trying to delete, received %s" % e)

        self._start_process()

        # Prints the stack trace for all threads.
        self._print_stack_trace_for_all_threads()
        self._generate_core_file()
        if self.terminate == True:
            self._terminateProcess()
        else:
            self._continue_process_to_completion()
        self._exit()

    def dumpProcessAndDetach(self):
        # Delete the core file first, then start the process.
        corefile = self._generate_core_file_path()
        try:
            os.remove(corefile)
        except OSError as e:
            if e.errno != errno.ENOENT:
                raise Exception("gdbExecutor: While trying to delete, received %s" % e)
                
        if self._attach_to_process():
            # Prints the stack trace for all threads.
            self._print_stack_trace_for_all_threads()
            self._generate_core_file()
            self._detach_from_process()
            return True
        else:
            return False
        self._exit()

# ----
# main

if __name__ == '__main__':
    print sys.argv
    if len(sys.argv) < 2:
        # Example: python gdbProcessDump.py ./a.out a b c
        # Example: python gdbProcessDump.py ../../../../out/macosx-10.9-x86_64-rel/bin/csf2g-testutilsTest --gtest_also_run_disabled_tests --gtest_filter=\*DebugBreak
        print "Usage: gdbProcessDump.py executable [args]"
        sys.exit(1)

    executable = sys.argv[1]
    executable_basename = os.path.basename(executable)
    core_file_name = executable_basename + '.core'
    executor = gdbExecutor(executable, sys.argv[2:], core_file_name)
    executor.run()

# end

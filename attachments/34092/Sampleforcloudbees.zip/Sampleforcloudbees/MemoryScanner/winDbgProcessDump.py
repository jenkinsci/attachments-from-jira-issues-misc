#!/usr/bin/python

# ---------------------------------------------------------------------
# Find module pykd at https://pykd.codeplex.com/releases.
# Try an installer like pykd-0.2.0.29-x86-python-2.7-setup.exe
# ---------------------------------------------------------------------

import os, sys
import pykd
import wmi

#
# This class will be responsible for catching exceptions and handling them.
#
class WinDbgExceptionHandler(pykd.eventHandler):
	def __init__(self, winDbgHandler):
		pykd.eventHandler.__init__(self)
		self.winDbgHandler = winDbgHandler

	def onException(self, exp):
		print "Exception occurred, stack trace:"
		stack = pykd.dbgCommand("kb")
		print stack

		# We will only create a dump if there was a break instruction on the
		# top of the stack, or in other words, if we caused it. We will ignore
		# other exceptions and breaks such as loader and termination breaks.
		topFrame = pykd.dbgCommand("k1")
		if topFrame.find("KERNELBASE!DebugBreak") != -1 or self.winDbgHandler.attachAndDump is True:
			dump = pykd.dbgCommand(".dump /o /ma " + self.winDbgHandler.coreFile)
			print dump
		else:
			print "WinDbgExceptionHandler.onException() ignoring exception not from DebugBreak"

		if self.winDbgHandler.attachAndDump is True:
			self.winDbgHandler.detachFromProcess()
		else:
			# Continue and execute the next segment of code.
			self.winDbgHandler.continueExecution()

#
# This class is responsible for execution of the target process under WinDbg.
#
class WinDbgExecution():
	def __init__(self, executable, arguments, coreFile, terminate_process):
		"""
		executable - The executable file of the process under debug
		arguments - The command arguments for the process under debug
		coreFile - The name of the core file to generate
		"""
		self.executable = unicode(executable)
		self.arguments = arguments
		self.coreFile = coreFile
		self.attachAndDump = False
		self.processHandle = 0
		self.terminate = terminate_process

	def continueExecution(self):
		try:
			pykd.go()
		except:
			# Ignore this exception.
			pass

	def run(self):
		try:
			command = self.executable + " " + " ".join(self.arguments)
			print 'WinDbgExecution command:', command
			pykd.handler = WinDbgExceptionHandler(self)
			self.processHandle = pykd.startProcess(command)
			self.continueExecution()
		except BaseException:
			raise Exception("WinDbgExecution could not start process for command '%s'" % (command) )

	def dumpProcessAndDetach(self):
		self.attachAndDump = True
		pid = 0
		try:
			print 'WinDbgExecution attach to process:', self.executable
			pykd.handler = WinDbgExceptionHandler(self)
			pid = self.getPidFromProcessName(self.executable)
			self.processHandle = pykd.attachProcess(pid)
		except Exception as exception:
			print exception
			raise Exception("WinDbgExecution could not attach to process '%s' with PID %d" % (self.executable, pid))

	def detachFromProcess(self):
		try:
			output = pykd.detachAllProcesses()
			print output
		except Exception as exception:
			print exception

	def getPidFromProcessName(self, processName):
		try:
			wmiInstance = wmi.WMI()

			if not processName.endswith(".exe"):
				processName += ".exe"

			for process in wmiInstance.Win32_Process(name = processName):
				print "Found process " + str(process.Name) + " with process ID: " + str(process.ProcessId)
				return process.ProcessId
		except:
			e = sys.exc_info()[0]
			print e

		return 0


################# Test Code #################

def testFunction():
	print "----------------- Test normal flow -----------------"
	winDbgExec = WinDbgExecution("out\windows-x86-MD-unicode-vs2013-rel\\bin\csf2g-testutilsTest.exe", "--gtest_filter=MemoryScannerTests.CArrayString", "windbgdump.dmp")
	winDbgExec.startExecuting()

def testFunctionNoApp():
	print "----------------- Test no application flow -----------------"
	winDbgExec = WinDbgExecution("", "", "")
	winDbgExec.startExecuting()

if __name__ == "__main__":
	testFunction()
	testFunction()
	testFunctionNoApp()
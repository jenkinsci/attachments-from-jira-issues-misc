package com.codeandme.tycho.plugin;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Test;

public class ExampleViewTest {

	@Test
	public void testID() {
		assertEquals("com.codeandme.tycho.views.example", ExampleView.VIEW_ID);
	}

	@Test
	public void testFail() {
		fail("This test should fail");
	}
}
Support Bundle Manifest
=======================

Generated on 2020-11-28 23:12:41.981+0000

Requested components:

  * Agent Configuration File

      - `nodes/slave/Chromium/config.xml`

      - `nodes/slave/Manganese/config.xml`

      - `nodes/slave/Titanium/config.xml`

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/au.com.rayh.GlobalConfigurationImpl.xml`

      - `jenkins-root-configuration-files/com.atlassian.bitbucket.jenkins.internal.config.BitbucketPluginConfiguration.xml`

      - `jenkins-root-configuration-files/com.cloudbees.hudson.plugins.folder.config.AbstractFolderConfiguration.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.bitbucket.endpoints.BitbucketEndpointConfiguration.xml`

      - `jenkins-root-configuration-files/com.dabsquared.gitlabjenkins.GitLabPushTrigger.xml`

      - `jenkins-root-configuration-files/com.dabsquared.gitlabjenkins.connection.GitLabConnectionConfig.xml`

      - `jenkins-root-configuration-files/com.michelin.cio.hudson.plugins.copytoslave.CopyToSlaveBuildWrapper.xml`

      - `jenkins-root-configuration-files/com.sic.plugins.kpp.provider.KPPKeychainsProvider.xml`

      - `jenkins-root-configuration-files/com.sic.plugins.kpp.provider.KPPProvisioningProfilesProvider.xml`

      - `jenkins-root-configuration-files/envInject.xml`

      - `jenkins-root-configuration-files/envinject-plugin-configuration.xml`

      - `jenkins-root-configuration-files/github-plugin-configuration.xml`

      - `jenkins-root-configuration-files/global-build-stats.xml`

      - `jenkins-root-configuration-files/hudson.maven.MavenModuleSet.xml`

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.plugins.ansicolor.AnsiColorBuildWrapper.xml`

      - `jenkins-root-configuration-files/hudson.plugins.campfire.CampfireNotifier.xml`

      - `jenkins-root-configuration-files/hudson.plugins.doxygen.DoxygenBuilder.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitSCM.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/hudson.plugins.growl.GrowlPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.jira.JiraGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/hudson.plugins.jira.JiraProjectProperty.xml`

      - `jenkins-root-configuration-files/hudson.plugins.mercurial.MercurialInstallation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.xcode.XcodeInstallation.xml`

      - `jenkins-root-configuration-files/hudson.scm.CVSSCM.xml`

      - `jenkins-root-configuration-files/hudson.scm.SubversionSCM.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Ant.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Mailer.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Maven.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Shell.xml`

      - `jenkins-root-configuration-files/hudson.triggers.SCMTrigger.xml`

      - `jenkins-root-configuration-files/io.jenkins.plugins.gitlabserverconfig.servers.GitLabServers.xml`

      - `jenkins-root-configuration-files/io.jenkins.plugins.junit.storage.JunitTestResultStorageConfiguration.xml`

      - `jenkins-root-configuration-files/javaposse.jobdsl.plugin.GlobalJobDslSecurityConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.CLI.xml`

      - `jenkins-root-configuration-files/jenkins.fingerprints.GlobalFingerprintConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.metrics.api.MetricsAccessKey.xml`

      - `jenkins-root-configuration-files/jenkins.model.ArtifactManagerConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.model.DownloadSettings.xml`

      - `jenkins-root-configuration-files/jenkins.model.GlobalBuildDiscarderConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.model.JenkinsLocationConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.mvn.GlobalMavenConfig.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.hipchat.HipChatNotifier.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.publish_over_ftp.BapFtpPublisherPlugin.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.slack.SlackNotifier.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.slack.webhook.GlobalConfig.xml`

      - `jenkins-root-configuration-files/jenkins.security.QueueItemAuthenticatorConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.security.ResourceDomainConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.security.UpdateSiteWarningsConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.security.apitoken.ApiTokenPropertyConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.tasks.filters.EnvVarsFilterGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.telemetry.Correlator.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/oauth-consumers.xml`

      - `jenkins-root-configuration-files/org.jenkins.plugins.lockableresources.LockableResourcesManager.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.blink1.Blink1Notifier.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.docker.commons.tools.DockerTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.docker.workflow.declarative.GlobalConfig.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.ghprb.GhprbTrigger.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitApacheTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.github_branch_source.GitHubConfiguration.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.snsnotify.AmazonSNSNotifier.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.stashNotifier.StashNotifier.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.flow.FlowExecutionList.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.flow.GlobalDefaultFlowDurabilityLevel.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.libs.GlobalLibraries.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.support.steps.StageStep.xml`

      - `jenkins-root-configuration-files/queue.xml`

      - `jenkins-root-configuration-files/scriptApproval.xml`

      - `jenkins-root-configuration-files/support-core.xml`

  * About browser

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `identity.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/Chromium/checksums.md5`

      - `nodes/slave/Manganese/checksums.md5`

      - `nodes/slave/Titanium/checksums.md5`

      - `plugins/active.txt`

      - `plugins/backup.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

  * Administrative monitors

      - `admin-monitors.md`

  * Agent Protocols

      - `agent-protocols.md`

  * Build queue

      - `buildqueue.md`

  * Master Custom Log Recorders

      - `nodes/master/logs/custom/Bitbucket.log`

  * Dump agent export tables (could reveal some memory leaks)

      - `nodes/slave/Chromium/exportTable.txt`

      - `nodes/slave/Manganese/exportTable.txt`

      - `nodes/slave/Titanium/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/Chromium/environment.txt`

      - `nodes/slave/Manganese/environment.txt`

      - `nodes/slave/Titanium/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/Chromium/file-descriptors.txt`

      - `nodes/slave/Titanium/file-descriptors.txt`

  * Garbage Collection Logs

  * Master Heap Histogram

      - `nodes/master/heap-histogram.txt`

  * Items Content (Computationally expensive)

      - `items.md`

  * Agent JVM process system metrics (Linux only)

  * Master JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

  * Master Log Recorders

      - `nodes/master/logs/all_2020-11-23_00.37.38.log`

      - `nodes/master/logs/all_2020-11-24_01.24.02.log`

      - `nodes/master/logs/all_2020-11-25_03.39.02.log`

      - `nodes/master/logs/all_2020-11-26_05.55.02.log`

      - `nodes/master/logs/all_2020-11-27_08.12.00.log`

      - `nodes/master/logs/all_2020-11-28_10.40.02.log`

      - `nodes/master/logs/all_2020-11-28_22.08.37.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

  * Load Statistics

      - `load-stats/label/Backup/gnuplot`

      - `load-stats/label/Backup/hour.csv`

      - `load-stats/label/Backup/min.csv`

      - `load-stats/label/Backup/sec10.csv`

      - `load-stats/label/Capistrano/gnuplot`

      - `load-stats/label/Capistrano/hour.csv`

      - `load-stats/label/Capistrano/min.csv`

      - `load-stats/label/Capistrano/sec10.csv`

      - `load-stats/label/Chromium/gnuplot`

      - `load-stats/label/Chromium/hour.csv`

      - `load-stats/label/Chromium/min.csv`

      - `load-stats/label/Chromium/sec10.csv`

      - `load-stats/label/Mac/gnuplot`

      - `load-stats/label/Mac/hour.csv`

      - `load-stats/label/Mac/min.csv`

      - `load-stats/label/Mac/sec10.csv`

      - `load-stats/label/Manganese/gnuplot`

      - `load-stats/label/Manganese/hour.csv`

      - `load-stats/label/Manganese/min.csv`

      - `load-stats/label/Manganese/sec10.csv`

      - `load-stats/label/PC/gnuplot`

      - `load-stats/label/PC/hour.csv`

      - `load-stats/label/PC/min.csv`

      - `load-stats/label/PC/sec10.csv`

      - `load-stats/label/Titanium/gnuplot`

      - `load-stats/label/Titanium/hour.csv`

      - `load-stats/label/Titanium/min.csv`

      - `load-stats/label/Titanium/sec10.csv`

      - `load-stats/label/Xcode/gnuplot`

      - `load-stats/label/Xcode/hour.csv`

      - `load-stats/label/Xcode/min.csv`

      - `load-stats/label/Xcode/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/Chromium/networkInterface.md`

      - `nodes/slave/Manganese/networkInterface.md`

      - `nodes/slave/Titanium/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Master Other Log Recorders

  * Reverse Proxy

      - `reverse-proxy.md`

  * Root CAs

      - `nodes/master/RootCA.txt`

      - `nodes/slave/Chromium/RootCA.txt`

      - `nodes/slave/Manganese/RootCA.txt`

      - `nodes/slave/Titanium/RootCA.txt`

  * Running Builds

      - `running-builds.txt`

  * Agent Command Statistics

      - `nodes/slave/Chromium/command-stats.md`

      - `nodes/slave/Titanium/command-stats.md`

  * Agent Log Recorders

      - `nodes/slave/Chromium/jenkins.log`

      - `nodes/slave/Chromium/logs/all_2020-11-23_00.38.15.log`

      - `nodes/slave/Chromium/logs/all_2020-11-23_22.02.03.log`

      - `nodes/slave/Chromium/logs/all_2020-11-24_19.03.18.log`

      - `nodes/slave/Chromium/logs/all_2020-11-28_13.45.47.log`

      - `nodes/slave/Chromium/logs/all_2020-11-28_16.36.06.log`

      - `nodes/slave/Chromium/logs/all_2020-11-28_16.41.20.log`

      - `nodes/slave/Chromium/logs/all_2020-11-28_22.09.44.log`

      - `nodes/slave/Chromium/logs/all_memory_buffer.log`

      - `nodes/slave/Manganese/jenkins.log`

      - `nodes/slave/Manganese/logs/all_memory_buffer.log`

      - `nodes/slave/Titanium/jenkins.log`

      - `nodes/slave/Titanium/logs/all_2020-11-23_00.38.09.log`

      - `nodes/slave/Titanium/logs/all_2020-11-24_19.03.21.log`

      - `nodes/slave/Titanium/logs/all_2020-11-28_13.45.19.log`

      - `nodes/slave/Titanium/logs/all_2020-11-28_16.35.34.log`

      - `nodes/slave/Titanium/logs/all_2020-11-28_16.40.50.log`

      - `nodes/slave/Titanium/logs/all_2020-11-28_22.09.42.log`

      - `nodes/slave/Titanium/logs/all_memory_buffer.log`

  * Agent system configuration (Linux only)

  * Master system configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/Chromium/system.properties`

      - `nodes/slave/Manganese/system.properties`

      - `nodes/slave/Titanium/system.properties`

  * Master Task Log Recorders

      - `task-logs/Connection Activity monitoring to agents.log`

      - `task-logs/Connection Activity monitoring to agents.log.1`

      - `task-logs/Connection Activity monitoring to agents.log.2`

      - `task-logs/Connection Activity monitoring to agents.log.3`

      - `task-logs/Connection Activity monitoring to agents.log.4`

      - `task-logs/Connection Activity monitoring to agents.log.5`

      - `task-logs/Download metadata.log`

      - `task-logs/Download metadata.log.1`

      - `task-logs/Download metadata.log.2`

      - `task-logs/Download metadata.log.3`

      - `task-logs/Download metadata.log.4`

      - `task-logs/Download metadata.log.5`

      - `task-logs/Fingerprint cleanup.log`

      - `task-logs/Fingerprint cleanup.log.1`

      - `task-logs/Fingerprint cleanup.log.2`

      - `task-logs/Fingerprint cleanup.log.3`

      - `task-logs/Fingerprint cleanup.log.4`

      - `task-logs/Fingerprint cleanup.log.5`

      - `task-logs/Periodic background build discarder.log`

      - `task-logs/Periodic background build discarder.log.1`

      - `task-logs/Periodic background build discarder.log.2`

      - `task-logs/Periodic background build discarder.log.3`

      - `task-logs/Periodic background build discarder.log.4`

      - `task-logs/Periodic background build discarder.log.5`

      - `task-logs/Workspace clean-up.log`

      - `task-logs/Workspace clean-up.log.1`

      - `task-logs/Workspace clean-up.log.2`

      - `task-logs/Workspace clean-up.log.3`

      - `task-logs/Workspace clean-up.log.4`

      - `task-logs/Workspace clean-up.log.5`

      - `task-logs/health-checker.log`

      - `task-logs/jenkins.branch.MultiBranchProject.log`

      - `task-logs/jenkins.branch.MultiBranchProject.log.1`

      - `task-logs/jenkins.branch.MultiBranchProject.log.2`

      - `task-logs/jenkins.branch.MultiBranchProject.log.3`

      - `task-logs/jenkins.branch.MultiBranchProject.log.4`

      - `task-logs/jenkins.branch.MultiBranchProject.log.5`

      - `task-logs/jenkins.branch.OrganizationFolder.log`

      - `task-logs/jenkins.branch.OrganizationFolder.log.1`

      - `task-logs/jenkins.branch.OrganizationFolder.log.2`

      - `task-logs/jenkins.branch.OrganizationFolder.log.3`

      - `task-logs/jenkins.branch.OrganizationFolder.log.4`

      - `task-logs/jenkins.branch.OrganizationFolder.log.5`

      - `task-logs/jobAnalytics.log`

      - `task-logs/jobAnalytics.log.1`

      - `task-logs/jobAnalytics.log.2`

      - `task-logs/jobAnalytics.log.3`

      - `task-logs/jobAnalytics.log.4`

      - `task-logs/jobAnalytics.log.5`

      - `task-logs/telemetry collection.log`

      - `task-logs/telemetry collection.log.1`

      - `task-logs/telemetry collection.log.2`

      - `task-logs/telemetry collection.log.3`

      - `task-logs/telemetry collection.log.4`

      - `task-logs/telemetry collection.log.5`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/Chromium/thread-dump.txt`

      - `nodes/slave/Manganese/thread-dump.txt`

      - `nodes/slave/Titanium/thread-dump.txt`

  * Update Center

      - `update-center.md`

  * User Count

      - `/users/count.md`

  * Slow Request Records

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`


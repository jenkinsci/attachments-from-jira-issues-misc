Item statistics
===============

  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 2
    - Number of builds per job: 1.0 [n=2, s=0.0]
  * `hudson.matrix.MatrixProject`
    - Number of items: 1
    - Number of builds per job: 3 [n=1]
    - Number of items per container: 2 [n=1]
  * `hudson.model.FreeStyleProject`
    - Number of items: 37
    - Number of builds per job: 11.567567567567568 [n=37, s=10.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 69
    - Number of builds per job: 5.681159420289855 [n=69, s=9.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 21
    - Number of items per container: 3.1904761904761907 [n=21, s=2.0]

Total job statistics
======================

  * Number of jobs: 109
  * Number of builds per job: 7.568807339449541 [n=109, s=9.9]

=== Sites ===
 - Url: https://updates.jenkins-ci.org/current/update-center.json
 - Connection Url: http://www.google.com/
 - Implementation Type: hudson.model.UpdateSite
======
Last updated: 22 hr
Proxy: 'async-http-client' not installed, so no proxy info available.

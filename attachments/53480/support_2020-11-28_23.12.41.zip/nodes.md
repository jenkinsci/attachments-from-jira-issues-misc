Node statistics
===============

  * Total number of nodes
      - Sample size:        253
      - Average (mean):     4.0
      - Average (median):   4.0
      - Standard deviation: 0.0
      - Minimum:            4
      - Maximum:            4
      - 95th percentile:    4.0
      - 99th percentile:    4.0
  * Total number of nodes online
      - Sample size:        253
      - Average (mean):     3.0000000000000004
      - Average (median):   3.0
      - Standard deviation: 4.374230896895496E-13
      - Minimum:            1
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors
      - Sample size:        253
      - Average (mean):     3.0000000000000004
      - Average (median):   3.0
      - Standard deviation: 4.374230896895496E-13
      - Minimum:            1
      - Maximum:            3
      - 95th percentile:    3.0
      - 99th percentile:    3.0
  * Total number of executors in use
      - Sample size:        253
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      1
      - FS root:        `/home/jenkins`
      - Labels:         (none)
      - Usage:          `EXCLUSIVE`
      - Slave Version:  4.6
      - Java
          + Home:           `/usr/lib/jvm/java-8-oracle/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;171
          + Maximum memory:   3.46 GB (3719299072)
          + Allocated memory: 1.58 GB (1696071680)
          + Free memory:      944.04 MB (989899688)
          + In-use memory:    673.46 MB (706171992)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.171-b11
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.19.0-12-amd64
          + Distribution: Debian GNU/Linux 10 (buster)
      - Process ID: 1896 (0x768)
      - Process started: 2020-11-28 22:08:20.361+0000
      - Process uptime: 1 hr 4 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`

  * `Chromium` (`hudson.slaves.DumbSlave`)
      - Description:    _Derek's Mac development machine_
      - Executors:      1
      - Remote FS root: `/Users/Shared/Applications/jenkins`
      - Labels:         Mac Capistrano
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.6
      - Java
          + Home:           `/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;25
          + Maximum memory:   3.56 GB (3817865216)
          + Allocated memory: 245.50 MB (257425408)
          + Free memory:      176.28 MB (184846600)
          + In-use memory:    69.22 MB (72578808)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.25-b02
      - Operating system
          + Name:         Mac OS X
          + Architecture: x86&#95;64
          + Version:      10.16
      - Process ID: 988 (0x3dc)
      - Process started: 2020-11-28 22:09:35.592+0000
      - Process uptime: 1 hr 3 min
      - JVM startup parameters:
          + Boot classpath: `/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/lib/resources.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/lib/rt.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/lib/sunrsasign.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/lib/jsse.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/lib/jce.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/lib/charsets.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/lib/jfr.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/classes`
          + Classpath: `/Users/Shared/Applications/jenkins/slave.jar`
          + Library path: `/Users/Shared/Applications/jenkins/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.`
          + arg[0]: `-Djava.awt.headless=true`

  * `Manganese` (`hudson.slaves.DumbSlave`)
      - Description:    _Derek's development PC_
      - Executors:      1
      - Remote FS root: `D:\Jenkins`
      - Labels:         PC
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * `Titanium` (`hudson.slaves.DumbSlave`)
      - Description:    _Derek's Mac build machine_
      - Executors:      1
      - Remote FS root: `/Users/Shared/Applications/jenkins`
      - Labels:         Mac Backup Xcode
      - Usage:          `NORMAL`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        4.6
      - Java
          + Home:           `/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0&#95;25
          + Maximum memory:   3.56 GB (3817865216)
          + Allocated memory: 245.50 MB (257425408)
          + Free memory:      183.63 MB (192554840)
          + In-use memory:    61.87 MB (64870568)
          + GC strategy:      ParallelGC
          + Available CPUs:   8
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.25-b02
      - Operating system
          + Name:         Mac OS X
          + Architecture: x86&#95;64
          + Version:      10.15.7
      - Process ID: 676 (0x2a4)
      - Process started: 2020-11-28 22:09:35.429+0000
      - Process uptime: 1 hr 3 min
      - JVM startup parameters:
          + Boot classpath: `/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/lib/resources.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/lib/rt.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/lib/sunrsasign.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/lib/jsse.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/lib/jce.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/lib/charsets.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/lib/jfr.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_25.jdk/Contents/Home/jre/classes`
          + Classpath: `/Users/Shared/Applications/jenkins/slave.jar`
          + Library path: `/Users/Shared/Applications/jenkins/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.`
          + arg[0]: `-Djava.awt.headless=true`


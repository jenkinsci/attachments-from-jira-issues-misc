Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * Chromium: Mac OS X (x86_64)
   * Manganese: null
   * Titanium: Mac OS X (x86_64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * Chromium: In sync
   * Manganese: null
   * Titanium: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: 722.221GB left on /home/jenkins.
   * Chromium: 585.410GB left on /Users/Shared/Applications/jenkins.
   * Manganese: null
   * Titanium: 516.460GB left on /Users/Shared/Applications/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:1822/15959MB  Swap:21564/22674MB
   * Chromium: Memory:0/0MB  Swap:321/7169MB
   * Manganese: null
   * Titanium: Memory:0/0MB  Swap:1468/2048MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: 6.792GB left on /tmp.
   * Chromium: 585.410GB left on /private/var/folders/40/kc0s08fd5_51667tyvpdmbq40000gq/T.
   * Manganese: null
   * Titanium: 516.460GB left on /private/var/folders/40/kc0s08fd5_51667tyvpdmbq40000gq/T.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * Chromium: 93ms
   * Manganese: null
   * Titanium: 21ms

Jenkins
=======

Version details
---------------

  * Version: `2.268`
  * Instance ID: `e38da43a41750d7f6baae6f11e034713`
  * Mode:    WAR
  * Url:     https://jenkins.gordonknight.co.uk:9443/
  * Java
      - Home:           `/usr/lib/jvm/java-8-oracle/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0&#95;171
      - Maximum memory:   3.46 GB (3719299072)
      - Allocated memory: 1.58 GB (1696071680)
      - Free memory:      945.49 MB (991420432)
      - In-use memory:    672.01 MB (704651248)
      - GC strategy:      ParallelGC
      - Available CPUs:   4
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.171-b11
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.19.0-12-amd64
      - Distribution: Debian GNU/Linux 10 (buster)
  * Process ID: 1896 (0x768)
  * Process started: 2020-11-28 22:08:20.361+0000
  * Process uptime: 1 hr 4 min
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-oracle/jre/lib/resources.jar:/usr/lib/jvm/java-8-oracle/jre/lib/rt.jar:/usr/lib/jvm/java-8-oracle/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jsse.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jce.jar:/usr/lib/jvm/java-8-oracle/jre/lib/charsets.jar:/usr/lib/jvm/java-8-oracle/jre/lib/jfr.jar:/usr/lib/jvm/java-8-oracle/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ansicolor:0.7.3 'AnsiColor'
  * ant:1.11 'Ant Plugin'
  * antisamy-markup-formatter:2.1 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.10-2.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.4 'Authentication Tokens API Plugin'
  * bitbucket:1.1.27 'Jenkins Bitbucket Plugin'
  * blink1:1.1 'BLINK(1) Notifier'
  * blueocean:1.24.3 'Blue Ocean'
  * blueocean-autofavorite:1.2.4 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.24.3 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.24.3 'Common API for Blue Ocean'
  * blueocean-config:1.24.3 'Config API for Blue Ocean'
  * blueocean-core-js:1.24.3 'Blue Ocean Core JS'
  * blueocean-dashboard:1.24.3 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.4.0 'Display URL for Blue Ocean'
  * blueocean-events:1.24.3 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.24.3 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.24.3 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.24.3 'i18n for Blue Ocean'
  * blueocean-jira:1.24.3 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.24.3 'JWT for Blue Ocean'
  * blueocean-personalization:1.24.3 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.24.3 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.24.3 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.24.3 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.24.3 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.24.3 'REST Implementation for Blue Ocean'
  * blueocean-web:1.24.3 'Web for Blue Ocean'
  * bootstrap4-api:4.5.3-1 'Bootstrap 4 API Plugin'
  * bouncycastle-api:2.18 'bouncycastle API Plugin'
  * branch-api:2.6.3 'Branch API Plugin'
  * checks-api:1.1.1 'Checks API plugin'
  * cloudbees-bitbucket-branch-source:2.9.4 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.15 'Folders Plugin'
  * cobertura:1.16 'Jenkins Cobertura Plugin'
  * code-coverage-api:1.2.0 'Code Coverage API Plugin'
  * command-launcher:1.5 'Command Agent Launcher Plugin'
  * compact-columns:1.12 'Compact Columns'
  * compress-artifacts:1.10 'Compress Artifacts Plugin'
  * copy-to-slave:1.4.4 'Copy To Slave Plugin'
  * credentials:2.3.14 'Credentials Plugin'
  * credentials-binding:1.24 'Credentials Binding Plugin'
  * custom-job-icon:0.2 'Custom Job Icon plugin'
  * cvs:2.16 'Jenkins CVS Plug-in'
  * display-url-api:2.3.4 'Display URL API'
  * docker-commons:1.17 'Docker Commons Plugin'
  * docker-workflow:1.25 'Docker Pipeline'
  * doxygen:0.18 'Jenkins Doxygen Plug-in'
  * durable-task:1.35 'Durable Task Plugin'
  * echarts-api:4.9.0-2 'ECharts API Plugin'
  * envinject:2.3.0 'Environment Injector Plugin'
  * envinject-api:1.7 'EnvInject API Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * extra-columns:1.22 'Extra Columns Plugin'
  * fail-the-build-plugin:1.0 'Fail The Build Plugin'
  * favorite:2.3.2 'Favorite'
  * font-awesome-api:5.15.1-1 'Font Awesome API Plugin'
  * ghprb:1.42.1 'GitHub Pull Request Builder'
  * git:4.4.5 'Jenkins Git plugin'
  * git-client:3.5.1 'Jenkins Git client plugin'
  * git-server:1.9 'Jenkins GIT server Plugin'
  * github:1.32.0 'GitHub plugin'
  * github-api:1.116 *(update available)* 'GitHub API Plugin'
  * github-branch-source:2.9.1 'GitHub Branch Source Plugin'
  * gitlab-api:1.0.6 'Gitlab API Plugin'
  * gitlab-plugin:1.5.13 'GitLab Plugin'
  * global-build-stats:1.5 'Hudson global-build-stats plugin'
  * greenballs:1.15 'Green Balls'
  * growl:1.1 'Jenkins Growl Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * handy-uri-templates-2-api:2.1.8-1.0 'Handy Uri Templates 2.x API Plugin'
  * hipchat:2.2.1 'Jenkins HipChat Plugin'
  * htmlpublisher:1.24 *(update available)* 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.11.3 'Jackson 2 API Plugin'
  * javadoc:1.6 'Javadoc Plugin'
  * jdk-tool:1.4 'Oracle Java SE Development Kit Installer Plugin'
  * jenkins-design-language:1.24.3 'Jenkins Design Language'
  * jira:3.1.3 'Jenkins Jira plugin'
  * job-dsl:1.77 'Job DSL'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jquery3-api:3.5.1-2 'JQuery3 API Plugin'
  * jsch:0.1.55.2 'Jenkins JSch dependency plugin'
  * junit:1.44 'JUnit Plugin'
  * ldap:2.0 *(update available)* 'LDAP Plugin'
  * lockable-resources:2.10 'Lockable Resources plugin'
  * mailer:1.32.1 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:2.6.4 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.18 'Matrix Project Plugin'
  * maven-plugin:3.8 'Maven Integration plugin'
  * mercurial:2.12 'Jenkins Mercurial plugin'
  * metrics:4.0.2.6 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * next-build-number:1.6 'Next Build Number Plugin'
  * notification:1.13 'Jenkins Notification plugin'
  * okhttp-api:3.14.9 'OkHttp Plugin'
  * pam-auth:1.6 'PAM Authentication plugin'
  * pipeline-build-step:2.13 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.10 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.12 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.7.2 'Pipeline: Model API'
  * pipeline-model-definition:1.7.2 'Pipeline: Declarative'
  * pipeline-model-extensions:1.7.2 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.18 *(update available)* 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.5 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.7.2 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.18 *(update available)* 'Pipeline: Stage View Plugin'
  * plain-credentials:1.7 'Plain Credentials Plugin'
  * plugin-util-api:1.4.0 *(update available)* 'Plugin Utilities API Plugin'
  * popper-api:1.16.0-7 'Popper.js API Plugin'
  * publish-over:0.22 'Infrastructure plugin for Publish Over X'
  * publish-over-ftp:1.15 'Publish Over FTP'
  * pubsub-light:1.13 'Jenkins Pub-Sub "light" Bus'
  * ruby-runtime:0.13 'ruby-runtime'
  * scm-api:2.6.4 'SCM API Plugin'
  * script-security:1.75 'Script Security Plugin'
  * slack:2.44 'Slack Notification Plugin'
  * snakeyaml-api:1.27.0 'Snakeyaml API Plugin'
  * snsnotify:1.13 'Amazon SNS Build Notifier'
  * sse-gateway:1.24 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-agent:1.20 'SSH Agent Plugin'
  * ssh-credentials:1.18.1 'SSH Credentials Plugin'
  * ssh-slaves:1.31.2 'SSH Build Agents plugin'
  * structs:1.20 'Structs Plugin'
  * support-core:2.70 'Support Core Plugin'
  * token-macro:2.12 'Token Macro Plugin'
  * translation:1.16 'Jenkins Translation Assistance plugin'
  * trilead-api:1.0.12 'Trilead API Plugin'
  * variant:1.3 'Variant Plugin'
  * versionnumber:1.9 'Version Number Plug-In'
  * view-job-filters:2.3 'View Job Filters'
  * windows-slaves:1.7 'WMI Windows Agents Plugin'
  * workflow-aggregator:2.6 'Pipeline'
  * workflow-api:2.40 'Pipeline: API'
  * workflow-basic-steps:2.23 'Pipeline: Basic Steps'
  * workflow-cps:2.86 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.17 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.37 'Pipeline: Nodes and Processes'
  * workflow-job:2.40 'Pipeline: Job'
  * workflow-multibranch:2.22 'Pipeline: Multibranch'
  * workflow-scm-step:2.11 'Pipeline: SCM Step'
  * workflow-step-api:2.23 'Pipeline: Step API'
  * workflow-support:3.6 'Pipeline: Supporting APIs'
  * xcode-plugin:2.0.14 'Xcode integration'
  * xml-job-to-job-dsl:0.1.13 'XML Job to Job DSL Plugin'
  * xshell:0.10 'Jenkins cross-platform shell plugin'

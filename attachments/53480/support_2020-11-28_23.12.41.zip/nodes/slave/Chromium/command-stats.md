# Totals
* Writes: 1789
  * sent 12.9Mb
* Reads: 1881
  * received 1.0Mb
* Responses: 70
  * waited 17 sec

# Commands sent
* `Pipe.Chunk`: 1344
  * sent 11.3Mb
* `ProxyOutputStream.Ack`: 2
  * sent 0.0Mb
* `ProxyOutputStream.Unexport`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 220
  * sent 0.9Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 48
  * sent 0.4Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 4
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 19
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.writeJarTo[long,long,java.io.OutputStream]`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 13
  * sent 0.0Mb
* `Unexport`: 67
  * sent 0.1Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 4
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 2
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 4
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 4
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Exists`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$Read`: 3
  * sent 0.0Mb
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 3
  * sent 0.0Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 2
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 2
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 2
  * sent 0.0Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 2
  * sent 0.0Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 13
  * sent 0.0Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 2
  * received 0.0Mb
* `ProxyOutputStream.Ack`: 1346
  * received 0.2Mb
* `ProxyOutputStream.EOF`: 3
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 220
  * received 0.1Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch[java.lang.String]`: 48
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 4
  * received 0.0Mb
* `Response`: 70
  * received 0.2Mb
* `Unexport`: 156
  * received 0.2Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 19
  * received 0.1Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 13
  * received 0.0Mb

# Responses received
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 1
  * waited 5 ms
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 2.6 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 2
  * waited 90 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 2
  * waited 0.15 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 2
  * waited 0.11 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 2
  * waited 21 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 2
  * waited 56 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 2
  * waited 62 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 2
  * waited 0.91 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 4
  * waited 0.21 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 1
  * waited 23 ms
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 2
  * waited 0.38 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 4
  * waited 0.12 sec
* `UserRequest:hudson.FilePath$CallableWith`: 4
  * waited 0.31 sec
* `UserRequest:hudson.FilePath$Exists`: 1
  * waited 2.3 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 2
  * waited 59 ms
* `UserRequest:hudson.FilePath$Read`: 3
  * waited 0.44 sec
* `UserRequest:hudson.logging.LogRecorder$SetLevel`: 3
  * waited 0.21 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 2
  * waited 89 ms
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 2
  * waited 32 ms
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 2
  * waited 0.16 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 2
  * waited 6.2 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 13
  * waited 0.51 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 93 ms
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 1
  * waited 9 ms
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 92 ms
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 1 sec
* `UserRequest:jenkins.util.SystemProperties$AgentCopier$CopySystemProperties`: 1
  * waited 0.36 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 26 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 0.46 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsRetriever`: 1
  * waited 0.18 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 90 ms

# JARs sent

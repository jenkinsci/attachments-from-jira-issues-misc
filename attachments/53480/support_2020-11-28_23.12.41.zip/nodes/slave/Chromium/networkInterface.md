-----------
 * Name utun7
 ** Index - 19
 ** InetAddress - /fe80:0:0:0:db37:16e4:4f19:6e2d%utun7
 ** MTU - 1380
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name utun6
 ** Index - 18
 ** InetAddress - /fe80:0:0:0:34d8:a3fb:e681:f931%utun6
 ** MTU - 1380
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name utun5
 ** Index - 17
 ** InetAddress - /fe80:0:0:0:70c0:7183:94b0:1d4c%utun5
 ** MTU - 1380
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name utun4
 ** Index - 16
 ** InetAddress - /fe80:0:0:0:8b9b:c43e:6066:a4fd%utun4
 ** MTU - 1380
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name utun3
 ** Index - 15
 ** InetAddress - /fe80:0:0:0:49a0:21df:19cd:9e44%utun3
 ** MTU - 1380
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name utun2
 ** Index - 14
 ** InetAddress - /fe80:0:0:0:5af0:f48:6f0c:af2c%utun2
 ** MTU - 1380
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name utun1
 ** Index - 13
 ** InetAddress - /fe80:0:0:0:af0a:37a:8dc8:5097%utun1
 ** MTU - 2000
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name utun0
 ** Index - 12
 ** InetAddress - /fe80:0:0:0:55fb:5a5a:70fe:eb62%utun0
 ** MTU - 1380
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name llw0
 ** Hardware Address - 5ed662ef1ada
 ** Index - 11
 ** InetAddress - /fe80:0:0:0:5cd6:62ff:feef:1ada%llw0
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name awdl0
 ** Hardware Address - 5ed662ef1ada
 ** Index - 10
 ** InetAddress - /fe80:0:0:0:5cd6:62ff:feef:1ada%awdl0
 ** MTU - 1484
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name en1
 ** Hardware Address - 8c8590f0751a
 ** Index - 5
 ** InetAddress - /fc00:1234:5678:9abc:55e7:104d:dcc2:941f
 ** InetAddress - /2404:4408:1342:6e00:55e7:104d:dcc2:941f
 ** InetAddress - /fc00:1234:5678:9abc:ecc5:660d:28dd:68ad
 ** InetAddress - /2404:4408:1342:6e00:ecc5:660d:28dd:68ad
 ** InetAddress - /fc00:1234:5678:9abc:d18b:2db4:e57b:edb8
 ** InetAddress - /2404:4408:1342:6e00:d18b:2db4:e57b:edb8
 ** InetAddress - /fc00:1234:5678:9abc:fca1:5105:f838:867f
 ** InetAddress - /2404:4408:1342:6e00:fca1:5105:f838:867f
 ** InetAddress - /fc00:1234:5678:9abc:387d:5e96:8b38:1b83
 ** InetAddress - /2404:4408:1342:6e00:387d:5e96:8b38:1b83
 ** InetAddress - /fc00:1234:5678:9abc:812d:65a6:335c:98db
 ** InetAddress - /2404:4408:1342:6e00:812d:65a6:335c:98db
 ** InetAddress - /fc00:1234:5678:9abc:0:0:0:73b
 ** InetAddress - /fc00:1234:5678:9abc:bdf5:f584:9ad5:c4fe
 ** InetAddress - /fc00:1234:5678:9abc:c16:585c:abaa:ee2
 ** InetAddress - /2404:4408:1342:6e00:d598:4496:bcb4:24f9
 ** InetAddress - /2404:4408:1342:6e00:ac:b628:79fa:a491
 ** InetAddress - /fe80:0:0:0:4c6:d15c:a978:ba24%en1
 ** InetAddress - /192.168.0.24
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name en0
 ** Hardware Address - 787b8ab819d0
 ** Index - 4
 ** InetAddress - /fc00:1234:5678:9abc:b52b:10cc:6e1a:cb3c
 ** InetAddress - /2404:4408:1342:6e00:b52b:10cc:6e1a:cb3c
 ** InetAddress - /fc00:1234:5678:9abc:84b3:7c8a:50c6:9793
 ** InetAddress - /2404:4408:1342:6e00:84b3:7c8a:50c6:9793
 ** InetAddress - /fc00:1234:5678:9abc:7825:3512:e64a:8dc4
 ** InetAddress - /2404:4408:1342:6e00:7825:3512:e64a:8dc4
 ** InetAddress - /fc00:1234:5678:9abc:3ca4:2fa5:9c89:9b01
 ** InetAddress - /2404:4408:1342:6e00:3ca4:2fa5:9c89:9b01
 ** InetAddress - /fc00:1234:5678:9abc:9ccd:f1ca:6039:de56
 ** InetAddress - /fc00:1234:5678:9abc:10c5:ea7:2dc0:7b5d
 ** InetAddress - /2404:4408:1342:6e00:3d13:a084:f5ce:6762
 ** InetAddress - /2404:4408:1342:6e00:180a:e89d:b286:7092
 ** InetAddress - /fe80:0:0:0:1c60:7f60:a8cb:deb1%en0
 ** InetAddress - /192.168.0.24
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo0
 ** Index - 1
 ** InetAddress - /fe80:0:0:0:0:0:0:1%lo0
 ** InetAddress - /0:0:0:0:0:0:0:1
 ** InetAddress - /127.0.0.1
 ** MTU - 16384
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true

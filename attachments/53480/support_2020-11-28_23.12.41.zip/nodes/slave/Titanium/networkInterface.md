-----------
 * Name utun3
 ** Index - 14
 ** InetAddress - /fe80:0:0:0:a3bf:4eec:c260:8563%utun3
 ** MTU - 1380
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name utun2
 ** Index - 13
 ** InetAddress - /fe80:0:0:0:3769:c81f:93dd:fce0%utun2
 ** MTU - 1380
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name utun1
 ** Index - 12
 ** InetAddress - /fe80:0:0:0:5dc2:999e:85fe:3d2b%utun1
 ** MTU - 2000
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name utun0
 ** Index - 11
 ** InetAddress - /fe80:0:0:0:3e2c:5e3:6789:38ff%utun0
 ** MTU - 1380
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name en0
 ** Hardware Address - 10ddb1c3ca3a
 ** Index - 8
 ** InetAddress - /fc00:1234:5678:9abc:d5c4:7a79:af38:b1b4
 ** InetAddress - /2404:4408:1342:6e00:d5c4:7a79:af38:b1b4
 ** InetAddress - /fc00:1234:5678:9abc:e89c:558c:e24f:4b46
 ** InetAddress - /2404:4408:1342:6e00:e89c:558c:e24f:4b46
 ** InetAddress - /fc00:1234:5678:9abc:30b3:b6a2:c734:a0dd
 ** InetAddress - /2404:4408:1342:6e00:30b3:b6a2:c734:a0dd
 ** InetAddress - /fc00:1234:5678:9abc:a0d1:501c:d281:228
 ** InetAddress - /2404:4408:1342:6e00:a0d1:501c:d281:228
 ** InetAddress - /fc00:1234:5678:9abc:e4ac:3913:5923:cdd7
 ** InetAddress - /fc00:1234:5678:9abc:182c:85c0:172f:a5a3
 ** InetAddress - /2404:4408:1342:6e00:48f6:8a1c:264a:9219
 ** InetAddress - /2404:4408:1342:6e00:1cd7:8f0e:e401:7cd1
 ** InetAddress - /fc00:1234:5678:9abc:0:0:0:23
 ** InetAddress - /fe80:0:0:0:866:af78:90cb:d83%en0
 ** InetAddress - /192.168.0.23
 ** InetAddress - /192.168.0.22
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo0
 ** Index - 1
 ** InetAddress - /fe80:0:0:0:0:0:0:1%lo0
 ** InetAddress - /0:0:0:0:0:0:0:1
 ** InetAddress - /127.0.0.1
 ** MTU - 16384
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true

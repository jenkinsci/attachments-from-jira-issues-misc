-----------
 * Name eth1
 ** Hardware Address - 902b34d0469d
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:922b:34ff:fed0:469d%eth1
 ** InetAddress - /fc00:1234:5678:9abc:0:0:0:8%eth1
 ** InetAddress - /fc00:1234:5678:9abc:0:0:0:9%eth1
 ** InetAddress - /fc00:1234:5678:9abc:0:0:0:6%eth1
 ** InetAddress - /192.168.0.9
 ** InetAddress - /192.168.0.8
 ** InetAddress - /192.168.0.6
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

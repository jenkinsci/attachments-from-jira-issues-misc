Loggers currently enabled
=========================
com.cloudbees.jenkins.plugins.BitbucketJobProbe - ALL
com.cloudbees.jenkins.plugins.BitbucketPayloadProcessor - ALL
org.apache.sshd - WARNING
winstone - INFO
com.cloudbees.jenkins.plugins.BitbucketHookReceiver - ALL
 - INFO

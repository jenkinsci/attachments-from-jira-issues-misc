 * Authenticated User Count: 3

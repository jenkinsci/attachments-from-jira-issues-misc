Node statistics
===============

  * Total number of nodes
      - Sample size:        1839
      - Average (mean):     0.9999999999999998
      - Average (median):   1.0
      - Standard deviation: 2.2204460492503128E-16
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of nodes online
      - Sample size:        1839
      - Average (mean):     0.9999999999999999
      - Average (median):   1.0
      - Standard deviation: 1.1102230246251564E-16
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        1839
      - Average (mean):     0.9999999999999999
      - Average (median):   1.0
      - Standard deviation: 1.1102230246251564E-16
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors in use
      - Sample size:        1839
      - Average (mean):     5.804154218554004E-42
      - Average (median):   0.0
      - Standard deviation: 2.4091812340614816E-21
      - Minimum:            0
      - Maximum:            1
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      0
      - FS root:        `/var/vcap/store/jenkins_master`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Java
          + Home:           `/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_65-
          + Maximum memory:   459.00 MB (481296384)
          + Allocated memory: 331.00 MB (347078656)
          + Free memory:      121.45 MB (127348104)
          + In-use memory:    209.55 MB (219730552)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.65-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.19.0-33-generic
          + Distribution: Ubuntu 14.04.3 LTS
      - Process ID: 4173 (0x104d)
      - Process started: 2015-11-30 11:18:56.718+0000
      - Process uptime: 7 hr 40 min
      - JVM startup parameters:
          + Boot classpath: `/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/lib/resources.jar:/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/lib/rt.jar:/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/lib/sunrsasign.jar:/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/lib/jsse.jar:/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/lib/jce.jar:/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/lib/charsets.jar:/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/lib/jfr.jar:/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/classes`
          + Classpath: `/var/vcap/packages/jenkins/jenkins.war`
          + Library path: `/var/vcap/packages/ruby/lib:/var/vcap/packages/openjdk-8/lib:/var/vcap/packages/maven/lib:/var/vcap/packages/git/lib:/var/vcap/packages/fontconfig/lib::/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx516m`
          + arg[1]: `-Dhudson.TcpSlaveAgentListener.hostName=10.0.16.64`
          + arg[2]: `-Djava.io.tmpdir=/var/vcap/sys/tmp/jenkins_master`
          + arg[3]: `-Djava.awt.headless=true`

  * 10.0.16.65 (built-in) (`hudson.slaves.DumbSlave`)
      - Description:    _Built-in slave_
      - Executors:      1
      - Remote FS root: `/var/vcap/data/jenkins_slave`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Launch method:  `com.cloudbees.jenkins.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53.1
      - Java
          + Home:           `/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_65-
          + Maximum memory:   837.50 MB (878182400)
          + Allocated memory: 49.00 MB (51380224)
          + Free memory:      20.99 MB (22014824)
          + In-use memory:    28.01 MB (29365400)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.65-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.19.0-33-generic
          + Distribution: Ubuntu 14.04.3 LTS
      - Process ID: 8613 (0x21a5)
      - Process started: 2015-11-30 11:19:22.267+0000
      - Process uptime: 7 hr 39 min
      - JVM startup parameters:
          + Boot classpath: `/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/lib/resources.jar:/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/lib/rt.jar:/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/lib/sunrsasign.jar:/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/lib/jsse.jar:/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/lib/jce.jar:/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/lib/charsets.jar:/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/lib/jfr.jar:/var/vcap/data/packages/openjdk-8/e7b298f2025dd7c929c24eaf6a75e12208f9dd56.1-daff9d8b8fe7997bd92988ade29e2bd630f04260/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.io.tmpdir=/var/vcap/data/jenkins_slave/tmp`


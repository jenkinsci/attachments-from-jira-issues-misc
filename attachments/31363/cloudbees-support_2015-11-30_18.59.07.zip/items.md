Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 12
    - Number of items per container: 1.75 [n=12, s=3.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 14
    - Number of builds per job: 3.642857142857143 [n=14, s=3.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 6
    - Number of builds per job: 7.0 [n=6, s=6.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 1
    - Number of items per container: 1 [n=1]

Total job statistics
======================

  * Number of jobs: 20
  * Number of builds per job: 4.65 [n=20, s=4.0]

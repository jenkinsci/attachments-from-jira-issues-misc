User
====

Authentication
--------------

  * Authenticated: false
  * Name: admin
  * Authorities 
      - `authenticated`
      - `cloud_controller.admin`
      - `system`
      - `cloudbees`
      - `pivotal`
  * Raw: `com.cloudfoundry.jenkins.cloudfoundryoauth.UaaAuthenticationToken@20454228: Username: admin; Password: [PROTECTED]; Authenticated: false; Details: org.acegisecurity.ui.WebAuthenticationDetails@ffffc434: RemoteIpAddress: 176.183.153.61; SessionId: 1sfcj5rp0rc7dl5zepuvdb5r5; Granted Authorities: authenticated, cloud_controller.admin, system, cloudbees, pivotal`


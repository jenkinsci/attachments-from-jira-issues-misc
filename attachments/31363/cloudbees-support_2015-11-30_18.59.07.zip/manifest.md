CloudBees Support Bundle Manifest
=================================

Generated on 2015-11-30 18:59:07.410+0000

Requested components:

  * Log Recorders

      - `nodes/master/logs/all_2015-11-23_11.44.35.log`

      - `nodes/master/logs/all_2015-11-23_11.50.55.log`

      - `nodes/master/logs/all_2015-11-24_18.21.38.log`

      - `nodes/master/logs/all_2015-11-25_14.01.27.log`

      - `nodes/master/logs/all_2015-11-26_11.47.36.log`

      - `nodes/master/logs/all_2015-11-26_14.52.18.log`

      - `nodes/master/logs/all_2015-11-26_14.53.36.log`

      - `nodes/master/logs/all_2015-11-30_11.19.03.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `nodes/slave/10.0.16.65 (built-in)/jenkins.log`

      - `nodes/slave/10.0.16.65 (built-in)/launchLogs/slave.log`

      - `nodes/slave/10.0.16.65 (built-in)/launchLogs/slave.log.1`

      - `nodes/slave/10.0.16.65 (built-in)/logs/all_2015-11-26_11.54.45.log`

      - `nodes/slave/10.0.16.65 (built-in)/logs/all_2015-11-26_14.52.33.log`

      - `nodes/slave/10.0.16.65 (built-in)/logs/all_2015-11-26_14.52.37.log`

      - `nodes/slave/10.0.16.65 (built-in)/logs/all_2015-11-26_14.53.52.log`

      - `nodes/slave/10.0.16.65 (built-in)/logs/all_2015-11-26_14.53.58.log`

      - `nodes/slave/10.0.16.65 (built-in)/logs/all_2015-11-30_11.19.17.log`

      - `nodes/slave/10.0.16.65 (built-in)/logs/all_2015-11-30_11.19.23.log`

      - `nodes/slave/10.0.16.65 (built-in)/logs/all_memory_buffer.log`

      - `other-logs/Download metadata.log`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/SharedConfigurationSynchronizer.log`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/com.cloudbees.opscenter.client.cloud.CloudImpl$PeriodicWorkImpl.log`

      - `other-logs/jenkins.metrics.api.Metrics$HealthChecker.log`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/10.0.16.65 (built-in)/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/10.0.16.65 (built-in)/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/10.0.16.65 (built-in)/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/10.0.16.65 (built-in)/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/10.0.16.65 (built-in)/proc/meminfo.txt`

      - `nodes/slave/10.0.16.65 (built-in)/proc/self/cmdline`

      - `nodes/slave/10.0.16.65 (built-in)/proc/self/environ`

      - `nodes/slave/10.0.16.65 (built-in)/proc/self/limits.txt`

      - `nodes/slave/10.0.16.65 (built-in)/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/10.0.16.65+%28built-in%29/gnuplot`

      - `load-stats/label/10.0.16.65+%28built-in%29/hour.csv`

      - `load-stats/label/10.0.16.65+%28built-in%29/min.csv`

      - `load-stats/label/10.0.16.65+%28built-in%29/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/10.0.16.65 (built-in)/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/10.0.16.65 (built-in)/networkInterface.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/10.0.16.65 (built-in)/dmesg.txt`

      - `nodes/slave/10.0.16.65 (built-in)/dmi.txt`

      - `nodes/slave/10.0.16.65 (built-in)/proc/cpuinfo.txt`

      - `nodes/slave/10.0.16.65 (built-in)/proc/mounts.txt`

      - `nodes/slave/10.0.16.65 (built-in)/proc/swaps.txt`

      - `nodes/slave/10.0.16.65 (built-in)/proc/system-uptime.txt`

      - `nodes/slave/10.0.16.65 (built-in)/sysctl.txt`

      - `nodes/slave/10.0.16.65 (built-in)/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/10.0.16.65 (built-in)/system.properties`

  * Slow Request Records

      - `slow-requests/20151104-170051.780.txt`

      - `slow-requests/20151123-115830.241.txt`

      - `slow-requests/20151123-192627.241.txt`

      - `slow-requests/20151124-175618.241.txt`

      - `slow-requests/20151124-175624.241.txt`

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/10.0.16.65 (built-in)/thread-dump.txt`


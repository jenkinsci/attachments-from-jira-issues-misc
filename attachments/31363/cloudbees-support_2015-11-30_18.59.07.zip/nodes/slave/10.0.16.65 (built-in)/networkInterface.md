-----------
 * Name docker0
 ** Hardware Address - 0242a0c85fa8
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:42:a0ff:fec8:5fa8%docker0
 ** InetAddress - /172.17.42.1
 ** MTU - 9001
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 0e09f125f5bd
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:c09:f1ff:fe25:f5bd%eth0
 ** InetAddress - /10.0.16.65
 ** MTU - 9001
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

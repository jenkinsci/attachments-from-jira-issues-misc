CloudBees Support Bundle Manifest
=================================

Generated on 2014-01-31 02:19:44 -0500

Requested components:

  * About Jenkins

      - `about.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/Deploy-101/checksums.md5`

      - `nodes/slave/Java-002/checksums.md5`

      - `nodes/slave/dotNET-005/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/Deploy-101/environment.txt`

      - `nodes/slave/Java-002/environment.txt`

      - `nodes/slave/dotNET-005/environment.txt`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/Deploy-101/metrics.json`

      - `nodes/slave/Java-002/metrics.json`

      - `nodes/slave/dotNET-005/metrics.json`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/Deploy-101/system.properties`

      - `nodes/slave/Java-002/system.properties`

      - `nodes/slave/dotNET-005/system.properties`


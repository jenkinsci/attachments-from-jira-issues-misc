/** 
 * Just here so we can create a HPI
 */
public class HelloWorld {   
}
-----------
 * Name docker0
 ** Hardware Address - 56847afe9799
 ** Index - 3
 ** InetAddress - /172.17.42.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 0a9f9748b4d8
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:89f:97ff:fe48:b4d8%eth0
 ** InetAddress - /172.30.0.20
 ** MTU - 9001
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

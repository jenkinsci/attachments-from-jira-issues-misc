User
====

Authentication
--------------

  * Authenticated: true
  * Name: admin
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@15aaf0c3: Username: hudson.security.HudsonPrivateSecurityRealm$Details@79845932; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@ffffe21a: RemoteIpAddress: 172.18.64.72; SessionId: 1pic5pfs5ssnmb9tarc6dsjhy; Granted Authorities: authenticated`


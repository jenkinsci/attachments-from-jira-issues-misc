Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 2
    - Number of items per container: 6.0 [n=2, s=4.0]
  * `jenkins.branch.OrganizationFolder`
    - Number of items: 3
    - Number of items per container: 3.0 [n=3, s=1.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 24
    - Number of builds per job: 1.2916666666666667 [n=24, s=0.7]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 18
    - Number of items per container: 1.3333333333333333 [n=18, s=2.0]

Total job statistics
======================

  * Number of jobs: 24
  * Number of builds per job: 1.2916666666666667 [n=24, s=0.7]

package com.test1.child2;

public class Class2 {
}


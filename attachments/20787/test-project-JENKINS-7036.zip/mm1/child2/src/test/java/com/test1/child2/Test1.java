package com.test1.child2;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class Test1 {

    public Test1() {
        //throw new NoClassDefFoundError();
    }
    
    @Before
    public void before() {
        throw new NoClassDefFoundError();
    }
    
    @Test
    public void test() {
        //Assert.fail();
    }
}

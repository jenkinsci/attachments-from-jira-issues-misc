$ErrorActionPreference = 'Stop'
& $PSScriptRoot\master\run.ps1
& $PSScriptRoot\slave\run.ps1
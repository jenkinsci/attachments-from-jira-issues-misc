param(
  [string] $JenkinsUrl = "http://$([System.Net.Dns]::GetHostByName($env:COMPUTERNAME).HostName):8080"
)

$ErrorActionPreference = 'Stop'

docker build --tag test/jenkins-slave --build-arg JENKINS_URL=$JenkinsUrl $PSScriptRoot

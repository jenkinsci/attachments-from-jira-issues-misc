
if (!(Test-Path "C:\ProgramData\Jenkins\workspace\deadlock-pipeline"))
{
    Write-Error "C:\ProgramData\Jenkins\workspace\deadlock-pipeline doesn't exist. Please create it manually on the Docker host machine, and remove this check if docker doesn't run locally!"
}

if (!(Test-Path "C:\ProgramData\Jenkins\workspace\deadlock-pipeline@tmp"))
{
    Write-Error "C:\ProgramData\Jenkins\workspace\deadlock-pipeline@tmp doesn't exist. Please create it manually on the Docker host machine, and remove this check if docker doesn't run locally!"
}

docker run -it --rm -d -v //./pipe/docker_engine://./pipe/docker_engine test/jenkins-slave

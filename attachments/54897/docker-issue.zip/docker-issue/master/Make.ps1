param(
  [string] $JenkinsUrl = "http://$([System.Net.Dns]::GetHostByName($env:COMPUTERNAME).HostName):8080"
)

$ErrorActionPreference = 'Stop'

docker build -t test/jenkins-master --build-arg JENKINS_URL=$JenkinsUrl $PSScriptRoot
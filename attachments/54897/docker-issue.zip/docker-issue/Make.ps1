param(
  [string] $JenkinsUrl = "http://$([System.Net.Dns]::GetHostByName($env:COMPUTERNAME).HostName):8080"
)

$ErrorActionPreference = 'Stop'

& $PSScriptRoot\master\Make.ps1 -JenkinsUrl $JenkinsUrl
& $PSScriptRoot\slave\Make.ps1 -JenkinsUrl $JenkinsUrl
Item statistics
===============

  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 26
    - Number of builds per job: 105.5 [n=26, s=100.0]
  * `hudson.matrix.MatrixProject`
    - Number of items: 5
    - Number of builds per job: 55.2 [n=5, s=90.0]
    - Number of items per container: 5.2 [n=5, s=8.0]
  * `hudson.maven.MavenModule`
    - Number of items: 1
    - Number of builds per job: 99 [n=1]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 1
    - Number of builds per job: 100 [n=1]
    - Number of items per container: 1 [n=1]
  * `hudson.model.FreeStyleProject`
    - Number of items: 1412
    - Number of builds per job: 253.4957507082153 [n=1412, s=8625.051111218829]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 25
    - Number of builds per job: 23.08 [n=25, s=30.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 3
    - Number of items per container: 1.3333333333333333 [n=3, s=2.0]

Total job statistics
======================

  * Number of jobs: 1470
  * Number of builds per job: 246.07551020408164 [n=1470, s=8453.161174766206]

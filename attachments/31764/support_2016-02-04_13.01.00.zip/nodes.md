Node statistics
===============

  * Total number of nodes
      - Sample size:        56158
      - Average (mean):     12.336718466870543
      - Average (median):   12.0
      - Standard deviation: 0.7317313621066125
      - Minimum:            8
      - Maximum:            27
      - 95th percentile:    14.0
      - 99th percentile:    15.0
  * Total number of nodes online
      - Sample size:        56158
      - Average (mean):     11.296519086106175
      - Average (median):   11.0
      - Standard deviation: 0.6738524893994737
      - Minimum:            7
      - Maximum:            26
      - 95th percentile:    13.0
      - 99th percentile:    14.0
  * Total number of executors
      - Sample size:        56158
      - Average (mean):     22.296519086106173
      - Average (median):   22.0
      - Standard deviation: 0.6738524893994737
      - Minimum:            18
      - Maximum:            37
      - 95th percentile:    24.0
      - 99th percentile:    25.0
  * Total number of executors in use
      - Sample size:        56158
      - Average (mean):     6.478438682958296
      - Average (median):   7.0
      - Standard deviation: 1.2730680937098733
      - Minimum:            1
      - Maximum:            24
      - 95th percentile:    8.0
      - 99th percentile:    8.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      4
      - FS root:        `/ic/.jenkins`
      - Labels:         master linux x64
      - Usage:          `NORMAL`
      - Slave Version:  2.53
      - Java
          + Home:           `/ic/logiciels/jdk1.8.0_25/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_25
          + Maximum memory:   2,44 GB (2621440000)
          + Allocated memory: 2,44 GB (2621440000)
          + Free memory:      929,71 MB (974870728)
          + In-use memory:    1,53 GB (1646569272)
          + GC strategy:      G1
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.25-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-431.17.1.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.0 (Santiago)"
          + LSB Modules:  `:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 9826 (0x2662)
      - Process started: 2016-01-25 20:00:33.511+0100
      - Process uptime: 9 days 18 hr
      - JVM startup parameters:
          + Boot classpath: `/ic/logiciels/jdk1.8.0_25/jre/lib/resources.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/rt.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/sunrsasign.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/jsse.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/jce.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/charsets.jar:/ic/logiciels/jdk1.8.0_25/jre/lib/jfr.jar:/ic/logiciels/jdk1.8.0_25/jre/classes`
          + Classpath: `/ic/scripts/../jenkins-1.625.2.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dhudson.TcpSlaveAgentListener.hostName=ic.mipih.net`
          + arg[1]: `-XX:+UseG1GC`
          + arg[2]: `-XX:+HeapDumpOnOutOfMemoryError`
          + arg[3]: `-XX:HeapDumpPath=/ic/jenkins-heapdump.hprof`
          + arg[4]: `-XX:OnError=t_alert_admin.sh "ERROR JVM sur le Jenkins de PROD --> A TRAITER EN URGENCE !"`
          + arg[5]: `-XX:OnOutOfMemoryError=t_alert_admin.sh "OOME sur le Jenkins de PROD --> A TRAITER EN URGENCE !"`
          + arg[6]: `-Dcom.sun.management.jmxremote.port=3334`
          + arg[7]: `-Dcom.sun.management.jmxremote.authenticate=false`
          + arg[8]: `-Dcom.sun.management.jmxremote.ssl=false`
          + arg[9]: `-Xmx2500m`
          + arg[10]: `-XX:+PrintGCTimeStamps`
          + arg[11]: `-Xloggc:/ic/.jenkins-gclog/gc.log`
          + arg[12]: `-XX:+PrintGCDetails`
          + arg[13]: `-Djava.io.tmpdir=/ic/tmp`

  * aix-1 (`hudson.slaves.DumbSlave`)
      - Description:    _Esclave AIX_
      - Executors:      4
      - Remote FS root: `/ic/.jenkins`
      - Labels:         aix continuous_deployment
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `/usr/java7_64/jre`
          + Vendor:           IBM Corporation
          + Version:          1.7.0
          + Maximum memory:   300.00 MB (314572800)
          + Allocated memory: 125.19 MB (131268608)
          + Free memory:      46.32 MB (48572392)
          + In-use memory:    78.87 MB (82696216)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Sun Microsystems Inc.
          + Version: 1.0
      - JVM Implementation
          + Name:    IBM J9 VM
          + Vendor:  IBM Corporation
          + Version: 2.6
      - Operating system
          + Name:         AIX
          + Architecture: ppc64
          + Version:      6.1
      - Process ID: 32440510 (0x1ef00be)
      - Process started: 2016-01-25 20:01:20.486+0100
      - Process uptime: 9 days 17 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/java7_64/jre/lib/ppc64/compressedrefs/jclSC170/vm.jar:/usr/java7_64/jre/lib/se-service.jar:/usr/java7_64/jre/lib/math.jar:/usr/java7_64/jre/lib/jlm.jar:/usr/java7_64/jre/lib/ibmorb.jar:/usr/java7_64/jre/lib/ibmorbapi.jar:/usr/java7_64/jre/lib/ibmcfw.jar:/usr/java7_64/jre/lib/ibmpkcs.jar:/usr/java7_64/jre/lib/ibmcertpathfw.jar:/usr/java7_64/jre/lib/ibmjgssfw.jar:/usr/java7_64/jre/lib/ibmjssefw.jar:/usr/java7_64/jre/lib/ibmsaslfw.jar:/usr/java7_64/jre/lib/ibmjcefw.jar:/usr/java7_64/jre/lib/ibmjgssprovider.jar:/usr/java7_64/jre/lib/ibmjsseprovider2.jar:/usr/java7_64/jre/lib/ibmcertpathprovider.jar:/usr/java7_64/jre/lib/xmldsigfw.jar:/usr/java7_64/jre/lib/xml.jar:/usr/java7_64/jre/lib/charsets.jar:/usr/java7_64/jre/lib/resources.jar:/usr/java7_64/jre/lib/rt.jar`
          + Classpath: `slave.jar`
          + Library path: `/usr/java7_64/jre/lib/ppc64/compressedrefs:/usr/java7_64/jre/lib/ppc64:/usr/java7_64/jre/lib/ppc64:/usr/java7_64/jre/lib/ppc64/compressedrefs:/usr/java7_64/jre/lib/ppc64/j9vm:/usr/java7_64/jre/lib/ppc64:/usr/java7_64/jre/../lib/ppc64:/usr/lib:/usr/lib`
          + arg[0]: `-Xoptionsfile=/usr/java7_64/jre/lib/ppc64/compressedrefs/options.default`
          + arg[1]: `-Xlockword:mode=default,noLockword=java/lang/String,noLockword=java/util/MapEntry,noLockword=java/util/HashMap$Entry,noLockword=org/apache/harmony/luni/util/ModifiedMap$Entry,noLockword=java/util/Hashtable$Entry,noLockword=java/lang/invoke/MethodType,noLockword=java/lang/invoke/MethodHandle,noLockword=java/lang/invoke/CollectHandle,noLockword=java/lang/invoke/ConstructorHandle,noLockword=java/lang/invoke/ConvertHandle,noLockword=java/lang/invoke/ArgumentConversionHandle,noLockword=java/lang/invoke/AsTypeHandle,noLockword=java/lang/invoke/ExplicitCastHandle,noLockword=java/lang/invoke/FilterReturnHandle,noLockword=java/lang/invoke/DirectHandle,noLockword=java/lang/invoke/ReceiverBoundHandle,noLockword=java/lang/invoke/DynamicInvokerHandle,noLockword=java/lang/invoke/FieldHandle,noLockword=java/lang/invoke/FieldGetterHandle,noLockword=java/lang/invoke/FieldSetterHandle,noLockword=java/lang/invoke/StaticFieldGetterHandle,noLockword=java/lang/invoke/StaticFieldSetterHandle,noLockword=java/lang/invoke/IndirectHandle,noLockword=java/lang/invoke/InterfaceHandle,noLockword=java/lang/invoke/VirtualHandle,noLockword=java/lang/invoke/InvokeExactHandle,noLockword=java/lang/invoke/InvokeGenericHandle,noLockword=java/lang/invoke/VarargsCollectorHandle,noLockword=java/lang/invoke/ThunkTuple`
          + arg[2]: `-Xjcl:jclse7b_26`
          + arg[3]: `-Dcom.ibm.oti.vm.bootstrap.library.path=/usr/java7_64/jre/lib/ppc64/compressedrefs:/usr/java7_64/jre/lib/ppc64`
          + arg[4]: `-Dsun.boot.library.path=/usr/java7_64/jre/lib/ppc64/compressedrefs:/usr/java7_64/jre/lib/ppc64`
          + arg[5]: `-Djava.library.path=/usr/java7_64/jre/lib/ppc64/compressedrefs:/usr/java7_64/jre/lib/ppc64:/usr/java7_64/jre/lib/ppc64:/usr/java7_64/jre/lib/ppc64/compressedrefs:/usr/java7_64/jre/lib/ppc64/j9vm:/usr/java7_64/jre/lib/ppc64:/usr/java7_64/jre/../lib/ppc64:/usr/lib:/usr/lib`
          + arg[6]: `-Djava.home=/usr/java7_64/jre`
          + arg[7]: `-Djava.ext.dirs=/usr/java7_64/jre/lib/ext`
          + arg[8]: `-Duser.dir=/ic/.jenkins`
          + arg[9]: `-Djava.runtime.version=pap6470sr5-20130619_01 (SR5)`
          + arg[10]: `-Djava.class.path=.`
          + arg[11]: `-Xmx300m`
          + arg[12]: `-Xgcpolicy:gencon`
          + arg[13]: `-Xverbosegclog:/ic/loggc/gc#.log,20,10000`
          + arg[14]: `-Djava.class.path=slave.jar`
          + arg[15]: `-Dsun.java.command=slave.jar`
          + arg[16]: `-Dsun.java.launcher=SUN_STANDARD`

  * docker-62319112def6-sv-t-vnl-ic-centos7-2.mipih.net (`com.nirima.jenkins.plugins.docker.DockerSwarmSlave`)
      - Description:    _Docker Node [docker-registry.mipih.net/forge/centos6-jenkins-slave:3 on docker]_
      - Executors:      1
      - Remote FS root: `/iclinux/.jenkins`
      - Labels:         rhel docker-rhel linux x64
      - Usage:          `NORMAL`
      - Launch method:  `com.nirima.jenkins.plugins.docker.launcher.DockerComputerSSHLauncher`
      - Availability:   `com.nirima.jenkins.plugins.docker.strategy.DockerOnceRetentionStrategy`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_65
          + Maximum memory:   622,50 MB (652738560)
          + Allocated memory: 303,50 MB (318242816)
          + Free memory:      248,06 MB (260113640)
          + In-use memory:    55,44 MB (58129176)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.65-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.3.0-1.el7.elrepo.x86_64
      - Process ID: 79 (0x4f)
      - Process started: 2016-02-04 13:58:13.420+0100
      - Process uptime: 2 mn 53 s
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/iclinux/oracle-instantclient-11.2::/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-XX:MaxPermSize=500m`
          + arg[1]: `-Xmx700m`

  * docker-93b8ebee37cd-sv-t-vnl-ic-centos7-3.mipih.net (`com.nirima.jenkins.plugins.docker.DockerSwarmSlave`)
      - Description:    _Docker Node [docker-registry.mipih.net/forge/centos6-jenkins-slave:3 on docker]_
      - Executors:      1
      - Remote FS root: `/iclinux/.jenkins`
      - Labels:         docker-super-build super-build linux x64 super-release release
      - Usage:          `NORMAL`
      - Launch method:  `com.nirima.jenkins.plugins.docker.launcher.DockerComputerSSHLauncher`
      - Availability:   `com.nirima.jenkins.plugins.docker.strategy.DockerOnceRetentionStrategy`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_65
          + Maximum memory:   622,50 MB (652738560)
          + Allocated memory: 446,50 MB (468189184)
          + Free memory:      314,69 MB (329974368)
          + In-use memory:    131,81 MB (138214816)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.65-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.3.0-1.el7.elrepo.x86_64
      - Process ID: 92 (0x5c)
      - Process started: 2016-02-04 13:56:23.600+0100
      - Process uptime: 4 mn 43 s
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/iclinux/oracle-instantclient-11.2::/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-XX:MaxPermSize=500m`
          + arg[1]: `-Xmx700m`

  * docker-aa0aa0aa315f-sv-t-vnl-ic-centos7-1.mipih.net (`com.nirima.jenkins.plugins.docker.DockerSwarmSlave`)
      - Description:    _Docker Node [docker-registry.mipih.net/forge/centos6-jenkins-slave:3 on docker]_
      - Executors:      1
      - Remote FS root: `/iclinux/.jenkins`
      - Labels:         rhel docker-rhel linux x64
      - Usage:          `NORMAL`
      - Launch method:  `com.nirima.jenkins.plugins.docker.launcher.DockerComputerSSHLauncher`
      - Availability:   `com.nirima.jenkins.plugins.docker.strategy.DockerOnceRetentionStrategy`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_65
          + Maximum memory:   622,50 MB (652738560)
          + Allocated memory: 303,50 MB (318242816)
          + Free memory:      107,81 MB (113048216)
          + In-use memory:    195,69 MB (205194600)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.65-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.3.0-1.el7.elrepo.x86_64
      - Process ID: 80 (0x50)
      - Process started: 2016-02-04 13:26:23.387+0100
      - Process uptime: 34 mn
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/iclinux/oracle-instantclient-11.2::/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-XX:MaxPermSize=500m`
          + arg[1]: `-Xmx700m`

  * docker-d2cfa59a731e-sv-t-vnl-ic-centos7-2.mipih.net (`com.nirima.jenkins.plugins.docker.DockerSwarmSlave`)
      - Description:    _Docker Node [docker-registry.mipih.net/forge/centos6-jenkins-slave:3 on docker]_
      - Executors:      1
      - Remote FS root: `/iclinux/.jenkins`
      - Labels:         rhel docker-rhel linux x64
      - Usage:          `NORMAL`
      - Launch method:  `com.nirima.jenkins.plugins.docker.launcher.DockerComputerSSHLauncher`
      - Availability:   `com.nirima.jenkins.plugins.docker.strategy.DockerOnceRetentionStrategy`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_65
          + Maximum memory:   622,50 MB (652738560)
          + Allocated memory: 303,50 MB (318242816)
          + Free memory:      153,44 MB (160893600)
          + In-use memory:    150,06 MB (157349216)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.65-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.3.0-1.el7.elrepo.x86_64
      - Process ID: 80 (0x50)
      - Process started: 2016-02-04 13:58:23.604+0100
      - Process uptime: 2 mn 43 s
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/iclinux/oracle-instantclient-11.2::/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-XX:MaxPermSize=500m`
          + arg[1]: `-Xmx700m`

  * rhel-ferrari (`hudson.slaves.DumbSlave`)
      - Description:    _Machine d'integration LINUX_
      - Executors:      1
      - Remote FS root: `/home/mipinst/.jenkins`
      - Labels:         linux x64 super-build super-release
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

  * rhel6-ssh-12 (`hudson.slaves.DumbSlave`)
      - Description:    _Machine d'integration RHEL_
      - Executors:      6
      - Remote FS root: `/iclinux/.jenkins`
      - Labels:         ssh linux x64 continuous_deployment acces_esx JENKINS-30084
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_65
          + Maximum memory:   676,69 MB (709558272)
          + Allocated memory: 68,23 MB (71548928)
          + Free memory:      40,87 MB (42851896)
          + In-use memory:    27,37 MB (28697032)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.65-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-71.18.2.el6.x86_64
          + Distribution: "Red Hat Enterprise Linux Server release 6.0 (Santiago)"
          + LSB Modules:  `:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 58729 (0xe569)
      - Process started: 2016-01-25 20:01:30.553+0100
      - Process uptime: 9 j 17 h
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-0.b17.el6_7.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/iclinux/oracle-instantclient-11.2::/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-XX:MaxPermSize=500m`
          + arg[1]: `-Xmx700m`

  * rhel7-1 (`hudson.slaves.DumbSlave`)
      - Description:    _Machine d'integration RHEL_
      - Executors:      1
      - Remote FS root: `/iclinux/.jenkins`
      - Labels:         docker linux x64
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_65
          + Maximum memory:   622,50 MB (652738560)
          + Allocated memory: 151,00 MB (158334976)
          + Free memory:      115,13 MB (120722496)
          + In-use memory:    35,87 MB (37612480)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.65-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.2.0-1.el7.elrepo.x86_64
      - Process ID: 13878 (0x3636)
      - Process started: 2016-01-25 20:01:20.120+0100
      - Process uptime: 9 j 17 h
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.65-3.b17.el7.x86_64/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/iclinux/oracle-instantclient-11.2::/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-XX:MaxPermSize=500m`
          + arg[1]: `-Xmx700m`

  * windows7-3 (`hudson.slaves.DumbSlave`)
      - Description:    _Windows7 - Selenium_
      - Executors:      1
      - Remote FS root: `c:\ic`
      - Labels:         windows selenium chrome seven x64 mdmia winN2J
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `C:\pgih\jdk\1.7.0-x64\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_45
          + Maximum memory:   910,50 MB (954728448)
          + Allocated memory: 373,00 MB (391118848)
          + Free memory:      138,06 MB (144769408)
          + In-use memory:    234,94 MB (246349440)
          + PermGen used:     30,01 MB (31462992)
          + PermGen max:      82,00 MB (85983232)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.45-b08
      - Operating system
          + Name:         Windows 7
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 1892 (0x764)
      - Process started: 2016-02-03 09:20:20.345+0100
      - Process uptime: 1 j 4 h
      - JVM startup parameters:
          + Boot classpath: `C:\pgih\jdk\1.7.0-x64\jre\lib\resources.jar;C:\pgih\jdk\1.7.0-x64\jre\lib\rt.jar;C:\pgih\jdk\1.7.0-x64\jre\lib\sunrsasign.jar;C:\pgih\jdk\1.7.0-x64\jre\lib\jsse.jar;C:\pgih\jdk\1.7.0-x64\jre\lib\jce.jar;C:\pgih\jdk\1.7.0-x64\jre\lib\charsets.jar;C:\pgih\jdk\1.7.0-x64\jre\lib\jfr.jar;C:\pgih\jdk\1.7.0-x64\jre\classes`
          + Classpath: `C:\ic\_slave.jar`
          + Library path: `C:\pgih\jdk\1.7.0-x64\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;%PGIHPATH%;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;;c:\pgih\svn\1.6\bin;c:\pgih\maven\3.2.1\bin;c:\pgih\jdk\1.6.0\bin;c:\pgih\jdk\1.7.0-x64\bin;c:\pgih\jdk\1.8.0-x64\bin;;.`

  * windows7-4 (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 7_
      - Executors:      1
      - Remote FS root: `c:\ic`
      - Labels:         windows selenium chrome seven x64 mdmia winN2J
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `C:\pgih\jdk\1.8.0-x64\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_05
          + Maximum memory:   910,50 MB (954728448)
          + Allocated memory: 356,00 MB (373293056)
          + Free memory:      112,78 MB (118259704)
          + In-use memory:    243,22 MB (255033352)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.5-b02
      - Operating system
          + Name:         Windows 7
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 3268 (0xcc4)
      - Process started: 2016-02-03 09:24:05.015+0100
      - Process uptime: 1 j 4 h
      - JVM startup parameters:
          + Boot classpath: `C:\pgih\jdk\1.8.0-x64\jre\lib\resources.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\rt.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\sunrsasign.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\jsse.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\jce.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\charsets.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\jfr.jar;C:\pgih\jdk\1.8.0-x64\jre\classes`
          + Classpath: `C:\ic\_slave.jar`
          + Library path: `C:\pgih\jdk\1.8.0-x64\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\Microsoft Network Monitor 3\;;c:\pgih\svn\1.6\bin;c:\pgih\maven\3.2.1\bin;c:\pgih\jdk\1.6.0\bin;c:\pgih\jdk\1.7.0-x64\bin;c:\pgih\jdk\1.8.0-x64\bin;;.`

  * windows7-5 (`hudson.slaves.DumbSlave`)
      - Description:    _Windows 7_
      - Executors:      1
      - Remote FS root: `c:\ic`
      - Labels:         windows selenium chrome seven x64 mdmia winN2J
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.slaves.JNLPLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `C:\pgih\jdk\1.8.0-x64\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_05
          + Maximum memory:   910,50 MB (954728448)
          + Allocated memory: 358,50 MB (375914496)
          + Free memory:      188,02 MB (197153968)
          + In-use memory:    170,48 MB (178760528)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.5-b02
      - Operating system
          + Name:         Windows 7
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 2932 (0xb74)
      - Process started: 2016-02-03 09:25:57.573+0100
      - Process uptime: 1 j 4 h
      - JVM startup parameters:
          + Boot classpath: `C:\pgih\jdk\1.8.0-x64\jre\lib\resources.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\rt.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\sunrsasign.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\jsse.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\jce.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\charsets.jar;C:\pgih\jdk\1.8.0-x64\jre\lib\jfr.jar;C:\pgih\jdk\1.8.0-x64\jre\classes`
          + Classpath: `C:\ic\_slave.jar`
          + Library path: `C:\pgih\jdk\1.8.0-x64\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\Program Files\Microsoft Network Monitor 3\;;c:\pgih\svn\1.6\bin;c:\pgih\maven\3.2.1\bin;c:\pgih\jdk\1.6.0\bin;c:\pgih\jdk\1.7.0-x64\bin;c:\pgih\jdk\1.8.0-x64\bin;;.`


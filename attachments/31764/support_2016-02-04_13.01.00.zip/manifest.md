Support Bundle Manifest
=======================

Generated on 2016-02-04 14:01:00.448+0100

Requested components:

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/aix-1/checksums.md5`

      - `nodes/slave/docker-62319112def6-sv-t-vnl-ic-centos7-2.mipih.net/checksums.md5`

      - `nodes/slave/docker-93b8ebee37cd-sv-t-vnl-ic-centos7-3.mipih.net/checksums.md5`

      - `nodes/slave/docker-aa0aa0aa315f-sv-t-vnl-ic-centos7-1.mipih.net/checksums.md5`

      - `nodes/slave/docker-d2cfa59a731e-sv-t-vnl-ic-centos7-2.mipih.net/checksums.md5`

      - `nodes/slave/rhel-ferrari/checksums.md5`

      - `nodes/slave/rhel6-ssh-12/checksums.md5`

      - `nodes/slave/rhel7-1/checksums.md5`

      - `nodes/slave/windows7-3/checksums.md5`

      - `nodes/slave/windows7-4/checksums.md5`

      - `nodes/slave/windows7-5/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/aix-1/exportTable.txt`

      - `nodes/slave/docker-62319112def6-sv-t-vnl-ic-centos7-2.mipih.net/exportTable.txt`

      - `nodes/slave/docker-93b8ebee37cd-sv-t-vnl-ic-centos7-3.mipih.net/exportTable.txt`

      - `nodes/slave/docker-aa0aa0aa315f-sv-t-vnl-ic-centos7-1.mipih.net/exportTable.txt`

      - `nodes/slave/docker-d2cfa59a731e-sv-t-vnl-ic-centos7-2.mipih.net/exportTable.txt`

      - `nodes/slave/rhel-ferrari/exportTable.txt`

      - `nodes/slave/rhel6-ssh-12/exportTable.txt`

      - `nodes/slave/rhel7-1/exportTable.txt`

      - `nodes/slave/windows7-3/exportTable.txt`

      - `nodes/slave/windows7-4/exportTable.txt`

      - `nodes/slave/windows7-5/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/aix-1/environment.txt`

      - `nodes/slave/docker-62319112def6-sv-t-vnl-ic-centos7-2.mipih.net/environment.txt`

      - `nodes/slave/docker-93b8ebee37cd-sv-t-vnl-ic-centos7-3.mipih.net/environment.txt`

      - `nodes/slave/docker-aa0aa0aa315f-sv-t-vnl-ic-centos7-1.mipih.net/environment.txt`

      - `nodes/slave/docker-d2cfa59a731e-sv-t-vnl-ic-centos7-2.mipih.net/environment.txt`

      - `nodes/slave/rhel-ferrari/environment.txt`

      - `nodes/slave/rhel6-ssh-12/environment.txt`

      - `nodes/slave/rhel7-1/environment.txt`

      - `nodes/slave/windows7-3/environment.txt`

      - `nodes/slave/windows7-4/environment.txt`

      - `nodes/slave/windows7-5/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/aix-1/file-descriptors.txt`

      - `nodes/slave/docker-62319112def6-sv-t-vnl-ic-centos7-2.mipih.net/file-descriptors.txt`

      - `nodes/slave/docker-93b8ebee37cd-sv-t-vnl-ic-centos7-3.mipih.net/file-descriptors.txt`

      - `nodes/slave/docker-aa0aa0aa315f-sv-t-vnl-ic-centos7-1.mipih.net/file-descriptors.txt`

      - `nodes/slave/docker-d2cfa59a731e-sv-t-vnl-ic-centos7-2.mipih.net/file-descriptors.txt`

      - `nodes/slave/rhel6-ssh-12/file-descriptors.txt`

      - `nodes/slave/rhel7-1/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/docker-62319112def6-sv-t-vnl-ic-centos7-2.mipih.net/proc/meminfo.txt`

      - `nodes/slave/docker-62319112def6-sv-t-vnl-ic-centos7-2.mipih.net/proc/self/cmdline`

      - `nodes/slave/docker-62319112def6-sv-t-vnl-ic-centos7-2.mipih.net/proc/self/environ`

      - `nodes/slave/docker-62319112def6-sv-t-vnl-ic-centos7-2.mipih.net/proc/self/limits.txt`

      - `nodes/slave/docker-62319112def6-sv-t-vnl-ic-centos7-2.mipih.net/proc/self/status.txt`

      - `nodes/slave/docker-93b8ebee37cd-sv-t-vnl-ic-centos7-3.mipih.net/proc/meminfo.txt`

      - `nodes/slave/docker-93b8ebee37cd-sv-t-vnl-ic-centos7-3.mipih.net/proc/self/cmdline`

      - `nodes/slave/docker-93b8ebee37cd-sv-t-vnl-ic-centos7-3.mipih.net/proc/self/environ`

      - `nodes/slave/docker-93b8ebee37cd-sv-t-vnl-ic-centos7-3.mipih.net/proc/self/limits.txt`

      - `nodes/slave/docker-93b8ebee37cd-sv-t-vnl-ic-centos7-3.mipih.net/proc/self/status.txt`

      - `nodes/slave/docker-aa0aa0aa315f-sv-t-vnl-ic-centos7-1.mipih.net/proc/meminfo.txt`

      - `nodes/slave/docker-aa0aa0aa315f-sv-t-vnl-ic-centos7-1.mipih.net/proc/self/cmdline`

      - `nodes/slave/docker-aa0aa0aa315f-sv-t-vnl-ic-centos7-1.mipih.net/proc/self/environ`

      - `nodes/slave/docker-aa0aa0aa315f-sv-t-vnl-ic-centos7-1.mipih.net/proc/self/limits.txt`

      - `nodes/slave/docker-aa0aa0aa315f-sv-t-vnl-ic-centos7-1.mipih.net/proc/self/status.txt`

      - `nodes/slave/docker-d2cfa59a731e-sv-t-vnl-ic-centos7-2.mipih.net/proc/meminfo.txt`

      - `nodes/slave/docker-d2cfa59a731e-sv-t-vnl-ic-centos7-2.mipih.net/proc/self/cmdline`

      - `nodes/slave/docker-d2cfa59a731e-sv-t-vnl-ic-centos7-2.mipih.net/proc/self/environ`

      - `nodes/slave/docker-d2cfa59a731e-sv-t-vnl-ic-centos7-2.mipih.net/proc/self/limits.txt`

      - `nodes/slave/docker-d2cfa59a731e-sv-t-vnl-ic-centos7-2.mipih.net/proc/self/status.txt`

      - `nodes/slave/rhel6-ssh-12/proc/meminfo.txt`

      - `nodes/slave/rhel6-ssh-12/proc/self/cmdline`

      - `nodes/slave/rhel6-ssh-12/proc/self/environ`

      - `nodes/slave/rhel6-ssh-12/proc/self/limits.txt`

      - `nodes/slave/rhel6-ssh-12/proc/self/status.txt`

      - `nodes/slave/rhel7-1/proc/meminfo.txt`

      - `nodes/slave/rhel7-1/proc/self/cmdline`

      - `nodes/slave/rhel7-1/proc/self/environ`

      - `nodes/slave/rhel7-1/proc/self/limits.txt`

      - `nodes/slave/rhel7-1/proc/self/status.txt`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/aix-1/metrics.json`

      - `nodes/slave/docker-62319112def6-sv-t-vnl-ic-centos7-2.mipih.net/metrics.json`

      - `nodes/slave/docker-93b8ebee37cd-sv-t-vnl-ic-centos7-3.mipih.net/metrics.json`

      - `nodes/slave/docker-aa0aa0aa315f-sv-t-vnl-ic-centos7-1.mipih.net/metrics.json`

      - `nodes/slave/docker-d2cfa59a731e-sv-t-vnl-ic-centos7-2.mipih.net/metrics.json`

      - `nodes/slave/rhel-ferrari/metrics.json`

      - `nodes/slave/rhel6-ssh-12/metrics.json`

      - `nodes/slave/rhel7-1/metrics.json`

      - `nodes/slave/windows7-3/metrics.json`

      - `nodes/slave/windows7-4/metrics.json`

      - `nodes/slave/windows7-5/metrics.json`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/aix-1/system.properties`

      - `nodes/slave/docker-62319112def6-sv-t-vnl-ic-centos7-2.mipih.net/system.properties`

      - `nodes/slave/docker-93b8ebee37cd-sv-t-vnl-ic-centos7-3.mipih.net/system.properties`

      - `nodes/slave/docker-aa0aa0aa315f-sv-t-vnl-ic-centos7-1.mipih.net/system.properties`

      - `nodes/slave/docker-d2cfa59a731e-sv-t-vnl-ic-centos7-2.mipih.net/system.properties`

      - `nodes/slave/rhel-ferrari/system.properties`

      - `nodes/slave/rhel6-ssh-12/system.properties`

      - `nodes/slave/rhel7-1/system.properties`

      - `nodes/slave/windows7-3/system.properties`

      - `nodes/slave/windows7-4/system.properties`

      - `nodes/slave/windows7-5/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/aix-1/thread-dump.txt`

      - `nodes/slave/docker-62319112def6-sv-t-vnl-ic-centos7-2.mipih.net/thread-dump.txt`

      - `nodes/slave/docker-93b8ebee37cd-sv-t-vnl-ic-centos7-3.mipih.net/thread-dump.txt`

      - `nodes/slave/docker-aa0aa0aa315f-sv-t-vnl-ic-centos7-1.mipih.net/thread-dump.txt`

      - `nodes/slave/docker-d2cfa59a731e-sv-t-vnl-ic-centos7-2.mipih.net/thread-dump.txt`

      - `nodes/slave/rhel-ferrari/thread-dump.txt`

      - `nodes/slave/rhel6-ssh-12/thread-dump.txt`

      - `nodes/slave/rhel7-1/thread-dump.txt`

      - `nodes/slave/windows7-3/thread-dump.txt`

      - `nodes/slave/windows7-4/thread-dump.txt`

      - `nodes/slave/windows7-5/thread-dump.txt`


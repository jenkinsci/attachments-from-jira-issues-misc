package com.tek42.perforce.parse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.tek42.perforce.PerforceException;

import junit.framework.TestCase;

public class ChangelistBuilderTest extends TestCase {

	public void testBuild() throws Exception {
		InputStream is = this.getClass().getResourceAsStream("_166289.txt");
				
		StringBuilder sb = new StringBuilder();
		byte[] buff = new byte[10*1024*1024];
		int read = 0;
		while( (read = is.read(buff)) != -1 ) {
			String line = new String(buff, 0, read);			
			sb.append(line);
			
		}
		
		ChangelistBuilder b = new ChangelistBuilder();
		b.build(sb);
	}

}

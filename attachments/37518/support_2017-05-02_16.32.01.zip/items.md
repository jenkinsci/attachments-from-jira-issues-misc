Item statistics
===============

  * `hudson.maven.MavenModule`
    - Number of items: 10
    - Number of builds per job: 13.3 [n=10, s=30.0]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 7
    - Number of builds per job: 18.857142857142858 [n=7, s=30.0]
    - Number of items per container: 1.4285714285714286 [n=7, s=0.8]
  * `hudson.model.FreeStyleProject`
    - Number of items: 72
    - Number of builds per job: 51.916666666666664 [n=72, s=90.0]
  * `jenkins.branch.OrganizationFolder`
    - Number of items: 3
    - Number of items per container: 0.6666666666666666 [n=3, s=0.6]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 41
    - Number of builds per job: 22.414634146341463 [n=41, s=50.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 3
    - Number of items per container: 8.333333333333334 [n=3, s=2.0]

Total job statistics
======================

  * Number of jobs: 130
  * Number of builds per job: 37.86153846153846 [n=130, s=78.0]

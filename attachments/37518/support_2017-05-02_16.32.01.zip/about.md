Jenkins
=======

Version details
---------------

  * Version: `2.58`
  * Mode:    WAR
  * Url:     http://10.0.1.63:9090/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_111
      - Maximum memory:   2.67 GB (2863661056)
      - Allocated memory: 432.50 MB (453509120)
      - Free memory:      111.09 MB (116483616)
      - In-use memory:    321.41 MB (337025504)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.111-b14
  * Operating system
      - Name:         Mac OS X
      - Architecture: x86_64
      - Version:      10.12.4
  * Process ID: 53324 (0xd04c)
  * Process started: 2017-05-02 15:13:39.258+0000
  * Process uptime: 1 hr 18 min
  * JVM startup parameters:
      - Boot classpath: `/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/resources.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/rt.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/sunrsasign.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/jsse.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/jce.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/charsets.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/jfr.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/classes`
      - Classpath: `/Applications/Jenkins/jenkins.war`
      - Library path: `/Users/ms/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.`
      - arg[0]: `-Xmx3072m`
      - arg[1]: `-Dhudson.tasks.MailSender.SEND_TO_UNKNOWN_USERS=true`
      - arg[2]: `-Dorg.jenkinsci.plugins.gitclient.Git.timeOut=60`
      - arg[3]: `-Dhudson.model.DirectoryBrowserSupport.CSP=`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `com.michelin.cio.hudson.plugins.rolestrategy.RoleBasedAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * android-emulator:2.15 'Android Emulator Plugin'
  * ant:1.4 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * bouncycastle-api:2.16.0 *(update available)* 'bouncycastle API Plugin'
  * branch-api:2.0.9 'Branch API Plugin'
  * build-keeper-plugin:1.3 'Build Keeper Plugin'
  * build-name-setter:1.6.5 'build-name-setter'
  * buildresult-trigger:0.17 'Jenkins BuildResultTrigger Plug-in'
  * cloudbees-folder:6.0.4 'Folders Plugin'
  * conditional-buildstep:1.3.5 'Conditional BuildStep'
  * copy-project-link:1.5 'Copy project link plugin'
  * copyartifact:1.38.1 'Copy Artifact Plugin'
  * credentials:2.1.13 'Credentials Plugin'
  * credentials-binding:1.11 'Credentials Binding Plugin'
  * cvs:2.13 'Jenkins CVS Plug-in'
  * display-url-api:2.0 'Display URL API'
  * docker-commons:1.6 'Docker Commons Plugin'
  * docker-workflow:1.9.1 *(update available)* 'Docker Pipeline'
  * durable-task:1.13 'Durable Task Plugin'
  * email-ext:2.57.2 'Email Extension Plugin'
  * envinject:2.0 'Environment Injector Plugin'
  * extensible-choice-parameter:1.4.0 'Extensible Choice Parameter plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * extra-columns:1.18 'Extra Columns Plugin'
  * favorite:2.0.4 'Favorite'
  * filesystem_scm:1.20 'File System SCM'
  * ghprb:1.36.2 'GitHub Pull Request Builder'
  * git:3.3.0 'Jenkins Git plugin'
  * git-client:2.4.5 'Jenkins Git client plugin'
  * git-parameter:0.8.0 'Git Parameter Plug-In'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.27.0 'GitHub plugin'
  * github-api:1.85 'GitHub API Plugin'
  * github-branch-source:2.0.5 'GitHub Branch Source Plugin'
  * github-oauth:0.27 'GitHub Authentication plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * google-oauth-plugin:0.5 'Google OAuth Credentials plugin'
  * google-play-android-publisher:1.5 'Google Play Android Publisher Plugin'
  * gradle:1.26 'Gradle Plugin'
  * greenballs:1.15 'Green Balls'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * hockeyapp:1.2.2 'HockeyApp Plugin'
  * htmlpublisher:1.13 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * JDK_Parameter_Plugin:1.0 'JDK Parameter Plugin'
  * jenkins-jira-issue-updater:1.18 'Jenkins Jira Issue Updater'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.20 'JUnit Plugin'
  * ldap:1.15 'LDAP Plugin'
  * lockable-resources:2.0 'Lockable Resources plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.5 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.10 'Matrix Project Plugin'
  * maven-plugin:2.15.1 'Maven Integration plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * naginator:1.17.2 'Naginator'
  * oauth-credentials:0.3 'OAuth Credentials plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * pipeline-build-step:2.5 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.3 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.7 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.1.3 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.1.3 'Pipeline: Model Definition'
  * pipeline-model-extensions:1.1.3 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.6 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.1.3 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.6 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * port-allocator:1.8 'Jenkins Port Allocator Plug-in'
  * postbuild-task:1.8 'Hudson Post build task'
  * pubsub-light:1.7 'Jenkins Pub-Sub "light" Bus'
  * resource-disposer:0.6 'Resource Disposer Plugin'
  * role-strategy:2.4.0 'Role-based Authorization Strategy'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:2.1.1 'SCM API Plugin'
  * script-security:1.27 'Script Security Plugin'
  * selenium-axis:0.0.6 'Selenium Capability Axis'
  * slack:2.2 'Slack Notification Plugin'
  * sounds:0.5 'Jenkins Sounds plugin'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-agent:1.15 'SSH Agent Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.17 'Jenkins SSH Slaves plugin'
  * structs:1.6 'Structs Plugin'
  * subversion:2.7.2 'Jenkins Subversion Plug-in'
  * support-core:2.40 'Support Core Plugin'
  * throttle-concurrents:1.9.0 'Jenkins Throttle Concurrent Builds Plug-in'
  * token-macro:2.1 'Token Macro Plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * variant:1.1 'Variant Plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.13 'Pipeline: API'
  * workflow-basic-steps:2.4 'Pipeline: Basic Steps'
  * workflow-cps:2.30 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.8 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.11 'Pipeline: Nodes and Processes'
  * workflow-job:2.10 'Pipeline: Job'
  * workflow-multibranch:2.14 'Pipeline: Multibranch'
  * workflow-scm-step:2.4 'Pipeline: SCM Step'
  * workflow-step-api:2.9 'Pipeline: Step API'
  * workflow-support:2.14 'Pipeline: Supporting APIs'
  * ws-cleanup:0.33 'Jenkins Workspace Cleanup Plugin'
  * xcode-plugin:1.4.11 'Xcode integration'

Browser
=======

  * Screen size: 1440x900
  * User Agent
      - Type:     Browser
      - Name:     Safari
      - Family:   SAFARI
      - Producer: Apple Inc.
      - Version:  10.0.3
      - Raw:      `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/602.4.8 (KHTML, like Gecko) Version/10.0.3 Safari/602.4.8`
  * Operating System
      - Name:     OS X
      - Family:   OS_X
      - Producer: Apple Computer, Inc.
      - Version:  10.12.3


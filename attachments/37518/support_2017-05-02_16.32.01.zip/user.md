User
====

Authentication
--------------

  * Authenticated: true
  * Name: marc
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@c1355fb1: Username: hudson.security.HudsonPrivateSecurityRealm$Details@52e463c2; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@7798: RemoteIpAddress: 10.0.1.233; SessionId: null; Granted Authorities: authenticated`


Node statistics
===============

  * Total number of nodes
      - Sample size:        312
      - Average (mean):     0.9999999999999999
      - Average (median):   1.0
      - Standard deviation: 1.1102230246251564E-16
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of nodes online
      - Sample size:        312
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        312
      - Average (mean):     4.999999999999999
      - Average (median):   5.0
      - Standard deviation: 8.881784197001251E-16
      - Minimum:            5
      - Maximum:            5
      - 95th percentile:    5.0
      - 99th percentile:    5.0
  * Total number of executors in use
      - Sample size:        312
      - Average (mean):     1.998893075450701E-9
      - Average (median):   0.0
      - Standard deviation: 4.470898199976295E-5
      - Minimum:            0
      - Maximum:            1
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      5
      - FS root:        `/Data/CI/Jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.7
      - Java
          + Home:           `/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_111
          + Maximum memory:   2.67 GB (2863661056)
          + Allocated memory: 429.00 MB (449839104)
          + Free memory:      255.74 MB (268159312)
          + In-use memory:    173.26 MB (181679792)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.111-b14
      - Operating system
          + Name:         Mac OS X
          + Architecture: x86_64
          + Version:      10.12.4
      - Process ID: 53324 (0xd04c)
      - Process started: 2017-05-02 15:13:39.258+0000
      - Process uptime: 1 hr 18 min
      - JVM startup parameters:
          + Boot classpath: `/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/resources.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/rt.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/sunrsasign.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/jsse.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/jce.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/charsets.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/lib/jfr.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_111.jdk/Contents/Home/jre/classes`
          + Classpath: `/Applications/Jenkins/jenkins.war`
          + Library path: `/Users/ms/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.`
          + arg[0]: `-Xmx3072m`
          + arg[1]: `-Dhudson.tasks.MailSender.SEND_TO_UNKNOWN_USERS=true`
          + arg[2]: `-Dorg.jenkinsci.plugins.gitclient.Git.timeOut=60`
          + arg[3]: `-Dhudson.model.DirectoryBrowserSupport.CSP=`


Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Mac OS X (x86_64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 149.791GB left on /Data/CI/Jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:0/0MB  Swap:1244/4096MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 149.791GB left on /private/var/folders/rx/c0vf17rd6wg50vhtsmhych940000gn/T.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms

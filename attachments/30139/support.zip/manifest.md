Support Bundle Manifest
=======================

Generated on 2015-07-09 14:20:32.432-0700

Requested components:

  * Log Recorders

      - `nodes/master/logs/all_2015-07-09_18.51.38.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Out of order build detection.log`

      - `other-logs/Workspace clean-up.log`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

  * Build queue

      - `buildqueue.md`

  * Environment variables

      - `nodes/master/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * JVM process system metrics (Linux only)

  * Load Statistics

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * Metrics

      - `nodes/master/metrics.json`

  * System configuration (Linux only)

  * System properties

      - `nodes/master/system.properties`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`


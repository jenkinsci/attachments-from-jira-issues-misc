Jenkins
=======

Version details
---------------

  * Version: `1.609.1`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/System/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Home`
      - Vendor:           Apple Inc.
      - Version:          1.6.0_65
      - Maximum memory:   123.94 MB (129957888)
      - Allocated memory: 81.06 MB (85000192)
      - Free memory:      21.14 MB (22168640)
      - In-use memory:    59.92 MB (62831552)
      - PermGen used:     70.54 MB (73962464)
      - PermGen max:      82.00 MB (85983232)
      - GC strategy:      ConcMarkSweepGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Sun Microsystems Inc.
      - Version: 1.6
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Sun Microsystems Inc.
      - Version: 1.0
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Apple Inc.
      - Version: 20.65-b04-466.1
  * Operating system
      - Name:         Mac OS X
      - Architecture: x86_64
      - Version:      10.10.4
  * Process ID: 16043 (0x3eab)
  * Process started: 2015-07-09 11:26:42.484-0700
  * Process uptime: 2 hr 53 min
  * JVM startup parameters:
      - Boot classpath: `/System/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Classes/jsfd.jar:/System/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Classes/classes.jar:/System/Library/Frameworks/JavaVM.framework/Frameworks/JavaRuntimeSupport.framework/Resources/Java/JavaRuntimeSupport.jar:/System/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Classes/ui.jar:/System/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Classes/laf.jar:/System/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Classes/sunrsasign.jar:/System/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Classes/jsse.jar:/System/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Classes/jce.jar:/System/Library/Java/JavaVirtualMachines/1.6.0.jdk/Contents/Classes/charsets.jar`
      - Classpath: `jenkins.war`
      - Library path: `.:/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java`
      - arg[0]: `-Dhudson.DNSMultiCast.disabled=true`

Important configuration
---------------

  * Security realm: `hudson.security.SecurityRealm$None`
  * Authorization strategy: `hudson.security.AuthorizationStrategy$Unsecured`

Active Plugins
--------------

  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.1 *(update available)* 'OWASP Markup Formatter Plugin'
  * credentials:1.22 'Credentials Plugin'
  * cvs:2.11 *(update available)* 'Jenkins CVS Plug-in'
  * durable-task:1.5 'Durable Task Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * git:2.3.5 'Jenkins GIT plugin'
  * git-client:1.17.1 'Jenkins GIT client plugin'
  * git-server:1.6 'Git server plugin'
  * gitlab-plugin:1.1.24 'GitLab Plugin'
  * google-login:1.1 'Google Login Plugin'
  * javadoc:1.1 *(update available)* 'Javadoc Plugin'
  * junit:1.2-beta-4 *(update available)* 'JUnit Plugin'
  * ldap:1.6 *(update available)* 'LDAP Plugin'
  * mailer:1.15 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * matrix-auth:1.1 *(update available)* 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.4.1 *(update available)* 'Matrix Project Plugin'
  * maven-plugin:2.7.1 *(update available)* 'Maven Integration plugin'
  * metrics:3.0.11 'Metrics Plugin'
  * pam-auth:1.1 *(update available)* 'PAM Authentication plugin'
  * rebuild:1.25 'Rebuilder'
  * scm-api:0.2 'SCM API Plugin'
  * script-security:1.13 *(update available)* 'Script Security Plugin'
  * show-build-parameters:1.0 'Show Build Parameters plugin'
  * ssh-credentials:1.10 *(update available)* 'SSH Credentials Plugin'
  * ssh-slaves:1.9 'Jenkins SSH Slaves plugin'
  * subversion:2.5 *(update available)* 'Jenkins Subversion Plug-in'
  * support-core:2.25 'Support Core Plugin'
  * translation:1.10 *(update available)* 'Jenkins Translation Assistance plugin'
  * windows-slaves:1.0 *(update available)* 'Windows Slaves Plugin'
  * workflow-aggregator:1.8 'Workflow: Aggregator'
  * workflow-api:1.8 'Workflow: API'
  * workflow-basic-steps:1.8 'Workflow: Basic Steps'
  * workflow-cps:1.8 'Workflow: Groovy CPS Execution'
  * workflow-cps-global-lib:1.8 'Workflow: Global Shared Library for CPS workflow'
  * workflow-durable-task-step:1.8 'Workflow: Durable Task Step'
  * workflow-job:1.8 'Workflow: Job'
  * workflow-scm-step:1.8 'Workflow: SCM Step'
  * workflow-step-api:1.8 'Workflow: Step API'
  * workflow-support:1.8 'Workflow: Execution Support'

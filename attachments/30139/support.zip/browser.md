Browser
=======

  * Screen size: 2560x1600
  * User Agent
      - Type:     Browser
      - Name:     Chrome
      - Family:   CHROME
      - Producer: Google Inc.
      - Version:  43.0.2357.130
      - Raw:      `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36`
  * Operating System
      - Name:     OS X
      - Family:   OS_X
      - Producer: Apple Computer, Inc.
      - Version:  10.10.4


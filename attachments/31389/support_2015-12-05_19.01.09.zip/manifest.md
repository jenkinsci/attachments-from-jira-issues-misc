Support Bundle Manifest
=======================

Generated on 2015-12-05 14:01:09.190-0500

Requested components:

  * Log Recorders

      - `nodes/master/logs/all_2015-11-24_21.34.03.log`

      - `nodes/master/logs/all_2015-11-25_04.16.20.log`

      - `nodes/master/logs/all_2015-11-29_16.50.00.log`

      - `nodes/master/logs/all_2015-12-01_10.09.17.log`

      - `nodes/master/logs/all_2015-12-02_22.50.31.log`

      - `nodes/master/logs/all_2015-12-03_03.38.17.log`

      - `nodes/master/logs/all_2015-12-03_03.52.01.log`

      - `nodes/master/logs/all_2015-12-05_06.55.02.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `nodes/slave/va1ihgdweb31/jenkins.log`

      - `nodes/slave/va1ihgdweb31/launchLogs/slave.log`

      - `nodes/slave/va1ihgdweb31/logs/all_2015-11-20_03.37.20.log`

      - `nodes/slave/va1ihgdweb31/logs/all_2015-11-20_03.39.59.log`

      - `nodes/slave/va1ihgdweb31/logs/all_2015-11-20_03.44.39.log`

      - `nodes/slave/va1ihgdweb31/logs/all_2015-11-22_19.14.15.log`

      - `nodes/slave/va1ihgdweb31/logs/all_2015-11-25_04.09.06.log`

      - `nodes/slave/va1ihgdweb31/logs/all_2015-11-25_04.16.37.log`

      - `nodes/slave/va1ihgdweb31/logs/all_2015-12-03_03.38.30.log`

      - `nodes/slave/va1ihgdweb31/logs/all_2015-12-03_03.52.17.log`

      - `nodes/slave/va1ihgdweb31/logs/all_memory_buffer.log`

      - `nodes/slave/va1ihgdweb32/jenkins.log`

      - `nodes/slave/va1ihgdweb32/launchLogs/slave.log`

      - `nodes/slave/va1ihgdweb32/logs/all_2015-11-20_03.39.59.log`

      - `nodes/slave/va1ihgdweb32/logs/all_2015-11-20_03.44.39.log`

      - `nodes/slave/va1ihgdweb32/logs/all_2015-11-22_19.14.15.log`

      - `nodes/slave/va1ihgdweb32/logs/all_2015-11-25_04.09.06.log`

      - `nodes/slave/va1ihgdweb32/logs/all_2015-11-25_04.16.37.log`

      - `nodes/slave/va1ihgdweb32/logs/all_2015-11-30_23.55.20.log`

      - `nodes/slave/va1ihgdweb32/logs/all_2015-12-03_03.38.30.log`

      - `nodes/slave/va1ihgdweb32/logs/all_2015-12-03_03.52.17.log`

      - `nodes/slave/va1ihgdweb32/logs/all_memory_buffer.log`

      - `nodes/slave/va1ihgdweb33/jenkins.log`

      - `nodes/slave/va1ihgdweb33/launchLogs/slave.log`

      - `nodes/slave/va1ihgdweb33/logs/all_2015-11-20_03.37.20.log`

      - `nodes/slave/va1ihgdweb33/logs/all_2015-11-20_03.39.59.log`

      - `nodes/slave/va1ihgdweb33/logs/all_2015-11-20_03.44.39.log`

      - `nodes/slave/va1ihgdweb33/logs/all_2015-11-22_19.14.15.log`

      - `nodes/slave/va1ihgdweb33/logs/all_2015-11-25_04.09.07.log`

      - `nodes/slave/va1ihgdweb33/logs/all_2015-11-25_04.16.36.log`

      - `nodes/slave/va1ihgdweb33/logs/all_2015-12-03_03.38.30.log`

      - `nodes/slave/va1ihgdweb33/logs/all_2015-12-03_03.52.17.log`

      - `nodes/slave/va1ihgdweb33/logs/all_memory_buffer.log`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/jenkins.metrics.api.Metrics$HealthChecker.log`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/va1ihgdweb31/checksums.md5`

      - `nodes/slave/va1ihgdweb32/checksums.md5`

      - `nodes/slave/va1ihgdweb33/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/va1ihgdweb31/exportTable.txt`

      - `nodes/slave/va1ihgdweb32/exportTable.txt`

      - `nodes/slave/va1ihgdweb33/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/va1ihgdweb31/environment.txt`

      - `nodes/slave/va1ihgdweb32/environment.txt`

      - `nodes/slave/va1ihgdweb33/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/va1ihgdweb31/file-descriptors.txt`

      - `nodes/slave/va1ihgdweb32/file-descriptors.txt`

      - `nodes/slave/va1ihgdweb33/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/va1ihgdweb31/proc/meminfo.txt`

      - `nodes/slave/va1ihgdweb31/proc/self/cmdline`

      - `nodes/slave/va1ihgdweb31/proc/self/environ`

      - `nodes/slave/va1ihgdweb31/proc/self/limits.txt`

      - `nodes/slave/va1ihgdweb31/proc/self/status.txt`

      - `nodes/slave/va1ihgdweb32/proc/meminfo.txt`

      - `nodes/slave/va1ihgdweb32/proc/self/cmdline`

      - `nodes/slave/va1ihgdweb32/proc/self/environ`

      - `nodes/slave/va1ihgdweb32/proc/self/limits.txt`

      - `nodes/slave/va1ihgdweb32/proc/self/status.txt`

      - `nodes/slave/va1ihgdweb33/proc/meminfo.txt`

      - `nodes/slave/va1ihgdweb33/proc/self/cmdline`

      - `nodes/slave/va1ihgdweb33/proc/self/environ`

      - `nodes/slave/va1ihgdweb33/proc/self/limits.txt`

      - `nodes/slave/va1ihgdweb33/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/%21slave2/gnuplot`

      - `load-stats/label/%21slave2/hour.csv`

      - `load-stats/label/%21slave2/min.csv`

      - `load-stats/label/%21slave2/sec10.csv`

      - `load-stats/label/%21va1ihgdweb32/gnuplot`

      - `load-stats/label/%21va1ihgdweb32/hour.csv`

      - `load-stats/label/%21va1ihgdweb32/min.csv`

      - `load-stats/label/%21va1ihgdweb32/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/nodejs/gnuplot`

      - `load-stats/label/nodejs/hour.csv`

      - `load-stats/label/nodejs/min.csv`

      - `load-stats/label/nodejs/sec10.csv`

      - `load-stats/label/slave1/gnuplot`

      - `load-stats/label/slave1/hour.csv`

      - `load-stats/label/slave1/min.csv`

      - `load-stats/label/slave1/sec10.csv`

      - `load-stats/label/slave2/gnuplot`

      - `load-stats/label/slave2/hour.csv`

      - `load-stats/label/slave2/min.csv`

      - `load-stats/label/slave2/sec10.csv`

      - `load-stats/label/slave3/gnuplot`

      - `load-stats/label/slave3/hour.csv`

      - `load-stats/label/slave3/min.csv`

      - `load-stats/label/slave3/sec10.csv`

      - `load-stats/label/va1ihgdweb31/gnuplot`

      - `load-stats/label/va1ihgdweb31/hour.csv`

      - `load-stats/label/va1ihgdweb31/min.csv`

      - `load-stats/label/va1ihgdweb31/sec10.csv`

      - `load-stats/label/va1ihgdweb32/gnuplot`

      - `load-stats/label/va1ihgdweb32/hour.csv`

      - `load-stats/label/va1ihgdweb32/min.csv`

      - `load-stats/label/va1ihgdweb32/sec10.csv`

      - `load-stats/label/va1ihgdweb33/gnuplot`

      - `load-stats/label/va1ihgdweb33/hour.csv`

      - `load-stats/label/va1ihgdweb33/min.csv`

      - `load-stats/label/va1ihgdweb33/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/va1ihgdweb31/metrics.json`

      - `nodes/slave/va1ihgdweb32/metrics.json`

      - `nodes/slave/va1ihgdweb33/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/va1ihgdweb31/networkInterface.md`

      - `nodes/slave/va1ihgdweb32/networkInterface.md`

      - `nodes/slave/va1ihgdweb33/networkInterface.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/va1ihgdweb31/dmesg.txt`

      - `nodes/slave/va1ihgdweb31/dmi.txt`

      - `nodes/slave/va1ihgdweb31/proc/cpuinfo.txt`

      - `nodes/slave/va1ihgdweb31/proc/mounts.txt`

      - `nodes/slave/va1ihgdweb31/proc/swaps.txt`

      - `nodes/slave/va1ihgdweb31/proc/system-uptime.txt`

      - `nodes/slave/va1ihgdweb31/sysctl.txt`

      - `nodes/slave/va1ihgdweb31/userid.txt`

      - `nodes/slave/va1ihgdweb32/dmesg.txt`

      - `nodes/slave/va1ihgdweb32/dmi.txt`

      - `nodes/slave/va1ihgdweb32/proc/cpuinfo.txt`

      - `nodes/slave/va1ihgdweb32/proc/mounts.txt`

      - `nodes/slave/va1ihgdweb32/proc/swaps.txt`

      - `nodes/slave/va1ihgdweb32/proc/system-uptime.txt`

      - `nodes/slave/va1ihgdweb32/sysctl.txt`

      - `nodes/slave/va1ihgdweb32/userid.txt`

      - `nodes/slave/va1ihgdweb33/dmesg.txt`

      - `nodes/slave/va1ihgdweb33/dmi.txt`

      - `nodes/slave/va1ihgdweb33/proc/cpuinfo.txt`

      - `nodes/slave/va1ihgdweb33/proc/mounts.txt`

      - `nodes/slave/va1ihgdweb33/proc/swaps.txt`

      - `nodes/slave/va1ihgdweb33/proc/system-uptime.txt`

      - `nodes/slave/va1ihgdweb33/sysctl.txt`

      - `nodes/slave/va1ihgdweb33/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/va1ihgdweb31/system.properties`

      - `nodes/slave/va1ihgdweb32/system.properties`

      - `nodes/slave/va1ihgdweb33/system.properties`

  * Slow Request Records

      - `slow-requests/20151201-105326.638.txt`

      - `slow-requests/20151201-113308.638.txt`

      - `slow-requests/20151201-114317.638.txt`

      - `slow-requests/20151201-122656.638.txt`

      - `slow-requests/20151201-123120.638.txt`

      - `slow-requests/20151201-125844.638.txt`

      - `slow-requests/20151201-144729.638.txt`

      - `slow-requests/20151201-160856.638.txt`

      - `slow-requests/20151201-160859.638.txt`

      - `slow-requests/20151201-160905.638.txt`

      - `slow-requests/20151201-160905.639.txt`

      - `slow-requests/20151201-161156.638.txt`

      - `slow-requests/20151201-161553.638.txt`

      - `slow-requests/20151201-171505.638.txt`

      - `slow-requests/20151201-174726.638.txt`

      - `slow-requests/20151201-175711.638.txt`

      - `slow-requests/20151201-180350.638.txt`

      - `slow-requests/20151201-180353.685.txt`

      - `slow-requests/20151201-181050.638.txt`

      - `slow-requests/20151201-183114.638.txt`

      - `slow-requests/20151201-183120.638.txt`

      - `slow-requests/20151201-183120.639.txt`

      - `slow-requests/20151201-183123.638.txt`

      - `slow-requests/20151202-004241.638.txt`

      - `slow-requests/20151202-004241.639.txt`

      - `slow-requests/20151202-073032.638.txt`

      - `slow-requests/20151202-101056.638.txt`

      - `slow-requests/20151202-101059.638.txt`

      - `slow-requests/20151202-110626.638.txt`

      - `slow-requests/20151202-130411.638.txt`

      - `slow-requests/20151202-130411.639.txt`

      - `slow-requests/20151202-150405.639.txt`

      - `slow-requests/20151202-150405.640.txt`

      - `slow-requests/20151202-150405.641.txt`

      - `slow-requests/20151202-150405.642.txt`

      - `slow-requests/20151202-150405.643.txt`

      - `slow-requests/20151202-150405.644.txt`

      - `slow-requests/20151202-173350.638.txt`

      - `slow-requests/20151202-181250.638.txt`

      - `slow-requests/20151202-225930.918.txt`

      - `slow-requests/20151202-225933.918.txt`

      - `slow-requests/20151203-092706.918.txt`

      - `slow-requests/20151203-101903.918.txt`

      - `slow-requests/20151203-104845.918.txt`

      - `slow-requests/20151203-120812.918.txt`

      - `slow-requests/20151203-145527.918.txt`

      - `slow-requests/20151203-154848.918.txt`

      - `slow-requests/20151203-165309.918.txt`

      - `slow-requests/20151203-191942.918.txt`

      - `slow-requests/20151205-135751.918.txt`

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/va1ihgdweb31/thread-dump.txt`

      - `nodes/slave/va1ihgdweb32/thread-dump.txt`

      - `nodes/slave/va1ihgdweb33/thread-dump.txt`


-----------
 * Name eth0
 ** Hardware Address - 000c299002d5
 ** Index - 2
 ** InetAddress - /10.126.56.17
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /127.0.0.1
 ** MTU - 16436
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

User
====

Authentication
--------------

  * Authenticated: true
  * Name: kirkg
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@df399646: Username: hudson.security.HudsonPrivateSecurityRealm$Details@62fa51b9; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@0: RemoteIpAddress: 10.165.42.70; SessionId: ohoqknb162k6wpqmrra6jcjo; Granted Authorities: authenticated`


Node statistics
===============

  * Total number of nodes
      - Sample size:        15155
      - Average (mean):     4.0
      - Average (median):   4.0
      - Standard deviation: 0.0
      - Minimum:            4
      - Maximum:            4
      - 95th percentile:    4.0
      - 99th percentile:    4.0
  * Total number of nodes online
      - Sample size:        15155
      - Average (mean):     4.0
      - Average (median):   4.0
      - Standard deviation: 0.0
      - Minimum:            4
      - Maximum:            4
      - 95th percentile:    4.0
      - 99th percentile:    4.0
  * Total number of executors
      - Sample size:        15155
      - Average (mean):     33.0
      - Average (median):   33.0
      - Standard deviation: 0.0
      - Minimum:            33
      - Maximum:            33
      - 95th percentile:    33.0
      - 99th percentile:    33.0
  * Total number of executors in use
      - Sample size:        15155
      - Average (mean):     1.00002276962794
      - Average (median):   1.0
      - Standard deviation: 0.004771698804825535
      - Minimum:            1
      - Maximum:            3
      - 95th percentile:    1.0
      - 99th percentile:    1.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      9
      - FS root:        `/var/lib/jenkins`
      - Labels:         master nodejs
      - Usage:          `NORMAL`
      - Java
          + Home:           `/usr/local/jdk1.7.0_51/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_51
          + Maximum memory:   3.56 GB (3817865216)
          + Allocated memory: 2.58 GB (2766667776)
          + Free memory:      1.28 GB (1377720920)
          + In-use memory:    1.29 GB (1388946856)
          + PermGen used:     144.72 MB (151751656)
          + PermGen max:      512.00 MB (536870912)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.51-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-431.29.2.el6.x86_64
      - Process ID: 18679 (0x48f7)
      - Process started: 2015-12-02 22:51:57.625-0500
      - Process uptime: 2 days 15 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/local/jdk1.7.0_51/jre/lib/resources.jar:/usr/local/jdk1.7.0_51/jre/lib/rt.jar:/usr/local/jdk1.7.0_51/jre/lib/sunrsasign.jar:/usr/local/jdk1.7.0_51/jre/lib/jsse.jar:/usr/local/jdk1.7.0_51/jre/lib/jce.jar:/usr/local/jdk1.7.0_51/jre/lib/charsets.jar:/usr/local/jdk1.7.0_51/jre/lib/jfr.jar:/usr/local/jdk1.7.0_51/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
          + arg[1]: `-Djava.awt.headless=true`
          + arg[2]: `-XX:PermSize=128m`
          + arg[3]: `-XX:MaxPermSize=512m`
          + arg[4]: `-Xms2048m`
          + arg[5]: `-Xmx4096m`
          + arg[6]: `-DJENKINS_HOME=/var/lib/jenkins`

  * va1ihgdweb31 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      8
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         slave1 nodejs
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `/usr/local/jdk1.7.0_51/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_51
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 460.50 MB (482869248)
          + Free memory:      74.89 MB (78524272)
          + In-use memory:    385.61 MB (404344976)
          + PermGen used:     47.53 MB (49836904)
          + PermGen max:      512.00 MB (536870912)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.51-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-431.29.2.el6.x86_64
      - Process ID: 26156 (0x662c)
      - Process started: 2015-12-02 22:52:14.823-0500
      - Process uptime: 2 days 15 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/local/jdk1.7.0_51/jre/lib/resources.jar:/usr/local/jdk1.7.0_51/jre/lib/rt.jar:/usr/local/jdk1.7.0_51/jre/lib/sunrsasign.jar:/usr/local/jdk1.7.0_51/jre/lib/jsse.jar:/usr/local/jdk1.7.0_51/jre/lib/jce.jar:/usr/local/jdk1.7.0_51/jre/lib/charsets.jar:/usr/local/jdk1.7.0_51/jre/lib/jfr.jar:/usr/local/jdk1.7.0_51/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-XX:PermSize=128m`
          + arg[1]: `-XX:MaxPermSize=512m`
          + arg[2]: `-Xms256m`
          + arg[3]: `-Xmx1024m`

  * va1ihgdweb32 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      8
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         slave2
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `/usr/local/jdk1.7.0_51/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_51
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 509.50 MB (534249472)
          + Free memory:      59.11 MB (61980400)
          + In-use memory:    450.39 MB (472269072)
          + PermGen used:     47.74 MB (50059928)
          + PermGen max:      512.00 MB (536870912)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.51-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-431.29.2.el6.x86_64
      - Process ID: 27992 (0x6d58)
      - Process started: 2015-12-02 22:52:14.729-0500
      - Process uptime: 2 days 15 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/local/jdk1.7.0_51/jre/lib/resources.jar:/usr/local/jdk1.7.0_51/jre/lib/rt.jar:/usr/local/jdk1.7.0_51/jre/lib/sunrsasign.jar:/usr/local/jdk1.7.0_51/jre/lib/jsse.jar:/usr/local/jdk1.7.0_51/jre/lib/jce.jar:/usr/local/jdk1.7.0_51/jre/lib/charsets.jar:/usr/local/jdk1.7.0_51/jre/lib/jfr.jar:/usr/local/jdk1.7.0_51/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-XX:PermSize=128m`
          + arg[1]: `-XX:MaxPermSize=512m`
          + arg[2]: `-Xms256m`
          + arg[3]: `-Xmx1024m`

  * va1ihgdweb33 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      8
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         slave3 nodejs
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        2.53
      - Java
          + Home:           `/usr/local/jdk1.7.0_51/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_51
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 532.50 MB (558366720)
          + Free memory:      202.43 MB (212266288)
          + In-use memory:    330.07 MB (346100432)
          + PermGen used:     50.37 MB (52814968)
          + PermGen max:      512.00 MB (536870912)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.51-b03
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-431.29.2.el6.x86_64
      - Process ID: 4280 (0x10b8)
      - Process started: 2015-12-02 22:52:14.973-0500
      - Process uptime: 2 days 15 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/local/jdk1.7.0_51/jre/lib/resources.jar:/usr/local/jdk1.7.0_51/jre/lib/rt.jar:/usr/local/jdk1.7.0_51/jre/lib/sunrsasign.jar:/usr/local/jdk1.7.0_51/jre/lib/jsse.jar:/usr/local/jdk1.7.0_51/jre/lib/jce.jar:/usr/local/jdk1.7.0_51/jre/lib/charsets.jar:/usr/local/jdk1.7.0_51/jre/lib/jfr.jar:/usr/local/jdk1.7.0_51/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-XX:PermSize=128m`
          + arg[1]: `-XX:MaxPermSize=512m`
          + arg[2]: `-Xms512m`
          + arg[3]: `-Xmx1024m`


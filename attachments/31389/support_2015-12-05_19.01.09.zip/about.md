Jenkins
=======

Version details
---------------

  * Version: `1.638`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/usr/local/jdk1.7.0_51/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_51
      - Maximum memory:   3.56 GB (3817865216)
      - Allocated memory: 2.58 GB (2766667776)
      - Free memory:      1.33 GB (1426671080)
      - In-use memory:    1.25 GB (1339996696)
      - PermGen used:     144.72 MB (151751656)
      - PermGen max:      512.00 MB (536870912)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.51-b03
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      2.6.32-431.29.2.el6.x86_64
  * Process ID: 18679 (0x48f7)
  * Process started: 2015-12-02 22:51:57.625-0500
  * Process uptime: 2 days 15 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/local/jdk1.7.0_51/jre/lib/resources.jar:/usr/local/jdk1.7.0_51/jre/lib/rt.jar:/usr/local/jdk1.7.0_51/jre/lib/sunrsasign.jar:/usr/local/jdk1.7.0_51/jre/lib/jsse.jar:/usr/local/jdk1.7.0_51/jre/lib/jce.jar:/usr/local/jdk1.7.0_51/jre/lib/charsets.jar:/usr/local/jdk1.7.0_51/jre/lib/jfr.jar:/usr/local/jdk1.7.0_51/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
      - arg[1]: `-Djava.awt.headless=true`
      - arg[2]: `-XX:PermSize=128m`
      - arg[3]: `-XX:MaxPermSize=512m`
      - arg[4]: `-Xms2048m`
      - arg[5]: `-Xmx4096m`
      - arg[6]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`

Active Plugins
--------------

  * ace-editor:1.0.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-collector:1.45 *(update available)* 'Static Analysis Collector Plug-in'
  * analysis-core:1.74 *(update available)* 'Static Analysis Utilities'
  * ansicolor:0.4.2 'AnsiColor'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * appdynamics-dashboard:1.0.7 'AppDynamics Dashboard Plugin for Jenkins'
  * artifact-diff-plugin:1.3 'Artifact diff Plugin'
  * artifact-promotion:0.3.7 'artifact-promotion'
  * artifactdeployer:0.33 'Jenkins Artifact Deployer Plug-in'
  * artifactory:2.4.3 *(update available)* 'Jenkins Artifactory Plugin'
  * async-http-client:1.7.8 'Async Http Client'
  * aws-java-sdk:1.10.26 'Amazon Web Services SDK'
  * branch-api:1.0 'Branch API Plugin'
  * build-blocker-plugin:1.7.1 *(update available)* 'Build Blocker Plugin'
  * build-cause-run-condition:0.1 'Build Cause Run Condition Plugin'
  * build-line:1.0.4 'Build Line Plugin'
  * build-pipeline-plugin:1.4.8 *(update available)* 'Build Pipeline Plugin'
  * build-user-vars-plugin:1.4 'Jenkins user build vars plugin'
  * build-view-column:0.2 'Build View Column Plugin'
  * build-with-parameters:1.3 'Build With Parameters'
  * buildgraph-view:1.1.1 'buildgraph-view'
  * buildresult-trigger:0.17 'Jenkins BuildResultTrigger Plug-in'
  * cloudbees-credentials:3.3 'CloudBees Credentials Plugin'
  * cloudbees-folder:5.1 'CloudBees Folders Plugin'
  * compact-columns:1.10 'Compact Columns'
  * composer-security-checker:1.7 'Jenkins composer security checker plugin'
  * compress-buildlog:1.0 'Jenkins Compress Build Log plugin'
  * conditional-buildstep:1.3.3 'conditional-buildstep'
  * config-file-provider:2.9.3 'Config File Provider Plugin'
  * configurationslicing:1.44 'Configuration Slicing plugin'
  * copy-project-link:1.4 'Copy project link plugin'
  * copy-to-slave:1.4.4 'Copy To Slave Plugin'
  * copyartifact:1.36.1 *(update available)* 'Copy Artifact Plugin'
  * countjobs-viewstabbar:1.0.0 'countjobs-viewstabbar'
  * createjobadvanced:1.8 'Create Job Advanced'
  * credentials:1.24 'Credentials Plugin'
  * cron_column:1.4 'Cron Column Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.6 'Dashboard View'
  * dependencyanalyzer:0.7 'Jenkins Dependency Analyzer Plugin'
  * depgraph-view:0.11 'Dependency Graph Viewer Plugin'
  * deployment-notification:1.2 'deployment-notification'
  * description-column-plugin:1.3 'Description Column Plugin'
  * description-setter:1.10 'Jenkins description setter plugin'
  * downstream-buildview:1.9 'Downstream build view'
  * downstream-ext:1.8 'Downstream-Ext'
  * durable-task:1.6 *(update available)* 'Durable Task Plugin'
  * dynamic_extended_choice_parameter:1.0.1 'Dynamic Extended Choice Parameter Plug-In'
  * dynamicparameter:0.2.0 'Jenkins Dynamic Parameter Plug-in'
  * ec2-deployment-dashboard:1.0.10 'Deployment Dashboard Plugin for Jenkins'
  * email-ext:2.40.5 'Email Extension Plugin'
  * emailext-template:0.4 'Email Extension Template Plugin'
  * enhanced-old-build-discarder:1.0 'enhanced-old-build-discarder'
  * envfile:1.2 'Jenkins Environment File Plugin'
  * envinject:1.92.1 'Environment Injector Plugin'
  * environment-dashboard:1.1.4 'Environment Dashboard Plugin'
  * extended-choice-parameter:0.52 *(update available)* 'Extended Choice Parameter Plug-In'
  * extended-read-permission:1.0 'Hudson Extended Read Permission Plugin'
  * extensible-choice-parameter:1.3.2 'Extensible Choice Parameter plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * extra-columns:1.15 'Extra Columns Plugin'
  * findbugs:4.62 *(update available)* 'FindBugs Plug-in'
  * form-element-path:1.5 'Form element path plugin'
  * git:2.4.0 'Jenkins GIT plugin'
  * git-chooser-alternative:1.1 'Alternative build chooser'
  * git-client:1.19.0 'Jenkins GIT client plugin'
  * git-parameter:0.4.0 'Git Parameter Plug-In'
  * git-server:1.6 'Git server plugin'
  * git-tag-message:1.4 'Git Tag Message Plugin'
  * global-post-script:1.0.12 'Global Post Script Plugin'
  * global-variable-string-parameter:1.2 'Global Variable String Parameter'
  * greenballs:1.15 'Green Balls'
  * groovy-postbuild:2.2.2 'Groovy Postbuild'
  * htmlpublisher:1.9 'HTML Publisher plugin'
  * hudson-wsclean-plugin:1.0.5 'Distributed Workspace Clean plugin'
  * jackson2-api:2.5.4 'Jackson 2 API Plugin'
  * jacoco:1.0.19 *(update available)* 'Jenkins JaCoCo plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * jenkins-flowdock-plugin:1.1.8 'Flowdock plugin'
  * job-import-plugin:1.2 'Job Import Plugin'
  * jobtemplates:1.0 'jobtemplates'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.1.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * junit:1.9 'JUnit Plugin'
  * junit-attachments:1.4-SNAPSHOT (private-11/14/2014 14:22-kulkarshri) 'JUnit Attachments Plugin'
  * lastfailureversioncolumn:1.1 'Last Failure Version Column'
  * lastsuccessdescriptioncolumn:1.0 'Last Success Description Column'
  * lastsuccessversioncolumn:1.1 'Last Success Version Column'
  * ldap:1.11 'LDAP Plugin'
  * locks-and-latches:0.6 'Hudson Locks and Latches plugin'
  * log-parser:2.0 'Log Parser Plugin'
  * m2release:0.14.0 'Jenkins Maven Release Plug-in Plug-in'
  * mailer:1.16 'Jenkins Mailer Plugin'
  * managed-scripts:1.2.1 'Managed Scripts'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * matrix-auth:1.2 'Matrix Authorization Strategy Plugin'
  * matrix-combinations-parameter:1.0.9 'Matrix Configuration Parameter Plugin'
  * matrix-project:1.6 'Matrix Project Plugin'
  * maven-dependency-update-trigger:1.5 'Maven Dependency Update Trigger'
  * maven-deployment-linker:1.5.1 'Maven Deployment Linker'
  * maven-info:0.2.0 'Jenkins Maven Info Plugin'
  * maven-metadata-plugin:1.2.0 *(update available)* 'Maven Metadata Plugin for Jenkins CI server'
  * maven-plugin:2.12.1 'Maven Integration plugin'
  * maven-repo-cleaner:1.2 'Maven Repository Scheduled Cleanup Plugin'
  * metrics:3.1.2.1 'Metrics Plugin'
  * monitoring:1.57.0 *(update available)* 'Monitoring'
  * multi-branch-project-plugin:0.3 *(update available)* 'Multi-Branch Project Plugin'
  * multiple-scms:0.5 'Jenkins Multiple SCMs plugin'
  * nodejs:0.2.1 'NodeJS Plugin'
  * nodelabelparameter:1.5.1 *(update available)* 'Node and Label parameter plugin'
  * pam-auth:1.2 'PAM Authentication plugin'
  * Parameterized-Remote-Trigger:2.2.2 'Parameterized Remote Trigger Plugin'
  * parameterized-trigger:2.29 'Jenkins Parameterized Trigger plugin'
  * persistent-parameter:1.1 'Persistent Parameter Plugin'
  * postbuild-task:1.8 'Hudson Post build task'
  * progress-bar-column-plugin:1.0 'Progress Bar Column Plugin'
  * project-inheritance:1.5.3 'inheritance-plugin'
  * publish-over-ssh:1.13 'Publish Over SSH'
  * purge-build-queue-plugin:1.0 'Purge Build Queue Plugin'
  * random-string-parameter:1.0 'Random String Parameter Plugin'
  * rebuild:1.25 'Rebuilder'
  * repository:1.2 'Jenkins Maven Repository Server Plugin'
  * repository-connector:1.1.2 'Repository Connector'
  * rich-text-publisher-plugin:1.3 'Rich Text Publisher Plugin'
  * role-strategy:2.2.0 'Role-based Authorization Strategy'
  * run-condition:1.0 'Run Condition Plugin'
  * run-condition-extras:0.2 'Jenkins Run Condition Extras Plugin'
  * s3:0.8 'Jenkins S3 publisher plugin'
  * saferestart:0.3 'Safe Restart Plugin'
  * sauce-ondemand:1.142 *(update available)* 'Jenkins Sauce OnDemand plugin'
  * scm-api:1.0 'SCM API Plugin'
  * script-security:1.15 'Script Security Plugin'
  * scriptler:2.7 *(update available)* 'Scriptler'
  * sectioned-view:1.19 *(update available)* 'Sectioned View Plugin'
  * selected-tests-executor:1.3.3 'Tests Selector'
  * selection-tasks-plugin:1.0 'Selection tasks plugin'
  * selenium-axis:0.0.6 'Selenium Capability Axis'
  * selenium-builder:1.14 'Jenkins Selenium Builder plugin'
  * seleniumhtmlreport:1.0 'Selenium HTML report'
  * shared-objects:0.44 'Shared Objects Plugin'
  * shelve-project-plugin:1.5 'Shelve Project Plugin'
  * show-build-parameters:1.0 'Show Build Parameters plugin'
  * sidebar-link:1.7 'Sidebar Link'
  * simple-theme-plugin:0.3 'Simple Theme Plugin'
  * sitemonitor:0.4 'SiteMonitor Plugin'
  * sonar:2.3 'Jenkins SonarQube Plugin'
  * sonargraph-plugin:1.6.4 'Sonargraph Plugin'
  * ssh-credentials:1.11 'SSH Credentials Plugin'
  * ssh-slaves:1.10 'Jenkins SSH Slaves plugin'
  * started-by-envvar:1.0 'Started-By Environment Variable Plugin'
  * StashBranchParameter:0.1.5 *(update available)* 'Stash Branch Parameter Plug-In'
  * stashNotifier:1.8 *(update available)* 'Stash Notifier'
  * subversion:2.5.3 *(update available)* 'Jenkins Subversion Plug-in'
  * support-core:2.28 'Support Core Plugin'
  * svn-tag:1.18 'Jenkins Subversion Tagging Plugin'
  * tasks:4.46 *(update available)* 'Task Scanner Plug-in'
  * team-views:0.9.0 'Team Views'
  * template-project:1.5.1 'Template Project plugin'
  * template-workflows:1.2 'Template Workflows'
  * terminal:1.4 'Jenkins Terminal Plugin'
  * test-stability:1.0 'Test stability history'
  * testInProgress:1.4 'Test In Progress Plugin'
  * text-finder:1.10 'Jenkins TextFinder plugin'
  * text-finder-run-condition:0.1 'Text Finder Run Condition Plugin'
  * throttle-concurrents:1.8.4 'Jenkins Throttle Concurrent Builds Plug-in'
  * timestamper:1.7.2 'Timestamper'
  * token-macro:1.11 'Token Macro Plugin'
  * tracking-git:1.0 'Tracking Git Plugin'
  * validating-string-parameter:2.3 'Validating String Parameter Plugin'
  * versioncolumn:0.2 'Jenkins Version Column plugin'
  * versionnumber:1.6 'Version Number Plug-In'
  * view-job-filters:1.27 'View Job Filters'
  * viewVC:1.7 'ViewVC Plugin'
  * violation-comments-to-stash:1.9 'Jenkins Violation Comments to Stash Plugin'
  * violations:0.7.11 'Jenkins Violations plugin'
  * windows-slaves:1.0 *(update available)* 'Windows Slaves Plugin'
  * workflow-aggregator:1.11 'Workflow: Aggregator'
  * workflow-api:1.11 'Workflow: API'
  * workflow-basic-steps:1.11 'Workflow: Basic Steps'
  * workflow-cps:1.11 'Workflow: Groovy CPS Execution'
  * workflow-cps-global-lib:1.11 'Workflow: Global Shared Library for CPS workflow'
  * workflow-durable-task-step:1.11 'Workflow: Durable Task Step'
  * workflow-job:1.11 'Workflow: Job'
  * workflow-multibranch:1.11 'Workflow: Multibranch'
  * workflow-scm-step:1.11 'Workflow: SCM Step'
  * workflow-step-api:1.11 'Workflow: Step API'
  * workflow-support:1.11 'Workflow: Execution Support'
  * ws-cleanup:0.28 'Jenkins Workspace Cleanup Plugin'

Item statistics
===============

  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 107
    - Number of builds per job: 2.7757009345794392 [n=107, s=7.8]
  * `hudson.matrix.MatrixProject`
    - Number of items: 13
    - Number of builds per job: 8.615384615384615 [n=13, s=10.0]
    - Number of items per container: 8.23076923076923 [n=13, s=10.0]
  * `hudson.maven.MavenModule`
    - Number of items: 1166
    - Number of builds per job: 18.86277873070326 [n=1166, s=11.47896170765291]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 279
    - Number of builds per job: 15.770609318996415 [n=279, s=14.0]
    - Number of items per container: 4.17921146953405 [n=279, s=9.6]
  * `hudson.model.FreeStyleProject`
    - Number of items: 222
    - Number of builds per job: 16.563063063063062 [n=222, s=38.0]
  * `org.jenkins.plugin.templateWorkflows.TemplatesWorkflowJob`
    - Number of items: 1
    - Number of builds per job: 0 [n=1]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 3
    - Number of builds per job: 0.0 [n=3, s=0.0]

Total job statistics
======================

  * Number of jobs: 1791
  * Number of builds per job: 17.018425460636514 [n=1791, s=17.64792851818955]

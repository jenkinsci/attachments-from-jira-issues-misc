Item statistics
===============

  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 1
    - Number of builds per job: 3 [n=1]
  * `hudson.matrix.MatrixProject`
    - Number of items: 1
    - Number of builds per job: 4 [n=1]
    - Number of items per container: 1 [n=1]

Total job statistics
======================

  * Number of jobs: 2
  * Number of builds per job: 3.5 [n=2, s=0.7]

Jenkins
=======

Version details
---------------

  * Version: `2.32.1`
  * Mode:    WAR
  * Url:     http://15.106.186.25:8080/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_111
      - Maximum memory:   875.00 MB (917504000)
      - Allocated memory: 392.00 MB (411041792)
      - Free memory:      220.39 MB (231098344)
      - In-use memory:    171.61 MB (179943448)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.111-b14
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.4.0-21-generic
      - Distribution: Ubuntu 16.04 LTS
  * Process ID: 5286 (0x14a6)
  * Process started: 2017-01-05 03:48:52.413-0800
  * Process uptime: 55 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * bouncycastle-api:2.16.0 'bouncycastle API Plugin'
  * config-file-provider:2.15.1 'Config File Provider Plugin'
  * credentials:2.1.10 'Credentials Plugin'
  * display-url-api:0.5 'Display URL API'
  * git:3.0.1 'Jenkins Git plugin'
  * git-client:2.2.0 'Jenkins Git client plugin'
  * github:1.25.0 'GitHub plugin'
  * github-api:1.82 'GitHub API Plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * junit:1.19 'JUnit Plugin'
  * mailer:1.18 'Jenkins Mailer Plugin'
  * matrix-auth:1.4 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.7.1 'Matrix Project Plugin'
  * maven-plugin:2.14 'Maven Integration plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * plain-credentials:1.3 'Plain Credentials Plugin'
  * saferestart:0.3 'Safe Restart Plugin'
  * scm-api:1.3 'SCM API Plugin'
  * script-security:1.25 'Script Security Plugin'
  * ssh-credentials:1.12 'SSH Credentials Plugin'
  * structs:1.5 'Structs Plugin'
  * support-core:2.38 'Support Core Plugin'
  * token-macro:2.0 'Token Macro Plugin'
  * windows-slaves:1.2 'Windows Slaves Plugin'
  * workflow-scm-step:2.3 'Pipeline: SCM Step'
  * workflow-step-api:2.6 'Pipeline: Step API'

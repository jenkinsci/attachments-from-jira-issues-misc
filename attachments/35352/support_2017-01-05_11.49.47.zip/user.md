User
====

Authentication
--------------

  * Authenticated: true
  * Name: dan
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@fdb2c08d: Username: hudson.security.HudsonPrivateSecurityRealm$Details@6e62e7c7; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@ef30: RemoteIpAddress: 15.106.186.20; SessionId: on24wfnndo4vg7kkwchodiqd; Granted Authorities: authenticated`


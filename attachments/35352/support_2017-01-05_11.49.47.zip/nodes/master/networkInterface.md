-----------
 * Name ens33
 ** Hardware Address - 000c296c733d
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:20c:29ff:fe6c:733d%ens33
 ** InetAddress - /15.106.186.25
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

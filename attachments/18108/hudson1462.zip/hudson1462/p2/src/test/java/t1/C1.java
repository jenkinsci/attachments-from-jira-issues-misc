package t1;
import org.testng.annotations.Test;

@Test
public class C1 {
	public void t1() {

	}

	public void t2() {

	}

}

package package2;
import org.testng.annotations.Test;

@Test
public class C2 {
	public void t1() {

	}

}

﻿
namespace Genesyslab.Lync.Test
{
    using NUnit.Framework;

    [TestFixture(CallAcceptTypeEnum.Accept)]
    [TestFixture(CallAcceptTypeEnum.Connect)]
    public class TestApplication: AbstractTestGroup
    {
        public TestApplication(CallAcceptTypeEnum ss)
        {
            CallAcceptType = ss;
        }

        [TestCase]
        public void TestMethod()
        {
            TestContext.Progress.WriteLine(CallAcceptType);
            Assert.True(true);
        }
    }
}
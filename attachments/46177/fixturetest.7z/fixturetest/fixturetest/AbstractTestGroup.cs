﻿using NUnit.Framework;

namespace Genesyslab.Lync.Test
{
    public abstract class AbstractTestGroup
    {
        public enum CallAcceptTypeEnum
        {
            Connect,
            Accept
        }

        public CallAcceptTypeEnum CallAcceptType;

        /// <summary>
        /// Initialize test group,
        /// </summary>
        [OneTimeSetUp]
        protected void Init()
        {
            TestContext.Progress.WriteLine("AbstractTestGroup");
            TestContext.Progress.WriteLine(CallAcceptType);
        }
    }
}

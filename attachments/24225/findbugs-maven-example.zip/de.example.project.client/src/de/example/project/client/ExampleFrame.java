/****************************************************************
 *                                                              *
 * Copyright (c) 2011-2013 compeople AG                         *
 * All rights reserved. The use of this program and the         *
 * accompanying materials are subject to license terms.         *
 *                                                              *
 ****************************************************************/
package de.example.project.client;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.ToolTipManager;

import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.layout.Sizes;

/** */
public class ExampleFrame extends JFrame {
	private static final String FRAME_TITLE = "Example Frame";
	private static final int FRAME_WIDTH = 400;
	private static final int FRAME_HEIGHT = 200;

	private FormLayout layout;
	private JPanel mainPanel;
	private CellConstraints cc;
	private JButton exitButton;
	private JButton okButton;

	protected void init() {
		addWindowListener( new WindowAdapter() {
			@Override
			public void windowClosing( final WindowEvent e ) {}
		} );
		setTitle( FRAME_TITLE );
		setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
		setSize( FRAME_WIDTH, FRAME_HEIGHT );
		setLocationRelativeTo( null );
		ToolTipManager.sharedInstance().setDismissDelay( 10000 );
		initLayout();
	}

	private void initLayout() {
		cc = new CellConstraints();
		layout = new FormLayout( "10pt, pref:grow, 10pt, 300pt:grow, 10pt" );
		layout.appendRow( new RowSpec( Sizes.pixel( 10 ) ) );
		mainPanel = new JPanel( layout );

		final JPanel buttonsPanel = new JPanel( new FormLayout( "10pt, pref:grow, 10pt, pref:grow, 10pt", "10pt, pref, 10pt" ) );
		okButton = new JButton( "OK" );
		exitButton = new JButton( "Exit" );
		exitButton.addActionListener( new ActionListener() {
			@Override
			public void actionPerformed( final ActionEvent arg0 ) {
				System.exit( 0 );// FindBugs won't like this!
			}
		} );
		buttonsPanel.add( okButton, cc.xy( 2, 2 ) );
		buttonsPanel.add( exitButton, cc.xy( 4, 2 ) );

		add( mainPanel, BorderLayout.CENTER );
		add( buttonsPanel, BorderLayout.SOUTH );
		mainPanel.setBackground( Color.WHITE );
		buttonsPanel.setBackground( Color.WHITE );
	}

	// FindBugs won't like this!
	@Override
	public boolean equals( final Object obj ) {
		return true;
	}
}

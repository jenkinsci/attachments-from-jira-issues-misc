package de.example.project.client;


/** */
public class Main {

	/** */
	public static void main( final String[] args ) {
		final ExampleFrame exampleFrame = new ExampleFrame();
		exampleFrame.init();
		exampleFrame.setVisible( true );
	}

}

User
====

Authentication
--------------

  * Authenticated: true
  * Name: jmaitrehenry@petalmd.com
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@7a24761b: Username: jmaitrehenry@petalmd.com; Password: [PROTECTED]; Authenticated: true; Details: null; Granted Authorities: authenticated`


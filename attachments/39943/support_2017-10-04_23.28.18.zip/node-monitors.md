Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal: Linux (amd64)
   * jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal: Linux (amd64)
   * jenkins-deploy: Linux (amd64)
   * mon-deploy-vm-mon-deploy: Linux (amd64)
   * stg-deploy-vm-stg-deploy: Linux (amd64)
   * xbot-laptop1: Mac OS X (x86_64)
   * xbot-laptop2: Mac OS X (x86_64)
   * xbot-laptop3: Mac OS X (x86_64)
   * xbot-mini1.local: null
   * xbot-mysql: Mac OS X (x86_64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal: In sync
   * jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal: In sync
   * jenkins-deploy: In sync
   * mon-deploy-vm-mon-deploy: In sync
   * stg-deploy-vm-stg-deploy: In sync
   * xbot-laptop1: In sync
   * xbot-laptop2: In sync
   * xbot-laptop3: In sync
   * xbot-mini1.local: null
   * xbot-mysql: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 23.419GB left on /var/lib/jenkins.
   * jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal: Disk space is too low. Only 18.902GB left on /ci/jenkins.
   * jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal: Disk space is too low. Only 18.675GB left on /ci/jenkins.
   * jenkins-deploy: Disk space is too low. Only 45.348GB left on /var/jenkins.
   * mon-deploy-vm-mon-deploy: Disk space is too low. Only 25.265GB left on /ci/jenkins.
   * stg-deploy-vm-stg-deploy: Disk space is too low. Only 24.772GB left on /ci/jenkins.
   * xbot-laptop1: Disk space is too low. Only 193.935GB left on /Users/xbot/build.
   * xbot-laptop2: Disk space is too low. Only 187.420GB left on /Users/xbot/build.
   * xbot-laptop3: Disk space is too low. Only 189.292GB left on /Users/xbot/build.
   * xbot-mini1.local: null
   * xbot-mysql: Disk space is too low. Only 96.711GB left on /Users/xbot/build.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:167/7482MB  Swap:4088/4095MB
   * jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal: Memory:2431/3956MB  Swap:0/0MB
   * jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal: Memory:2672/3956MB  Swap:0/0MB
   * jenkins-deploy: Memory:529/3791MB  Swap:3946/3968MB
   * mon-deploy-vm-mon-deploy: Memory:5124/6970MB  Swap:0/0MB
   * stg-deploy-vm-stg-deploy: Memory:5742/6970MB  Swap:0/0MB
   * xbot-laptop1: Memory:0/0MB  Swap:1689/2048MB
   * xbot-laptop2: Memory:0/0MB  Swap:920/1024MB
   * xbot-laptop3: Memory:0/0MB  Swap:0/0MB
   * xbot-mini1.local: null
   * xbot-mysql: Memory:0/0MB  Swap:1025/2048MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 23.419GB left on /tmp.
   * jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal: Disk space is too low. Only 18.902GB left on /tmp.
   * jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal: Disk space is too low. Only 18.675GB left on /tmp.
   * jenkins-deploy: Disk space is too low. Only 10.272GB left on /tmp.
   * mon-deploy-vm-mon-deploy: Disk space is too low. Only 25.265GB left on /tmp.
   * stg-deploy-vm-stg-deploy: Disk space is too low. Only 24.772GB left on /tmp.
   * xbot-laptop1: Disk space is too low. Only 193.935GB left on /private/var/folders/zr/nhy1m6kj1dng9h06g8l51p0h0000gn/T.
   * xbot-laptop2: Disk space is too low. Only 187.420GB left on /private/var/folders/rz/3174t0cx74q9f6ld64d7v2540000gn/T.
   * xbot-laptop3: Disk space is too low. Only 189.292GB left on /private/var/folders/b6/xpvmrppn329_xr8sm5l026qr0000gn/T.
   * xbot-mini1.local: null
   * xbot-mysql: Disk space is too low. Only 96.711GB left on /private/var/folders/5p/cv1tw19941s0jvpqlhsq_zcr0000gn/T.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal: 410ms
   * jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal: 411ms
   * jenkins-deploy: 275ms
   * mon-deploy-vm-mon-deploy: 439ms
   * stg-deploy-vm-stg-deploy: 410ms
   * xbot-laptop1: 410ms
   * xbot-laptop2: 274ms
   * xbot-laptop3: 223ms
   * xbot-mini1.local: Time out for last 5 try
   * xbot-mysql: 249ms

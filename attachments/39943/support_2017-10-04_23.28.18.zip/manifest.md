Support Bundle Manifest
=======================

Generated on 2017-10-04 23:28:18.888+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-10-04_23.27.36.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/custom/EC2.log`

      - `nodes/master/logs/custom/Github.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/health-checker.log`

      - `other-logs/jenkins.branch.MultiBranchProject.log`

      - `other-logs/jenkins.branch.MultiBranchProject.log.1`

      - `other-logs/jenkins.branch.MultiBranchProject.log.2`

      - `other-logs/jenkins.branch.MultiBranchProject.log.3`

      - `other-logs/jenkins.branch.MultiBranchProject.log.4`

      - `other-logs/jenkins.branch.MultiBranchProject.log.5`

      - `other-logs/jenkins.branch.OrganizationFolder.log`

      - `other-logs/jenkins.branch.OrganizationFolder.log.1`

      - `other-logs/jenkins.branch.OrganizationFolder.log.2`

      - `other-logs/jenkins.branch.OrganizationFolder.log.3`

      - `other-logs/jenkins.branch.OrganizationFolder.log.4`

      - `other-logs/jenkins.branch.OrganizationFolder.log.5`

  * Garbage Collection Logs

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/docker-jenkins-jnlp-tpl-5-jenkins-igm-5-qp63.c.jenkins-160014.internal/checksums.md5`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/checksums.md5`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/checksums.md5`

      - `nodes/slave/jenkins-deploy/checksums.md5`

      - `nodes/slave/mon-deploy-vm-mon-deploy/checksums.md5`

      - `nodes/slave/stg-deploy-vm-stg-deploy/checksums.md5`

      - `nodes/slave/xbot-laptop1/checksums.md5`

      - `nodes/slave/xbot-laptop2/checksums.md5`

      - `nodes/slave/xbot-laptop3/checksums.md5`

      - `nodes/slave/xbot-mini1.local/checksums.md5`

      - `nodes/slave/xbot-mysql/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/docker-jenkins-jnlp-tpl-5-jenkins-igm-5-qp63.c.jenkins-160014.internal/exportTable.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/exportTable.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/exportTable.txt`

      - `nodes/slave/jenkins-deploy/exportTable.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/exportTable.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/exportTable.txt`

      - `nodes/slave/xbot-laptop1/exportTable.txt`

      - `nodes/slave/xbot-laptop2/exportTable.txt`

      - `nodes/slave/xbot-laptop3/exportTable.txt`

      - `nodes/slave/xbot-mini1.local/exportTable.txt`

      - `nodes/slave/xbot-mysql/exportTable.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/file-descriptors.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/file-descriptors.txt`

      - `nodes/slave/jenkins-deploy/file-descriptors.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/file-descriptors.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/file-descriptors.txt`

      - `nodes/slave/xbot-laptop1/file-descriptors.txt`

      - `nodes/slave/xbot-laptop2/file-descriptors.txt`

      - `nodes/slave/xbot-laptop3/file-descriptors.txt`

      - `nodes/slave/xbot-mysql/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/proc/meminfo.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/proc/self/cmdline`

      - `nodes/slave/mon-deploy-vm-mon-deploy/proc/self/environ`

      - `nodes/slave/mon-deploy-vm-mon-deploy/proc/self/limits.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/proc/self/mountstats.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/proc/self/status.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/proc/meminfo.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/proc/self/cmdline`

      - `nodes/slave/stg-deploy-vm-stg-deploy/proc/self/environ`

      - `nodes/slave/stg-deploy-vm-stg-deploy/proc/self/limits.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/proc/self/mountstats.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/%E2%80%98mysql%E2%80%99/gnuplot`

      - `load-stats/label/%E2%80%98mysql%E2%80%99/hour.csv`

      - `load-stats/label/%E2%80%98mysql%E2%80%99/min.csv`

      - `load-stats/label/%E2%80%98mysql%E2%80%99/sec10.csv`

      - `load-stats/label/deploy/gnuplot`

      - `load-stats/label/deploy/hour.csv`

      - `load-stats/label/deploy/min.csv`

      - `load-stats/label/deploy/sec10.csv`

      - `load-stats/label/docker-jenkins-jnlp-tpl-5-jenkins-igm-5-qp63.c.jenkins-160014.internal/gnuplot`

      - `load-stats/label/docker-jenkins-jnlp-tpl-5-jenkins-igm-5-qp63.c.jenkins-160014.internal/hour.csv`

      - `load-stats/label/docker-jenkins-jnlp-tpl-5-jenkins-igm-5-qp63.c.jenkins-160014.internal/min.csv`

      - `load-stats/label/docker-jenkins-jnlp-tpl-5-jenkins-igm-5-qp63.c.jenkins-160014.internal/sec10.csv`

      - `load-stats/label/docker-jenkins-jnlp-tpl-5/gnuplot`

      - `load-stats/label/docker-jenkins-jnlp-tpl-5/hour.csv`

      - `load-stats/label/docker-jenkins-jnlp-tpl-5/min.csv`

      - `load-stats/label/docker-jenkins-jnlp-tpl-5/sec10.csv`

      - `load-stats/label/docker-large/gnuplot`

      - `load-stats/label/docker-large/hour.csv`

      - `load-stats/label/docker-large/min.csv`

      - `load-stats/label/docker-large/sec10.csv`

      - `load-stats/label/docker/gnuplot`

      - `load-stats/label/docker/hour.csv`

      - `load-stats/label/docker/min.csv`

      - `load-stats/label/docker/sec10.csv`

      - `load-stats/label/ios-provisioning/gnuplot`

      - `load-stats/label/ios-provisioning/hour.csv`

      - `load-stats/label/ios-provisioning/min.csv`

      - `load-stats/label/ios-provisioning/sec10.csv`

      - `load-stats/label/ios-tests/gnuplot`

      - `load-stats/label/ios-tests/hour.csv`

      - `load-stats/label/ios-tests/min.csv`

      - `load-stats/label/ios-tests/sec10.csv`

      - `load-stats/label/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/gnuplot`

      - `load-stats/label/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/hour.csv`

      - `load-stats/label/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/min.csv`

      - `load-stats/label/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/sec10.csv`

      - `load-stats/label/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/gnuplot`

      - `load-stats/label/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/hour.csv`

      - `load-stats/label/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/min.csv`

      - `load-stats/label/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/sec10.csv`

      - `load-stats/label/jenkins-builder/gnuplot`

      - `load-stats/label/jenkins-builder/hour.csv`

      - `load-stats/label/jenkins-builder/min.csv`

      - `load-stats/label/jenkins-builder/sec10.csv`

      - `load-stats/label/jenkins-deploy/gnuplot`

      - `load-stats/label/jenkins-deploy/hour.csv`

      - `load-stats/label/jenkins-deploy/min.csv`

      - `load-stats/label/jenkins-deploy/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/mon-deploy-vm-mon-deploy/gnuplot`

      - `load-stats/label/mon-deploy-vm-mon-deploy/hour.csv`

      - `load-stats/label/mon-deploy-vm-mon-deploy/min.csv`

      - `load-stats/label/mon-deploy-vm-mon-deploy/sec10.csv`

      - `load-stats/label/mon-deploy/gnuplot`

      - `load-stats/label/mon-deploy/hour.csv`

      - `load-stats/label/mon-deploy/min.csv`

      - `load-stats/label/mon-deploy/sec10.csv`

      - `load-stats/label/staging/gnuplot`

      - `load-stats/label/staging/hour.csv`

      - `load-stats/label/staging/min.csv`

      - `load-stats/label/staging/sec10.csv`

      - `load-stats/label/stg-deploy-vm-stg-deploy/gnuplot`

      - `load-stats/label/stg-deploy-vm-stg-deploy/hour.csv`

      - `load-stats/label/stg-deploy-vm-stg-deploy/min.csv`

      - `load-stats/label/stg-deploy-vm-stg-deploy/sec10.csv`

      - `load-stats/label/stg-deploy/gnuplot`

      - `load-stats/label/stg-deploy/hour.csv`

      - `load-stats/label/stg-deploy/min.csv`

      - `load-stats/label/stg-deploy/sec10.csv`

      - `load-stats/label/xbot-laptop1/gnuplot`

      - `load-stats/label/xbot-laptop1/hour.csv`

      - `load-stats/label/xbot-laptop1/min.csv`

      - `load-stats/label/xbot-laptop1/sec10.csv`

      - `load-stats/label/xbot-laptop2/gnuplot`

      - `load-stats/label/xbot-laptop2/hour.csv`

      - `load-stats/label/xbot-laptop2/min.csv`

      - `load-stats/label/xbot-laptop2/sec10.csv`

      - `load-stats/label/xbot-laptop3/gnuplot`

      - `load-stats/label/xbot-laptop3/hour.csv`

      - `load-stats/label/xbot-laptop3/min.csv`

      - `load-stats/label/xbot-laptop3/sec10.csv`

      - `load-stats/label/xbot-mini1.local/gnuplot`

      - `load-stats/label/xbot-mini1.local/hour.csv`

      - `load-stats/label/xbot-mini1.local/min.csv`

      - `load-stats/label/xbot-mini1.local/sec10.csv`

      - `load-stats/label/xbot-mysql/gnuplot`

      - `load-stats/label/xbot-mysql/hour.csv`

      - `load-stats/label/xbot-mysql/min.csv`

      - `load-stats/label/xbot-mysql/sec10.csv`

      - `load-stats/label/xlarge/gnuplot`

      - `load-stats/label/xlarge/hour.csv`

      - `load-stats/label/xlarge/min.csv`

      - `load-stats/label/xlarge/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/docker-jenkins-jnlp-tpl-5-jenkins-igm-5-qp63.c.jenkins-160014.internal/metrics.json`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/metrics.json`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/metrics.json`

      - `nodes/slave/jenkins-deploy/metrics.json`

      - `nodes/slave/mon-deploy-vm-mon-deploy/metrics.json`

      - `nodes/slave/stg-deploy-vm-stg-deploy/metrics.json`

      - `nodes/slave/xbot-laptop1/metrics.json`

      - `nodes/slave/xbot-laptop2/metrics.json`

      - `nodes/slave/xbot-laptop3/metrics.json`

      - `nodes/slave/xbot-mini1.local/metrics.json`

      - `nodes/slave/xbot-mysql/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/docker-jenkins-jnlp-tpl-5-jenkins-igm-5-qp63.c.jenkins-160014.internal/networkInterface.md`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/networkInterface.md`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/networkInterface.md`

      - `nodes/slave/jenkins-deploy/networkInterface.md`

      - `nodes/slave/mon-deploy-vm-mon-deploy/networkInterface.md`

      - `nodes/slave/stg-deploy-vm-stg-deploy/networkInterface.md`

      - `nodes/slave/xbot-laptop1/networkInterface.md`

      - `nodes/slave/xbot-laptop2/networkInterface.md`

      - `nodes/slave/xbot-laptop3/networkInterface.md`

      - `nodes/slave/xbot-mini1.local/networkInterface.md`

      - `nodes/slave/xbot-mysql/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/dmesg.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/dmi.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/proc/cpuinfo.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/proc/mounts.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/proc/net/rpc/nfs.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/proc/net/rpc/nfsd.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/proc/swaps.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/proc/system-uptime.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/sysctl.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/userid.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/dmesg.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/dmi.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/proc/cpuinfo.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/proc/mounts.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/proc/net/rpc/nfs.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/proc/net/rpc/nfsd.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/proc/swaps.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/proc/system-uptime.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/sysctl.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/userid.txt`

      - `nodes/slave/jenkins-deploy/dmesg.txt`

      - `nodes/slave/jenkins-deploy/dmi.txt`

      - `nodes/slave/jenkins-deploy/proc/cpuinfo.txt`

      - `nodes/slave/jenkins-deploy/proc/mounts.txt`

      - `nodes/slave/jenkins-deploy/proc/net/rpc/nfs.txt`

      - `nodes/slave/jenkins-deploy/proc/net/rpc/nfsd.txt`

      - `nodes/slave/jenkins-deploy/proc/swaps.txt`

      - `nodes/slave/jenkins-deploy/proc/system-uptime.txt`

      - `nodes/slave/jenkins-deploy/sysctl.txt`

      - `nodes/slave/jenkins-deploy/userid.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/dmesg.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/dmi.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/proc/cpuinfo.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/proc/mounts.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/proc/net/rpc/nfs.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/proc/net/rpc/nfsd.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/proc/swaps.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/proc/system-uptime.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/sysctl.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/userid.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/dmesg.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/dmi.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/proc/cpuinfo.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/proc/mounts.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/proc/net/rpc/nfs.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/proc/net/rpc/nfsd.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/proc/swaps.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/proc/system-uptime.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/sysctl.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/docker-jenkins-jnlp-tpl-5-jenkins-igm-5-qp63.c.jenkins-160014.internal/system.properties`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/system.properties`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/system.properties`

      - `nodes/slave/jenkins-deploy/system.properties`

      - `nodes/slave/mon-deploy-vm-mon-deploy/system.properties`

      - `nodes/slave/stg-deploy-vm-stg-deploy/system.properties`

      - `nodes/slave/xbot-laptop1/system.properties`

      - `nodes/slave/xbot-laptop2/system.properties`

      - `nodes/slave/xbot-laptop3/system.properties`

      - `nodes/slave/xbot-mini1.local/system.properties`

      - `nodes/slave/xbot-mysql/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/docker-jenkins-jnlp-tpl-5-jenkins-igm-5-qp63.c.jenkins-160014.internal/thread-dump.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-6614.c.jenkins-160014.internal/thread-dump.txt`

      - `nodes/slave/jenkins-builder-jenkins-builder-ig-v1-0-mc59.c.jenkins-160014.internal/thread-dump.txt`

      - `nodes/slave/jenkins-deploy/thread-dump.txt`

      - `nodes/slave/mon-deploy-vm-mon-deploy/thread-dump.txt`

      - `nodes/slave/stg-deploy-vm-stg-deploy/thread-dump.txt`

      - `nodes/slave/xbot-laptop1/thread-dump.txt`

      - `nodes/slave/xbot-laptop2/thread-dump.txt`

      - `nodes/slave/xbot-laptop3/thread-dump.txt`

      - `nodes/slave/xbot-mini1.local/thread-dump.txt`

      - `nodes/slave/xbot-mysql/thread-dump.txt`


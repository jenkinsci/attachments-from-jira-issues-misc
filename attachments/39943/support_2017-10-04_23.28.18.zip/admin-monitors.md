Monitors
========

`OldData`
--------------
  * Problematic object: `hudson.slaves.DumbSlave[xbot-laptop2]`
    - ConversionException: Cannot construct hudson.slaves.RetentionStrategy : hudson.slaves.RetentionStrategy : Cannot construct hudson.slaves.RetentionStrategy : hudson.slaves.RetentionStrategy
---- Debugging information ----
message             : Cannot construct hudson.slaves.RetentionStrategy : hudson.slaves.RetentionStrategy
cause-exception     : com.thoughtworks.xstream.converters.reflection.ObjectAccessException
cause-message       : Cannot construct hudson.slaves.RetentionStrategy : hudson.slaves.RetentionStrategy
class               : hudson.slaves.RetentionStrategy
required-type       : hudson.slaves.RetentionStrategy
converter-type      : hudson.util.RobustReflectionConverter
path                : /slave/retentionStrategy
line number         : 7
-------------------------------

`hudson.model.UpdateCenter$CoreUpdateMonitor`
--------------
(active and enabled)

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)

`jenkins.slaves.DeprecatedAgentProtocolMonitor`
--------------
(active and enabled)

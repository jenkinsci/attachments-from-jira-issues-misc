Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 28
    - Number of builds per job: 80.89285714285714 [n=28, s=100.0]
  * `jenkins.branch.OrganizationFolder`
    - Number of items: 1
    - Number of items per container: 3 [n=1]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 128
    - Number of builds per job: 13.1953125 [n=128, s=85.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 3
    - Number of items per container: 42.666666666666664 [n=3, s=50.0]

Total job statistics
======================

  * Number of jobs: 156
  * Number of builds per job: 25.346153846153847 [n=156, s=99.0]

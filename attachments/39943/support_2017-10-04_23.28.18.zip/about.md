Jenkins
=======

Version details
---------------

  * Version: `2.79`
  * Mode:    WAR
  * Url:     http://jenkins2.petalmd.com/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_141
      - Maximum memory:   1.62 GB (1744830464)
      - Allocated memory: 978.50 MB (1026031616)
      - Free memory:      254.48 MB (266843768)
      - In-use memory:    724.02 MB (759187848)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.141-b16
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.4.41-35.53.amzn1.x86_64
  * Process ID: 27249 (0x6a71)
  * Process started: 2017-09-20 19:08:43.471+0000
  * Process uptime: 14 days
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
      - arg[1]: `-Djava.awt.headless=true`
      - arg[2]: `-Dhudson.model.ParametersAction.safeParameters=ghprbActualCommit,ghprbActualCommitAuthor,ghprbActualCommitAuthorEmail,ghprbAuthorRepoGitUrl,ghprbCommentBody,ghprbCredentialsId,ghprbGhRepository,ghprbPullAuthorEmail,ghprbPullAuthorLogin,ghprbPullAuthorLoginMention,ghprbPullDescription,ghprbPullId,ghprbPullLink,ghprbPullLongDescription,ghprbPullTitle,ghprbSourceBranch,ghprbTargetBranch,ghprbTriggerAuthor,ghprbTriggerAuthorEmail,ghprbTriggerAuthorLogin,ghprbTriggerAuthorLoginMention,GIT_BRANCH,sha1`
      - arg[3]: `-Dorg.apache.commons.jelly.tags.fmt.timeZone=America/New_York`
      - arg[4]: `-Duser.timezone=America/New_York`
      - arg[5]: `-DsessionTimeout=1440`
      - arg[6]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `org.jenkinsci.plugins.googlelogin.GoogleOAuth2SecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ansicolor:0.5.2 'AnsiColor'
  * ant:1.7 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * aws-credentials:1.22 *(update available)* 'CloudBees Amazon Web Services Credentials Plugin'
  * aws-java-sdk:1.11.119 'Amazon Web Services SDK'
  * blueocean:1.2.4 'Blue Ocean'
  * blueocean-analytics-tools:1.0-alpha-7 'BlueOcean :: Analytics Tools'
  * blueocean-autofavorite:1.0.0 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.2.4 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.2.4 'Common API for Blue Ocean'
  * blueocean-config:1.2.4 'Config API for Blue Ocean'
  * blueocean-dashboard:1.2.4 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.1.0 'Display URL for Blue Ocean'
  * blueocean-events:1.2.4 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.2.4 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.2.4 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.2.4 'i18n for Blue Ocean'
  * blueocean-jira:1.2.4 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.2.4 'JWT for Blue Ocean'
  * blueocean-personalization:1.2.4 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.2.4 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.2.4 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.2.4 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.2.4 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.2.4 'REST Implementation for Blue Ocean'
  * blueocean-web:1.2.4 'Web for Blue Ocean'
  * bouncycastle-api:2.16.2 'bouncycastle API Plugin'
  * branch-api:2.0.11 'Branch API Plugin'
  * build-pipeline-plugin:1.5.7.1 'Build Pipeline Plugin'
  * build-timeout:1.18 'Jenkins build timeout plugin'
  * cloud-stats:0.13 *(update available)* 'Cloud Statistics Plugin'
  * cloudbees-bitbucket-branch-source:2.2.3 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.1.2 'Folders Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * config-file-provider:2.16.3 *(update available)* 'Config File Provider Plugin'
  * copyartifact:1.38.1 'Copy Artifact Plugin'
  * credentials:2.1.16 'Credentials Plugin'
  * credentials-binding:1.13 'Credentials Binding Plugin'
  * dashboard-view:2.9.11 'Dashboard View'
  * display-url-api:2.0 'Display URL API'
  * docker-commons:1.8 'Docker Commons Plugin'
  * docker-workflow:1.13 'Docker Pipeline'
  * durable-task:1.14 'Durable Task Plugin'
  * ec2:1.36 *(update available)* 'Amazon EC2 plugin'
  * embeddable-build-status:1.9 'embeddable-build-status'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * favorite:2.3.0 'Favorite'
  * ghprb:1.39.0 'GitHub Pull Request Builder'
  * git:3.5.1 *(update available)* 'Jenkins Git plugin'
  * git-client:2.5.0 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.28.0 'GitHub plugin'
  * github-api:1.86 *(update available)* 'GitHub API Plugin'
  * github-branch-source:2.2.3 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * google-login:1.3 'Google Login Plugin'
  * greenballs:1.15 'Green Balls'
  * groovy-postbuild:2.3.1 'Groovy Postbuild'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * heavy-job:1.1 'Heavy Job Plugin'
  * htmlpublisher:1.14 'HTML Publisher plugin'
  * http_request:1.8.20 *(update available)* 'HTTP Request Plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jclouds-jenkins:2.14 'Jenkins JClouds plugin'
  * jira:2.4.2 'Jenkins JIRA plugin'
  * jquery:1.11.2-1 'jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.21 'JUnit Plugin'
  * ldap:1.17 'LDAP Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * matrix-auth:1.7 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.11 *(update available)* 'Matrix Project Plugin'
  * maven-plugin:2.17 *(update available)* 'Maven Integration plugin'
  * mercurial:2.1 'Jenkins Mercurial plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * node-iterator-api:1.5 'Node Iterator API Plugin'
  * openstack-cloud:2.24 *(update available)* 'Openstack Cloud Plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parameterized-trigger:2.35.2 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.5.1 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.5 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.1.9 *(update available)* 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.1.9 *(update available)* 'Pipeline: Model Definition'
  * pipeline-model-extensions:1.1.9 *(update available)* 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.9 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.1.9 *(update available)* 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.9 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * postbuild-task:1.8 'Hudson Post build task'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * resource-disposer:0.8 'Resource Disposer Plugin'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:2.2.2 'SCM API Plugin'
  * script-security:1.34 'Script Security Plugin'
  * slack:2.3 'Slack Notification Plugin'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-agent:1.15 'SSH Agent Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.21 'Jenkins SSH Slaves plugin'
  * structs:1.10 'Structs Plugin'
  * support-core:2.41 'Support Core Plugin'
  * timestamper:1.8.8 'Timestamper'
  * token-macro:2.3 'Token Macro Plugin'
  * variant:1.1 'Variant Plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.20 *(update available)* 'Pipeline: API'
  * workflow-basic-steps:2.6 'Pipeline: Basic Steps'
  * workflow-cps:2.40 *(update available)* 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.9 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.15 'Pipeline: Nodes and Processes'
  * workflow-job:2.14.1 'Pipeline: Job'
  * workflow-multibranch:2.16 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.13 'Pipeline: Step API'
  * workflow-support:2.14 *(update available)* 'Pipeline: Supporting APIs'
  * ws-cleanup:0.34 'Jenkins Workspace Cleanup Plugin'
  * xunit:1.102 'xUnit plugin'

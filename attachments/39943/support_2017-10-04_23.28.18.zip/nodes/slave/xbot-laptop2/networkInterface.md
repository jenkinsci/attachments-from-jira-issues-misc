-----------
 * Name utun0
 ** Index - 11
 ** InetAddress - /fe80:0:0:0:949a:6130:6252:1563%utun0
 ** MTU - 2000
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name en0
 ** Hardware Address - 406c8f4bd6ea
 ** Index - 4
 ** InetAddress - /fe80:0:0:0:b7:503b:306b:c716%en0
 ** InetAddress - /10.0.1.169
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo0
 ** Index - 1
 ** InetAddress - /fe80:0:0:0:0:0:0:1%lo0
 ** InetAddress - /0:0:0:0:0:0:0:1
 ** InetAddress - /127.0.0.1
 ** MTU - 16384
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true

-----------
 * Name utun0
 ** Index - 10
 ** InetAddress - /fe80:0:0:0:1070:77b2:5b19:bdbb%utun0
 ** MTU - 2000
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - true
 ** Supports multicast - true
-----------
 * Name en0
 ** Hardware Address - 406c8f0111a2
 ** Index - 4
 ** InetAddress - /fe80:0:0:0:1007:b174:d7c0:4b95%en0
 ** InetAddress - /10.0.1.192
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo0
 ** Index - 1
 ** InetAddress - /fe80:0:0:0:0:0:0:1%lo0
 ** InetAddress - /0:0:0:0:0:0:0:1
 ** InetAddress - /127.0.0.1
 ** MTU - 16384
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - true

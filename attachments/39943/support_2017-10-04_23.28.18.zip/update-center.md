=== Sites ===
 - Url: https://updates.jenkins-ci.org/update-center.json
 - Connection Url: http://www.google.com/
 - Implementation Type: hudson.model.UpdateSite
======
Last updated: 1 day 4 hr
Proxy: 'async-http-client' not installed, so no proxy info available.

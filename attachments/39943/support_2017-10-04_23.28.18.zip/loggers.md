Loggers currently enabled
=========================
hudson.plugins.ec2.EC2Cloud - ALL
org.jenkinsci.plugins.github.webhook - ALL
org.apache.sshd - WARNING
winstone - 5
 - INFO

Node statistics
===============

  * Total number of nodes
      - Sample size:        81678
      - Average (mean):     12.0
      - Average (median):   12.0
      - Standard deviation: 5.1702483247123323E-14
      - Minimum:            12
      - Maximum:            33
      - 95th percentile:    12.0
      - 99th percentile:    12.0
  * Total number of nodes online
      - Sample size:        81678
      - Average (mean):     10.000000000000002
      - Average (median):   10.0
      - Standard deviation: 5.173298964432602E-14
      - Minimum:            10
      - Maximum:            31
      - 95th percentile:    10.0
      - 99th percentile:    10.0
  * Total number of executors
      - Sample size:        81678
      - Average (mean):     38.99999999999999
      - Average (median):   39.0
      - Standard deviation: 5.218844576966487E-14
      - Minimum:            39
      - Maximum:            60
      - 95th percentile:    39.0
      - 99th percentile:    39.0
  * Total number of executors in use
      - Sample size:        81678
      - Average (mean):     1.292880128852408E-22
      - Average (median):   0.0
      - Standard deviation: 1.137049370860875E-11
      - Minimum:            0
      - Maximum:            26
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      10
      - FS root:        `/var/lib/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.12
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_141
          + Maximum memory:   1.62 GB (1744830464)
          + Allocated memory: 978.50 MB (1026031616)
          + Free memory:      240.96 MB (252659696)
          + In-use memory:    737.54 MB (773371920)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.141-b16
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.4.41-35.53.amzn1.x86_64
      - Process ID: 27249 (0x6a71)
      - Process started: 2017-09-20 19:08:43.471+0000
      - Process uptime: 14 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.141-1.b16.32.amzn1.x86_64/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
          + arg[1]: `-Djava.awt.headless=true`
          + arg[2]: `-Dhudson.model.ParametersAction.safeParameters=ghprbActualCommit,ghprbActualCommitAuthor,ghprbActualCommitAuthorEmail,ghprbAuthorRepoGitUrl,ghprbCommentBody,ghprbCredentialsId,ghprbGhRepository,ghprbPullAuthorEmail,ghprbPullAuthorLogin,ghprbPullAuthorLoginMention,ghprbPullDescription,ghprbPullId,ghprbPullLink,ghprbPullLongDescription,ghprbPullTitle,ghprbSourceBranch,ghprbTargetBranch,ghprbTriggerAuthor,ghprbTriggerAuthorEmail,ghprbTriggerAuthorLogin,ghprbTriggerAuthorLoginMention,GIT_BRANCH,sha1`
          + arg[3]: `-Dorg.apache.commons.jelly.tags.fmt.timeZone=America/New_York`
          + arg[4]: `-Duser.timezone=America/New_York`
          + arg[5]: `-DsessionTimeout=1440`
          + arg[6]: `-DJENKINS_HOME=/var/lib/jenkins`

  * docker-jenkins-jnlp-tpl-5-jenkins-igm-5-qp63.c.jenkins-160014.internal (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      0

package com.home.spotbug;

import java.net.InetAddress;
import java.net.UnknownHostException;

public final class HostUtils {

    private HostUtils() {
    }

    public static String getHostName() {
        try {
            return InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            return null;
        }
    }
}

Jenkins
=======

Version details
---------------

  * Version: `2.32.2`
  * Mode:    WAR
  * Url:     https://jenkins.signall.com/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_95
      - Maximum memory:   6.98 GB (7495745536)
      - Allocated memory: 2.89 GB (3102736384)
      - Free memory:      384.53 MB (403211296)
      - In-use memory:    2.51 GB (2699525088)
      - PermGen used:     86.25 MB (90436048)
      - PermGen max:      166.00 MB (174063616)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.95-b01
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.4.35-1-pve
      - Distribution: Ubuntu 16.04.2 LTS
  * Process ID: 8464 (0x2110)
  * Process started: 2017-02-16 15:35:39.608+0000
  * Process uptime: 3 min 28 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`
      - arg[1]: `-Dhudson.model.DirectoryBrowserSupport.CSP=`

Important configuration
---------------

  * Security realm: `org.jenkinsci.plugins.GithubSecurityRealm`
  * Authorization strategy: `org.jenkinsci.plugins.GithubAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-core:1.82 'Static Analysis Utilities'
  * ant:1.4 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * bouncycastle-api:2.16.0 'bouncycastle API Plugin'
  * branch-api:2.0.6 'Branch API Plugin'
  * build-timeout:1.18 'Jenkins build timeout plugin'
  * checkstyle:3.47 'Checkstyle Plug-in'
  * cloudbees-folder:5.17 'Folders Plugin'
  * cloverphp:0.5 'Jenkins Clover PHP plugin'
  * crap4j:0.9 'Jenkins Crap4J plugin'
  * credentials:2.1.11 'Credentials Plugin'
  * credentials-binding:1.10 'Credentials Binding Plugin'
  * disk-usage:0.28 'Jenkins disk-usage plugin'
  * display-url-api:1.1.1 'Display URL API'
  * docker-commons:1.6 'Docker Commons Plugin'
  * docker-workflow:1.10 'Docker Pipeline'
  * dry:2.46 'DRY Plug-in'
  * durable-task:1.13 'Durable Task Plugin'
  * email-ext:2.56 'Email Extension Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * ghprb:1.35.0 'GitHub Pull Request Builder'
  * git:3.0.5 'Jenkins Git plugin'
  * git-client:2.2.1 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.26.0 'GitHub plugin'
  * github-api:1.84 'GitHub API Plugin'
  * github-branch-source:2.0.3 'GitHub Branch Source Plugin'
  * github-oauth:0.25 'GitHub Authentication plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * github-pr-coverage-status:1.2.0 'GitHub Pull Request Coverage Status'
  * gradle:1.26 'Gradle Plugin'
  * greenballs:1.15 'Green Balls'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * htmlpublisher:1.12 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jdepend:1.2.4 'Jenkins JDepend Plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.20 'JUnit Plugin'
  * ldap:1.14 'LDAP Plugin'
  * mailer:1.19 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.4 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.8 'Matrix Project Plugin'
  * maven-plugin:2.14 'Maven Integration plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * multi-branch-project-plugin:0.5.1 'Multi-Branch Project Plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * pipeline-build-step:2.4 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.3 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.5 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3 'Pipeline: Milestone Step'
  * pipeline-model-api:1.0.1 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.0.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.0.1 'Pipeline: Model Definition'
  * pipeline-rest-api:2.5 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.0.1 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.5 'Pipeline: Stage View Plugin'
  * plain-credentials:1.3 *(update available)* 'Plain Credentials Plugin'
  * plot:1.9 'Plot plugin'
  * pmd:3.46 'PMD Plug-in'
  * resource-disposer:0.6 'Resource Disposer Plugin'
  * scm-api:2.0.4 'SCM API Plugin'
  * scm-sync-configuration:0.0.10 'SCM Sync Configuration Plugin'
  * script-security:1.26 'Script Security Plugin'
  * ssh-agent:1.14 'SSH Agent Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.13 'Jenkins SSH Slaves plugin'
  * structs:1.6 'Structs Plugin'
  * subversion:2.7.1 'Jenkins Subversion Plug-in'
  * support-core:2.38 'Support Core Plugin'
  * timestamper:1.8.8 'Timestamper'
  * token-macro:2.0 'Token Macro Plugin'
  * violations:0.7.11 'Jenkins Violations plugin'
  * warnings:4.59 'Warnings Plug-in'
  * windows-slaves:1.2 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.11 'Pipeline: API'
  * workflow-basic-steps:2.4 'Pipeline: Basic Steps'
  * workflow-cps:2.27 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.6 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.9 'Pipeline: Nodes and Processes'
  * workflow-job:2.10 'Pipeline: Job'
  * workflow-multibranch:2.12 'Pipeline: Multibranch'
  * workflow-scm-step:2.3 'Pipeline: SCM Step'
  * workflow-step-api:2.9 'Pipeline: Step API'
  * workflow-support:2.13 'Pipeline: Supporting APIs'
  * ws-cleanup:0.32 'Jenkins Workspace Cleanup Plugin'
  * xunit:1.102 'xUnit plugin'

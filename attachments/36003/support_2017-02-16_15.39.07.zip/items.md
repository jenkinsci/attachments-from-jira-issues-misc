Item statistics
===============

  * `com.github.mjdetullio.jenkins.plugins.multibranch.FreeStyleMultiBranchProject`
    - Number of items: 4
    - Number of items per container: 6.75 [n=4, s=3.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 27
    - Number of builds per job: 4.518518518518518 [n=27, s=6.0]

Total job statistics
======================

  * Number of jobs: 27
  * Number of builds per job: 4.518518518518518 [n=27, s=6.0]

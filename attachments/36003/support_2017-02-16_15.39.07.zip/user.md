User
====

Authentication
--------------

  * Authenticated: true
  * Name: moroine
  * Authorities 
      - `authenticated`
      - `AdactiveSAS`
      - `AdactiveSAS*Signall`
      - `AdactiveSAS*Admin bot`
      - `AdactiveSAS*Adactive`
  * Raw: `org.jenkinsci.plugins.GithubAuthenticationToken@3ee39f: Username: moroine; Password: [PROTECTED]; Authenticated: true; Details: null; Granted Authorities: authenticated, AdactiveSAS, AdactiveSAS*Signall, AdactiveSAS*Admin bot, AdactiveSAS*Adactive`


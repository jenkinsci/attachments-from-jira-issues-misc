
package com.dbo2.bugs.hudson;

import junit.framework.TestCase;

public class SimpleUnitTest extends TestCase
{

  public void testNothingSpecial()
  {
  // This test simply passes without doing anything
  }

  public void testAnotherNothing()
  {
  // This test simply passes without doing anything
  }

}

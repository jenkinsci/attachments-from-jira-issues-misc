Browser
=======

  * Screen size: 1920x1018
  * User Agent
      - Type:     Browser
      - Name:     Firefox
      - Family:   FIREFOX
      - Producer: Mozilla Foundation
      - Version:  30.0
      - Raw:      `Mozilla/5.0 (X11; Linux x86_64; rv:30.0) Gecko/20100101 Firefox/30.0`
  * Operating System
      - Name:     Linux
      - Family:   LINUX
      - Producer: 
      - Version:  


Jenkins
=======

Version details
---------------

  * Version: `1.569`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/8.y.z-SNAPSHOT`
  * Java
      - Home:           `/usr/java/jdk1.7.0_60/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_60
      - Maximum memory:   3.44 GB (3693084672)
      - Allocated memory: 1.39 GB (1495793664)
      - Free memory:      567.89 MB (595477688)
      - In-use memory:    858.61 MB (900315976)
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.60-b09
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      2.6.32-431.17.1.el6.x86_64
      - Distribution: "CentOS release 6.5 (Final)"
      - LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
  * Process ID: 94601 (0x17189)
  * Process started: 2014-06-24 10:17:43.607+0300
  * Process uptime: 1 min 55 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/java/jdk1.7.0_60/jre/lib/resources.jar:/usr/java/jdk1.7.0_60/jre/lib/rt.jar:/usr/java/jdk1.7.0_60/jre/lib/sunrsasign.jar:/usr/java/jdk1.7.0_60/jre/lib/jsse.jar:/usr/java/jdk1.7.0_60/jre/lib/jce.jar:/usr/java/jdk1.7.0_60/jre/lib/charsets.jar:/usr/java/jdk1.7.0_60/jre/lib/jfr.jar:/usr/java/jdk1.7.0_60/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
      - arg[1]: `-Djava.awt.headless=true`
      - arg[2]: `-DJENKINS_HOME=/var/lib/jenkins`


Important configuration
---------------

  * Security realm: (none)
  * Authorization strategy: Anyone can do anything

Active Plugins
--------------

  * antisamy-markup-formatter:1.2 'OWASP Markup Formatter Plugin'
  * credentials:1.14 'Credentials Plugin'
  * javadoc:1.1 'Javadoc Plugin'
  * ldap:1.10.2 'LDAP Plugin'
  * mailer:1.8 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.1.0 'MapDB API Plugin'
  * matrix-auth:1.2 'Matrix Authorization Strategy Plugin'
  * matrix-combinations-parameter:1.0.6 'Matrix Configuration Parameter Plugin'
  * matrix-project:1.2 'Matrix Project Plugin'
  * maven-plugin:2.3 'Maven Integration plugin'
  * metrics:3.0.5 'Metrics Plugin'
  * pam-auth:1.1 'PAM Authentication plugin'
  * scm-api:0.2 'SCM API Plugin'
  * ssh-credentials:1.7.1 'SSH Credentials Plugin'
  * ssh-slaves:1.6 'Jenkins SSH Slaves plugin'
  * support-core:2.6 'Support Core Plugin'
  * windows-slaves:1.0 'Windows Slaves Plugin'

Node statistics
---------------

  * Total number of nodes
      - Sample size:        8
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of nodes online
      - Sample size:        8
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        8
      - Average (mean):     2.0
      - Average (median):   2.0
      - Standard deviation: 0.0
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors in use
      - Sample size:        8
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0


Job statistics
--------------

  * All jobs
      - Number of jobs: 5
      - Number of builds per job: 0.0 [n=5, s=0.0]
  * Jobs that `Build a free-style software project`
      - Number of jobs: 0
      - Number of builds per job: N/A
  * Jobs that `Build multi-configuration project`
      - Number of jobs: 1
      - Number of builds per job: 0 [n=1]
  * Jobs that `Build a maven2/3 project`
      - Number of jobs: 0
      - Number of builds per job: N/A

Container statistics
--------------------

  * All containers
      - Number of containers: 1
      - Number of items per container: 4 [n=1]
  * Container type: `Build multi-configuration project`
      - Number of containers: 1
      - Number of items per container: 4 [n=1]
  * Container type: `Build a maven2/3 project`
      - Number of containers: 0
      - Number of items per container: N/A

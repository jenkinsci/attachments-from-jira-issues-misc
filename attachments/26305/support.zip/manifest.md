Support Bundle Manifest
=======================

Generated on 2014-06-24 10:19:38 +0300

Requested components:

  * Log Recorders

      - `nodes/master/logs/all_2014-06-24_06.57.46.log`

      - `nodes/master/logs/all_2014-06-24_07.17.48.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/jenkins.metrics.api.Metrics$HealthChecker.log`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Environment variables

      - `nodes/master/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * Metrics

      - `nodes/master/metrics.json`

  * System properties

      - `nodes/master/system.properties`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`


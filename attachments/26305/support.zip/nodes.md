Build Nodes
===========

  * master (Jenkins)
      - Description:    `the master Jenkins node`
      - Executors:      2
      - Remote FS root: `/var/lib/jenkins`
      - Labels:         (none)
      - Usage:          Utilize this node as much as possible
      - Java
          + Home:           `/usr/java/jdk1.7.0_60/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_60
          + Maximum memory:   3.44 GB (3693084672)
          + Allocated memory: 1.39 GB (1495793664)
          + Free memory:      567.89 MB (595477624)
          + In-use memory:    858.61 MB (900316040)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.60-b09
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-431.17.1.el6.x86_64
          + Distribution: "CentOS release 6.5 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 94601 (0x17189)
      - Process started: 2014-06-24 10:17:43.607+0300
      - Process uptime: 1 min 55 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.7.0_60/jre/lib/resources.jar:/usr/java/jdk1.7.0_60/jre/lib/rt.jar:/usr/java/jdk1.7.0_60/jre/lib/sunrsasign.jar:/usr/java/jdk1.7.0_60/jre/lib/jsse.jar:/usr/java/jdk1.7.0_60/jre/lib/jce.jar:/usr/java/jdk1.7.0_60/jre/lib/charsets.jar:/usr/java/jdk1.7.0_60/jre/lib/jfr.jar:/usr/java/jdk1.7.0_60/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dcom.sun.akuma.Daemon=daemonized`
          + arg[1]: `-Djava.awt.headless=true`
          + arg[2]: `-DJENKINS_HOME=/var/lib/jenkins`


CloudBees Support Bundle Manifest
=================================

Generated on 2014-01-30 09:08:54 -0500

Requested components:

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/Deploy-101/thread-dump.txt`

      - `nodes/slave/Java-002/thread-dump.txt`

      - `nodes/slave/dotNET-005/thread-dump.txt`



package StandAloneGroovy1;

public class Main {

    public static void main(String[] args) {
        
        System.out.println("StandAloneGroovy1.Main.main - entry");
        
        int n1 = 0;
        while(true){
            
            n1++;
            System.out.println("StandAloneGroovy1.Main.main - run $n1");

            if(1 == 1){
                def g1 = new MyGroovyClass1()
                g1.Test1()
            }

            if(0 == 1){
                def g2 = new MyGroovyClass2()
                g2.Test2()
            }
            
            Thread.sleep(10 * 1000)   // pause
            
        }
        
    }
    
}

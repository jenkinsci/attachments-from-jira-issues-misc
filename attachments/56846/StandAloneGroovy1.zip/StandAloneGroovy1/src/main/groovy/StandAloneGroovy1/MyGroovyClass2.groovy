
package StandAloneGroovy1

import org.apache.velocity.Template
import org.apache.velocity.VelocityContext
import org.apache.velocity.app.Velocity
import org.apache.velocity.app.VelocityEngine
import org.apache.velocity.runtime.resource.util.StringResourceRepository
import org.apache.velocity.runtime.resource.loader.StringResourceLoader

public class MyGroovyClass2 {
    
    public void Test2(){
        
        System.out.println("MyGroovyClass2.Test2 entry " + new Date())
    
        def start_time = System.currentTimeMillis()

        def template_text = 'Using Velocity, s1 = $s1'
        
        // Initialize the engine.
        def engine = new VelocityEngine()
        //engine.setProperty(RuntimeConstants.RUNTIME_LOG_LOGSYSTEM_CLASS, "org.apache.velocity.runtime.log.Log4JLogChute")
        //engine.setProperty("runtime.log.logsystem.log4j.logger", LOGGER.getName())
        engine.setProperty(Velocity.RESOURCE_LOADER, "string")
        engine.addProperty("string.resource.loader.class", StringResourceLoader.class.getName())
        engine.addProperty("string.resource.loader.repository.static", "false")
        //  engine.addProperty("string.resource.loader.modificationCheckInterval", "1");
        engine.init();

        // Initialize my template repository. 
        def repo = engine.getApplicationAttribute(StringResourceLoader.REPOSITORY_NAME_DEFAULT) as StringResourceRepository
        repo.putStringResource("my_template_name", template_text);

        // Set parameters for my template.
        def context = new VelocityContext()
        context.put("s1", "number $n1");

        // Get template.
        def t = engine.getTemplate("my_template_name")
        
        var report_step = 10 * 1000 * 1000
        var max_iter = 10 * report_step
        for(int n1 = 1; n1 <= max_iter; n1++){
            
            // Merge the template with my parameters.
            def writer = new StringWriter()
            t.merge(context, writer);
            
            // Result
            def text = writer.toString()
    
            if(n1 % report_step == 0) System.out.println text
        }
        def seconds = (System.currentTimeMillis() - start_time) / 1000 as int
        double minutes = seconds / 60.0
        minutes = Math.round(minutes * 10) /  10.0
        System.out.println "Test duration $minutes m"
    }	
}


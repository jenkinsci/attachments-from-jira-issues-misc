
package StandAloneGroovy1

import groovy.text.SimpleTemplateEngine

public class MyGroovyClass1 {
    
    public void Test1(){
        
        System.out.println("MyGroovyClass1.Test1 entry " + new Date())
    
        def start_time = System.currentTimeMillis()

        def template_text = 'Using SimpleTemplateEngine, s1 = $s1'

        def engine = new SimpleTemplateEngine()
   
        var report_step = 10 * 1000
        var max_iter = 10 * report_step
        for(int n1 = 1; n1 <= max_iter; n1++){
    
            def t = engine.createTemplate(template_text)

            def bindings = [
                s1: "number $n1"
            ]
    
            def text = t.make(bindings).toString()
    
            if(n1 % report_step == 0) System.out.println text
        }
        def seconds = (System.currentTimeMillis() - start_time) / 1000 as int
        double minutes = seconds / 60.0
        minutes = Math.round(minutes * 10) /  10.0
        System.out.println "Test duration $minutes m"
    }	
}


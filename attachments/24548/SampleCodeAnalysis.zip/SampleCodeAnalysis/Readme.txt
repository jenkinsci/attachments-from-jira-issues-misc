This sample console application was created using:

	Microsoft Visual Studio Premium 2012
	Version 11.0.60610.01 Update 3

It is the default C# console application project with code analysis enabled and set to the "Microsoft All Rules" ruleset.

To build using msbuild you can us the msbuild.proj file:

- Open a Visual Studio 2012 Command Prompt
- Change to the directory containing the msbuild.proj file
- Run the command: msbuild /t:RebuildAll msbuild.proj

An example of the console output has been saved as "RebuildOutput.log"


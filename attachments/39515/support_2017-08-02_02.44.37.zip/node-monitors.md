Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 18.918GB left on /data/common/jenkins/home.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:1276/3950MB  Swap:0/0MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 18.918GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms

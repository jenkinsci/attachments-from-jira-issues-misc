-----------
 * Name docker0
 ** Hardware Address - 02429d5d4ed6
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:42:9dff:fe5d:4ed6%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 127d6728006e
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:107d:67ff:fe28:6e%eth0
 ** InetAddress - /172.31.74.127
 ** MTU - 9001
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

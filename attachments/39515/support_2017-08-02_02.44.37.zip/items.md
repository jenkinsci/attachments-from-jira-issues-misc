Item statistics
===============

  * `jenkins.branch.OrganizationFolder`
    - Number of items: 1
    - Number of items per container: 2 [n=1]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 4
    - Number of builds per job: 2.75 [n=4, s=2.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 2
    - Number of items per container: 2.0 [n=2, s=1.0]

Total job statistics
======================

  * Number of jobs: 4
  * Number of builds per job: 2.75 [n=4, s=2.0]

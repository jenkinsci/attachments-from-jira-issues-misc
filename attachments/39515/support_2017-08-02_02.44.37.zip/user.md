User
====

Authentication
--------------

  * Authenticated: true
  * Name: hai
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@d49dafda: Username: hudson.security.HudsonPrivateSecurityRealm$Details@474cbd83; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@59b2: RemoteIpAddress: 115.78.233.251; SessionId: null; Granted Authorities: authenticated`


Support Bundle Manifest
=======================

Generated on 2017-05-19 13:02:58.673+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-05-19_13.00.20.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Out of order build detection.log`

  * Garbage Collection Logs

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/au.com.rayh.GlobalConfigurationImpl.xml`

      - `jenkins-root-configuration-files/au.com.rayh.XCodeBuilder.xml`

      - `jenkins-root-configuration-files/be.certipost.hudson.plugin.SCPRepositoryPublisher.xml`

      - `jenkins-root-configuration-files/com.backelite.jenkins.rocketchat.RocketChatPublisher.xml`

      - `jenkins-root-configuration-files/com.michelin.cio.hudson.plugins.maskpasswords.MaskPasswordsConfig.xml`

      - `jenkins-root-configuration-files/com.mtvi.plateng.subversion.SVNPublisher.xml`

      - `jenkins-root-configuration-files/com.nirima.jenkins.plugins.docker.DockerPluginConfiguration.xml`

      - `jenkins-root-configuration-files/disk-usage.xml`

      - `jenkins-root-configuration-files/envInject.xml`

      - `jenkins-root-configuration-files/envinject-plugin-configuration.xml`

      - `jenkins-root-configuration-files/github-plugin-configuration.xml`

      - `jenkins-root-configuration-files/hudson.ivy.IvyBuildTrigger.xml`

      - `jenkins-root-configuration-files/hudson.ivy.IvyModuleSet.xml`

      - `jenkins-root-configuration-files/hudson.maven.MavenModuleSet.xml`

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.plugins.analysis.core.GlobalSettings.xml`

      - `jenkins-root-configuration-files/hudson.plugins.copyartifact.TriggeredBuildSelector.xml`

      - `jenkins-root-configuration-files/hudson.plugins.disk_usage.DiskUsageProjectActionFactory.xml`

      - `jenkins-root-configuration-files/hudson.plugins.disk_usage.DiskUsageProperty.xml`

      - `jenkins-root-configuration-files/hudson.plugins.emailext.ExtendedEmailPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitSCM.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/hudson.plugins.gradle.Gradle.xml`

      - `jenkins-root-configuration-files/hudson.plugins.ircbot.IrcPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.nextexecutions.NextBuilds.xml`

      - `jenkins-root-configuration-files/hudson.plugins.promoted_builds.GlobalBuildPromotedBuilds.xml`

      - `jenkins-root-configuration-files/hudson.plugins.sonar.MsBuildSQRunnerInstallation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.sonar.SonarGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/hudson.plugins.sonar.SonarPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.sonar.SonarRunnerInstallation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.warnings.WarningsPublisher.xml`

      - `jenkins-root-configuration-files/hudson.scm.CVSSCM.xml`

      - `jenkins-root-configuration-files/hudson.scm.SubversionMailAddressResolverImpl.xml`

      - `jenkins-root-configuration-files/hudson.scm.SubversionSCM.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Ant.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Mailer.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Maven.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Shell.xml`

      - `jenkins-root-configuration-files/hudson.tools.JDKInstaller.xml`

      - `jenkins-root-configuration-files/hudson.triggers.SCMTrigger.xml`

      - `jenkins-root-configuration-files/jenkins.CLI.xml`

      - `jenkins-root-configuration-files/jenkins.model.ArtifactManagerConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.model.DownloadSettings.xml`

      - `jenkins-root-configuration-files/jenkins.model.JenkinsLocationConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.mvn.GlobalMavenConfig.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.http_request.HttpRequest.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.publish_over_cifs.CifsPublisherPlugin.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.publish_over_ssh.BapSshPublisherPlugin.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.rocketchatnotifier.RocketChatNotifier.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.slack.SlackNotifier.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.slack.webhook.GlobalConfig.xml`

      - `jenkins-root-configuration-files/jenkins.security.QueueItemAuthenticatorConfiguration.xml`

      - `jenkins-root-configuration-files/jobConfigHistory.xml`

      - `jenkins-root-configuration-files/maven-global-settings-files.xml`

      - `jenkins-root-configuration-files/maven-settings-files.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.conditionalbuildstep.singlestep.SingleConditionalBuilder.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.configfiles.GlobalConfigFiles.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.docker.commons.tools.DockerTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitApacheTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.gitclient.JGitTool.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.slave_setup.SetupConfig.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.flow.FlowExecutionList.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.libs.GlobalLibraries.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.support.steps.StageStep.xml`

      - `jenkins-root-configuration-files/scriptApproval.xml`

      - `jenkins-root-configuration-files/sonar.xml`

      - `jenkins-root-configuration-files/support-core.xml`

      - `jenkins-root-configuration-files/temp-global-settings-files.xml`

      - `jenkins-root-configuration-files/temp-maven-settings-files.xml`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/cmbbldidm005/checksums.md5`

      - `nodes/slave/cmbbldidm006/checksums.md5`

      - `nodes/slave/cmbbldidm009/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/cmbbldidm005/exportTable.txt`

      - `nodes/slave/cmbbldidm006/exportTable.txt`

      - `nodes/slave/cmbbldidm009/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/cmbbldidm005/environment.txt`

      - `nodes/slave/cmbbldidm006/environment.txt`

      - `nodes/slave/cmbbldidm009/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/cmbbldidm005/file-descriptors.txt`

      - `nodes/slave/cmbbldidm006/file-descriptors.txt`

      - `nodes/slave/cmbbldidm009/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/cmbbldidm005/proc/meminfo.txt`

      - `nodes/slave/cmbbldidm005/proc/self/cmdline`

      - `nodes/slave/cmbbldidm005/proc/self/environ`

      - `nodes/slave/cmbbldidm005/proc/self/limits.txt`

      - `nodes/slave/cmbbldidm005/proc/self/mountstats.txt`

      - `nodes/slave/cmbbldidm005/proc/self/status.txt`

      - `nodes/slave/cmbbldidm006/proc/meminfo.txt`

      - `nodes/slave/cmbbldidm006/proc/self/cmdline`

      - `nodes/slave/cmbbldidm006/proc/self/environ`

      - `nodes/slave/cmbbldidm006/proc/self/limits.txt`

      - `nodes/slave/cmbbldidm006/proc/self/mountstats.txt`

      - `nodes/slave/cmbbldidm006/proc/self/status.txt`

      - `nodes/slave/cmbbldidm009/proc/meminfo.txt`

      - `nodes/slave/cmbbldidm009/proc/self/cmdline`

      - `nodes/slave/cmbbldidm009/proc/self/environ`

      - `nodes/slave/cmbbldidm009/proc/self/limits.txt`

      - `nodes/slave/cmbbldidm009/proc/self/mountstats.txt`

      - `nodes/slave/cmbbldidm009/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/64bit/gnuplot`

      - `load-stats/label/64bit/hour.csv`

      - `load-stats/label/64bit/min.csv`

      - `load-stats/label/64bit/sec10.csv`

      - `load-stats/label/cmbbldidm005/gnuplot`

      - `load-stats/label/cmbbldidm005/hour.csv`

      - `load-stats/label/cmbbldidm005/min.csv`

      - `load-stats/label/cmbbldidm005/sec10.csv`

      - `load-stats/label/cmbbldidm006/gnuplot`

      - `load-stats/label/cmbbldidm006/hour.csv`

      - `load-stats/label/cmbbldidm006/min.csv`

      - `load-stats/label/cmbbldidm006/sec10.csv`

      - `load-stats/label/cmbbldidm009/gnuplot`

      - `load-stats/label/cmbbldidm009/hour.csv`

      - `load-stats/label/cmbbldidm009/min.csv`

      - `load-stats/label/cmbbldidm009/sec10.csv`

      - `load-stats/label/docker/gnuplot`

      - `load-stats/label/docker/hour.csv`

      - `load-stats/label/docker/min.csv`

      - `load-stats/label/docker/sec10.csv`

      - `load-stats/label/gradle/gnuplot`

      - `load-stats/label/gradle/hour.csv`

      - `load-stats/label/gradle/min.csv`

      - `load-stats/label/gradle/sec10.csv`

      - `load-stats/label/installanywhere%26%26linux%26%2664bit/gnuplot`

      - `load-stats/label/installanywhere%26%26linux%26%2664bit/hour.csv`

      - `load-stats/label/installanywhere%26%26linux%26%2664bit/min.csv`

      - `load-stats/label/installanywhere%26%26linux%26%2664bit/sec10.csv`

      - `load-stats/label/installanywhere/gnuplot`

      - `load-stats/label/installanywhere/hour.csv`

      - `load-stats/label/installanywhere/min.csv`

      - `load-stats/label/installanywhere/sec10.csv`

      - `load-stats/label/ivy/gnuplot`

      - `load-stats/label/ivy/hour.csv`

      - `load-stats/label/ivy/min.csv`

      - `load-stats/label/ivy/sec10.csv`

      - `load-stats/label/jshint%26%26gradle/gnuplot`

      - `load-stats/label/jshint%26%26gradle/hour.csv`

      - `load-stats/label/jshint%26%26gradle/min.csv`

      - `load-stats/label/jshint%26%26gradle/sec10.csv`

      - `load-stats/label/jshint/gnuplot`

      - `load-stats/label/jshint/hour.csv`

      - `load-stats/label/jshint/min.csv`

      - `load-stats/label/jshint/sec10.csv`

      - `load-stats/label/linux%26%2664bit/gnuplot`

      - `load-stats/label/linux%26%2664bit/hour.csv`

      - `load-stats/label/linux%26%2664bit/min.csv`

      - `load-stats/label/linux%26%2664bit/sec10.csv`

      - `load-stats/label/linux/gnuplot`

      - `load-stats/label/linux/hour.csv`

      - `load-stats/label/linux/min.csv`

      - `load-stats/label/linux/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/svn/gnuplot`

      - `load-stats/label/svn/hour.csv`

      - `load-stats/label/svn/min.csv`

      - `load-stats/label/svn/sec10.csv`

      - `load-stats/label/swarm/gnuplot`

      - `load-stats/label/swarm/hour.csv`

      - `load-stats/label/swarm/min.csv`

      - `load-stats/label/swarm/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/cmbbldidm005/metrics.json`

      - `nodes/slave/cmbbldidm006/metrics.json`

      - `nodes/slave/cmbbldidm009/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/cmbbldidm005/networkInterface.md`

      - `nodes/slave/cmbbldidm006/networkInterface.md`

      - `nodes/slave/cmbbldidm009/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/cmbbldidm005/dmesg.txt`

      - `nodes/slave/cmbbldidm005/dmi.txt`

      - `nodes/slave/cmbbldidm005/proc/cpuinfo.txt`

      - `nodes/slave/cmbbldidm005/proc/mounts.txt`

      - `nodes/slave/cmbbldidm005/proc/net/rpc/nfs.txt`

      - `nodes/slave/cmbbldidm005/proc/net/rpc/nfsd.txt`

      - `nodes/slave/cmbbldidm005/proc/swaps.txt`

      - `nodes/slave/cmbbldidm005/proc/system-uptime.txt`

      - `nodes/slave/cmbbldidm005/sysctl.txt`

      - `nodes/slave/cmbbldidm005/userid.txt`

      - `nodes/slave/cmbbldidm006/dmesg.txt`

      - `nodes/slave/cmbbldidm006/dmi.txt`

      - `nodes/slave/cmbbldidm006/proc/cpuinfo.txt`

      - `nodes/slave/cmbbldidm006/proc/mounts.txt`

      - `nodes/slave/cmbbldidm006/proc/net/rpc/nfs.txt`

      - `nodes/slave/cmbbldidm006/proc/net/rpc/nfsd.txt`

      - `nodes/slave/cmbbldidm006/proc/swaps.txt`

      - `nodes/slave/cmbbldidm006/proc/system-uptime.txt`

      - `nodes/slave/cmbbldidm006/sysctl.txt`

      - `nodes/slave/cmbbldidm006/userid.txt`

      - `nodes/slave/cmbbldidm009/dmesg.txt`

      - `nodes/slave/cmbbldidm009/dmi.txt`

      - `nodes/slave/cmbbldidm009/proc/cpuinfo.txt`

      - `nodes/slave/cmbbldidm009/proc/mounts.txt`

      - `nodes/slave/cmbbldidm009/proc/net/rpc/nfs.txt`

      - `nodes/slave/cmbbldidm009/proc/net/rpc/nfsd.txt`

      - `nodes/slave/cmbbldidm009/proc/swaps.txt`

      - `nodes/slave/cmbbldidm009/proc/system-uptime.txt`

      - `nodes/slave/cmbbldidm009/sysctl.txt`

      - `nodes/slave/cmbbldidm009/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/cmbbldidm005/system.properties`

      - `nodes/slave/cmbbldidm006/system.properties`

      - `nodes/slave/cmbbldidm009/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/cmbbldidm005/thread-dump.txt`

      - `nodes/slave/cmbbldidm006/thread-dump.txt`

      - `nodes/slave/cmbbldidm009/thread-dump.txt`


-----------
 * Name br-b52158cc2475
 ** Hardware Address - 0242f850ea26
 ** Index - 4
 ** InetAddress - /fe80:0:0:0:42:f8ff:fe50:ea26%br-b52158cc2475
 ** InetAddress - /172.18.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 024268bea009
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:42:68ff:febe:a009%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name ens160
 ** Hardware Address - 005056882955
 ** Index - 2
 ** InetAddress - /2620:113:8044:8009:a88d:dd07:ec6c:8823%ens160
 ** InetAddress - /2620:113:8044:8009:3546:d735:e3e2:e69d%ens160
 ** InetAddress - /2620:113:8044:8009:a478:6e7d:3398:da31%ens160
 ** InetAddress - /2620:113:8044:8009:250:56ff:fe88:2955%ens160
 ** InetAddress - /2620:113:8044:8009:90b4:51b2:b59b:be89%ens160
 ** InetAddress - /2620:113:8044:8009:34e5:384f:6d27:69ed%ens160
 ** InetAddress - /fe80:0:0:0:250:56ff:fe88:2955%ens160
 ** InetAddress - /2620:113:8044:8009:24c4:5f1:8865:c38e%ens160
 ** InetAddress - /2620:113:8044:8009:2d98:bf09:9f07:61d3%ens160
 ** InetAddress - /10.204.32.14
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

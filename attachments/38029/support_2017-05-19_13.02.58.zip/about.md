Jenkins
=======

Version details
---------------

  * Version: `2.61`
  * Mode:    WAR
  * Url:     http://jenkins.idmapps.nqbuild.lab/jenkins/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/java/jdk1.8.0_92/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_92
      - Maximum memory:   636.00 MB (666894336)
      - Allocated memory: 636.00 MB (666894336)
      - Free memory:      327.37 MB (343276392)
      - In-use memory:    308.63 MB (323617944)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.92-b14
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.11.10-21-default
      - Distribution: "openSUSE 13.1 (Bottle) (x86_64)"
      - LSB Modules:  `n/a`
  * Process ID: 15979 (0x3e6b)
  * Process started: 2017-05-18 12:25:45.743+0000
  * Process uptime: 1 day 0 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/java/jdk1.8.0_92/jre/lib/resources.jar:/usr/java/jdk1.8.0_92/jre/lib/rt.jar:/usr/java/jdk1.8.0_92/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_92/jre/lib/jsse.jar:/usr/java/jdk1.8.0_92/jre/lib/jce.jar:/usr/java/jdk1.8.0_92/jre/lib/charsets.jar:/usr/java/jdk1.8.0_92/jre/lib/jfr.jar:/usr/java/jdk1.8.0_92/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`
      - arg[1]: `-Xms256m`
      - arg[2]: `-Xmx640m`
      - arg[3]: `-Dhudson.DNSMultiCast.disabled=true`
      - arg[4]: `-XX:+HeapDumpOnOutOfMemoryError`
      - arg[5]: `-Dorg.apache.commons.jelly.tags.fmt.timeZone=America/New_York`
      - arg[6]: `-DJENKINS_HOME=/var/lib/jenkins`

Important configuration
---------------

  * Security realm: `de.theit.jenkins.crowd.CrowdSecurityRealm`
  * Authorization strategy: `com.michelin.cio.hudson.plugins.rolestrategy.RoleBasedAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * all-changes:1.5 'All changes plugin'
  * analysis-core:1.86 'Static Analysis Utilities'
  * ant:1.5 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * bouncycastle-api:2.16.1 'bouncycastle API Plugin'
  * branch-api:2.0.9 'Branch API Plugin'
  * build-pipeline-plugin:1.5.6 'Build Pipeline Plugin'
  * checkstyle:3.48 'Checkstyle Plug-in'
  * cloudbees-folder:6.0.4 'Folders Plugin'
  * conditional-buildstep:1.3.5 'Conditional BuildStep'
  * config-file-provider:2.15.7 'Config File Provider Plugin'
  * copyartifact:1.38.1 'Copy Artifact Plugin'
  * credentials:2.1.13 'Credentials Plugin'
  * credentials-binding:1.11 'Credentials Binding Plugin'
  * crowd2:1.8 'Crowd 2 Integration'
  * cvs:2.13 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.10 'Dashboard View'
  * dependencyanalyzer:0.7 'Jenkins Dependency Analyzer Plugin'
  * disk-usage:0.28 'Jenkins disk-usage plugin'
  * display-url-api:2.0 'Display URL API'
  * docker-build-publish:1.3.2 'CloudBees Docker Build and Publish plugin'
  * docker-commons:1.6 'Docker Commons Plugin'
  * docker-plugin:0.16.2 'Docker plugin'
  * docker-workflow:1.11 'Docker Pipeline'
  * durable-task:1.13 'Durable Task Plugin'
  * email-ext:2.57.2 'Email Extension Plugin'
  * envinject:2.1 'Environment Injector Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * findbugs:4.70 'FindBugs Plug-in'
  * git:3.3.0 'Jenkins Git plugin'
  * git-client:2.4.5 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.27.0 'GitHub plugin'
  * github-api:1.85 'GitHub API Plugin'
  * github-branch-source:2.0.5 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * gradle:1.26 'Gradle Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * http_request:1.8.19 'HTTP Request Plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * instant-messaging:1.35 'Jenkins instant-messaging plugin'
  * ircbot:2.27 'Jenkins IRC Plugin'
  * ivy:1.27.1 'Ivy Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jcaptcha-plugin:1.1 'JCaptcha Plugin'
  * job-import-plugin:1.6 'Job Import Plugin'
  * jobConfigHistory:2.16 'Jenkins Job Configuration History Plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.20 'JUnit Plugin'
  * ldap:1.15 'LDAP Plugin'
  * mail-watcher-plugin:1.16 'Mail Watcher Plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * mask-passwords:2.10.1 'Mask Passwords Plugin'
  * matrix-auth:1.6 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.11 'Matrix Project Plugin'
  * maven-dependency-update-trigger:1.5 'Maven Dependency Update Trigger'
  * maven-plugin:2.15.1 'Maven Integration plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * monitoring:1.67.0 'Monitoring'
  * next-executions:1.0.12 'next-executions'
  * notification:1.12-SNAPSHOT (private-4bcd9893-ubuntu) 'Jenkins Notification plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parallel-test-executor:1.9 'Parallel Test Executor Plugin'
  * parameterized-trigger:2.33 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.5 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.3 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.7 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.1.4 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.1.4 'Pipeline: Model Definition'
  * pipeline-model-extensions:1.1.4 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.6 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.1.4 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.6 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * plugin-usage-plugin:0.3 'Plugin Usage - Plugin'
  * promoted-builds:2.28.1 'Jenkins promoted builds plugin'
  * publish-over-cifs:0.3 'Publish Over CIFS'
  * publish-over-ssh:1.17 'Publish Over SSH'
  * rocketchat-notification:1.0 'Rocket.Chat Plugin'
  * role-strategy:2.4.0 'Role-based Authorization Strategy'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:2.1.1 'SCM API Plugin'
  * scp:1.8 'Hudson SCP publisher plugin'
  * script-security:1.27 'Script Security Plugin'
  * skip-certificate-check:1.0 'skip-certificate-check'
  * slave-setup:1.10 'Jenkins Slave SetupPlugin'
  * sonar:2.6.1 'SonarQube Scanner for Jenkins'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.17 'Jenkins SSH Slaves plugin'
  * structs:1.6 'Structs Plugin'
  * subversion:2.7.2 'Jenkins Subversion Plug-in'
  * support-core:2.41 'Support Core Plugin'
  * svnpublisher:0.2-SNAPSHOT (private-08/29/2012 10:49-lwashington) 'SVN Publisher plugin'
  * swarm:3.4 'Jenkins Self-Organizing Swarm Plug-in Modules'
  * token-macro:2.1 'Token Macro Plugin'
  * toolenv:1.1 'Tool Environment plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * urltrigger:0.41 'Jenkins URLTrigger Plug-in'
  * versionnumber:1.8.1 'Version Number Plug-In'
  * view-job-filters:1.27 'View Job Filters'
  * warnings:4.62 'Warnings Plug-in'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.13 'Pipeline: API'
  * workflow-basic-steps:2.4 'Pipeline: Basic Steps'
  * workflow-cps:2.30 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.8 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.11 'Pipeline: Nodes and Processes'
  * workflow-job:2.12 'Pipeline: Job'
  * workflow-multibranch:2.14 'Pipeline: Multibranch'
  * workflow-remote-loader:1.4 'Jenkins Pipeline Remote Loader Plugin'
  * workflow-scm-step:2.4 'Pipeline: SCM Step'
  * workflow-step-api:2.9 'Pipeline: Step API'
  * workflow-support:2.14 'Pipeline: Supporting APIs'
  * xcode-plugin:1.4.11 'Xcode integration'

Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 3
    - Number of items per container: 21.0 [n=3, s=10.0]
  * `hudson.maven.MavenModule`
    - Number of items: 614
    - Number of builds per job: 5.872964169381108 [n=614, s=11.0]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 66
    - Number of builds per job: 6.166666666666667 [n=66, s=3.0]
    - Number of items per container: 9.303030303030303 [n=66, s=10.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 104
    - Number of builds per job: 15.490384615384615 [n=104, s=93.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 11
    - Number of builds per job: 9.363636363636363 [n=11, s=10.0]

Total job statistics
======================

  * Number of jobs: 795
  * Number of builds per job: 7.203773584905661 [n=795, s=35.0]

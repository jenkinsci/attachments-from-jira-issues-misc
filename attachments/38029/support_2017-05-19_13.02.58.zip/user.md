User
====

Authentication
--------------

  * Authenticated: true
  * Name: lwashington
  * Authorities 
      - `authenticated`
      - `audited_security_eng_opencontributors_dev`
      - `confluence-users`
      - `coverity`
      - `everyone`
      - `jenkins-cmb-admins`
      - `jenkins-cmb-users`
      - `msdnu`
      - `nexus-cmb-admins`
      - `nexus-cmb-devs`
      - `nonmanager`
      - `novellemployees`
  * Raw: `de.theit.jenkins.crowd.CrowdAuthenticationToken@2903a236: Username: de.theit.jenkins.crowd.CrowdUser@2177269c; Password: [PROTECTED]; Authenticated: true; Details: null; Granted Authorities: authenticated, audited_security_eng_opencontributors_dev, confluence-users, coverity, everyone, jenkins-cmb-admins, jenkins-cmb-users, msdnu, nexus-cmb-admins, nexus-cmb-devs, nonmanager, novellemployees`


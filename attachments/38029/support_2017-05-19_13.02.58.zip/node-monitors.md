Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * cmbbldidm005: Linux (amd64)
   * cmbbldidm006: Linux (amd64)
   * cmbbldidm009: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * cmbbldidm005: 1.1 sec ahead
   * cmbbldidm006: 1.1 sec ahead
   * cmbbldidm009: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 5GB
 - Computers:
   * master: Disk space is too low. Only 234.979GB left on /var/lib/jenkins.
   * cmbbldidm005: Disk space is too low. Only 6.791GB left on /home/jenkins/jenkins-root.
   * cmbbldidm006: Disk space is too low. Only 35.801GB left on /home/jenkins/jenkins-root.
   * cmbbldidm009: Disk space is too low. Only 64.239GB left on /home/jenkins/jenkins-root.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:680/3962MB  Swap:1808/2053MB
   * cmbbldidm005: Memory:725/5981MB  Swap:2003/2039MB
   * cmbbldidm006: Memory:1357/3961MB  Swap:1923/2039MB
   * cmbbldidm009: Memory:1702/5967MB  Swap:2034/2047MB
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * cmbbldidm005: 3ms
   * cmbbldidm006: 2ms
   * cmbbldidm009: 2ms
Free Temp Space
----
 - Is Ignored: true
 - Threshold: 1GB

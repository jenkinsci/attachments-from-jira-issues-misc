Node statistics
===============

  * Total number of nodes
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of nodes online
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors in use
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/var/lib/jenkins`
      - Labels:         master
      - Usage:          `EXCLUSIVE`
      - Slave Version:  3.7
      - Java
          + Home:           `/usr/java/jdk1.8.0_92/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_92
          + Maximum memory:   636.00 MB (666894336)
          + Allocated memory: 636.00 MB (666894336)
          + Free memory:      292.29 MB (306485000)
          + In-use memory:    343.71 MB (360409336)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.92-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.11.10-21-default
          + Distribution: "openSUSE 13.1 (Bottle) (x86_64)"
          + LSB Modules:  `n/a`
      - Process ID: 15979 (0x3e6b)
      - Process started: 2017-05-18 12:25:45.743+0000
      - Process uptime: 1 day 0 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_92/jre/lib/resources.jar:/usr/java/jdk1.8.0_92/jre/lib/rt.jar:/usr/java/jdk1.8.0_92/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_92/jre/lib/jsse.jar:/usr/java/jdk1.8.0_92/jre/lib/jce.jar:/usr/java/jdk1.8.0_92/jre/lib/charsets.jar:/usr/java/jdk1.8.0_92/jre/lib/jfr.jar:/usr/java/jdk1.8.0_92/jre/classes`
          + Classpath: `/usr/lib/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`
          + arg[1]: `-Xms256m`
          + arg[2]: `-Xmx640m`
          + arg[3]: `-Dhudson.DNSMultiCast.disabled=true`
          + arg[4]: `-XX:+HeapDumpOnOutOfMemoryError`
          + arg[5]: `-Dorg.apache.commons.jelly.tags.fmt.timeZone=America/New_York`
          + arg[6]: `-DJENKINS_HOME=/var/lib/jenkins`

  * cmbbldidm005 (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.204.33.34 : 64bit Linux build node based in Provo vLab_
      - Executors:      2
      - Remote FS root: `/home/jenkins/jenkins-root`
      - Labels:         swarm 64bit linux ivy gradle jshint svn
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_91
          + Maximum memory:   1.30 GB (1394606080)
          + Allocated memory: 304.50 MB (319291392)
          + Free memory:      157.19 MB (164820800)
          + In-use memory:    147.31 MB (154470592)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.91-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.12.57-44-default
          + Distribution: "openSUSE 13.1 (Bottle) (x86_64)"
          + LSB Modules:  `n/a`
      - Process ID: 510 (0x1fe)
      - Process started: 2017-04-27 16:32:40.168+0000
      - Process uptime: 21 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/resources.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/rt.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/sunrsasign.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/jsse.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/jce.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/charsets.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/jfr.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/classes`
          + Classpath: `/home/jenkins/bin/swarm-client-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * cmbbldidm006 (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.204.33.35 : 64bit Linux build node based in Provo vLab_
      - Executors:      2
      - Remote FS root: `/home/jenkins/jenkins-root`
      - Labels:         swarm 64bit linux installanywhere ivy svn
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        2.59
      - Java
          + Home:           `/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_111
          + Maximum memory:   882.00 MB (924844032)
          + Allocated memory: 135.00 MB (141557760)
          + Free memory:      43.44 MB (45550344)
          + In-use memory:    91.56 MB (96007416)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.111-b14
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.12.67-58-default
          + Distribution: "openSUSE 13.1 (Bottle) (x86_64)"
          + LSB Modules:  `n/a`
      - Process ID: 18647 (0x48d7)
      - Process started: 2017-05-05 14:04:19.210+0000
      - Process uptime: 13 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/resources.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/rt.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/sunrsasign.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/jsse.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/jce.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/charsets.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/jfr.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/classes`
          + Classpath: `/home/jenkins/bin/swarm-client-jar-with-dependencies.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * cmbbldidm009 (`hudson.plugins.swarm.SwarmSlave`)
      - Description:    _Swarm slave from 10.204.32.14 : Build node based in Provo vLab_
      - Executors:      2
      - Remote FS root: `/home/jenkins/jenkins-root`
      - Labels:         swarm docker 64bit
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.swarm.SwarmSlave$1`
      - Availability:   `hudson.slaves.RetentionStrategy$2`
      - Status:         on-line
      - Version:        3.4.1
      - Java
          + Home:           `/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_121
          + Maximum memory:   1.30 GB (1390936064)
          + Allocated memory: 132.50 MB (138936320)
          + Free memory:      39.25 MB (41153680)
          + In-use memory:    93.25 MB (97782640)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.121-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.10.9-1-default
      - Process ID: 6242 (0x1862)
      - Process started: 2017-05-05 14:05:38.086+0000
      - Process uptime: 13 days
      - JVM startup parameters:
          + Boot classpath: `/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/resources.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/rt.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/sunrsasign.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/jsse.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/jce.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/charsets.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/jfr.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/classes`
          + Classpath: `/home/jenkins/bin/swarm-client.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`


#!/usr/bin/env groovy
// 176851

/**
 * Return the snapshot UUID
 *  
 *  actionNum	the number of the fetch we want to retrieve (1-4, there are 4 in a typical build)
 *  
 * @return buildprops 	RTC Snapshot UUID
 *
 */
 
def call(def actionNum=0) {
    echo "DSL->GetSnapshotUUID()"
    def actions = currentBuild.build().getActions(com.ibm.team.build.internal.hjplugin.RTCBuildResultAction.class)
    if (actions != null && actions.size() > 0 && actionNum > 0 && actionNum <= actions.size()) {
        def buildProps = actions.get(actionNum-1).getBuildProperties()
        return (buildProps['team_scm_snapshotUUID'])
    }
    return null
}




#!/usr/bin/env groovy
// 176851

/**
 * Assign a UCD component to a specific team
 * 
 *  @param componentName the UCD component name
 *  @param teamName the team to assign the component to
 * 
 */
 
void call(def componentName, def teamName, def useTest) {
	String methodName = 'DJSL -> Assign_Component_To_Team()';
	echo methodName
	def urlHeader = (useTest=="true")?"ucd-test":"ucd"
    def parsedComponent = URLIFY(componentName)
    try {
            httpRequest authentication: 'UCDImport', httpMode: 'PUT', ignoreSslErrors: true, responseHandle: 'NONE', url: "https://${urlHeader}.bcbst.com/cli/component/teams?component=${parsedComponent}&team=${teamName}"
    } catch (e) {
            echo "The component was not assigned to your team - "+ e.message
        }
}




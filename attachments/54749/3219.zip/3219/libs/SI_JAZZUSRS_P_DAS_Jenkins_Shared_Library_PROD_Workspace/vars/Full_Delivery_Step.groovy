#!/usr/bin/env groovy
/**
 * Full delivery step for UCD Jenkinsfiles
 * 
 * @param nonBuild whether this is a code build or just a generic copy
 */
void call(def nonBuild="false"){
    echo "DSL->Full_Delivery_Step()"
	if (env.personalBuild?.equalsIgnoreCase('true')) {
		if(env.ucdVersionPrefix != null && env.ucdVersionPrefix!="") {
			env.VERSION_NOM = "Personal_${env.ucdVersionPrefix}_${env.VERSION_NOM}"
		} else {
			env.VERSION_NOM = "Personal_${env.VERSION_NOM}"
		}
		println "Note: Personal builds are prohibited from deployment to production environments"
	} else if((env.ucdComponentName == "Generic_Component")&&(nonBuild=="true")) {
		env.VERSION_NOM= "${buildDefinitionId}_${env.VERSION_NOM}"
	} else if(env.ucdVersionPrefix != "" && env.ucdVersionPrefix != null) {
		echo "Found version prefix ${env.ucdVersionPrefix}"
		env.VERSION_NOM= "${env.ucdVersionPrefix}_${env.VERSION_NOM}" 
	} else { 
		echo "no additional prefixes found for version"
	}
	
	echo "UCD delivery switch is set to ${env.ucdDeliverSwitch}"
	def deliverResult = Deliver_UCD("${env.VERSION_NOM}")
	
	if (deliverResult instanceof hudson.AbortException) {
		echo 'Delivery failed because: ' + deliverResult.message;
		error deliverResult.message
	} else {
		// change link back to RTC from Jenkins
		Replace_UCD_Link("${env.VERSION_NOM}", "Jenkins%20Build%20${buildDefinitionId}_${BUILD_TIMESTAMP}","Build%20Result",ucdComponentName, buildResultUUID, env.useTestUCD)
	}
	
	if (env.personalBuild?.equalsIgnoreCase('true')) {
		Set_UCD_Status (env.ucdComponentName, "${env.VERSION_NOM}","PersonalBuild", env.useTestUCD)
	} else { 
		def status = (env.sqStatus == "true") ? "PASS" : "FAIL"
		Set_UCD_Status (env.ucdComponentName, "${env.VERSION_NOM}","Code%20Quality%20-%20" + status, env.useTestUCD)
		status = (env.nexusStatus == "true") ? "PASS" : "FAIL"
		Set_UCD_Status (env.ucdComponentName, "${env.VERSION_NOM}","OSS%20Component%20Security%20-%20" + status, env.useTestUCD)
        if (env.veracodeResult == "PASS" || env.veracodeResult == "FAIL") {
            Set_UCD_Status (env.ucdComponentName, "${env.VERSION_NOM}","SAST%20-%20" + env.veracodeResult, env.useTestUCD)
        }
		echo "Get UCD Component Size"
		ucdComponentSize = Get_UCD_Component_Size(env.ucdComponentName, env.VERSION_NOM, env.useTestUCD)
	}
	echo "Get UCD Version Link"
	def UCDVersionUUID = Get_UCD_Version_UUID(env.ucdComponentName,env.VERSION_NOM,env.useTestUCD)
	def ucdenv = (env.useTestUCD?.equalsIgnoreCase('true'))? "ucd-test":"ucd"
	echo "Get RTC Build Link"
	Set_RTC_Build_Link("UCD Version ${env.VERSION_NOM}","https://${ucdenv}.bcbst.com/#version/${UCDVersionUUID}")
}
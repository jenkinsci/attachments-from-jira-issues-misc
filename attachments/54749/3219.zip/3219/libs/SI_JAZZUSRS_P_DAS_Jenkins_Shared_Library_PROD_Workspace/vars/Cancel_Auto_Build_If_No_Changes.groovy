#!/usr/bin/env groovy
// 176851

/**
 * Cancel both RTC and Jenkins automated (scheduled) build if there are no changes present
 *  
 * @param buildDefId The build definition name
 * 
 */
import hudson.model.Result 
boolean call(def buildDefId="") {
	def incomingChanges = Get_Incoming_Changes("https://rtcccm.bcbst.com/ccm",buildDefId)
	if (IsDebug()) {
		println "Incoming Changes is "+ incomingChanges+", userid is ${env.buildRequesterUserId}"
	}
	if ((!incomingChanges) && (env.buildRequesterUserId == "ADMIN") && (scheduleBuildCheckChanges.equalsIgnoreCase("true"))) {
		echo "setting autoCancelled to true"
		setParam("autoCancelled","true")
		echo "running Ant Task"
		Run_Ant_Build_Task("f69fb97e-db98-4cd3-a50e-13d1f7593ea4",["buildResultUUID=${buildResultUUID}"])
        currentBuild.build().getExecutor().interrupt(Result.ABORTED)
		sleep(1)
        return true
	}
    return false
}




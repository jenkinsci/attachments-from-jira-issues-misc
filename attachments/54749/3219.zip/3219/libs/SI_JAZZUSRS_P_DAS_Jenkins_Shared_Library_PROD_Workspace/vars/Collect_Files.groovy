#!/usr/bin/env groovy
// 176851

/**
 * Checkout source from file system using the build definition parameters
 *  
 * @param workingDir The current working directory
 * @param source the source path to pull files from
 * @param ver the version to establish in UCD for nonversion file system imports
 * 
 * @return the output of the batch collect
 */
 
def call(def workingDir, def source, def ver) {
	String methodName = 'DJSL -> Collect_Files()';
	echo methodName + ' :: Retrieving source via file system'
	fileOperations([folderCreateOperation("${workingDir}/toUCD")])
	def totalPath="${source}"
	if (ver != "") {
		totalPath +="\\${ver}"
	}
	if (IsDebug()) {
		powershell 'echo $env:computername'
		powershell 'whoami'
		bat script:"dir ${totalPath}"
	}
	def outPut = bat returnStatus:true, script: "robocopy ${totalPath} ${workingDir}/toUCD /MIR /XD archive"


	return outPut
}

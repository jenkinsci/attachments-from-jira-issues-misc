#!/usr/bin/env groovy
// 198354

/**
 *
 * @param repoURL		[String] (required) The repository URL to run the API call against
 *
 * @param inclArchived	[boolean] (optional) If set to true, include archived project areas in the results
 *
 * @return projectList 	[String] - A list containing the names of all project areas in the given repository
 *
 */
 

def call(String repoURL, boolean inclArchived = false) {
	echo "Fetching project area list from RTC..."
	
	if (inclArchived == true) {
		echo "Including archived project areas..."
		httpRequest authentication: 'RTC', ignoreSslErrors: true, outputFile: 'outputP.log', responseHandle: 'NONE', url: repoURL + '/rpt/repository/foundation?fields=projectArea%2FprojectArea%2Fname&size=10000'
	}
	else {
		httpRequest authentication: 'RTC', ignoreSslErrors: true, outputFile: 'outputP.log', responseHandle: 'NONE', url: repoURL + '/rpt/repository/foundation?fields=projectArea%2FprojectArea%5Barchived%3Dfalse%5D%2Fname&size=10000'
	}
	
	def outputH = steps.readFile "outputP.log"
	def rootNode = new XmlSlurper()
	def projectList = ""
	
	rootNode.setFeature("http://apache.org/xml/features/disallow-doctype-decl", false) 
	rootNode = rootNode.parseText(outputH)
	rootNode.projectArea.eachWithIndex { projectArea , i -> 
		projectList += projectArea.name.text() + '\n'
	}
	projectList = projectList.trim()
	return projectList
}
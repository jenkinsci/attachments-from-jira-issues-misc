#!/usr/bin/env groovy
// 356637
/**
 * Assigns ALM test parameter values to the env object, available through 
 * script argument (defined as 'this' in pipeline).
 * 
 * @param script - the pipeline script containing the env object
 * @param jsonRoot - json object read from servers.json file, used to obtain test values
 * @param appIndex - the name of the object to search for, as assigned to the name property
 * @param envnt - Type of test environment, either Prod or NonProd
 * 
 * @return void
 **/
def call(def env, def jsonRoot, def appIndex, def envnt) {
    echo "DSL->Assign_Env()"
    if (IsDebug()) {
        println jsonRoot.toString()
        echo "app index is ${appIndex}"
        echo envnt
    }
    def selection = Filter_JSON_By_Field(jsonRoot, appIndex)
    if (IsDebug()) {println "selection is "+ selection.toString()}
    env.appname = selection[0]
    env.testpath = (envnt == "NonProd")? selection[3]:selection[5]
    env.testdomain = (envnt == "Prod")? "SERVICEENABLINGAPPLICATIONS":selection[1]
    env.testproject = (envnt == "Prod")? "PatchValidation":selection[2]
    env.serverhost = (envnt == "NonProd")? selection[4]:selection[6]
}

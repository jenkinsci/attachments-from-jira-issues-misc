#!/usr/bin/env groovy

def call(String component, String ucdResourceMaps){

	echo "BEGIN Add_Component_To_Resource"
	
	def ucdEnv = "ucd.bcbst.com"
	if("${useTestUCD}" != null && "${useTestUCD}".equalsIgnoreCase('true')){
		ucdEnv = "ucd-test.bcbst.com"
	}
	
	def ucdUrl = "https://" + ucdEnv + "/cli/resource/create"
	echo "UCD URL: " + ucdUrl
	
	if(ucdResourceMaps == "" || ucdResourceMaps == null){
		echo "No application mappings have been defined using the \"ucdResourceMaps\" build definition property."
	}
	else{
		def resourceList = ucdResourceMaps.split(',')
		
		for(String resource : resourceList){
			echo "Mapping component " + component + " to resource " + resource + " in UCD..."
			
			
			def sb = new StringBuilder("");
			sb.append("{\"name\": \"");
			sb.append(component);
			sb.append("\",\"description\": \"");
			sb.append(component);
			sb.append("\",\"parent\": \"");
			sb.append(resource);
			sb.append("\",\"role\": \"");	
			sb.append(component);
			sb.append("\"}");
			
			def jsonRequest = sb.toString()
			echo "JSON Request: " + jsonRequest
			
			//def testme = URLIFY(ucdUrl)
			//echo testme
			
			def response
			try{
				response = httpRequest httpMode:'PUT', authentication: 'UCDImport', url: URLIFY(ucdUrl), ignoreSslErrors: true, responseHandle: 'NONE', contentType: 'APPLICATION_JSON', requestBody: jsonRequest, validResponseCodes: '200:399,400,404'
				if (response.status == 400){
					echo "Component '" + component + "' not mapped to resource '" + resource + "'. Resource already exists."
				}
				else if (response.status == 404){
					throw new Exception("Missing parent resource '" + resource + "'.")
					echo "Missing parent resource '" + resource + "'."
				}	
			}
			catch(Exception er){
				echo "ERROR: " + er
				currentBuild.result = 'UNSTABLE'
			}	
		}
	}
}
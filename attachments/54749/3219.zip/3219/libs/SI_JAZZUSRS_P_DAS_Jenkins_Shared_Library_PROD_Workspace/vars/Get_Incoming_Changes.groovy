#!/usr/bin/env groovy
// 176851

/**
 * @param repoURL (required) The repository URL to run the API call against
 * @param buildDefId (required) The build definition ID of the changes
 * @param workspaceUUID	(optional) The UUID of the workspace to check
 *
 * @return jsonObj.changes 		[Boolean] - Returns true if incoming changes are detected, false otherwise
 *
 */
 

boolean call(String repoURL, def buildDefId, String workspaceUUID = "") {
	echo "Checking incoming changes..."
	String uriCall
	if (workspaceUUID != "") {
		uriCall = rtcRepo + "/resource/virtual/build/incomingchanges?workspaceUUID=" + workspaceUUID
	}
	else {
		uriCall = rtcRepo + "/resource/virtual/build/incomingchanges?definitionUUID=" + Get_Build_Definition_UUID(buildDefId)
	}
	
	def response = httpRequest authentication: 'RTC', ignoreSslErrors: true, outputFile: 'output.log', responseHandle: 'NONE', url: uriCall
	def jsonObj = readJSON file: 'output.log'
	
	return jsonObj.changes
	
}
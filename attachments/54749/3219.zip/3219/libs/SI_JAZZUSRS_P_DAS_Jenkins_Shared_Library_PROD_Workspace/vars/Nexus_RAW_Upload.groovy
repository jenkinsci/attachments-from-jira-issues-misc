#!/usr/bin/env groovy

/**
 * Perform a RAW Nexus deploy using the build definition parameters
 * 
 * @param nexusFilePath(required) the directory (excluding file name) that contains the file you want to push
 * @param nexusFileName(required) the name of the file you want to push.
 * @param nexusURLPath(required) everything after nexus.bcbst.com/repository/ in the nexus url. Defaults to raw-file-hosting.
 *
 */
 
// Curl script to push one file to the ${nexusRepo}. ${nexusRepo} is defined on the Jenkins servers as an environment variable. 
void call(def nexusFilePath, def nexusFileName, def nexusURLPath) {
    echo "DSL->Nexus_RAW_Upload()"
   	withCredentials([usernamePassword(credentialsId: 'SI_JAZZUSRS_P', passwordVariable: 'password', usernameVariable: 'username')]) {
		bat label: 'Upload Command', script: "curl -v -u %username%:%password% --upload-file ${nexusFilePath}/${nexusFileName} ${nexusRepo}/${nexusURLPath}/${nexusFileName} -k"
  			}
   		}
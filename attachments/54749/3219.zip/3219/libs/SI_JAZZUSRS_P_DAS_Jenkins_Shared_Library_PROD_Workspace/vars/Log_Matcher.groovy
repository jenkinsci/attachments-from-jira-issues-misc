/**
 * This is a non-serializable function that returns the first result of 
 * a matched expression in a log
 * 
 * @param pattern the pattern to match
 * @param log the text of the log
 * 
 * @return the matched pattern in the log
 */

@NonCPS
def call(def pattern, def log) {
    def x = pattern.matcher(log)
    def result = (x.size()>0)? x[0][1]:""
    return result
}
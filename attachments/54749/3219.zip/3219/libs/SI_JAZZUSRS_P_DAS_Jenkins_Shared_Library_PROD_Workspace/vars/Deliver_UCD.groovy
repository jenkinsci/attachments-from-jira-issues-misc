#!/usr/bin/env groovy
// 176851

/**
 * Deliver build artifacts to UCD.
 * 
 * @param versionName the version name to assign to the artifacts' UCD version 
 * @return ucdResults 	[Object] - the return value (if any) of the UCD deliver command
 *
 */
 
def call(String versionName) {
    def wiList="none"
	String methodName = 'DJSL -> Deliver_UCD()';
	echo methodName
	def siteEnv = (env.useTestUCD?.equalsIgnoreCase('true'))? "UCDTest":"UCDProd"

	//translate properties into valid patterns
	String include1=env.ucdIncludePattern?.replaceAll(",",'\n')
	String exclude1=env.ucdExcludePattern?.replaceAll(",",'\n')
	if (IsDebug()) {
		echo "Delivering to ${siteEnv}..."
		echo "New include pattern is "+include1
		echo "component name is ${env.ucdComponentName}"
		echo "version name is "+versionName
		echo "target path is ${workingDirectory}/${env.ucdTargetPath}"
	}
    def ucdProps=""
    if (env.enableIntegration?.equalsIgnoreCase('true')) {
        ucdProps = "buildDefinitionId=" + URLIFY(buildDefinitionId)+
            "\nbuildRequesterUserId=${buildRequesterUserId}"
    }
//    } else {
//        ucdProps = "buildRequesterUserId=${buildRequesterUserId}"
//    }
    try {
        wiList = readFile("das/workitems.txt")
        if (env.enableIntegration?.equalsIgnoreCase('true')) {
            ucdProps +="\nworkItems=${wiList}"
        } else {
            ucdProps +="workItems=${wiList}"
        }
    } catch (e) {
        echo "Could not find any work items to list"
    }
    echo "ucd properties: ${ucdProps}"
	def ucdResults;
        try {
     			ucdResults = step([
    				$class: 'UCDeployPublisher',
    				siteName: siteEnv,
    				component: [
    				   $class: 'com.urbancode.jenkins.plugins.ucdeploy.VersionHelper$VersionBlock',
    					componentName: "${env.ucdComponentName}",
    					createComponent: [
    						$class: 'com.urbancode.jenkins.plugins.ucdeploy.ComponentHelper$CreateComponentBlock',
    						componentTemplate: env.ucdComponentTemplateName,
    					//	componentApplication: ucdApplicationName
    					],
    					delivery: [
    						$class: 'com.urbancode.jenkins.plugins.ucdeploy.DeliveryHelper$Push',
    						pushVersion: versionName,
    						baseDir: "${workingDirectory}/${env.ucdTargetPath}",
    						fileIncludePatterns: "${include1}",
    						fileExcludePatterns: "${exclude1}",
//    						pushProperties: "${ucdProps}",
    						pushDescription: "Pushed from Jenkins, Requested by ${buildRequesterUserId}",
    						pushIncremental: false
    					] // delivery parameter
    				] //component
    			]) //steps.step
    			sleep(3)
                Set_UCD_Version_Property(env.ucdComponentName, versionName,"workItems",wiList,false,env.useTestUCD) 
    			Assign_Component_To_Team(env.ucdComponentName,"${isDomainName}_${isTeamName}",env.useTestUCD)
        } catch (e) {
            echo "Problem found: ${e.message}"
            return 1;
        }
	return 0;
}




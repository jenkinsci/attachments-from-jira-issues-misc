#!/usr/bin/env groovy
// 176851

/**
 * 
 * @param workItem	the work item number
 * @param descText the comment text
 * 
 * @return uuid the uuid of the work item comments
 *
 */
 
def call(def workItem="184130", def descText="sample comment") {
	echo "DSL -> WriteWorkItemComment_RTC()"
	try {
		httpRequest authentication: 'RTC', ignoreSslErrors: true, outputFile: 'comment.log', responseHandle: 'NONE', url: 'https://rtcccm.bcbst.com/ccm/oslc/workitems/'+env.workItem+'.xml'
		
		def outputH = readFile "comment.log"
		def rootNode = new XmlSlurper(false,false).parseText(outputH)
		echo "rootNode =  ${rootNode.'rtc_cm:contextId'}"
		def uuid = "${rootNode.'rtc_cm:contextId'}"
		httpRequest authentication: 'RTC',
		 consoleLogResponseBody: true,
		 customHeaders:  [[maskValue: false, name: 'Accept', value: 'application/x-oslc-cm-change-request+xml'],
                         [maskValue: false, name: 'Content-type', value: 'application/x-oslc-cm-change-request+xml']],
		 httpMode: 'POST', ignoreSslErrors: true,
		 requestBody: """<?xml version='1.0' encoding='UTF-8'?>
<rtc_cm:Comment xmlns:rtc_cm='http://jazz.net/xmlns/prod/jazz/rtc/cm/1.0/' xmlns:oslc_cm='http://open-services.net/xmlns/cm/1.0/' xmlns:dc='http://purl.org/dc/terms/'>
<dc:description>${descText}
</dc:description>
</rtc_cm:Comment>
""",
		  responseHandle: 'NONE',
		  url: 'https://rtcccm.bcbst.com/ccm/oslc/workitems/'+workItem+'/rtc_cm:comments'
		 return uuid
	} catch (error) {
        echo error.message
		return "Undefined"
	}
}




/** 
* Run NeoLoad tests using YAML file to determine which tests are run. Compatible with running in parallel as this method returns a closure (stage).
* This method runs cleanWs at the START of the block set to run on the performance test server, thereby clearing files from the previous run. 
* The step archiveArtifacts runs at the end of the node block, using an include pattern. 
* @param apps ArrayList of JSONObject's containing relevant test data from servers.json.
* @param envName The name of the environment being tested.
* @param nodeName the label of the Jenkins node running the test
* @return A closure (pipeline Stage) containing the code to be executed in parallel. 
**/
def call(ArrayList apps, String envName, String nodeName="neoload") {
    return {
        stage ("stage: Performance Test") {
            node (nodeName) {
                def xmlStr = "";
                try {
                    println "[PERFORMANCE] => CleanWs -> (${nodeName}): ${env.WORKSPACE}";
                    cleanWs notFailBuild: true;
                    println "[PERFORMANCE] => Running performance test in workspace (${nodeName}): ${env.WORKSPACE}";
                    println "[PERFORMANCE] => Jenkins user: ${env.USERNAME}";
                    int execMode = Gen_Neo_Yaml(apps, envName);
                    if (IsDryRun()) {
                        xmlStr = Gen_Patch_Test_Warning_XML('dry_run_success');
                    } 
                    else {
                        StringBuilder sb = new StringBuilder();
                        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                        sb.append("<resource name=\"NeoLoadTests\">");

                        int exitCode = Exec_NeoLoad_Yaml_Download_Script(envName);
                        if (exitCode > 0) throw new Exception('[PERFORMANCE] => Download NeoLoad script method Exec_NeoLoad_Yaml_Download_script() returned a non-zero status code indicating that it failed');
                        sleep 30 // 30 sec. Enough time to complete building the NeoLoad artifacts   // comment for testing

                        if (!!(execMode &1)) {  // NTLM Execution: execMode == 1 || 3
                            exitCode = Exec_NeoLoad_Yaml(false, envName);
                            if (exitCode > 0) throw new Exception('[PERFORMANCE] => NeoLoad test execution method Exec_NeoLoad_Yaml() returned a non-zero status code indicating that it failed');
                            sleep 30;    // comment for testing
                            sb.append(readTestData());  // add test result xml
                        }
                        if (!!(execMode &2)) {  // KERB Execution: execMode == 2 || 3
                            exitCode = Exec_NeoLoad_Yaml(true, envName);
                            if (exitCode > 0) throw new Exception('[PERFORMANCE] => NeoLoad test execution method Exec_NeoLoad_Yaml() returned a non-zero status code indicating that it failed');
                            sleep 30;    // comment for testing
                            sb.append(readTestData());  // add test result xml
                        }
                        xmlStr = sb.append("</resource>").toString();
                    }
                } catch (e) {
                    println "[PERFORMANCE] => EXCEPTION raised while attempting to complete test.";
                    println e;
                    StringBuilder sb = new StringBuilder();
                    xmlStr = Gen_Patch_Test_Warning_XML('exception');
                    throw e;    // bubble up since parallel step doesnt allow checking return values (or isnt documented)
                } finally {
                    if (IsDebug()) println "[DEBUG] Performance results generated: ${xmlStr}";
                    if (IsDebug()) println "[DEBUG] Checking for test warnings";
                    def xmlWarn = Get_Warning_Or_Null(xmlStr);
                    if (xmlWarn) println "[PERFORMANCE] => WARNING -> ${xmlWarn.name} : ${xmlWarn.msg} for Performance Test";
                    def savePath = "${env.WORKSPACE}\\${env.BUILD_ID}\\neoload-results\\junit-sla-combined-results-${env.BUILD_ID}.xml"
                    if (IsDebug()) println "[DEBUG] Saving test results to file: ${savePath}";
                    writeFile file: "${savePath}", text: xmlStr;
                    if (IsDebug()) println "[DEBUG] Test file saved: ${savePath}";
                    archiveArtifacts artifacts: "**/junit-sla-combined-results-${env.BUILD_ID}.xml, **/Default*.yaml", followSymlinks: false;
                }
            }
        }
    }
}

import hudson.Functions;
String readTestData() {
    String data = null;
    try {
        if (IsDebug()) println "Run_NeoLoad_Test_Parallel() --> readTestData()";
        String readPath = "${env.WORKSPACE}/neoload-report/junit-sla-results.xml";
        if (!fileExists(readPath)) throw new Exception("File does not exist: ${readPath}");
        data = readFile file: readPath;
        data = data.minus("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        data = data.minus("<resource name=\"NeoLoadTests\">");
        data = data.minus("</resource>");
        println "[PERFORMANCE] => File read: ${readPath}";
    } catch (e) {
        println Functions.printThrowable(e);
    } finally {
        return data;
    }
    
} 
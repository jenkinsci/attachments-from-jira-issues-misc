#!/usr/bin/env groovy
// 426735


 
void call(){

	echo "Performing Overrides Validation..."
	
	def barPath = workingDirectory + "\\BARfiles\\" + componentName + "_" + componentVersion + "\\" + componentName + ".bar"
	def overridesPath = workingDirectory + "\\BARfiles\\" + componentName + "_" + componentVersion + "\\~overrides"
	def command = "cmd /c java -jar " + overridesValidationPath + " -e All -b " + barPath + " -o " + overridesPath + " -f " + workingDirectory + "\\output.txt"
	
	echo command
	
	def outP = powershell (returnStdout: true, script: "${command}")
	
	echo outP
	
	if (outP.contains("Exit :0")) {
		echo "Overrides validation successful"
	}
	else {
		outP = powershell (returnStdout: true, script: "Get-Content -Path ${workingDirectory}\\output.txt")
		echo outP
		throw new Exception("Error during overrides validation. Please check your BAR overrides for any issues.")
	}
}

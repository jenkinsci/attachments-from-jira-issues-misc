#!groovy
/** Returns build engine memory statistics in the form of a string
*
* @param nodeName the Jenkins node on which we're running
* 
* @return String the memory statistics string
*/
 
 String call(def nodeName = ""){
	 echo "DSL->Get_Process_Memory()"
	 def scriptContent = 'get-process -name \'j[as][vl]*\' -computername '+nodeName+' | Group-Object -Property ProcessName |Format-Table Name, @{n=\'Mem (KB)\';e={\'{0:N0}\' -f (($_.Group|Measure-Object WorkingSet -Sum).Sum / 1KB)};a=\'right\'} -AutoSize'
	 echo scriptContent
	 def memoryStats = bat (returnStdout:true, script:"Powershell.exe -executionpolicy remotesigned -File F:/Jenkins/ScanMemory.ps1")
	  	echo "Memory Stats: ${memoryStats}"
	return memoryStats
 }
#!/usr/bin/env groovy
// 176851

/**
 * Get a list of changes since last build.
 *  
 * @return changeList 	[String] - A list of changes in html format (string)
 *
 */
 
String call() {
    def changeList = ""
    if (env.personalBuild != "true") {
        try {
            echo "looking for changesets..."
            timeout(1) {
                waitUntil (quiet:true, initialRecurrencePeriod:15000) {
                    fileExists 'das/changelist.txt'
                }   //wait
            } //timeout
            changeList = readFile "das/changelist.txt"
            if (changeList==""|| changeList == null) changeList = "<tr><td>No changes found since last build.</td></tr>"
            if (IsDebug()) echo "Retrieved changelist from file: ${changeList}"
            return changeList
        } catch (e) {
            echo "Could not retrieve changes."
            if (IsDebug()) echo "${e.message}"
            return "<tr><td>No changes found since last build.</td></tr>"
        }
    }
//	return changeList 
}


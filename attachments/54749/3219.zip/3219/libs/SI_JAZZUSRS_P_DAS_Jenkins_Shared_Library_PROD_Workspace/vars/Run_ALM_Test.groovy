/**
*   Used to run an ALM test from a predetermined test set path
* @param almDomain  the ALM domain
* @param almProject the ALM project name
* @param almTestSetPath    the path to the test set
* @param almServer  the jenkins server where the alm client is
* 
* @return status 0(pass) or 1(fail)
* 
*/

int call(def almDomain, def almProjectName, def almTestSetPath, def almServer, def uid="p28826c"){
    try {
        if (IsDebug()) println "DSL->Run_ALM_Test('${almDomain}', '${almProjectName}', '${almTestSetPath}', '${almServer}')"
            def almPath = """${almTestSetPath}
                    """
            echo "ALM Test Set Path is ${almPath}"
            runFromAlmBuilder almServerName: 'ALM Prod',
                almUserName: uid,
                almDomain: "${almDomain}",
                almProject: "${almProjectName}",
                almTestSets: almPath,
                almRunResultsMode:'',
                almTimeout: '',
                almRunMode: 'RUN_LOCAL',
                almRunHost: '',
                almClientID: '',
                almApiKey: '',
                isSSOenabled: false
             archiveArtifacts '**/*'
//        } //withCredentials
        return 0
    } catch (e) {
        echo "Problem running test: ${e.message}"
        return 1 
    }
}
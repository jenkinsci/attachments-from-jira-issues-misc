import hudson.Functions
/** 
* Downloads the Performance Script, required before calling Execute_Performance()
* 
* @param exePath The path to the NeoLoad executable. Passed in to prevent hard-coding value in method.
* @param ptNTS The NeoLoad server name. Passed in to prevent hard-coding value in method.
* @param envName The name of the environment being tested. 
* @return Nothing if successful, throws error otherwise. 
* 
**/
def call(String envName) {
    try {
        if (IsDebug()) println "DJSL -> Exec_NeoLoad_Yaml_Download_Script(String envName=${envName})";
        LinkedHashMap ops = [
            ptNTS : (envName.equalsIgnoreCase('PROD')) ? 'SQA NeoLoad' : 'SQA NeoLoad NonProd',
            exePath : 'C:\\Program Files\\NeoLoad 7.7\\bin\\NeoLoadCmd',
            scenario : 'Test',
        ]
        if (IsDebug()) println "[DEBUG] Running NeoLoad plugin with the following options:\n${ops}";
        neoloadRun executable: ops.exePath,
            project: [
                server: ops.ptNTS,
                name: "All_${envName}",
                publishTestResult: false
            ],
            scenario: ops.scenario,
            sharedLicense: [server: ops.ptNTS, duration: 2, vuCount: 50],
            autoArchive: 'false' // by default the plugin runs archiveArtifacts 
        return 0;
    } catch (Exception e) {
        StringBuilder sb = new StringBuilder(); // Adding error messages since plugin isn't very descriptive
        sb.append("* * * * * * ERROR EXECUTING PERFORMANCE TEST * * * * * *\n");
        sb.append("Method: Execute_Performance_Download_Script\n");
        sb.append("Message: Unable to download test script.\n");
        sb.append("${Functions.printThrowable(e) }");
        println sb.toString();
        return 1;
    }
}
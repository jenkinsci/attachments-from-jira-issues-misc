/**
*Attempts to split the input by the given delimiter. 
*Intended to handle bad input such as non-strings, empty strings, or nulls gracefully.
*
*	@param source The string to be split into sub-strings.
	@param delimiter The string to use as a delimiter.
*
**/

def call(source, String delimiter = ','){
	def String[] out = []
	if(source instanceof String && source != null && source != ''){
		out = source.split(delimiter)		
	}
	//Ensures that we always return an array
	if(out instanceof String){
		return [out]
	}else{
		return out
	}
}
/**
 * Determine if pipeline is in dry_run mode by checking build parameter dry_run
 *  
 * @return boolean - whether dry_run is set to true
 *
 */
 
def call() {
    if (IsDebug()) echo "DSL->IsDryRun()"
	return ("${params.dry_run}".equalsIgnoreCase("true"))
}




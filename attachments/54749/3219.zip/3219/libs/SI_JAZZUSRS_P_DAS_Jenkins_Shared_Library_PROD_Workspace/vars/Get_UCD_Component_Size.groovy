#!/usr/bin/env groovy
// 198354

/** Returns UCD Component size in KB
*
* @param componentName name of the component
* @param version version number
* @param useTest whether to use UCD test
* 
* @return the size of the UCD component in KB
*
*
**/

import groovy.json.JsonSlurperClassic
 

def call(String componentName, String version, def useTest="true") {
    echo "DSL->Get_UCD_Component_Size()"
	componentName = URLIFY(componentName)
	def env = (useTest?.equalsIgnoreCase('true'))? "ucd-test":"ucd"
	def makeSilent = !(IsDebug())
	def response=httpRequest httpMode:'GET', authentication: 'UCDImport', quiet: false, outputFile: 'output.json', url: "https://${env}.bcbst.com/cli/version/listVersionArtifacts?component=${componentName}&version=${version}"
	def jsonData = new groovy.json.JsonSlurperClassic().parseText(response.content)
	if (IsDebug()) {
		println jsonData?.toString()
	}
	def totalBytes = 0
	for(def item in jsonData){
		if (IsDebug()) {
			echo "print item"
			echo item?.toString()
			echo "end print item"
		}
		if (item.totalSize != null) {
			totalBytes += item.totalSize
		} else {
			totalBytes += item.length
		}
		if (IsDebug()) {
			echo "print totalbytes"	
			echo totalBytes?.toString()
			echo "end print totalbytes"
		}
	}
	
	return totalBytes / 1024	//convert to KB
}	
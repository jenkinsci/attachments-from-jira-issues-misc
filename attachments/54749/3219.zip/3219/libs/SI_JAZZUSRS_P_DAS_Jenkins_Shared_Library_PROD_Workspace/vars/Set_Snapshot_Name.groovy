#!/usr/bin/env groovy
// 176851

/**
 * Set the snapshot name to match the UCD version.
 *  
 * @param snapshotUUID the UUID of the snapshot to be changed
 * @param snapshotText the text to set the snapshot to
 *
 */
 
def call(def buildUUID, def snapshotText="${BUILD_TIMESTAMP}") {
    echo "DSL->Set_Snapshot_Name()"
    if (env.personalBuild != "true") {
        try {
            withCredentials([usernamePassword(credentialsId:'SI_JAZZUSRS_P', passwordVariable: 'pwd', usernameVariable:'uid')]) {
                env.RTC_USER_ID='SI_JAZZUSRS_P'
                env.RTC_PASSWORD=pwd
                Run_Groovy_Script("das/Change_Snapshot_Name.groovy","\"%uid%\" \"%pwd%\" \"${buildUUID}\" \"${snapshotText}\"")
            }
            return 0
        } catch (e) {
            if (!IsExcludedStream()) {
                echo "Error - Receiving a null value for snapshot without personal build. You must not be using a build workspace!"
                error "Build definition using streams is unsupported"
            }
            echo "Snapshot not found for build. Skipping rename..."
            return 1
        }
    }
}		
#!/usr/bin/env groovy
// 176851

/**
 * 
 *  
 *
 */
void call() {
    echo "DSL->NPM_Test()"
	try {						
		println "Running unit tests ---> 'npm test'"
		bat "npm test"
	} catch(e) {
		echo "encountered an error during unit testing"
	}
}



#!/usr/bin/env groovy
// 176851

/**
 * Deliver build artifacts to UCD.
 * 
 * @param versionName the version name to assign to the artifacts' UCD version 
 * @return ucdResults 	[Object] - the return value (if any) of the UCD deliver command
 *
 */
 
def call(def external = false) {
    echo "DSL->Full_Deploy_Step()"
	if (!external) {
		def deployResults = Deploy_UCD(env.ucdApplicationName,env.ucdApplicationProcessName,env.ucdEnvironmentNameDVLP,env.VERSION_NOM,env.ucdComponentName,env.useTestUCD);
		if (deployResults instanceof hudson.AbortException) {
			echo 'Deployment failed because: ' + deployResults.message;
			error deployResults.message
		} else {
		// we are now deployed to DVLP
			if (env.personalBuild != "true") {
				Set_UCD_Status (env.ucdComponentName,env.VERSION_NOM,"DVLP",env.useTestUCD)
			}	                
		}
	} else {
		echo "External build - skipping Deploy Step for now"
	}

}


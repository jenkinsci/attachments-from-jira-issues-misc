#!/usr/bin/env groovy
// 198354

/**
 * @param steps					[Object] (required) The calling pipeline's steps object (this.steps)
 *
 * @param repoURL				[String] (required) The repository URL to run the API call against
 *
 * @param inclArchived			[boolean] (optional) If set to true, include archived project areas in the results
 *
 * @param projectArea			[String] (optional) If set, only include results from the specified project area 
 *
 * @return nameListBuild 		[String] - A list containing the names of build definitions
 *
 * @return uuidListBuild 		[String] - A list containing the UUID's of build definitions
 *
 * @return nameListProjectArea 	[String] - A list of names for project areas, indicating which project a build definition belongs to
 *
 * @return uuidListProjectArea 	[String] - A list of UUID's for project areas, indicating which project a build definition belongs to
 *
 */
 

def call(String repoURL, boolean inclArchived = false, String projectArea = "") {
	echo "Fetching build definition list from RTC..."
	httpRequest authentication: 'RTC', ignoreSslErrors: true, outputFile: 'outputBD.log', responseHandle: 'NONE', url: repoURL + '/rpt/repository/build?fields=build%2FbuildDefinition%2F%28itemId%7Cid%7C%28projectArea%2F%28itemId%7Carchived%7Cname%29%29%29&size=10000'
	def outputH = readFile "outputBD.log"
	def rootNode = new XmlSlurper()
	def nameListBuild = ""
	def uuidListBuild = ""
	def nameListProjectArea = ""
	def uuidListProjectArea = ""
	
	rootNode.setFeature("http://apache.org/xml/features/disallow-doctype-decl", false) 
	rootNode = rootNode.parseText(outputH)
	rootNode.buildDefinition.eachWithIndex { buildDefinition , i -> 
		if (inclArchived == true && projectArea == "") {
			nameListBuild += buildDefinition.id.text() + '\n'
			uuidListBuild += buildDefinition.itemId.text() + '\n'
			nameListProjectArea += buildDefinition.projectArea.name.text() + '\n'
			uuidListProjectArea += buildDefinition.projectArea.itemId.text() + '\n'
		} else if (inclArchived == true && projectArea != "") {
			if (projectArea == buildDefinition.projectArea.name.text()) {
				nameListBuild += buildDefinition.id.text() + '\n'
				uuidListBuild += buildDefinition.itemId.text() + '\n'
				nameListProjectArea += buildDefinition.projectArea.name.text() + '\n'
				uuidListProjectArea += buildDefinition.projectArea.itemId.text() + '\n'
			}
		} else if (inclArchived == false && projectArea == "") {
			if (buildDefinition.projectArea.archived.text() == "false") {
				nameListBuild += buildDefinition.id.text() + '\n'
				uuidListBuild += buildDefinition.itemId.text() + '\n'
				nameListProjectArea += buildDefinition.projectArea.name.text() + '\n'
				uuidListProjectArea += buildDefinition.projectArea.itemId.text() + '\n'
			}
		} else if (inclArchived == false && projectArea != "") {
			if (buildDefinition.projectArea.archived.text() == "false" && projectArea == buildDefinition.projectArea.name.text()) {
				nameListBuild += buildDefinition.id.text() + '\n'
				uuidListBuild += buildDefinition.itemId.text() + '\n'
				nameListProjectArea += buildDefinition.projectArea.name.text() + '\n'
				uuidListProjectArea += buildDefinition.projectArea.itemId.text() + '\n'
			}
		} 
	}
	nameListBuild = nameListBuild.trim()
	uuidListBuild = uuidListBuild.trim()
	nameListProjectArea = nameListProjectArea.trim()
	uuidListProjectArea = uuidListProjectArea.trim()
	return [ nameListBuild, uuidListBuild, nameListProjectArea, uuidListProjectArea ]
}
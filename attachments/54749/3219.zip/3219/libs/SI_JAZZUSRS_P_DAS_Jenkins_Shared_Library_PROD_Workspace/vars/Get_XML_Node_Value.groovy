#!/usr/bin/env groovy
// 176851

/**
 * Find the value of a given XML node by name
 * If attribute, then can choose between one of the following names for findName:
 * processName - project area
 * config - build configuration
 * directory - build directory
 * solution - solution file name
 * type - build type
 *  
 * @param object the XML object
 * @param refName the name to search for
 * @attribute boolean - is this an attribute? if false, it's a value
 * 
 * @return the value of the node
 * 
 */
@NonCPS
def call(def object, def refName, boolean attribute=false) {
    println "DSL->Get_XML_Node_Value() for ${refName}"
	if (attribute) {
			switch (refName) {
				case 'processName': 
					return object['@processAreaName']
				case 'config':
					return object['@configuration']
				case 'directory':
					return object['@directory']
				case 'solution':
					return object['@solution']
				case 'type':
					return object['@type']
				default:
					return 'NA'
			}
	} else {
		return object.find { it.'@name' == "${refName}" }['@value']
	}
	
}




#!/usr/bin/env groovy
// 176851

/**
 * Set a new link in the current RTC build results.
 * 
 * @param versionNM	[Object] (required) The version number in UCD for the component artifacts
 * @return rtcLinkName 	[String] - RTC Link name
 *
 */

def call(linkName="Link",def linkURL="URL",def buildUUID=env.buildResultUUID) {
	String methodName = 'DSL -> Set_RTC_Build_Link'
	echo methodName
    def uidstr= (env.NODE_LABELS.contains("aix"))?"\$RTC_USER_ID":"%uid%"
    def pwdstr= (env.NODE_LABELS.contains("aix"))?"\$RTC_PASSWORD":"%pwd%"
        try {
            timeout(2) {
                withCredentials([usernamePassword(credentialsId:'SI_JAZZUSRS_P', passwordVariable: 'pwd', usernameVariable:'uid')]) {
                    env.RTC_USER_ID='SI_JAZZUSRS_P'
                    env.RTC_PASSWORD=pwd
                    Run_Groovy_Script("das/Set_BR_Link.groovy","\"${uidstr}\" \"${pwdstr}\" \"${buildUUID}\" \"${linkName}\" \"${linkURL}\"",IsDebug(),true)
                    sleep time:7, unit:'SECONDS'
                }
            }
            return 0
        } catch (e) {
            echo "Could not set RTC link: ${e.message}"
            return 1
        }
}




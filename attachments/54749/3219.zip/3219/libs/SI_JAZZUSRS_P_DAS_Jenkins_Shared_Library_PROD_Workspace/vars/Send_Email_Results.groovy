#!/usr/bin/env groovy
// 176851

/**
 * Send an email warning notification
 * 
 * @param recipient			[String] (required) The email recipient(s) of the notification
 * @param notifySubject		[String] (required) The notification subject line
 * @param atchFile			[String] (optional) a file attachment pattern
 * @param admin				[Boolean] (optional) whether to create an admin email
 * @param useTemplate		[String] (optional) the email template filename
 * @param preSendTemplate   [String] (optional) the pre-send template filename
 * @param atchLog           [String] (optional) whether to include the build log as an attachment
 *  
 */
def call(String recipient='',def  notifySubject='', String atchFile='', boolean admin=false,String useTemplate="jenkins-matrix-email-html.template",String preSendTemplate="build-presend.groovy",boolean atchLog=true) {

	String methodName = 'DJSL -> Send_Email_Results() v2';
	echo methodName
    templateName= useTemplate
	preSendScript = '${SCRIPT, template="'+preSendTemplate+'"}'
	if (admin) {
            echo "send admin"
			emailext body:templateName, presendScript: preSendScript, replyTo: 'DeliveryAutomationSvcs@bcbst.com', subject: notifySubject, to: recipient, attachLog:atchLog, attachmentsPattern: atchFile
	} else {
            echo "send nonadmin"
			emailext body:templateName, presendScript: preSendScript, recipientProviders: [developers(), requestor()], subject: notifySubject, replyTo: 'DeliveryAutomationSvcs@bcbst.com', to: recipient, attachLog:atchLog, attachmentsPattern: atchFile
		
	}	
}

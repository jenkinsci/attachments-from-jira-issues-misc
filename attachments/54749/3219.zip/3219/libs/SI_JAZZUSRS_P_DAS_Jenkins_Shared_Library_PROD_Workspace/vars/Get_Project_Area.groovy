#!/usr/bin/env groovy
// 176851

/**
 * 
 * @param buildDefId the build definition to check 
 *  
 * @return projectArea 	[String] - the name of the project area corresponding to the current build definition
 *
 */
 
String call(def buildDefId="") {
	try {
        echo "DSL->Get_Project_Area()"
		def keepQuiet = !(IsDebug())
		steps.httpRequest authentication: 'RTC', ignoreSslErrors: true, outputFile: 'output.log', responseHandle: 'NONE', quiet: keepQuiet, url: 'https://rtcccm.bcbst.com/ccm/rpt/repository/build?fields=buildDefinition/buildDefinition[id='+buildDefId+']/projectArea/name'
		def outputH = steps.readFile "output.log"
		def rootNode = new XmlSlurper().parseText(outputH)
		return rootNode.toString()
	} catch (error) {
		return "Undefined"
	} 
}




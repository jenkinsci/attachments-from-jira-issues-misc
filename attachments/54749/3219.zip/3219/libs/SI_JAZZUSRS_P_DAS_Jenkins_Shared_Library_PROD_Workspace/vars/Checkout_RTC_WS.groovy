#!/usr/bin/env groovy
// 176851

/**
 * Checkout source from RTC using the build workspace parameters
 *  
 * @param buildWSId the name of the build workspace to pull from
 * @param loadRule [optional] whether to use load rules
 * @param loadRuleFile [optional] the name of the load rule file to use
 * 
 * @return the value returned by checkout
 */
 
def call(def buildWSId="NoBuild", def loadRuleFile='') {
	String methodName = "DJSL -> Checkout_RTC_WS(${buildWSId})";
    def result = null
    if (loadRuleFile != '') {
	    result = checkout([
		$class: 'RTCScm', 
		avoidUsingToolkit: true, 
		buildTool: 'build engine', 
		buildType: [buildWorkspace: buildWSId, loadPolicy: 'useLoadRules', customizedSnapshotName: '', pathToLoadRuleFile:loadRuleFile, value: 'buildWorkspace'], 
		credentialsId: 'SI_JAZZUSRS_P',
		overrideGlobal: true, 
		serverURI: 'https://rtcccm.bcbst.com/ccm', 
		timeout: 480]);
    } else {
        result = checkout([
            $class: 'RTCScm',
            avoidUsingToolkit: true,
            buildTool: 'build engine',
            buildType: [buildWorkspace: buildWSId, componentLoadConfig: 'loadAllComponents', createFoldersForComponents: true, customizedSnapshotName: '', loadDirectory: "${WORKSPACE}", loadPolicy: 'useComponentLoadConfig', value: 'buildWorkspace'],
            credentialsId: 'SI_JAZZUSRS_P',
            overrideGlobal: true,
            serverURI: 'https://rtcccm.bcbst.com/ccm',
            timeout: 480]);
    }
    //    if (IsDebug()) { echo "checkout result is ${result.requestUUID}" }
    return result //result is returned as a map to build information
}




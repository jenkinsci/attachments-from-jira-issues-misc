#!/usr/bin/env groovy
// 176851

/**
 * Set the snapshot name to match the UCD version.
 *  
 * @param snapshotUUID the UUID of the snapshot to be changed
 * @param snapshotText the text to set the snapshot to
 *
 */
 
void call(def buildUUID, def labelText="${BUILD_TIMESTAMP}") {
    echo "DSL->Set_Build_Id()"
    withCredentials([usernamePassword(credentialsId:'SI_JAZZUSRS_P', passwordVariable: 'pwd', usernameVariable:'uid')]) {
//        env.RTC_USER_ID='SI_JAZZUSRS_P'
//        env.RTC_PASSWORD=pwd
        Run_Groovy_Script("das/Set_Build_Label.groovy","\"%uid%\" \"%pwd%\" \"${buildUUID}\" \"${labelText}\"")
    }
}		
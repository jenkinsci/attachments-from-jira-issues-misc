#!/usr/bin/env groovy
// 176851

/**
 * Run Sonarqube Scanner for MSBuild
 * 
 * @param sonarKey The sonarqube key for the application
 * @param loadDir the current load directory
 * @param ver the version to apply
 * @return sqstate did sonarqube succeed?
 *  
 */
def call(String sonarKey, def loadDir="", def ver="", disableSCM="true") {
    if (disableSCM=="null" || disableSCM == null) disableSCM = "true"
	String methodName = 'DJSL -> Scan_Sonar()';
	echo methodName
	def outPut = ""
	def sqState=0
	def gv = bcbst.das.GlobalVars
	if ((slnFile.contains('.rptproj')) || (isExcludedSQ())) {
		return -1
	}	
	if (version=="timestamp") {
		version="${BUILD_TIMESTAMP}"
	}
	echo "Sending Version ${ver} to SonarQube"
	switch (sonarKey) {
		case "stop":
				echo "Sending end to Sonarqube..."
				sqState = bat (script:"${tool 'BCBST_SonarQube'} end", returnStatus:true)
				break
		default:
				echo "Processing through Sonarqube..."
				try {
					sqState = bat (script: "${tool 'BCBST_SonarQube'} begin /k:\"${sonarKey}\" /n:\"${sonarKey}\" /v:\"${ver}\" /d:\"sonar.cs.opencover.reportsPaths=${loadDir}/build-results/opencover-coverage.xml\" /d:\"sonar.cs.vstest.reportsPaths=${loadDir}/build-results/*.trx\" /d:\"sonar.verbose=true\" /d:\"sonar.scm.disabled=${disableSCM}\" /d:\"sonar.cs.nunit.reportsPaths=${loadDir}/build-results/nunit-results.xml\" /d:\"sonar.c.file.suffixes=-\" /d:\"sonar.cpp.file.suffixes=-\" /d:\"sonar.obj.file.suffixes=-\"", returnStatus:true)
				} catch (Error e) {
					echo "Sonarqube analysis failed - ${e}"
				}	
	} //switch
	return sqState
}



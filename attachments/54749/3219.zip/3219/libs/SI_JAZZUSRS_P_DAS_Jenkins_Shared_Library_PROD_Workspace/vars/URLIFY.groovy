#!groovy
/**
 * URL-ify a string
 *
 * @param urlString the string to convert
 * @param extra whether or not to decode characters beyond just spaces and backslashes
 * @return String containing url encoded characters
 *
 */

String call(String urlString, boolean extra=false) {
 urlString = urlString?.replaceAll("\\\\","%5C");
    urlString = urlString?.replaceAll("\\<","%3C")
    urlString = urlString?.replaceAll("\\>","%3E")
    urlString = urlString?.replaceAll('"',"%22")
    urlString = urlString?.replaceAll("\\n","%0A")
    urlString = urlString?.replaceAll(/%0A$/,"\\n")
    urlString = urlString?.replaceAll("\\|","%7C")
    urlString = urlString?.replaceAll("\\'","%27")
if (extra == true) {
    urlString = urlString?.replaceAll("/","%2F")
    urlString = urlString?.replaceAll("=","%3D")
}
def newString = urlString?.replaceAll(" ",'%20');

//if (IsDebug()) {echo "urlified string is ${newString}"}

return newString;
}

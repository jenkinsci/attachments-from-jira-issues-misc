#!/usr/bin/env groovy
// 198354
/**
 *
 * @param buildDefId the name of the build definition ID
 *
 * @return String The uuid of the build definition
*/
String call(def buildDefId = "") {
    echo "DSL->Get_Build_Definition_UUID()"
    def uuid=""
    if (fileExists("das/uuid.txt")) {
        uuid = readFile("das/uuid.txt")
        fileOperations([fileDeleteOperation(excludes: '', includes: 'das/uuid.txt')])
        if (IsDebug()) {echo "Get_Build_Definition_UUID-> ${buildDefId} = ${uuid}"}
    }
    return uuid
}
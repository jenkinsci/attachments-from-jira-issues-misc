/** Acquires the response the contains the access and secret key for the SDM API
*
*	@param sdmAcct The Jenkins credential ID to lookup user/pass
*	@param sdmApi The base sdm api url/path
*
*	@return accessXML The response from the rest access request
*/

def call(String sdmAcct){
	echo "DJSL->Get_SDM_API_Access(String sdmAcct)"
	def sdmApi = (sdmAcct.equalsIgnoreCase('SI_DASSdm_P')) ? "http://sdmws.bcbst.com:8050/caisd-rest/rest_access" : "http://sdmtest.bcbst.com:8050/caisd-rest/rest_access"
	def accessXML = null;
	try{
		withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:sdmAcct, usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
		def encodedAuth = "$USERNAME:$PASSWORD"
		encodedAuth = encodedAuth.bytes.encodeBase64().toString()
		encodedAuth = "SDM " + encodedAuth
		accessXML = httpRequest httpMode:'POST', url: "${sdmApi}",requestBody:"<rest_access></rest_access>" ,customHeaders: [[name: "Authorization", value: encodedAuth],[name: "Content-Type", value: "application/xml"],[name:"Cache-Control",value:"no-cache"], [name:"x-obj-attrs", value:"access_key,secret_key,content-type,date"]]
    }
	
	}catch(Exception ex){
		echo ex.getMessage()
	}
	
	return accessXML.content
}
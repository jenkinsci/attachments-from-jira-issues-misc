#!/usr/bin/env groovy
// 176851

/**
 * prepare results file for performance testing.
 * 
 * @param environmentNm - environment name
 * @param resultsFile - name and path of results file
 * @param apps - apps to be tested
 * @return name and path of resultsFile
 *
 */
 
def call(String environmentNm, String resultsFile, String apps) {
    echo "DSL->Create_PT_Results_File()"
    fileOperations([
        fileCreateOperation(
            fileContent: """<pre><p><h2 style="color:#204f66">------------------------ Performance Smoke Test Results  ------------------------</h2><h3></p><ul style="list-style-type:square"><li Style="color:#0000ff"><b>Applications Tested: ${apps} </b></li><li Style="color:#138D75"><b>Environment: ${environmentNm} </b></li><li Style="color:#ffa500"><b>Date/Time: $BUILD_TIMESTAMP </b></li></ul><p></h3><h3 style="color:#204f66">-------------------------------------------------------------------------------------------------------------</h3></p><h3>Detailed performance smoke test results per application is listed below: </h3></pre>""", 
            fileName: "${resultsFile}"
        )
    ])
    return resultsFile
}




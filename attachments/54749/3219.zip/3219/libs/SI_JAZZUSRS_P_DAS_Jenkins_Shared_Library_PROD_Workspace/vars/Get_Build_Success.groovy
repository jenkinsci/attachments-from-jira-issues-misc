#!/usr/bin/env groovy
// 176851

/**
 * 
 * @param buildDefId the current build definition id
 * @param printOut whether to show debug stuff 
 *  
 * @return projectArea 	[Float] - success rate
 *
 */
 
def call(def buildDefId, def printOut="false") {
//	try {
//		steps.echo "Build Definition id is ${buildDefinitionId}"
        if (IsDebug()) echo "DSL->Get_Build_Success()"
		steps.httpRequest authentication: 'RTC', ignoreSslErrors: true, quiet: !printOut, outputFile: "times_${buildDefinitionId}.log", responseHandle: 'NONE', url: 'https://rtcccm.bcbst.com/ccm/rpt/repository/build?fields=build/buildResult[buildDefinition/id='+buildDefId+'%20and%20buildState=COMPLETED]/(buildStatus)'
		def outputH = steps.readFile "times_${buildDefId}.log"
//		echo outputH
		def build = new XmlSlurper().parseText(outputH)
		def scount=0
		def count=0
		def pct=0
		build.buildResult.each { buildResult->
			buildResult.buildStatus.each { stat ->
				if (stat.text()=="OK") {
					scount++
				}
				count++
			}
		}
		echo "total = ${count}, passed= ${scount}"
		pct = scount.div(count)*100;
		echo "Success rate is ${pct} percent"
		return pct;
//	} catch (error) {
//		return -1
//	} 
}




#!/usr/bin/env groovy
// 176851

/**
 * 
 *  
 *
 */
void call() {
    echo "DSL->NPM_Coverage()"
	try {
		println "Running code coverage ---> 'npm run coverage'"
		bat "npm run coverage"
	} catch(e) {
		echo "encountered an error during coverage testing"
	}
}



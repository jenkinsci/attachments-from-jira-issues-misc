def call(def failedTests){
	echo "DJSL-> Create_Request_Incident(def failedTests)"
	try{
		
		if (params.incidentCreation == true && ((jenkinsEnvironment.equalsIgnoreCase('PROD') && appEnvironment.equalsIgnoreCase('PROD')) || (jenkinsEnvironment.equalsIgnoreCase('TEST') && appEnvironment.equalsIgnoreCase('NONPROD')))) {
			def sdmApi = (appEnvironment.equalsIgnoreCase('PROD') && jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "http://sdmws.bcbst.com:8050/caisd-rest/in" : "http://sdmtest.bcbst.com:8050/caisd-rest/in"
			def sdmAcct = (appEnvironment.equalsIgnoreCase('PROD') && jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "SI_DASSdm_P" : "SI_DASSdm_T"
			def accessXML = Get_SDM_API_Access(sdmAcct)
			echo accessXML
			accessObj = new XmlParser().parseText(accessXML)
			def access = accessObj.access_key.text()
			descriptionString = "Tests in request at ${failedTests.applications.toString()} has ${failedTests.failures.size()} failures. See Activity Log for more detail."
					incidentXML = "<in><customer COMMON_NAME=\"System_Delivery_Automation_Services\"/><description>${descriptionString}</description><group COMMON_NAME=\"ITOC-IT OPERATIONS CENTER\"/><affected_resource COMMON_NAME=\"Non-CI\"/><zinquiry_type COMMON_NAME=\"Automated Alert\"/><affected_resource COMMON_NAME=\"Non-CI\"/><category COMMON_NAME=\"Software.Performance\"/><requested_by COMMON_NAME=\"System_Delivery_Automation_Services\"/></in>"
					if (IsDebug()){
						echo "incidentXML : ${incidentXML}"
					}
					response = httpRequest httpMode:'POST', url: "${sdmApi}", requestBody: incidentXML, customHeaders: [[name: "Content-Type", value: "application/xml"],[name:"Cache-Control",value:"no-cache"], [name:"x-obj-attrs", value:"ref_num"],[name: "X-AccessKey", value: access]]
					if (IsDebug()) {
						echo "Incident creation http response: ${response.content}"
					} 
					def createdIncidentXML = new XmlParser().parseText(response.content)
					failedTests.failures.each {
							Create_Incident_Comment(createdIncidentXML.attributes()['REL_ATTR'].toString(), appEnvironment, access, "${it.toString()}")
						
					}
				
			}
	} catch (ex){
		echo ex
	}

}
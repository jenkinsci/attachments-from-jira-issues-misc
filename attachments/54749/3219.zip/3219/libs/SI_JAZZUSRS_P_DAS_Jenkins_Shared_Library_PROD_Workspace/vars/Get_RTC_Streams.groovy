#!/usr/bin/env groovy
// 176851

/**
 *  
 * @param repoURL				[String] (required) The repository URL to run the API call against
 *
 * @return uuidListStream 		[String] - A list of UUID's for streams in RTC
 *
 * @return nameListStream 		[String] - A list of names for streams in RTC
 *
 * @return uuidListProjectArea 	[String] - A list of UUID's for project areas, indicating which project a stream belongs to
 *
 * @return nameListProjectArea 	[String] - A list of names for project areas, indicating which project a stream belongs to
 *
 * @return isArchived 			[String] - Value indicating if a stream belongs to an archived project area
 *
 */
 

def call(String repoURL) {
	echo "Fetching stream list from RTC..."
	httpRequest authentication: 'RTC', ignoreSslErrors: true, outputFile: 'output.log', responseHandle: 'NONE', url: repoURL + '/rpt/repository/scm?fields=workspace%2F%28workspace%5Bstream%3Dtrue%5D%2F%28reportableUrl%7CitemId%7Cname%7Cstream%7C%28projectArea%2F%28itemId%7Carchived%7Cname%29%29%29%29&size=100000'
	def outputH = steps.readFile "output.log"
	def rootNode = new XmlSlurper()
	def uuidListStream = ""
	def uuidListProjectArea = ""
	def nameListStream = ""
	def nameListProjectArea = ""
	def isArchived = ""
	
	rootNode.setFeature("http://apache.org/xml/features/disallow-doctype-decl", false) 
	rootNode = rootNode.parseText(outputH)
	rootNode.workspace.eachWithIndex { workspace , i -> 
		uuidListStream += workspace.itemId.text() + '\n'
		nameListStream += workspace.name.text() + '\n'
		uuidListProjectArea += workspace.projectArea.itemId.text() + '\n'
		nameListProjectArea += workspace.projectArea.name.text() + '\n'
		isArchived += workspace.projectArea.archived.text() + '\n'
	}
	uuidListStream = uuidListStream.trim()
	uuidListProjectArea = uuidListProjectArea.trim()
	nameListStream = nameListStream.trim()
	nameListProjectArea = nameListProjectArea.trim()
	isArchived = isArchived.trim()
	return [ uuidListStream, nameListStream, uuidListProjectArea, nameListProjectArea, isArchived ]

}
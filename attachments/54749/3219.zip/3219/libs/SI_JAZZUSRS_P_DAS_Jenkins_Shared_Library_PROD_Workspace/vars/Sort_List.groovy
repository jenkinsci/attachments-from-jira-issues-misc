#!/usr/bin/env groovy
import com.cloudbees.groovy.cps.NonCPS

// 176851

/**
 * Provide a non-CPS solution to sorting lists (without this, produces class mismatch)
 *
 *@param list  an unsorted list
 *
 *@return a sorted list
 */
@NonCPS 
String call(def list= []) {
    echo "DSL->Sort_List"
	return list.sort{it};
}




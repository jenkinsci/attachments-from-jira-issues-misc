#!groovy
/**
*Sends an email with Performance report.
*
* @param emailContent - the content of the email
* @param environmentName - the environment being tested
* @param emailTo - the email recipients
*/

void call(String emailContent,String environmentName,String emailTo){
    env.PerformanceReport = emailContent
    Send_Email_Results(emailTo, "Performance Smoke Test Results -  ${environmentName} - (Date:$BUILD_TIMESTAMP)",
                        "**/PerformanceReports_${BUILD_TIMESTAMP}.zip",false,"jenkins-perf.template")
}
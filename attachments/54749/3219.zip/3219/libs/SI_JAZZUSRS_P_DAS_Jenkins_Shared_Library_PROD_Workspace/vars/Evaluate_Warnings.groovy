#!/usr/bin/env groovy
// 176851

/**
 * Evaluate static log analysis
 * 
 *  @param workingDir the current working directory
 *  @param buildType the type of build to evaluate
 *  @param personal whether or not this is a personal build
 * 
 */
 
void call(def workingDir,def buildType="msbuild", def personal="false") {
    echo "DSL->Evaluate_Warnings()"
	// initiate SonarQube evaluation
	def warningString = ""
    echo "personal build is set to ${personal}"
	if (personal != "true") {
		def readContent = ""
			configFileProvider(
				[configFile(fileId: 'warningtemplate', variable: 'WARNINGTEMPLATE')]) {
					readContent = readFile "${WARNINGTEMPLATE}"
		} //configFileProvider
		writeFile file:"${workingDir}/static-report-${buildType}.htm", text:readContent
                echo "Enter get warning data"
				def jsonData = Get_Warning_Data(buildType)
                println "size of json data is "+jsonData.size()
                echo jsonData.toString()
				if (jsonData.size() <1) {
					echo "WARNING: Jenkins log review data not found, exiting with error!"
					readContent = readFile "${workingDir}/static-report-${buildType}.htm"
					writeFile file: "${workingDir}/static-report-${buildType}.htm", text: readContent+"WARNING: log review data not found, exiting with error!\n"
				} else {
					def rating = ['0','<span style="color:green"><b>A</b></span>',
								'<span style="color:#00FF82"><b>B</b></span>',
								'<span style="color:#FFD000"><b>C</b></span>',
								'<span style="color:#FF7800"><b>D</b></span>',
								'<span style="color:red"><b>E</b></span>']
					def metricString=""							
					jsonData.issues.each { metricPos->
						String baseName = metricPos.baseName
						String category = metricPos.category
						String lineStart = metricPos.lineStart
						String fileName = metricPos.fileName
						String message = metricPos.message+metricPos.description
						String severity = metricPos.severity
						warningString+="<TR><TD>" + baseName + "</TD><TD>" + category + "</TD><TD>" + lineStart + "</TD><TD>" + fileName + "</TD><TD>" + message + "</TD><TD>" + severity + "</TD></TR>\n"
					} //each measurement
					readContent = readFile "${workingDir}/static-report-${buildType}.htm"
					writeFile file: "${workingDir}/static-report-${buildType}.htm", text: readContent+warningString
 				} //if
				echo "Generated log analysis report..."
	} else {
        echo "skipping warnings evaluation - this is a personal build"
    }
	
} //function


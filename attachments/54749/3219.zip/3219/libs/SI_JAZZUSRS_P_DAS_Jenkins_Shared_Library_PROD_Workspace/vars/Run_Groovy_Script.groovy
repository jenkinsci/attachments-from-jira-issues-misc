/** 
 * Run Groovy Script 
 * Runs non-Jenkins groovy script
 * 
 * @param groovyFile the name of the script
 * @param classPath class path to include
 * @param params commands to send the groovy script
 * @param showOutput if true, show debug output
 * @param fast If true, run in background
 * 
 * @return output of command
 */
def call(def groovyFile, def params="", def showOutput=false, def fast=true) {
        try {
            if (IsDebug()) echo "DSL->Run_Groovy_Script(${groovyFile})"
            // whether to run fast or not (fast - in background so you don't notice it loading classes)
            fastPrefix = (fast == true)? ((env.NODE_LABELS.contains("aix"))? " &":"START /B "):""
            // check for the groovy native executable
            def groovyPath = tool name:'groovy-2.4.16'
            def classPath = tool name:'build engine', type: 'com.ibm.team.build.internal.hjplugin.RTCBuildToolInstallation'
            def exists = fileExists groovyPath
            if (IsDebug()) println "Does ${groovyPath} exist? "+ exists
            // if executable doesn't exist, settle for 2nd best, in ucd agent path
            if (!exists) {
                echo "Could not find groovy.exe - using groovy.bat in slow verbose mode"
                groovyPath = tool name: 'groovy-2.4.15'
                fastPrefix = ""
                showOutput = true
            }
            echo "using groovy path ${groovyPath}"
            def outPut = ""
            // do not show output of command
            if (env.NODE_LABELS.contains("aix")) {
                if(showOutput == false) {
                    if (classPath=="" || classPath == null) {
                        outPut = sh returnStdout: true, script:"${groovyPath} ${groovyFile} ${params}${fastPrefix}"
                    } else {
                        outPut = sh returnStdout: true, script: "${groovyPath} -cp \"${classPath}/*\" ${groovyFile} ${params}${fastPrefix}"
                    }
                    return outPut
                // show output of command
                } else {
                    if (classPath=="" || classPath == null) {
                        outPut = sh script:"${groovyPath} ${groovyFile} ${params}${fastPrefix}"
                    } else {
                        outPut = sh script: "${groovyPath} -cp \"${classPath}/*\" ${groovyFile} ${params}${fastPrefix}"
                    }
                    return outPut
    
                } // check showOutput
    
            } else {
                if(showOutput == false) {
                    if (classPath=="" || classPath == null) {
                        outPut = bat returnStdout: true, script:"${fastPrefix}${groovyPath} ${groovyFile} ${params}"
                    } else {
                        outPut = bat returnStdout: true, script: "${fastPrefix}${groovyPath} -cp \"${classPath}/*\" ${groovyFile} ${params}" 
                    }
                    return outPut
                // show output of command
                } else {
                    if (classPath=="" || classPath == null) {
                        outPut = bat script:"${fastPrefix}${groovyPath} ${groovyFile} ${params}"
                    } else {
                        outPut = bat script: "${fastPrefix}${groovyPath} -cp \"${classPath}/*\" ${groovyFile} ${params}"
                    }
                    return outPut
                } // check showOutput
            }
        } catch (e) {
            echo "Error initializing jazz api stuff - ${e.message}"
        }
}
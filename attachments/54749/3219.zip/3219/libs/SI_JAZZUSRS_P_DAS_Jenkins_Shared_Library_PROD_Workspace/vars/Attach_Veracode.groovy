/**
 * Attach Veracode results to work item
 *
 * @param currentLog the contents of the log
 *
 * @return veracode report URL
 *
 */


def call(def buildid, def appid, detailed="true", def projarea, def workit, def reportType="SAST_",def external="") {
    echo "DSL->Attach_Veracode()"
    // The sandbox_id of the new sandbox is "2664265"
    // The build_id of the new build is "9336401"
    vcreport = "https://analysiscenter.veracode.com/auth/index.jsp#ViewReportsDetailedReport:73233:${appid}:${buildid}"
    echo "The build number is ${buildid}, the app id is ${appid}"
    def vcReportFile = Retrieve_VC_PDF(buildid,detailed,reportType,external)
    if (workit != "000000") {
        def result = Attach_To_Work_Item(projarea, workit, vcReportFile)
        if (workit == "") {
            env.workItem = result
        }
        if (IsDebug()) echo "Work items passed to Attach_Veracode: ${result}"
    }
    return vcreport
}
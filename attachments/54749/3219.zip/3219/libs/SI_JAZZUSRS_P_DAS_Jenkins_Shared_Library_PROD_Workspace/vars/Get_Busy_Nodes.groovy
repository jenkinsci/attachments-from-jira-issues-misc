#!/usr/bin/env groovy
/**
 * Get the number of slots active on a server node.
 *  
 * @param nodename the server name of the node
 * @param multiThread a flag that determines whether multithread is true
 * 
 * @return the number of busy threads on the node
 */
int call(def nodename, def multiThread) {

	echo "DSL-> Get_Busy_Nodes()"
    
    String status = 'ready';
    if (jenkinsEnvironment == "PROD") {
        jauth = "SI_JENKINS_P_API"
        jurl = "jenkins"
    } else {
        jauth="SI_JENKINS_T_API"
        jurl="jenkins-test"
    }
    def response = httpRequest authentication: jauth, ignoreSslErrors: true, url: "https://${jurl}.bcbst.com/computer/api/json?pretty=true"
    if (IsDebug()) {echo "Response: "+ response.getContent()}
    def jsonNodes = readJSON text:response.getContent()
    def busyNum = jsonNodes['busyExecutors']
    
	if (multiThread!="true") {
		busyNum = -1
	}
	if (IsDebug()) {
		echo "Busy nodes count is ${busyNum}"
	}
	return busyNum	
}




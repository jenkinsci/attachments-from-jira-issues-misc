#!/usr/bin/env groovy
// 176851

import groovy.time.*

/**
 * Get a list of changes since last build.
 * 
 *  
 *  @param buildDefId the build definition id 
 *  @param buildUUID the uuid of the build result
 *  @param  textValue the version to include in the snapshot and build label
 *  @param external whether the build is external (personal or external build)
 *  @param  fast boolean to indicate fast groovy mode
 *  
 * @return changeList 	[String] - A list of changes in html format (string)
 *
 */
 
def call(def buildUUID,def external="false",def fast=false) {
    println "Jazz configuration..."
    try {
            if (env.personalBuild=="true") external = "true"
            withCredentials([usernamePassword(credentialsId:'SI_JAZZUSRS_P', passwordVariable: 'pwd', usernameVariable:'uid')]) {
                env.RTC_USER_ID='SI_JAZZUSRS_P'
                env.RTC_PASSWORD=pwd
                Run_Groovy_Script("das/Get_Relevant_Work_Items.groovy","\"%uid%\" \"%pwd%\" \"${buildUUID}\"",true,fast)
            }
    } catch (e) {
            echo "Could not run script: ${e.message}"
    }
//	return changeList 
}




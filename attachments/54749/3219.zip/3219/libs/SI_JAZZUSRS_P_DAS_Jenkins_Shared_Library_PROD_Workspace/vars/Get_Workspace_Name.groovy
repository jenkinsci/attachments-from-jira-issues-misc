#!/usr/bin/env groovy
// 176851

/**
 * Get a build workspace name from UUID
 * 
 * @param uuidNum the workspace UUID
 *  
 * @return String The name of the current Build Workspace
 *
 */
 
String call(def uuidNum) {
	try {
        echo "DSL->Get_Workspace_Name()"
		httpRequest authentication: 'RTC', ignoreSslErrors: true, outputFile: 'output.log', responseHandle: 'NONE', quiet: true, url: 'https://rtcccm.bcbst.com/ccm/rpt/repository/scm?fields=workspace/workspace[itemId='+uuidNum+']/name'
		def outputH = readFile "output.log"
		def rootNode = new XmlSlurper().parseText(outputH)
		return rootNode.toString()
	} catch (error) {
		return "Undefined"
	}
}




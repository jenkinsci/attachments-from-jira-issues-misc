#!/usr/bin/env groovy
// 176851

/**
 * Perform a Maven Build using the build definition parameters
 * 
 * @param workingDir(required) the current working directory
 * @param pomXML(required) the name of the pom file
 * @param mvnCmdLine(required) the rest of the mvn command line
 * @param sqEnv(required) The Jenkins sonarqube environment label (we use test and prod labels)
 * @param disableSonar(required) whether to skip sonar in the maven build
 *
 */
 
void call(def workingDir, def pomXml, def mvnCmdLine,def sqEnv="BCBST Sonarqube",int busy=-1,def disableSonar=false) {
 // *** THE BUILD ***
    echo "DSL->Perform_Maven_Build()"
	def sonarString= (disableSonar == true)?"":"sonar:sonar"
	def parallel = ""
    def thisMaven = tool name:'RTC Maven', type: 'maven'
    println "Maven command line path " + thisMaven
	mvnCmdLine = mvnCmdLine - "deploy"
	echo "Maven command line is ${mvnCmdLine}"
	if (busy <3 && busy >=0) {
		parallel = "-T 2"
		echo "Multithread set to true and ${busy} nodes busy. Running the build in 2 parallel threads..." 
	}
//	def encryptedPW = Get_Encrypted_PW()
//	withEnv(["encryptedPass=${encryptedPW}"]) {

    configFileProvider(
    //Uses SI_Jenkins_Maven files as the settings.xml for Maven. This file is defined in Jenkins.
    [configFile(fileId: 'SI_Jenkins_Maven', variable: 'MAVEN_SETTINGS')]) {
        withCredentials([usernamePassword(credentialsId: 'SI_JAZZUSRS_P', passwordVariable: 'password', usernameVariable: 'username')]) {
            withSonarQubeEnv(sqEnv) {
                bat "${thisMaven}/bin/mvn -s ${MAVEN_SETTINGS} -f${workingDir}/${pomXml} -Drepo.pwd=%password% ${parallel} ${mvnCmdLine} ${sonarString}"
            }
        }
    }
}




#!/usr/bin/env groovy
// 176851

/**
 * Remove the .jazz5 directory.
 *  
 *
 */
 
void call() {
        if (IsDebug()) echo "DSL->Remove_Jazz()"
//		if (jenkinsEnvironment != "TEST") {
			echo "Deleting .jazz5 if it's there"
			dir(path: "./.jazz5") {
				deleteDir()
			}
//		}
	}
#!/usr/bin/env groovy
// 176851

/**
 * Main Sonarqube creation method.
 * 
 *  @param workingDir the current working directory
 *  @param isDN the domain name component of the key
 *  @param isTN the team name component of the key
 *  @param isAN the app name component of the key
 *  @param personal whether or not a personal build is being run
 * 
 */
 
void call(def workingDir, def isDN, def isTN, def isAN,def personal="false") {
	String methodName = 'DJSL -> Evaluate_SQ_Results()';
	echo methodName
	try{
	// initiate SonarQube evaluation
	if (personal != "true") {
		timeout(time: 5, unit: 'MINUTES') {
			def qg = waitForQualityGate abortPipeline: false
			if (qg.status == 'OK') {
				env.sqStatus="true"
				echo "Sonarqube passed"
			} else {
				env.sqStatus="false"
				echo "Sonarqube failed"
			} // if
			def readContent = ""
			configFileProvider(
				[configFile(fileId: 'sqtemplate', variable: 'SQTEMPLATE')]) {
					readContent = readFile "${SQTEMPLATE}"
			} //configFileProvider
			writeFile file:"${workingDir}/sonarqube-report.htm", text:readContent
			def jsonData = Get_SQ_Report_Data("${isDN}_${isTN}_${isAN}")
			def qualityGateName = Get_SQ_Quality_Gate("${isDN}_${isTN}_${isAN}")
			if (jsonData.size() == 0) {
				echo "WARNING: Metrics data not found, exiting with error!"
				readContent = readFile "${workingDir}/sonarqube-report.htm"
				writeFile file: "${workingDir}/sonarqube-report.htm", text: readContent+"WARNING: Metrics data not found, exiting with error!\n"
			} else {
				def rating = ['0','<span style="color:green"><b>A</b></span>',
							'<span style="color:#00FF82"><b>B</b></span>',
							'<span style="color:#FFD000"><b>C</b></span>',
							'<span style="color:#FF7800"><b>D</b></span>',
							'<span style="color:red"><b>E</b></span>']
				def metricString=""		
                def metricHashArray= [[name:"NAME", value:"VALUE"]]					
				jsonData.component.measures.each { metricPos->
					String metric = metricPos.metric
					metricUpper = metric.toUpperCase()
					metricValue = Analyze_Sonar_Metric(metricPos, metric)
                    metricHashArray.add([name:metricUpper, value:metricValue])
				}
                    //sort list of maps
                    metricHashArray = Sort_List_of_Map(metricHashArray)
                    metricHashArray.each { metricPos->
                    if (IsDebug()) { echo "setting SQ_METRIC_${metricPos.name} to \"${metricPos.value}\""}
                    evaluate("env.SQ_METRIC_${metricPos.name}='"+"${metricPos.value}"+"'")	
                    if (metricPos.name=="NAME") {
//                        metricString+="<TR><TD>" + metricPos.name + "</TD><TD>" + metricPos.value + "</TD></TR>\n"
                        
                    } else {			
                        metricString+="<TR><TD>SQ_METRIC_" + metricPos.name + "</TD><TD>" + metricPos.value + "</TD></TR>\n"
                    }
				} //each measurement
				readContent = readFile "${workingDir}/sonarqube-report.htm"
				writeFile file: "${workingDir}/sonarqube-report.htm", text: readContent+metricString
			} //if
			def qgState = (qg.status=="OK")?'RESULT: <span style="color:green">PASSED</span>':'<span style="color:red">RESULT: FAILED</span>'
            env.SQ_QUALITY_GATE_STATE=qgState
            env.qualityGate = qualityGateName.toString()
			readContent = readFile "${workingDir}/sonarqube-report.htm"
			writeFile file: "${workingDir}/sonarqube-report.htm", text: readContent+"<TR><TD>SQ_QUALITY_GATE_STATE</TD><TD>" + qgState+"</TD></TR></TABLE></BODY>\n</HTML>"
			echo "Generated SonarQube report..."
		} //timeout         		
	} //if
	}
	catch(Exception e){
	echo "Exception caught in Evaluate_SQ_Results:" + e 
	}
} //function

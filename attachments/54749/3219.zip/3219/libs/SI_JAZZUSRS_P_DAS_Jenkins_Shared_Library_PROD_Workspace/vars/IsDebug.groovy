#!/usr/bin/env groovy
// 176851

/**
 * Determine if pipeline is in debug mode
 *  
 * @return boolean - whether debug is set to true
 *
 */
 
boolean call() {
	return ("${env.debug}"?.equalsIgnoreCase("true"))
}




#!/usr/bin/env groovy
// 208844

/**
 *
 * @param streamID				[String] (required) The UUID of a stream to exclude 
 *
 * @return fMatch				[Boolean] - Returns "true" is a stream is in the exception list, "false" otherwise
 *
 */
 
def call(String streamID){
	def excl = readFile "streamList.txt"
	def fTemp = excl.split('\n')
	def fMatch = false
	
	fTemp.each {
		if (it == streamID) {
			fMatch = true
		}
	}
	
	return fMatch
	
}

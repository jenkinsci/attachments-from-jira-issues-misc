/** 
 * Get Unit test statistics from Jenkins
 * 
 * @return a map of the test suites
 * 
 */


import hudson.AbortException
import java.lang.IllegalStateException
def call () {
    def cases = []
    try {
        echo "Pulling Detailed Test Results into file"
        def userNm= (jenkinsEnvironment=="TEST")?"SI_JENKINS_T_API":"SI_JENKINS_P_API"
        httpRequest authentication: userNm, outputFile: 'junitdetail.json',
            url: "${BUILD_URL}testReport/api/json?pretty=true"
        def junitjson = readJSON file: 'junitdetail.json'
        env.jDuration =  junitjson.duration
        env.jPassCount = junitjson.passCount
        env.jFailCount = junitjson.failCount
        env.jSkipCount = junitjson.skipCount
        env.jTotalCount = (jSkipCount.toInteger()+jPassCount.toInteger()+jFailCount.toInteger()).toString()
        
        env.junitName = "{root}"
        echo junitjson.suites[0].cases.toString()
        junitjson.suites.each() { suite ->
            if (IsDebug()) println "suite ${suite.name}"
            suite.cases.each() { jcase ->
                if (IsDebug()) echo "case ${jcase.name} ${jcase.status}"
                if (jcase.status == "FAILED" || jcase.status == "FIXED" || jcase.status == "REGRESSION") {
                    echo "${suite.name} - ${jcase.name}: ${jcase.status} (Age: ${jcase.age})"
//                    def jcasestatus = jcase.status
                    def jcasestatus = "<span style='color:green'>${jcase.status}</span>"
                    def jcasetd = "test test-fixed"
                    if (jcase.status == "FAILED" || jcase.status == "REGRESSION") {
                          jcasestatus = "<span style='color:red'>${jcase.status}</span>"
                          jcasetd = "test test-failed"
                    } 
                    cases.add("<tr><td class=\"${jcasetd}\" colspan=\"5\">${suite.name} - case <i>${jcase.name}</i>: ${jcasestatus} (Age: ${jcase.age})</td></tr>")
                }
            }
        }
        return cases
    } catch(IllegalStateException ae) {
        echo "Could not find junit results"
        return []
    } catch (e) {
        echo e.message
        return []
    }
    
}
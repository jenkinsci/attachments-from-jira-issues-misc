#!/usr/bin/env groovy
// 176851

/**
 * Replace the current link to Jenkins with a link to the RTC build page.
 * 
 * @param versionNM	The version number in UCD for the component artifacts
 * @param linkName link to remove
 * @param rtcLinkName The new link name
 * @param ucdComponent UCD component name
 * @param resultUUID the RTC build result UUID to use in the link
 * @param testUCD whether to use UCD test
 * @return String - RTC Link name
 *
 */
 
String call(String versionNM, def linkName="link", String rtcLinkName="rtc link",def ucdComponent,def resultUUID, def testUCD="true") {
	String methodName = 'DSL -> Replacing RTC Link'
    beQuiet = (!IsDebug())
	echo methodName
	if ("${testUCD}"== "true"){
		httpRequest httpMode:'DELETE', authentication: 'UCDImport', ignoreSslErrors:true, quiet:beQuiet, url: URLIFY("https://ucd-test.bcbst.com/cli/version/removeLink?component=${ucdComponent}&version=${versionNM}&linkName=${linkName}")
		httpRequest httpMode:'PUT', authentication: 'UCDImport', ignoreSslErrors:true, quiet:beQuiet, url: URLIFY("https://ucd-test.bcbst.com/cli/version/addLink?component=${ucdComponent}&version=${versionNM}&linkName=${rtcLinkName}&link=${repositoryAddress}resource/itemOid/com.ibm.team.build.BuildResult/${resultUUID}")
		
	} else {
		httpRequest httpMode:'DELETE', authentication: 'UCDImport', ignoreSslErrors:true, quiet:beQuiet, url: URLIFY("https://ucd.bcbst.com/cli/version/removeLink?component=${ucdComponent}&version=${versionNM}&linkName=${linkName}")
		httpRequest httpMode:'PUT', authentication: 'UCDImport', quiet:beQuiet, ignoreSslErrors:true, url: URLIFY("https://ucd.bcbst.com/cli/version/addLink?component=${ucdComponent}&version=${versionNM}&linkName=${rtcLinkName}&link=${repositoryAddress}resource/itemOid/com.ibm.team.build.BuildResult/${resultUUID}")
	}
	return rtcLinkName;
}




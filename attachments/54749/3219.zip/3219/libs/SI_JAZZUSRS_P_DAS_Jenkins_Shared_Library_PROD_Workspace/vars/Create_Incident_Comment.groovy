/** Adds a comment to an incident log
 * @param	[Integer] incidentId
 * @param	[Integer] accessKey
 * @param	[String] logComment
 */

 def call(def incidentCRId, def envName, def accessKey, def logComment) {
	 echo "DJSL -> Create_Incident_Comment(def incidentId, def accessKey, def logComment)"
	 def sdmEnv = (envName.equalsIgnoreCase('PROD') && jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "http://sdmws.bcbst.com:8050/caisd-rest/alg":"http://sdmtest.bcbst.com:8050/caisd-rest/alg"
	 def sdmAcct = (envName.equalsIgnoreCase('PROD') && jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "SI_DASSdm_P":"SI_DASSdm_T"
	 def response = null
	 try {
		 def commentXML = "<alg>" +
		 "<type REL_ATTR=\"LOG\"/>" +
		 "<call_req_id REL_ATTR=\"" + incidentCRId + "\"/>" +
		 "<description>" + logComment +"</description>" +
		 "</alg>";
		 if (IsDebug()) {
			 echo commentXML
		 }
		 response = httpRequest httpMode:'POST', url: "${sdmEnv}", requestBody: commentXML, customHeaders: [[name: "Content-Type", value: "application/xml"],[name:"Cache-Control",value:"no-cache"], [name:"x-obj-attrs", value:"ref_num"],[name: "X-AccessKey", value: accessKey]]
	 }catch(Exception ex) {
		 echo ex.getMessage()
	 }
 }
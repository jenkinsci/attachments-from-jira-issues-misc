#!/usr/bin/env groovy
// 208844

/**
 *
 * @param streamID				[String] (required) The UUID of a stream file which contains a list of files 
 *
 */
 
void call(String streamID){
    echo "DSL->Check_File_Exclusions()"
	def fName = streamID + ".txt"
	def fPath = pwd().toString() + "/" + fName.toString()
	def fContents = readFile fName
	def excl = readFile "exclList.txt"
	def fTemp = excl.split('\n')
	def fMatch = false
	def fHasExcl = false
	
	fTemp.each {
		if (it.startsWith('_')) {
			fMatch = false
		}
		if (fMatch) {
			fContents = fContents.replaceAll(it,"Excluded")
		}
		if (it == streamID) {
			echo "Stream contains exclusions"
			fMatch = true
			fHasExcl = true
		}
	}
	
	if (fHasExcl) {
		powershell "rm -fo ${fPath}"
		writeFile file: fName, text: fContents
	}
}

#!/usr/bin/env groovy

/******
*
* Set_SQL_Status: looks for SQL file extensions in the build. 
* 	Sets a UCD component version status of "SQL" or "Non SQL",
*	depending on whether any are found.
*
* @param componentName: the component to update
* @param versionNM: the version of the component to update
* @param testUCD: determines what UCD environment to send the request to
*
* @see also: Set_UCD_Status
*
*******/

void call(String componentName, String versionNM, def String testUCD="true"){
    echo "DSL->Set_SQL_Status()"
	def String[] sqlFileExtensions = ["sql"]
	def sqlFiles
	def sqlFound = false
	
	sqlFileExtensions.each{
		sqlFiles = Grab_Files(it)			//note: "it" is a keyword used in "each" iterations
		echo "SQL files found: " + sqlFiles.size().toString()
		if(sqlFiles != null || sqlFiles.size() > 0){
			sqlFound = true
		}
	}
	Set_UCD_Status(componentName, versionNM, (sqlFound? "SQL" : "Non%20SQL"), testUCD)
}
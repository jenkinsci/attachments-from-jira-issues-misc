#!/usr/bin/env groovy
// 176851

/**
 * Run an RTC build task on a file in the workspace.
 * 
 * @param fileIdentifier - the managed file name of the ant task file (xml format)
 * @param environmentVarList[] - the list of environment variables to include as tokens for the file
 * @credId - the credentials ID to run from in RTC
 * @return  the standard output
 */
 
def call(def fileName,def environmentVarList=[],def credId="SI_JAZZUSRS_P") {
	String methodName = 'DSL -> Run Ant Task from File'
    def repoAddress = "https://rtcccm.bcbst.com/ccm"
	echo methodName
	withAnt(installation: 'Anthill') {
		def buildtoolkitpath = /F:\ProgramFiles\IBM\RTC\jazz\buildsystem\buildtoolkit/
		echo "using credentials ${credId}" 
        try {
    		withCredentials([usernamePassword(credentialsId:credId, passwordVariable: 'password', usernameVariable: 'userName')]) {
                def varList = ["userId=${userName}","password=${password}", "repositoryAddress=${repoAddress}"]
                varList.addAll(environmentVarList)
                withEnv(environmentVarList) {
                    echo "running script"
                    def stdOut = bat script:"ant -f ${fileName} -lib ${buildtoolkitpath}", returnStatus:true
                    def antListing = readFile("${fileName}")
                    if (IsDebug()) {
                        echo "${antListing}"
                    } //if debug
                    return stdOut
                } //withEnv
            } //withCredentials
        } catch (e) {
            echo e.message
        }
	} //withAnt
}




#!/usr/bin/env groovy
// 176851

/**
 * Check for binaries, unauthorized scripts, and object directories in the source.
 *  
 * @param loadDir the current load directory 
 *  
 * @return Object a list of compiled/packaged files found in prebuild
 *
 */
 
def call(def loadDir="") {
    echo "DSL->Check_Load_Directory(${loadDir})"
    if (loadDir == "F:/Jazz/Applications" ||
        loadDir == "F:/Jazz/Applications/" ||
        loadDir == "F:\\Jazz\\Applications" ||
        loadDir == "F:\\Jazz\\Applications\\" ||
        loadDir == "F:/Jazz" ||
        loadDir == "F:/Jazz/" ||
        loadDir == "F:\\Jazz" ||
        loadDir =="F:\\Jazz\\" ) {
            throw new Exception("Cannot use base Jazz path as load directory! Failing")
    } else {
        echo "Base load directory is good."
        return 0
    }

}
	


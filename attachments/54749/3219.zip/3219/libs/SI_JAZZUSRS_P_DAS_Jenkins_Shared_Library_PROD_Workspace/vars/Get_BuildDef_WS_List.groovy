#!/usr/bin/env groovy
// 176851

/**
 * Get a list of all RTC build definitions with their build workspaces
 * 
 * 
 *  
 * @return HashList An array of hashes containing build def, ws
 *
 */
 
def call(def bdString="") {
    echo "DSL->Get_BuildDef_WS_List"
    try {    
        def bdArray = []
        def bdParse = bdString.split("\n")
        bdParse.each { 
            def bdRecord = it.split(',')
            def bdBDName = bdRecord[0]
            def bdWSName = bdRecord[1]
            def bdBDType = bdRecord[2]
            bdArray.add([name: bdBDName, ws: bdWSName.trim(), type: bdBDType])
        }
        if (IsDebug()) {
                    echo bdArray.toString()
            bdArray.each() { 
                    echo "name:${it.name}  ws: ${it.ws} type: ${it.type}"
            }
        }
        return bdArray
    } catch(e) {
        return "ERROR:"+e.message
    }
}




/** 
* Retrieves a PDF summary of veracode report
* 
* @param buildId - the build to be reported on
* @param detailed - true or false, whether or not the report should be detailed 
* 
* @return the filename of the veracode report
* 
**/
def call(String buildId, def detailed,type="SAST_",def external="") {
    reportType = (detailed=="true")?"detailed":"summary"
    isExternal = (external!="false" && external !="" && external != null)?"_${external}":""
    echo "DSL->Retrieve_VC_PDF(${buildId},${detailed})"
    def serviceAccount = (jenkinsEnvironment=="TEST")? "SI_JENKINS_T":"SI_JENKINS_P"
    try {
        withCredentials([usernamePassword(credentialsId: serviceAccount, passwordVariable: 'pd', usernameVariable: 'uid')]) {
            env.pd = URLIFY(pd)
            def httpcmd = "http --proxy=https:https://%uid%:%pwdConverted%@webproxy.bcbst.com:80 --auth-type=veracode_hmac -o ${type}${reportType}report.pdf \"https://analysiscenter.veracode.com/api/4.0/${reportType}reportpdf.do\" \"build_id==${buildId}\""
            def httpoutput = bat returnStdout:true, script:httpcmd
        echo httpoutput
    }
    return "${type}${reportType}${isExternal}report.pdf"
    } catch (e) {
        echo "ERROR: ${e.message}"
        return ""
    }
}
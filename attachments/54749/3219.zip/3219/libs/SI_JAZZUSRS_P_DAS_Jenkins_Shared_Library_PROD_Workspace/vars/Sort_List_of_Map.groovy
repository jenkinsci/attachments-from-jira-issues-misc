#!/usr/bin/env groovy
// 176851

/**
 * Provide a non-CPS solution to sorting lists of maps by name (without this, produces class mismatch)
 *
 *@param list  an unsorted list
 *
 *@return a sorted list
 */
@NonCPS 
def call(def list) {
	return list.sort{a,b -> a.name <=> b.name};
}




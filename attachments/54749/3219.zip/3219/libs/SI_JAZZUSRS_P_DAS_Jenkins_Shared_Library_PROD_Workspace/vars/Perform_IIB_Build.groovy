#!/usr/bin/env groovy
/**
 * Perform IIB Build
 */
void call(sqEnv="BCBST Sonarqube"){


//                    fileOperations([
 //                       fileCopyOperation(
   //                         excludes: '',
     //                       flattenFiles: false,
       //                     includes: "build.xml",
         //                   renameFiles: true,
           //                 sourceCaptureExpression: '',
             //               targetLocation: 'F:/Scripts/ant',
               //             targetNameExpression: "build.xml"
                 //       )
                   // ]){

// configFileProvider([configFile(fileId: 'ANT_IIB_BUILD_XML', targetLocation: 'F:/Scripts/ant/build.xml')]) {
//		
//		Run_Ant_Build_Task("ANT_IIB_BUILD_XML",[""])

//string(name:'dummy', value: "${index}")
//		build job: '../_Sean/Invoke_Ant', parameters: []
//		bat script:"F:\\ProgramFiles\\Apache\\Ant\\current\\bin\\ant.bat -file F:\\Scripts\\ant\\build.xml -lib F:\\ProgramFiles\\Apache\\Ant\\current\\lib -Dbuild.log.filepath='' && exit %%ERRORLEVEL%%"
//-------------------

def environmentVarList = []

withEnv(environmentVarList) {
	echo "Running a dope ANT script"
	def antStr = "F:\\ProgramFiles\\Apache\\Ant\\current\\bin\\ant.bat init -file F:\\Scripts\\ant\\build.xml "
	antStr += "-lib F:\\ProgramFiles\\IBM\\RTC\\jazz\\buildsystem\\buildtoolkit "
//---------
//Add property definitions here
	antStr += "-DbuildResultUUID=${buildResultUUID} "
	antStr += "-DRTC_PASSWORD_FILE=${RTC_PASSWORD_FILE} "
	antStr += "-DrepositoryAddress=${repositoryAddress} "
	antStr += "-DRTC_USERNAME=${RTC_USERNAME} "
	antStr += "-Dteam.scm.fetchDestination=${teamScmFetchDestination} " 
	antStr += "-DworkingDirectory=${workingDirectory} "
	antStr += "-DMQSICREATEBAR_PATH=${MQSICREATEBAR_PATH} "
	antStr += "-DworkingDirectory=${workingDirectory} "
	antStr += "-Dcomponent.type=${componentType} "
	antStr += "-Dcomponent.name=${componentName} "
	antStr += "-Dversioning.enabled=${versioningEnabled} "
	antStr += "-Dcomponent.version=${componentVersion} "
	antStr += "-DbuildLabel=${env.VERSION_NOM} "
//	antStr += "-Dcomponent.version='bobby' "
	
	
	
//---------
//But before here
	antStr += "-Dbuild.log.filepath='' && exit %%ERRORLEVEL%%"

	bat script: antStr
}

//-------------------
/*
//		def environmentVarList = ""
//withSonarQubeEnv(sqEnv) {
		withAnt(installation: 'Ant Current') {
		def buildtoolkitpath = /F:\ProgramFiles\IBM\RTC\jazz\buildsystem\buildtoolkit/
		echo "using credentials SI_JAZZUSRS_P" 
		withCredentials([usernamePassword(credentialsId:SI_JAZZUSRS_P, passwordVariable: 'password', usernameVariable: 'userName')]) {
			def varList = ["userId=${userName}","password=${password}"]
			varList.addAll(environmentVarList)
			withEnv(environmentVarList) {
					echo "running script"
                    def stdOut = ""
                    try {
                        stdout=bat script:"ant -f 'F:\\Scripts\\ant\\build.xml' -lib ${buildtoolkitpath} >ant.txt 2>&1" 
                    } catch(e) {
                    	echo "Exception caught in DSL -> Run Ant Task:"
                        echo e.message
                        def d=readFile "ant.txt"
                        dArray = d.split('\n')
                        throw new Exception(dArray[5])
                    }
                    def antListing = readFile("${RTCLink}")
					if (IsDebug()) {
						echo "${antListing}"
                        echo stdOut
					} //if debug
                    return stdOut
			} //withEnv
		} //withCredentials
	} //withAnt
//	}//withSonarQubeEnv
	*/
//---------------------------------------------------------------------------------

//	withSonarQubeEnv(sqEnv) {
//		echo "I am building a BAR file!"
	//	try{
//			def buildBar = bat(returnStdout: true, script:"cmd /c mqsicreatebar -data F:\\Jazz\\Applications\\DAS_IIB_TEST_SEAN -a REST_ProvDtls -version 1.3 -b F:\\Jazz\\Applications\\DAS_IIB_TEST_SEAN\\REST_ProvDtls_1.3\\REST_ProvDtls.bar -deployAsSource")
	//	}//catch(Exception e){
		//	echo "An error occurred."
		//	echo e.toString()
		//}
//	}
}
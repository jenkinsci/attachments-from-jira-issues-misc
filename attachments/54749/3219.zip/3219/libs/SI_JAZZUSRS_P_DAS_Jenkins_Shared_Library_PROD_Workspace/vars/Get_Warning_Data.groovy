#!groovy
/**
 * Get Warning data in JSON format.
 *
 * @param buildType the type of build
 * @return warningData [Object] - static warning data
 *
 */
import groovy.json.JsonSlurperClassic;


def call(def buildType="msbuild") {
echo "DSL->Get_Warning_Data()"

def jsonData;

// API URLS
String urlBase="$BUILD_URL";

// metrics api
String warningApiMetrics="/${buildType}/all/api/json?pretty=true"

// urls
String warningUrl = urlBase + warningApiMetrics

if (IsDebug()) {
	echo "warnings list URL is ${warningUrl}"
}

/**
 * START METRICS REQUEST
 */
try {
def authCred = (jenkinsEnvironment == "PROD")? "SI_JENKINS_P_API":"SI_JENKINS_T_API"
def response= httpRequest(httpMode:'GET', authentication: authCred, quiet: false, url: warningUrl)
def jsonText = response.content
if (IsDebug()) {
//	echo jsonText
    jsonData = readJSON(text: jsonText);
    return jsonData;
    }
} catch (e) {
    echo "was not able to catch data"
    return
}
}

// 176851

/**
 * Trigger a DVLP environment (smoke test) build
 * 
 * 
 * 
 * 
 */
 
def call() {
	echo "DSL->Trigger_DVLP()"
    echo "Enable Integration: ${env.enableIntegration}"
    echo "Enable DAST: ${env.veracodeDASTMode}"
    def jenkinsCred = (jenkinsEnvironment == "TEST")? "SI_JENKINS_T_API":"SI_JENKINS_P_API"
    if (env.veracodeDASTAdd == null) env.veracodeDASTAdd="false"
	if ((env.personalBuild != "true") && (env.enableIntegration?.equalsIgnoreCase("true") || env.veracodeDASTMode?.equalsIgnoreCase("true")) && (currentBuild.result != 'FAILURE')) {
        echo "Next environment triggered by script..."
		timeout(time: 1, unit: 'HOURS') {
			try {
				if ("${env.enableApproval}".equalsIgnoreCase("true")) {
					input id:'approval', message:'Approve delivery to Integration Testing?',ok:'Yes',submitter:"${env.approveList}"
				}
				def almPath = (env.almTestSetPath != null)? URLIFY(env.almTestSetPath):""
				if (IsDebug()) { echo "ALM Path is ${env.almPath}" }
				StringBuilder jenBuilder = new StringBuilder()
				jenBuilder << "${JENKINS_URL}/job/DVLP_Pipeline/buildWithParameters?token=771c755f82e8"
		        jenBuilder << "&ucdApplicationName=" << URLIFY(env.ucdApplicationName)
				jenBuilder << "&ucdApplicationProcessName=" << URLIFY(env.ucdApplicationProcessName)
				jenBuilder << "&ucdEnvironmentNameDVLP=" << URLIFY(env.ucdEnvironmentNameDVLP)
				jenBuilder << "&ucdEnvironmentNameTEST=" << URLIFY(env.ucdEnvironmentNameTEST)
				jenBuilder << "&ucdComponentName=" << URLIFY(env.ucdComponentName)
                jenBuilder << "&ucdDeliverSwitch=${env.ucdDeliverSwitch}"
                jenBuilder << "&ucdDeploySwitch=${env.ucdDeploySwitch}"
				jenBuilder << "&ucdVersion=${env.VERSION_NOM}"
				jenBuilder << "&buildDefinitionId=" << URLIFY(buildDefinitionId)
				jenBuilder << "&buildResultUUID=${buildResultUUID}"
				jenBuilder << "&loadDirectory=" <<  URLIFY(loadDirectory)
				jenBuilder << "&contactEmail=${env.contactEmail}"
				jenBuilder << "&buildRequesterUserId=${env.buildRequesterUserId}"
				jenBuilder << "&PROJECTAREA=${env.PROJECTAREA}"
				jenBuilder << "&buildEngineHostName=${env.buildEngineHostName}"
				jenBuilder << "&enableQADelivery=${env.enableQADelivery}"
                jenBuilder << "&veracode=${env.veracodeSASTMode}"
                jenBuilder << "&DAST=${env.veracodeDASTMode}"
                jenBuilder << "&veracodeApplicationName=${env.veracodeApp}"
                jenBuilder << "&veracodeDASTAdd=${env.veracodeDASTAdd}"
                jenBuilder << "&vcAppId=${env.vcid}"
                jenBuilder << "&vcBuildId=${env.vcbuildId}"
				jenBuilder << "&isDomainName=${env.isDomainName}"
                jenBuilder << "&isTeamName=${env.isTeamName}"
                jenBuilder << "&isApplicationName=${env.isApplicationName}"
                jenBuilder << "&isDepartmentName=" << URLIFY(env.isDepartmentName)
                jenBuilder << "&enableIntegration=${env.enableIntegration}"
				jenBuilder << "&almTestSetPath=" << URLIFY(env.almTestSetPath)
				jenBuilder << "&almProjectName=${env.almProjectName}"
                jenBuilder << "&almHost=${env.almHost}"
				jenBuilder << "&isTestUCD=${env.useTestUCD}"
                jenBuilder << "&workItem=${env.workItem}"
                jenBuilder << "&debug=${env.debug}"
				def jenURL = jenBuilder.toString()
				httpRequest authentication: jenkinsCred, httpMode: 'POST',ignoreSslErrors: true,responseHandle: 'NONE', url: jenURL
			} catch (err) {
				if (env.enableApproval?.equalsIgnoreCase("true")) {
					def user = err.getCauses()[0].getUser()
					userInput = false
					echo "Delivery to Test denied by [${user}]"
				}
				echo "Error: ${err.message}"
			}
		} //timeout
	} //if	enableIntegration					
}




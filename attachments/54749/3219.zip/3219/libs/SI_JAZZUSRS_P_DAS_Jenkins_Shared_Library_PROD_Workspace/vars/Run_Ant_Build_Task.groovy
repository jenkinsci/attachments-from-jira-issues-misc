#!/usr/bin/env groovy
// 176851

/**
 * Run an RTC build task.
 * 
 * @param fileIdentifier - the managed file name of the ant task file (xml format)
 * @param environmentVarList[] - the list of environment variables to include as tokens for the file
 * @credId - the credentials ID to run from in RTC
 * @return  the standard output
 */
 
def call(def fileIdentifier="config.xml",def environmentVarList=[],def credId="SI_JAZZUSRS_P") {
	String methodName = 'DSL -> Run Ant Task'
	echo methodName
	withAnt(installation: 'Anthill') {
		def buildtoolkitpath = /F:\ProgramFiles\IBM\RTC\jazz\buildsystem\buildtoolkit/
		echo "using credentials ${credId}" 
		withCredentials([usernamePassword(credentialsId:credId, passwordVariable: 'password', usernameVariable: 'userName')]) {
			def varList = ["userId=${userName}","password=${password}"]
			varList.addAll(environmentVarList)
			withEnv(environmentVarList) {
				configFileProvider([configFile(fileId: fileIdentifier, replaceTokens: true, variable: 'RTCLink')]) {
					echo "running script"
                    def stdOut = ""
                    try {
                        stdout=bat script:"ant -f ${RTCLink} -lib ${buildtoolkitpath} >ant.txt 2>&1" 
                    } catch(e) {
                    	echo "Exception caught in DSL -> Run Ant Task:"
                        echo e.message
                        def d=readFile "ant.txt"
                        dArray = d.split('\n')
                        throw new Exception(dArray[5])
                    }
                    def antListing = readFile("${RTCLink}")
					if (IsDebug()) {
						echo "${antListing}"
                        echo stdOut
					} //if debug
                    return stdOut
				} //configFileProvider
			} //withEnv
		} //withCredentials
	} //withAnt
}




#!/usr/bin/env groovy

void call() {
						echo "Version is Declarative 2.1"
		            	echo 'Base path: ' + bcbst.das.GlobalVars.LOAD_BASE + "${buildDefinitionId}"
// 		              	echo "PATH = ${PATH}"
 		              	echo "personalBuild= ${personalBuild}"
 		              	echo "Requestor User ID = ${buildRequesterUserId}"
              			if (env.environmentVar == 'true') {
                   			bat 'set > env.txt' 
							for (String i : readFile('env.txt').split("\r?\n")) {
	    						println i
							}
						}
 						def rtcProps = Checkout_RTC();
   					    sleep time:3 //give some time to fetch what is needed to be fetched

//						Detect version in maven pom file
//   						def versionFile = "${workingDirectory}/${pomXmlName}"
//	   					def assInfo = readFile "${versionFile}"
//	   					def pattern = ~/<version>(.*)<\/version>/
//	   					def match = pattern.matcher(assInfo)
//	   				    echo "Match size is "+ match.size()+", match count is "+match.getCount()
//	   					if (match.size() > 0) {
//							def gMinusOne=match.getCount()-1
//	   						echo match[0][1]
//	   						if ("${version}" == "" || "${version}" == "1.0.0") {
//	   							setParam("version",match[0][1])
//	   						}
//	   					}
// 						Rename the Jenkins Build
   						buildName "${buildDefinitionId}_${BUILD_TIMESTAMP}" //do not use with Build Name Plugin < v2.0
   						buildDescription "Executed on ${NODE_NAME}"
//						Grab workspace and project area from RTC
						def workspaceName=Get_Workspace_Name()
						def projectArea=Get_Project_Area()
						echo "Workspace is ${workspaceName}, Project Area is ${projectArea}"
						echo "moon"
						build.setParam("WSNAME","${workspaceName}") //reset build parameters on the fly
						echo "stars"
						setParam("PROJECTAREA","${projectArea}")

///						If no Sonarqube or Nexus project exists, create them!
						echo "mars"
						dir ("F:/ProgramFiles/DASPython") {
						echo "jupiter"
							def argument = ""
							echo "saturn"
				        	if (serviceAccount == "SI_JENKINS_T") {
				        		echo "venus"
				        		argument = "-t"
				        	}
				        	echo "about to run some python"
				        	bat "python -m pip install -r ${modulesList}"
				        	echo "about to use credentials"
					        withCredentials([usernamePassword(credentialsId: "${serviceAccount}", passwordVariable: 'password', usernameVariable: 'username')]) {
//		        		        	bat "echo $username:$password"
		                			bat "python F:/ProgramFiles/DASPython/das_scripts.py -c ${isDomainName} ${isTeamName} ${isApplicationName} -L ${username} ${password} ${argument}"
		           			} //withCred
		           			
	           			} //dir	           			
						echo "Checking for binaries in your repo...."
						def naughty = Check_For_Violations()
						// compile a warning email for the violations
						if (naughty) {
							echo "Some policy violations found."
							def offensiveFiles=""
							naughty.each {
								offensiveFiles+="- ${it}\n"
							} //each
							fileOperations([fileCreateOperation(fileContent:offensiveFiles, fileName: "binaries_detected.txt")])
							offensiveFiles=""
							setParam("violations",naughty.size().toString())
						} else {
							setParam("violations", "0")
						} //if/else
}
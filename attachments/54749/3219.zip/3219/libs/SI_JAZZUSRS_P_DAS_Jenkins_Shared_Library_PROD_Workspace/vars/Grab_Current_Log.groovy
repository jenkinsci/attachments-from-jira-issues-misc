import java.util.stream.IntStream
import java.util.stream.Collectors
/** Send the current build log to a list
 *  This is the complete log, not limited by line numbers
 *  
 *  @return the log as a string
 */
// 176851

/**
 * Send the current build log to a list.
 *  
 * @param maxLines (int) the maximum number of lines to read
 * 
 * @return a list containing each line of the log being read
 */
//@NonCPS 
def call() {
    println "DSL->Grab_Current_Log()"
    def logContent = Jenkins.getInstance()
                    .getItemByFullName(env.JOB_NAME)
                    .getBuildByNumber(
                        Integer.parseInt(env.BUILD_NUMBER))
                    .logFile.text	
    return logContent
}




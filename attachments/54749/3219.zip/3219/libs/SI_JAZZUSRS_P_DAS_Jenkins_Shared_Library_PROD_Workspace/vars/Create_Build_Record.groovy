#!groovy
/**Sends success flag and naughty file (binaries) count to DAS_MASTER
*
* @param buildName		[String] (required)	used to identify the build
* @param buildUuid	[String] 
* @param pipelineName	[String] (required)	
* @param projectAreaName [String]
*
*/
import groovy.sql.Sql
void call(String buildName, String buildUuid, String pipelineName, String projectAreaName){
	 echo "JDL->Create_Build_Record()"
	String stdOut = ""
    String s = '{call DAS_MASTER.dbo.SP_DAS_CreateBuild('+
        "'','${buildName}','${buildUuid}','JENKINS','${pipelineName}','','','','','${projectAreaName}')"+
        '}'
    echo s
	try {
        def bdCommand
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:'SQ_DASUcd_T', usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
            Run_JDBC_Query(USERNAME,PASSWORD,s)
        }
    } catch (Exception ex){
        echo ex.message
    }
//	def err = readFile('dbErr.txt').trim()
//    env.errorMsg = err
//	setParam("errorMsg", err)
//	bat(returnStdout: false, script: "DEL dbErr.txt")
//	Send_Error_Email('IS_Delivery_Auto_Ser_Team@bcbst.com','Internal Jenkins Error - Create_Build_Record')
	
 }

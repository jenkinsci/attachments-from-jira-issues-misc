import groovy.json.*
def call(def almParams) {
    return {
        stage ("stage: ${almParams.appName}") {
            def xmlStr = "";
            try {
                def preTestStatus = Run_ALM_Pre_Test_Validation(almParams);
                if (preTestStatus != 'ready') {
                    xmlStr = Gen_Patch_Test_Warning_XML(preTestStatus, almParams);
                } 
                else {
                    timeout(activity:true, time:5) {
                        node (almParams.serverNode) {
                            println "[AUTOMATION] => CleanWs -> (${almParams.serverNode}): ${env.WORKSPACE}";
                            cleanWs notFailBuild: true;
                            println "[AUTOMATION] => Testing application in workspace (${almParams.serverNode}): ${env.WORKSPACE}\n ${almParams.toString()}";
                            int errorCode = Run_ALM_Test(almParams.domainName, almParams.projectName, almParams.testSetPath, almParams.serverNode);
                            sleep time:10,unit:'SECONDS'; 
                            if (errorCode > 0) throw new Exception('[AUTOMATION] => Run_ALM_Test() returned a non-zero status code indicating that it failed');
                            else {
                                xmlStr = Read_ALM_Test_File("Results*.xml");
                                archiveArtifacts artifacts: '**/*', followSymlinks: false;
                            }
                        } // node
                    }
                }
            } catch (e) {
                println e;
                println "[AUTOMATION] => EXCEPTION raised while attempting to complete test.";
                xmlStr = Gen_Patch_Test_Warning_XML('exception', almParams);
            } finally {
                def xmlWarn = Get_Warning_Or_Null(xmlStr);
                if (xmlWarn) println "[AUTOMATION] => WARNING -> ${xmlWarn.name} : ${xmlWarn.msg} for ${almParams.toString()}";
                def json = JsonOutput.toJson([results : xmlStr, params : almParams.toXmlString()]);
                def filePath = "${env.WORKSPACE}\\${env.BUILD_ID}\\automation-tests\\alm-results-${almParams.appName}_${env.BUILD_ID}.json";
                writeFile(file: "${filePath}", text:json);
                if (IsDebug()) println "[AUTOMATION] => Test file saved successfully: ${filePath}";
            }
        }
    }
}
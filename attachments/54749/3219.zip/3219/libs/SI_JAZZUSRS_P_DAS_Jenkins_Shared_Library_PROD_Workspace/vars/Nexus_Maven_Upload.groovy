#!/usr/bin/env groovy

/**
 * Perform a Maven Nexus deploy using the build definition parameters
 * 
 * @param workingDir(required) the current working directory
 * @param pomXML(required) the name of the pom file
 * @param packageType(required) is the type of file that will be made to upload (jar, ear, war)
 *
 */
 
void call(def workingDir, def pomXml, def packageType) {
    def thisMaven = tool name:'RTC Maven', type: 'maven'
    echo "DSL->Nexus_Maven_Upload()"
	configFileProvider(
		//Uses SI_Jenkins_Maven files as the settings.xml for Maven. This file is defined in Jenkins.
		[configFile(fileId: 'SI_Jenkins_Maven', variable: 'MAVEN_SETTINGS')]) {
			withCredentials([usernamePassword(credentialsId: 'SI_JAZZUSRS_P', passwordVariable: 'password', usernameVariable: 'username')]) {
				bat "${thisMaven}/bin/mvn -s ${MAVEN_SETTINGS} -f${workingDir}/${pomXml} -Drepo.pwd=%password% ${packageType}:${packageType} deploy:deploy"
			}
		}
}
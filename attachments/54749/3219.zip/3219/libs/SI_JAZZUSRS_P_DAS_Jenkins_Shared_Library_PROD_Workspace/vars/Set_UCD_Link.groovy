#!/usr/bin/env groovy
// 176851

/**
 * Replace the current link to Jenkins with a link to the RTC build page.
 * 
 * @param componentName the component to use
 * @param versionNM	The version number in UCD for the component artifacts
 * @param linkName	the link text
 * @param linkURL the link URL
 * @param useTestUCD whether to use UCD test
 * 
 * @return RTC Link name
 *
 */
 
def call(def componentName, String versionNM,linkName="Link",linkURL="URL",testUCD="true") {
	String methodName = 'DSL -> Setting UCD Link to RTC'
	echo methodName
	def quietValue = (!IsDebug())
    def ucdTestProd = (testUCD == "true")?"https://ucd-test.bcbst.com":"https://ucd.bcbst.com"
    try {
        httpRequest httpMode:'PUT', authentication: 'UCDImport', quiet:quietValue, url: "${ucdTestProd}/cli/version/addLink?component="+URLIFY(componentName)+"&version=${versionNM}&linkName=${linkName}&link="+URLIFY(linkURL)
    } catch (err) {
        echo "Encountered a problem setting link "+linkName+":"+err.message
        return err;
    }	
    return linkName;
}




#!/usr/bin/env groovy
// 176851

/**
 * 
 * 
 * Translate the type of failure caught by the build definition update analysis
 * 
 * @param failText the text of the exception/failure 
 *  
 * @return the new text describing the failure
 *
 */
 
def call(def failText) {
    echo "DSL->Get_BD_Failure"
    if (failText?.contains("workspace not found")) {
        failure = "build workspace not found"
    } else if (failText?.contains("Component not found")) {
        failure = "component not found"
    } else if (failText?.contains("Process area not found")) {
        failure = "project area not found"
    } else if (failText?.contains("The following record was not found in the database")) {
        failure = "record not found in database"   
    } else {
        failure = failText
    }
    return failure


}




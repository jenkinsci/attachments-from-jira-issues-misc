#!/usr/bin/env groovy
// 176851

/**
 * Send an email warning notification
 * 
 * @param recipient			[String] (required) The email recipient(s) of the notification
 * @param notifySubject		[String] (required) The notification subject line
 * @param notifyBody		[String] (required) The notification body contents
 * @param atchFile			[String] (optional) a file attachment pattern
 *  
 * @return command 	[String] - A bat-structured command for the calling pipeline to execute.
 *
 */
 
def call(String recipient='',String notifySubject='',String notifyBody='', String atchFile='') {
//, String buildDefinitionId, String buildTimeStamp
	String methodName = 'DJSL -> Send_Notification()';
	if (atchFile.trim() != '') {
		emailext body:notifyBody, subject: notifySubject, to: recipient, attachmentsPattern: atchFile
	} else {	
		emailext body:notifyBody, subject: notifySubject, to: recipient
	}
	return 0;
}




#!/usr/bin/env groovy
// 176851

/**
 * Set a version status to a value in UCD - the status must be visible and the UCD Import account must
 * have permissions.
 *
 * @param componentName The component name
 * @param versionNM	 The version number in UCD for the component artifacts
 * @param status The status text
 * @param testUCD whether to use UCD Test
*  
 * @return status 	[String] - Status name
 *
 */
 
String call(def componentName, String versionNM, String status, def testUCD="true", boolean ignoreSSL=true) {
	String methodName = 'DJSL -> Setting Status to '+status;
	echo methodName
	def quietValue = (!(IsDebug()))
    def ucdTestProd = (testUCD == "true")?"https://ucd-test.bcbst.com":"https://ucd.bcbst.com"
	try {
			httpRequest httpMode:'PUT', authentication: 'UCDImport', quiet:quietValue, ignoreSslErrors: ignoreSSL, url: "${ucdTestProd}/cli/version/addStatus?component="+URLIFY(componentName)+"&version=${versionNM}&status="+URLIFY(status)
	} catch (err) {
			echo "Encountered a problem setting status "+status+":"+err.message
			return err;
	}
	return status;
}




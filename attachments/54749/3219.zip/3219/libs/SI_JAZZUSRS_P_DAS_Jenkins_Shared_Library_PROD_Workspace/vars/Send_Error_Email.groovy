#!groovy
/**
*Sends an email when there is an internal error in the  jenkins pipeline.
*
* @param recipient the recipient of the email
* @param notifySubject the subject of the email
*
*/

void call(String recipient='',String notifySubject=''){
	String methodName = 'DJSL -> Send_Error_Email()';
	echo methodName
	try{
	emailext body:'${SCRIPT, template="jenkins-error-email-html.template"}', subject: notifySubject, to: recipient, attachLog:false
	} catch (Exception ex){
	 String error = "There was an error while emailing the error report to Jenkins admins: "
	 echo error
	 echo ex.toString()
	}finally{
//        setParam("errorMsg", "")
        env.errorMsg = ""    
    }
}
#!/usr/bin/env groovy
// 176851

/**
 * Check if a Sonarqube/Nexus app exists and create if missing.
 * 
 *  @param svcAccount the name of the service account being used to check nexus and sq
 * 
 */
 
void call(def svcAccount = "SI_JENKINS_T") {
	String methodName = 'DJSL -> Check_SQ_Nexus()';
	echo methodName

	if (env.personalBuild != "true") {
		dir ("F:/ProgramFiles/DASPython") {
			def argument = ""
			if (svcAccount == "SI_JENKINS_T") {
				argument = "-t"
			}
			bat "python -m pip install -r ${modulesList}"
			withCredentials([usernamePassword(credentialsId: "${svcAccount}", passwordVariable: 'password', usernameVariable: 'username')]) {
				def results = bat script:"python F:/ProgramFiles/DASPython/das_scripts.py -c ${isDomainName} ${isTeamName} ${isApplicationName} -L %username% %password% ${argument}", returnStdout:true
				if (IsDebug()) {
					echo results
				}
			} //withCredentials
		} //dir	           		
	} // check if personal build
}




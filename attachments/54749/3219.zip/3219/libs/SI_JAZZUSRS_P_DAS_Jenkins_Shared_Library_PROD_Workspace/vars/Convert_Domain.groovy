#!groovy
/**
 * Convert RTC Domain to ALM domain
 *
 * @param urlString the string to convert
 * @return ALM domain name
 *
 */
def call(def domainString) {
    echo "DSL->Convert_Domain()"
	def gv = bcbst.das.GlobalVars;
	if (IsDebug()) {
		println "binding to ${domainString} is "+ gv.TeamMap.get(domainString)
	}
	if (gv.TeamMap.containsKey(domainString)) {
		return gv.TeamMap.get(domainString)
	} else {
		return "NULL" 
	}
}

	
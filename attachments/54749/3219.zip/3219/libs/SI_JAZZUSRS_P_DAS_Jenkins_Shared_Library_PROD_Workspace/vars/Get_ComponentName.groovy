#!/usr/bin/env groovy
// 198354
/**
 *  Get a component name from its UUID (RTC)
 *
 * @param compId the uuid of the rtc component
 * 
 * @return String The name of the component
*/
String call(def compId = "") {
    echo "DSL->Get_ComponentName()"
	def keepQuiet = !(IsDebug())
	httpRequest authentication: 'RTC', ignoreSslErrors: true, quiet:keepQuiet, outputFile: 'output.log', responseHandle: 'NONE', url: 'https://rtcccm.bcbst.com/ccm/rpt/repository/scm?fields=component/component[itemId='+compId+']/name'
	def outputH = steps.readFile "output.log"
	def rootNode = new XmlSlurper().parseText(outputH)
	def compName = rootNode.component.name.text()
	if (IsDebug()) {echo "Get_ComponentName-> ${compId} = ${compName}"}
	return compName
}
/** 
* Renames a file.
* 
* @param sourcePath The path to the file to be renamed
* @param destPath The path to the new file.
* @return 0 if successful, or 1 for error.
**/
int call(String sourcePath, String destPath) {
    echo "DSL->Rename_File()"
    int ret = 1;
    try {
        fileOperations([
            fileRenameOperation([
                source: "${sourcePath}",
                destination: "${destPath}"
            ])
        ]);
        ret = 0;
    } catch (Exception e) {
        StringBuilder sb = new StringBuilder();
        sb.append("* * * * * * ERROR EXECUTING FILE RENAME * * * * * *\n");
        sb.append("Method: Rename_File\n");
        sb.append("Message: Unable to rename file ${sourcePath} to ${destPath}.\n");
        sb.append("${Functions.printThrowable(e) }");
        println sb.toString();
    } finally {
        return ret;
    }
}
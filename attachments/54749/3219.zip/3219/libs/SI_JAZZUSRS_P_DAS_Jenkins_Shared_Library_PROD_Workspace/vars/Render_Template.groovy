import groovy.text.StreamingTemplateEngine

/** 
* Renders a given template with variable values
* 
* @param input the template text
* @param variables a map of variables in name:value format.
* 
* @return the completed text provided by the template
**/
String call(def input, def variables) {
  echo "DSL->RenderTemplate()"
  def engine = new StreamingTemplateEngine()
  return engine.createTemplate(input).make(variables).toString()
}
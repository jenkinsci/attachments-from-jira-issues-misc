#!/usr/bin/env groovy
// 176851

import groovy.time.*

/**
 * Get a list of changes since last build.
 * 
 *  
 *  @param buildDefId the build definition id 
 *  @param buildUUID the uuid of the build result
 *  @param  textValue the version to include in the snapshot and build label
 *  @param external whether the build is external (personal or external build)
 *  @param  fast boolean to indicate fast groovy mode
 *  
 * @return changeList 	[String] - A list of changes in html format (string)
 *
 */
 
def call(def buildDefId, def buildUUID, def textValue, def external="false",def fast=true) {
    println "Jazz configuration..."
//    def classPath = (env.NODE_LABELS.contains("aix"))?"/jenkins/jazz/buildsystem/buildtoolkit/*":"F:/ProgramFiles/IBM/RTC/jazz/buildsystem/buildtoolkit/*"
    def uidstr= (env.NODE_LABELS.contains("aix"))?"\$RTC_USER_ID":"%uid%"
    def pwdstr= (env.NODE_LABELS.contains("aix"))?"\$RTC_PASSWORD":"%pwd%"
    try {
            if (env.personalBuild=="true") external = "true"
            withCredentials([usernamePassword(credentialsId:'SI_JAZZUSRS_P', passwordVariable: 'pwd', usernameVariable:'uid')]) {
                env.RTC_USER_ID='SI_JAZZUSRS_P'
                env.RTC_PASSWORD=pwd
                if (env.NODE_LABELS.contains("aix")) sh("printenv")
                Run_Groovy_Script("das/Perform_Jazz_Init_Functions.groovy", "\"${uidstr}\" \"${pwdstr}\" \"${buildDefId}\" \"${buildUUID}\" \"${textValue}\" \"${external}\"",true,fast)
                sleep(time:15, unit:"SECONDS")
            }
            return "Started"
    } catch (e) {
            echo "Could not run script: ${e.message}"
            return "Error"
    }
//	return changeList 
}




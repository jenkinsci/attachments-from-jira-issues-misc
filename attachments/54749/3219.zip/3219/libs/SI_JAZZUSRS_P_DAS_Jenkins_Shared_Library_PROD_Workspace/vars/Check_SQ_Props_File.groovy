#!/usr/bin/env groovy
// 176851

/**
 * Check if a Sonarqube/Nexus properties file exists and create if missing.
 *  
 * @param workingDir The current working directory
 * @param isDN the domain name component of the sq key
 * @param isTN the team name component of the sq key
 * @param isAN the app name component of the sq key
 * @param ver the version number to be set in the sonarqube properties
 * 
 */
 
void call(def workingDir="", def isDN="", def isTN="", def isAN="", def ver="", def excl="", def disabled="true") {
    if (disabled=="null" || disabled == null) disabled = "true"
    echo "DSL->Check_SQ_Props_File()"
	if (fileExists("${workingDir}/sonar-project.properties")) {
   		echo "sonar-project.properties file detected"
   	} else {
   		echo "sonar-project.properties file missing. Generating from template"
		withEnv(["sqKey=${isDN}_${isTN}_${isAN}","version=${ver}","sonarExclusions=${excl}","scmDisabled=${disabled}"]) {
			configFileProvider(
				[configFile(fileId: 'sonar-project-properties-excludes', replaceTokens: true, targetLocation: "${workingDir}/sonar-project.properties")]) {}
//        	[configFile(fileId: 'sonar-project.properties', targetLocation: "${workingDir}/sonar-project.properties")]) {}
//       	powershell """(Get-Content ${workingDir}/sonar-project.properties).replace('[sqKey]', "${isDN}_${isTN}_${isAN}") | Set-Content ${workingDir}/sonar-project.properties"""
//			powershell """(Get-Content ${workingDir}/sonar-project.properties).replace('[version]', "${ver}") | Set-Content ${workingDir}/sonar-project.properties"""
   		}	//withEnv			
	} //else
}




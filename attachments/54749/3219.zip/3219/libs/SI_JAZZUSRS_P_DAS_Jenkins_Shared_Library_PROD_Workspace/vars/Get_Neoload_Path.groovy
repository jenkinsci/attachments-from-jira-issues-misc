/**
 * Convenience method to use different neoload executable path for apps that use Kerberos
 * 
 * @param execType Either KERB or NTLM
 * @return The path to the correct executable, or the NTLM executable by default
 **/
String call(String execType=null) {
    if (IsDebug()) println "[DEBUG] Reached method : String Get_Neoload_Path(String execType)";
    String kerbPath = 'C:\\Program Files\\NeoLoad 7.7_kerb\\bin\\NeoLoadCmd';
    String ntlmPath = 'C:\\Program Files\\NeoLoad 7.7\\bin\\NeoLoadCmd';
    switch (execType?.toUpperCase()) {
        case 'KERB' : return kerbPath;
        case 'NTLM' : return ntlmPath;
        default : return ntlmPath
    }
}
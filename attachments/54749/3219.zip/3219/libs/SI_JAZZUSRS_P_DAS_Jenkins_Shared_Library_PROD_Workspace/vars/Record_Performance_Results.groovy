/* Reads the Performance test XML, parses it, and creates a record and incident for the test
*
*	@param recId	[integer]	(required) The ID of the record in the database
* 	@param envName	[string] (required) The application environment being tested
*	@param xml	[string]	(required) The test result xml
*
*/
def call(def recId, def envName,def appName, def results){
def failedTests = [];
	try{
		echo "DJSL-> Record_Performance_Results(recId,envName,results)"
		results.each{ test->
			Create_ITOC_Test_Record(recId, "${appName} ${test.key.toString()}", "${test.value.toString()}", "Performance")
			if (test.value.toString().equalsIgnoreCase("failure")) {
				failedTests.push("Performance test ${appName} ${test.key.toString()} failed")
				}
			}
		if (failedTests.size() > 0){
			//Create_Performance_Incident("${testsuite.@name}", failedTests)
			Update_ITOC_Request_Record(recId, "FAILURES")
			return failedTests
			}
		else 
			{
			Update_ITOC_Request_Record(recId, "SUCCESS")
			}
		return failedTests
	
	
	} catch (ex){
	echo "Exception in Record_Performance_Results() -> ${ex.getMessage()}"
	return failedTests
	}
}
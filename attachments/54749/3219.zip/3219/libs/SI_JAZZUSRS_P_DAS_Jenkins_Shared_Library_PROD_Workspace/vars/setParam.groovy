#!/usr/bin/env groovy
// 176851

/**
* Deploy using UCD.
* 
* @param envNM		[String] (required) The environment name to deploy to
* @param versionNM 	[String] (required) the UCD Version to deploy
*  
* @return command 	[String] - Whatever the deploy returns.
*
*/
 
def call(String paramName, String paramValue) {
    List<ParameterValue> newParams = new ArrayList<>()
    newParams.add(new StringParameterValue(paramName, paramValue))
    $build().addOrReplaceAction($build().getAction(ParametersAction.class).createUpdated(newParams))
//	currentBuild.getRawBuild().addOrReplaceAction(currentBuild.getRawBuild().getAction(ParametersAction.class).createUpdated(newParams))	
}
#!groovy
/**
 * Report results of MSTest/VSTest
 *
 */

def call() {
    echo "DSL->Report_MSTest_Results()"
	step([$class: 'MSTestPublisher', testResultsFile:"**/*.trx", keepLongStdio: true, failOnError: false])
    def cases = Get_Unit_Test_Stats()
    return cases

}

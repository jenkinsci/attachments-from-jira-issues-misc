#!/usr/bin/env groovy
/**
 * Return the UCD version UUID
 *
 * @param componentName the UCD component name
 * @param version the UCD version name
 * @param useTest whether to use UCD test
 *
 * @return UCD Version UUID
 *
 */

import groovy.json.JsonSlurperClassic
 

def call(String componentName, String version, def useTest="true") {
    if (IsDebug()) echo "DSL->Get_UCD_Version_UUID()"
	componentName = URLIFY(componentName)
	def env = (useTest?.equalsIgnoreCase('true'))? "ucd-test":"ucd"
	def makeSilent = !(IsDebug())
	def response=httpRequest httpMode:'GET', authentication: 'UCDImport', quiet: makeSilent,  url: "https://${env}.bcbst.com/cli/version/getVersionId?component=${componentName}&version=${version}"
	return response.content
}	
#!/usr/bin/env groovy
// 176851

/**
 * Get Jenkins Version
 *
 *@return the current jenkins version
 */
String call() {
	return Jenkins.instance.getVersion().toString();
}




import hudson.Functions
/** 
* Executes the performance test using NeoLoad plugin using project & YAML files. Errors are rather cryptic, so including error details to assist with debugging. 
* 
* @param exePath The path to the NeoLoad executable.
* @param nlpPath The path to the NeoLoad project config file.
* @param yamlPath The path to the YAML file containing the applications to test.
* @param scenario The scenario to test.
* @param ptNTS The NeoLoad Server name.
* @return Nothing if successful, throws error otherwise. Test results are saved to disk and backed up in a later function call. 
* 
**/
def call(boolean useKerb, String envName) {
    try {
        if (IsDebug()) println "DJSL -> Exec_NeoLoad_Yaml(boolean useKerb=${useKerb}, String envName=${envName})";
        LinkedHashMap ops = [
            nlpPath : "C:\\Users\\${env.USERNAME}\\Documents\\NeoLoad Projects\\All_${envName}\\All_${envName}.nlp",
            ptNTS : (envName.equalsIgnoreCase('PROD')) ? 'SQA NeoLoad' : 'SQA NeoLoad NonProd',
            yamlPath : (useKerb) ? "${env.WORKSPACE}\\${env.BUILD_ID}\\neo-yaml-inputs\\DefaultKerb_${env.BUILD_ID}.yaml" : "${env.WORKSPACE}\\${env.BUILD_ID}\\neo-yaml-inputs\\Default_${env.BUILD_ID}.yaml",
            exePath : (useKerb) ? 'C:\\Program Files\\NeoLoad 7.7_kerb\\bin\\NeoLoadCmd' : 'C:\\Program Files\\NeoLoad 7.7\\bin\\NeoLoadCmd',
            scenario : (useKerb) ? "dynamicKerb" : "dynamic",
			nlWebURL : "${env.nlWebURL}",
			nlWebTokenKey : "${env.nlWebTokenKey}",
			testName : (useKerb) ? "PatchValidation_kerb" : "PatchValidation",
        ]
        if (IsDebug()) println "[DEBUG] Running NeoLoad plugin with the following options: ${ops}";
        neoloadRun executable: ops.exePath,
            project: ops.nlpPath,
            commandLineOption: "-project ${ops.yamlPath} -exitCodeFailIgnore -nlweb -nlwebAPIURL ${ops.nlWebURL} -nlwebToken ${ops.nlWebTokenKey}",
            testName: ops.testName,
			scenario: ops.scenario,
            sharedLicense: [server: ops.ptNTS, duration: 2, vuCount: 50],
            autoArchive: 'false'
        return 0;
    } catch (Exception e) {
        StringBuilder sb = new StringBuilder(); // Adding error messages since plugin isn't very descriptive
        sb.append("* * * * * * ERROR EXECUTING PERFORMANCE TEST * * * * * *\n");
        sb.append("Method: Execute_Performance\n");
        sb.append("Message: Unable to perform NeoLoad test execution.\n");
        sb.append("${Functions.printThrowable(e) }");
        println sb.toString();
        return 1;
    }
}
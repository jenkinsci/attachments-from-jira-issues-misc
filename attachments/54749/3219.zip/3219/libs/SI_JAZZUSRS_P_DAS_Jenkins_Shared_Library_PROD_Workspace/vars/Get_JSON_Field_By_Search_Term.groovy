#!groovy
/** return a the value of a json field based on another matched field
 *  on the same level
*
* @param appsMap    the Map containing the applications (from the json file)
* @param searchTerm the term/text to search for
* @param searchField the field to search on
* @param objectField the field to return based on the search
* 
* @return String the object field value that's in the same grouping as the search term
*/
 
 def call(def appsMap, def searchTerm, searchField="name", objectField="test_path"){
     if (IsDebug()) echo "Get_JSON_Field_By_Search_Term"
     return appsMap.find {it[searchField] == searchTerm}?.get(objectField)
}
#!/usr/bin/env groovy
// 176851

/**
 * @param testFiles 	[String] (required) A .sln file -or- space-delimited list of .dll test files
 * @param testNames 	[String] (optional) A COMMA-delimited list of test-cases to run
 * @param testListFile 	[String] (optional) A text file containing NEWLINE-delimited list of test-cases to run
 * @param testQuery		[String] (optional) A nUnit query expression to select a subset of test cases
 *
 * @return command [String] - A bat-structured command for the calling pipeline to execute.
 */
def call(String testFiles = '', String testNames = '', String testListFile = '', String testQuery = '', String openCoverFilter = '') {
	
	def gv = bcbst.das.GlobalVars;
	
	String methodName = "DJSL -> UnitTest_NUnit(${testFiles},${testNames},${testListFile},${testQuery},${openCoverFilter})";
	echo methodName + ' :: Building OpenCover command for nUnit.';

	// set default nUnit OpenCover filter if one is not provided
	if (openCoverFilter == '') { 
		openCoverFilter = gv.OPENCOVER_FILTER_NUNIT;
	} else {
		if (!openCoverFilter.startsWith(' ')) { 
			// make sure that OpenCover's -filter argument has a space in front! 
			openCoverFilter = ' ' + openCoverFilter;
		}
	}
	
	// if invalid, error will be thrown in the validator
	String nUnitArgs = validateTestFiles(testFiles.trim());
	
	// test names, testlist file, and where clause are all optional
	// and mutually exclusive
	if (testNames.trim() != '') {
		// cannot contain space - validator will throw an error
		nUnitArgs = nUnitArgs + ' --test:' + validateTests(testNames);
	} else if (testListFile.trim() != '' ) {
		nUnitArgs = nUnitArgs + ' --testlist:' + testListFile;
	} else if (testQuery+'' != '') {
		nUnitArgs = nUnitArgs + ' --where:' + testQuery;
	}
	
	// build command from various parts and arguments
	String nUnitCmd = gv.OPENCOVER_EXE + gv.OPENCOVER_ARGS + ' "-target:' + gv.NUNIT_EXE + '" "-targetargs:' + nUnitArgs + ' ' + gv.NUNIT_ARGS + '"';
	
	// log the command (helpful for troubleshooting)
	echo methodName + ' :: Returning OpenCover command (nUnit target): ' + nUnitCmd;
	
	// and return as string to the pipeline
	return nUnitCmd;
}

/**
 * Accepts string containing a .sln file or a space-delimited list of .dll test files.
 *
 * @param testFiles [String]
 * @return testFiles [String]
 * @throws error (validation)
 */
def validateTestFiles(String testFiles = '') {
	echo 'DJSL -> UnitTest_NUnit() -> validateTestFiles() :: Validating argument: testFiles -> "' + testFiles + '"';
		
	if (testFiles.endsWith('.sln')) return testFiles;
	if (testFiles.contains('.dll')) return testFiles;
	
	error('DJSL -> UnitTest_NUnit() -> validateTestFiles() :: Invalid argument: testFiles -> "' + testFiles + '" '
		+ ' -> This must contain a .SLN file or a space-delimited list of .DLL test files.');
}

/**
 * Accepts string containing a comma-delimited list of test names to run.
 *
 * @param testNames [String]
 * @return testNames [String]
 * @throws error (validation)
 */
def validateTests(String testNames = '') {
	echo 'DJSL -> UnitTest_NUnit() -> validateTests() :: Validating argument: testNames -> "' + testNames + '"';
		
	if (!testNames.contains(' ')) return testNames;
	
	error('DJSL -> UnitTest_NUnit() -> validateTests() :: Invalid argument: testNames -> "' + testNames + '" '
		+ ' -> This is a COMMA-delimited list of tests - it cannot contain a space.');
}

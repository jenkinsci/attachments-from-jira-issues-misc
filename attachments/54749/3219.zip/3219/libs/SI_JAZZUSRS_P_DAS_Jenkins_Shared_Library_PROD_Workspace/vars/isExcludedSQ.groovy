#!/usr/bin/env groovy
// 176851
// 276499

/**
  *
 * @return [Boolean] - Tells whether the build definition is in the exclude list
 */
boolean call() {
	boolean returnValue = false
	if (IsDebug()) {
		echo "SharedLibrary -> isExcludedSQ for ${buildDefinitionId}"
	}
	if ("${SQ_EXCLUDES}".contains(buildDefinitionId)) {
		if (IsDebug()) { echo "returning true" }
		returnValue=true
	}
	everyExclude = SQ_EXCLUDES.split(',')
	everyExclude.each {
		if (buildDefinitionId.contains(it)) {
			if (IsDebug()) {
				echo "build definition contains ${it}"
				echo "returning true"
			}
			returnValue=true
		} else if (IsDebug()) {
			echo "build definition does not contain ${it}"
		}
	}
	return returnValue
	
	
}


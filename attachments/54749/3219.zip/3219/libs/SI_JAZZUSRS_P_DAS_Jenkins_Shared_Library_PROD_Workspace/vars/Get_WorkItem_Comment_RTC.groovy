#!/usr/bin/env groovy
// 176851

/**
 * This function exists solely to provide a template for the RTC status comment.
 *  
 * @return RTC_COMMENT 	[String] - The text of the RTC status comment
 *
 */
 
def call() {
    echo "DSL->Get_WorkItem_Comment_RTC()"
    String SQ_COMMENT = (env.personalBuild=="true"||(isExcludedSQ()))? "":"""
        &lt;b&gt;Quality &amp; Security&lt;/b&gt;
          - SonarQube Score: ${env.SQ_QUALITY_GATE_STATE}
          - SonarQube Project Dashboard: https://sonarqube.bcbst.com/dashboard?id=&lt;b&gt;${env.isDomainName}_${env.isTeamName}_${env.isApplicationName}&lt;/b&gt;
          - &lt;b&gt;SONARQUBE QUALITY METRICS&lt;/b&gt;
            - Bugs: ${env.SQ_METRIC_BUGS} (${env.SQ_METRIC_NEW_BUGS})
            - Vulnerabilities: ${env.SQ_METRIC_VULNERABILITIES} (${env.SQ_METRIC_NEW_VULNERABILITIES})
            - Smells: ${env.SQ_METRIC_CODE_SMELLS} (${env.SQ_METRIC_NEW_CODE_SMELLS})
            - BLOCKER-VIOLATIONS: ${env.SQ_METRIC_BLOCKER_VIOLATIONS} (${env.SQ_METRIC_NEW_BLOCKER_VIOLATIONS})
            - CRITICAL-VIOLATIONS: ${env.SQ_METRIC_CRITICAL_VIOLATIONS} (${env.SQ_METRIC_NEW_CRITICAL_VIOLATIONS})
            - MAJOR-VIOLATIONS: ${env.SQ_METRIC_MAJOR_VIOLATIONS} (${env.SQ_METRIC_NEW_MAJOR_VIOLATIONS})
            - MINOR-VIOLATIONS: ${env.SQ_METRIC_MINOR_VIOLATIONS} (${env.SQ_METRIC_NEW_MINOR_VIOLATIONS})
            - INFO-VIOLATIONS: ${env.SQ_METRIC_INFO_VIOLATIONS} (${env.SQ_METRIC_NEW_INFO_VIOLATIONS})

"""
	String RTC_COMMENT = """
        ** RELEASE STATUS REPORT **
        ===========================&lt;/b&gt;
         
        &lt;b&gt;Build&lt;/b&gt;
          - Build: &lt;b&gt;${env.curTime}&lt;/b&gt;
          - Build Requested By: &lt;b&gt;${env.buildRequesterUserId}&lt;/b&gt;
          - Build Status: &lt;b&gt;${currentBuild.result}&lt;/b&gt;*
          - Build Result: &lt;b&gt;${repositoryAddress}resource/itemOid/com.ibm.team.build.BuildResult/${buildResultUUID}&lt;/b&gt;
         
${SQ_COMMENT}
        &lt;b&gt;Target Environment&lt;/b&gt;
          - Environment: &lt;b&gt;${env.ucdEnvironmentNameDVLP}&lt;/b&gt;
          - Host(s): &lt;b&gt;${env.buildEngineHostName}&lt;/b&gt;
          - App Server(s): &lt;b&gt;File System&lt;/b&gt;
         
        &lt;b&gt;Deployment Process&lt;/b&gt;
          - Deployment Requested By: &lt;b&gt;${env.buildRequesterUserId}&lt;/b&gt;
          - Application / Process: &lt;b&gt;${env.ucdApplicationName}&lt;/b&gt; / &lt;b&gt;${env.ucdApplicationProcessName}&lt;/b&gt;
          - Component / Process: &lt;b&gt;${env.ucdComponentName}&lt;/b&gt; / &lt;b&gt;just print something to the work item&lt;/b&gt;
          - Component Version: &lt;b&gt;${env.VERSION_NOM}&lt;/b&gt;
          - Final Result: &lt;b&gt;${currentBuild.result}&lt;/b&gt;*
          &lt;br /&gt;&lt;br /&gt;
"""
		return RTC_COMMENT
}
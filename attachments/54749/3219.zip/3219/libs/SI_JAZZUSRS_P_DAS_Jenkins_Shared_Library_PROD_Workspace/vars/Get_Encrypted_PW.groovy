#!/usr/bin/env groovy
// 176851

/**
 * Get encrypted maven password
 *  
 * @return encrypted text
 *
 */
 
def call() {
	dir("F:/Jenkins") {
		def encryptedText = readFile('encryptedOne.txt')
		if (IsDebug()) { echo "Encrypted Text is ${encryptedText}" }
		return encryptedText
	}
}




#!groovy
/**Creates a record for the ITOC Smoke tests on DAS_MASTER_DVLP
*
* @param recordId		[String] (required)	used to identify the overall test request
* @parem testName		[String] (required) the name of the test
* @param status			[String] (required) identifies whether the test passed or failed
*
*/
 
 def call(def recordId, def testName, def status, def appName){
	 echo "DJSL->Create_ITOC_Test_Record(def recordId, def testName, def status)"
	 def dbReturnValue = null
	 def dbAcct = (jenkinsEnvironment.equalsIgnoreCase("Prod")) ? "SQ_DASUcd_P" : "SQ_DASUcd_T"
	 def dbServer = (jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "wprc2211": "wnrc0811"
	 def dbDatabase = (jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "DAS_MASTER": "DAS_MASTER_DVLP"
	 testName = testName.replaceAll("&"," and ");
	try {
 	withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: dbAcct, usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
		dbReturnValue = bat(returnStdout: true, script:"cmd /c \"\"C:\\Program Files\\Microsoft SQL Server\\Client SDK\\ODBC\\130\\Tools\\Binn\\SQLCMD.EXE\" -S ${dbServer} -U %USERNAME% -P \"%PASSWORD%\" -Q \"EXEC ${dbDatabase}.dbo.SP_ITOC_CreateAutomationTestRecord @pRequestID='${recordId}', @pTestName='${testName}', @pStatus='${status}', @pAppName='${appName}'\" 2> dbITOCErr.txt\"")
		
		if (fileExists("dbITOCErr.txt")){
		 def err = readFile('dbITOCErr.txt').trim()
		if ( err.contains("Error")){
		throw new Exception( err)
		}}
    }} catch (Exception ex){
	if (fileExists("dbITOCErr.txt"))
	{
	def err = readFile('dbITOCErr.txt').trim()
    env.errorMsg = err
	echo err
	bat(returnStdout: false, script: "DEL dbITOCErr.txt")
	}
	echo ex.getMessage()
	Send_Error_Email('Derald_Rogers@bcbst.com','Internal Jenkins Error - Create_ITOC_Test_Record')
	}
 }
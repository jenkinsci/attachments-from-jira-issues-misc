/**
*	Upload nupkg to Nexus repository nuget-releases
*
*	@param nupkgFile is the name of the .csproj or .nuspec file used to make a nupkg
*	@param workingDir working directory
*	@param vsPack switches between msbuild pack or nuget pack
*
*/

void call(String nupkgFile,def workingDir, String vsPack){

	//choosing the correct msbuild to use based on properties provided from the build def. Tools should be defined on the Jenkins Server
	if (env.useLegacyMSBuild == "true") {
			msBuildCmd = ("${env.msBuild64}"== "true")? "${tool 'MSBuild 4.0 64 bit'}":"${tool 'MSBuild 4.0 32 bit'}"	
		} else {
			msBuildCmd = ("${env.msBuild64}"== "true")? "${tool 'MSBuild VS2017 64 bit'}":"${tool 'MSBuild VS2017 32 bit'}"
		}
		
	// Credentials (secret) should be set on the Jenkins server, it is the Nexus apiKey for SI_Jenkins_*
	withCredentials([string(credentialsId: 'NexusApiKey', variable: 'apikey')]) {
		
		echo "Creating the nupkg file from ${workingDir}${nupkgFile}"
		
		if ("${vsPack}" == "false") {
			// Nuget command to make the nupkg from a .csproj or .nuspec file, nugetLocation variable should be set on Jenkins Server
			bat label: 'nuget package', script: "\"${nugetLocation}nuget\" pack \"${workingDir}${nupkgFile}\" -OutputDirectory ${workingDir}nexusupload/nexusupload"
		} else {
			//msbuild command to make the nupkg from a .csproj or .nuspec file
			bat label: 'MSBuild Pack', script: "\"${msBuildCmd}/msbuild\" \"${workingDir}${nupkgFile}\" /t:pack /p:PackageOutputPath=${workingDir}nexusupload/nexusupload"
		}
		
		// Finds the .nupkg file in a specified location created in last step
		def files = ""
		dir("${workingDir}nexusupload/nexusupload"){
			files = findFiles glob: '*.nupkg'
			echo "Grabbing nupkg ${files[0].path}"
		
			/* Pushes the found .nupkg file into Nexus using the SI_Jenkins_* apikey; nexusRepo variable should be set as an 
		 	environment variable on the Jenkins server */
			echo "Pushing ${files[0].path} to ${nexusRepo}/nuget-releases/" 
			bat label: 'nuget push', script: "${nugetLocation}nuget push ${files[0].path} -ApiKey %apikey% -Source ${nexusRepo}/nuget-releases/"
			
			//deleting the file in case server cleanup doesn't happen quick enough.
			echo "Removing the pushed file from the server"
			fileOperations([fileDeleteOperation(excludes: '', includes: '*.nupkg')])
			}
	}
}
#!/usr/bin/env groovy
// 176851

/**
 * Convert the fields for the XML call to a Map
 *  
 * @param buildDefinitionName
 * @param workspaceUUID
 * @param projectArea
 * @param excludeComponents
 * @param deleteDest
 * @param acceptBeforeFetch
 * @param createFolders
 * @param buildIfChanges
 * @param fetchDestination
 * @param pipelineName
 * @param includeFiles
 * @param excludeFiles
 * @param deliveryEnabled
 * @param deployEnabled
 * @param componentName
 * @param applicationName
 * @param appProcess
 * @param devEnvironment
 * 
 * @return a Map containing parameter/value pairs
 * 
 */
@NonCPS
def call(def buildDefinitionName, def workspaceUUID,def projectArea,def excludeComponents,def deleteDest,def acceptBeforeFetch,
		def createFolders,def buildIfChanges, def fetchDestination,def pipelineName,
		def includeFiles,def excludeFiles,def deliveryEnabled,def deployEnabled, def componentName,
		def applicationName,def appProcess,def devEnvironment) {

	def fields = ["buildDefId=${buildDefinitionName}",
		"wsName=${workspaceUUID}",
		"projectArea=${projectArea}",
		"excludeComponents=${excludeComponents}",
		"deleteDest=${deleteDest}",
		"acceptBeforeFetch=${acceptBeforeFetch}",
		"createFolders=${createFolders}",
		"buildIfChanges=${buildIfChanges}",
		"fetchDestination=${fetchDestination}",
		"pipelineName=${pipelineName}",
		"includeFiles=${includeFiles}",
		"excludeFiles=${excludeFiles}",
		"deliveryEnabled=${deliveryEnabled}",
		"deployEnabled=${deployEnabled}",
		"componentName=${componentName}",
		"applicationName=${applicationName}",
		"appProcess=${appProcess}",
		"devEnvironment=${devEnvironment}"
		]
		return fields
}




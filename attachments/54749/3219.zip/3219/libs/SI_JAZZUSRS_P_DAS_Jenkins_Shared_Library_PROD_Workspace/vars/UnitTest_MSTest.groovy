#!/usr/bin/env groovy
// 176851

/**
 * @param testFiles 	[String] (required) A .sln file -or- space-delimited list of .dll test files
 * @param testNames 	[String] (optional) A COMMA-delimited list of test-cases to run
 * @param testListFile 	[String] (optional) A text file containing NEWLINE-delimited list of test-cases to run
 * @param testQuery		[String] (optional) A nUnit query expression to select a subset of test cases
 * @param openCoverFilter [String] (optional) the OpenCover filter for MSTest
 *
 * @return command [String] - A bat-structured command for the calling pipeline to execute.
 */
def call(String testFiles = '', String testNames = '', String testListFile = '', String testQuery = '', String openCoverFilter = '') {
//def call() {	

	def gv = bcbst.das.GlobalVars;
	
	String methodName = 'DJSL -> UnitTest_MSTest()';
	echo methodName + ' :: Building OpenCover command for MSTest';

	// set default MDTest OpenCover filter if one is not provided
	if (openCoverFilter == '') { 
		openCoverFilter = gv.OPENCOVER_FILTER_VSTEST;
	} else {
		if (!openCoverFilter.startsWith(' ')) { 
			// make sure that OpenCover's -filter argument has a space in front! 
			openCoverFilter = ' ' + openCoverFilter;
		}
	}
	
	// if invalid, error will be thrown in the validator
	String msTestArgs = validateTestFiles(testFiles.trim());
	
	// test names, testlist file, and where clause are all optional
	// and mutually exclusive
	if (testNames.trim() != '') {
		// cannot contain space - validator will throw an error
		msTestArgs = msTestArgs + ' --Tests:' + validateTests(testNames);
	} else if (testListFile.trim() != '') {
		msTestArgs = msTestArgs + ' --testlist:' + testListFile;
	} else if (testQuery.trim() != '') {
		msTestArgs = msTestArgs + ' --where:' + testQuery;
	}
	
	// build command from various parts and arguments
	String msTestCmd = gv.OPENCOVER_EXE + gv.OPENCOVER_ARGS + openCoverFilter + ' "-target:' + "${tool 'VSTest_15'}" + '" "-targetargs:' + msTestArgs + ' ' + gv.VSTEST_ARGS + '"';
	
	// log the command (helpful for troubleshooting)
	echo methodName + ' :: Returning OpenCover command (MSTest target): ' + msTestCmd;
	
	// and return as string to the pipeline
	return msTestCmd;
}

/**
 * Accepts string containing a .sln file or a space-delimited list of .dll test files.
 *
 * @param testFiles [String]
 * @return testFiles [String]
 * @throws error (validation)
 */
def validateTestFiles(String testFiles = '') {
	echo 'DJSL -> UnitTest_MSTest() -> validateTestFiles() :: Validating argument: testFiles -> "' + testFiles + '"';
		
	if (testFiles.endsWith('.sln')) return testFiles;
	if (testFiles.contains('.dll')) return testFiles;
	
	error('DJSL -> UnitTest_MSTest() -> validateTestFiles() :: Invalid argument: testFiles -> "' + testFiles + '" '
		+ ' -> This must contain a .SLN file or a space-delimited list of .DLL test files.');
}

/**
 * Accepts string containing a comma-delimited list of test names to run.
 *
 * @param testNames [String]
 * @return testNames [String]
 * @throws error (validation)
 */
def validateTests(String testNames = '') {
	echo 'DJSL -> UnitTest_MSTest() -> validateTests() :: Validating argument: testNames -> "' + testNames + '"';
		
	if (!testNames.contains(' ')) return testNames;
	
	error('DJSL -> UnitTest_MSTest() -> validateTests() :: Invalid argument: testNames -> "' + testNames + '" '
		+ ' -> This is a COMMA-delimited list of tests - it cannot contain a space.');
}

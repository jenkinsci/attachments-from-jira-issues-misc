#!/usr/bin/env groovy
// 176851

/**
 * 
 * @param loadDir the rtc load directory
 * 
 * @return String whether to run npm install or npm ci based on config
 *
 */
String call(def loadDir = "") {
    echo "DSL->Check_NPM_Config()"
	/* Ensure a valid reference to lock file (package-lock.json || npm-shrinkwrap.json) exists */
	echo "Checking for dependency lock-file in loadDirectory"
	def shrinkwrap = fileExists "${loadDir}/npm-shrinkwrap.json"
	def packagelock = fileExists "${loadDir}/package-lock.json"
	if (shrinkwrap) {  // npm-shrinkwrap.json has higher precedence, use it first (if exists)
		echo "Lock-file found: (npm-shrinkwrap.json) --> Proceeding to resolve dependencies"
	} else if (packagelock) {  // use package-lock.json if exists
		echo "Lock-file found: (package-lock.json) --> Proceeding to resolve dependencies"
	} else {
		echo "* ****************** WARNING *******************\n" +
			"* A valid dependency lock file is required for deterministic builds.\n" +
			"* Please ensure either of package-lock.json or npm-shrinkwrap.json exists at the path\n" +
			"* specified by loadDirectory before performing a check-in.\n" +
			"* ---> Run 'npm install --lock-file', or more preferably 'npm shrinkwrap', to generate a lock file." +
			"* Running npm install"
		return "install"
	}
	echo "Running a clean slate install ---> 'npm ci'"
	return "ci"
}



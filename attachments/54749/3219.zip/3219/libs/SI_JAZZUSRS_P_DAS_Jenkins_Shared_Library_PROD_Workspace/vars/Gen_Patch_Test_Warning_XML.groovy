import bcbst.das.ALMTestParams

/**
 * Generates warning XML indicative of why a test could not be run. Useful for capturing detailed errors at any point in the pipeline. 
 *
 * @param warning A string containing the type of xml warning to generate for Portal. Value can be one of 'dry_run_success', node_not_found', 'node_offline', 'exception', 'test_execution_failed', 'invalid_params, or the default 'execution_undefined'.
 * @param almParams An instance of ALMTestParams containing test parameter values.
 * @return string containing XML
 **/
String call(String warning, ALMTestParams almParams = null) {
    if (IsDebug()) println "DJSL -> String Gen_Patch_Test_Warning_XML()";
    String msg = null;
    switch (warning) {
        case 'dry_run_success' : 
            msg = 'Dry run completed successfully';
            break;
        case 'node_not_found' :
            msg = 'Server not found for application';
            break;
        case 'node_offline' :
            msg = 'Server is currently offline';
            break;
        case 'test_execution_failed' :
            msg = 'ALM test failed to execute';
            break;
        case 'invalid_params' : 
            msg = 'One or more alm test params are invalid';
            break;
        case 'exception' :
            msg = 'An exception occurred in Jenkins, and the operation cannot be completed';
            break;
        default :
            warning = 'execution_undefined';
            msg = 'Execution undefined. Contact DAS for more information';
    }
    StringBuilder sb = new StringBuilder();
    sb.append("<?xml version=\"1.0\"?>");
    sb.append("<no_test>\r\n");
    sb.append("<warning>${warning}</warning>");
    sb.append("<msg>${msg}</msg>");
    if (almParams) {
        sb.append("<almParams>${almParams.toXmlString()}</almParams>");
        sb.append("<almParamsToString>${almParams.toString()}</almParamsToString>");
    }
    sb.append("</no_test>");
    return sb.toString();
}
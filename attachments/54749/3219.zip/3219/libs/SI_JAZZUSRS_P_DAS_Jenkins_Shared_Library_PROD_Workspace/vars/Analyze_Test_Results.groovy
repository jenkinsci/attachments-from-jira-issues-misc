#!/usr/bin/env groovy
// 176851

/**
 * Calculate test pass percentage and return success/unstable/fail based on percentage
 * 
 * @param resultsList	[List] (required)
 * @param successTH	[int] (required) success threshold
 * @param unstableTH [int] (required) unstable threshold
 *  
 * @return status 	[String] - success/failure/unstable
 *
 */
 
def call(def resultsList, int successTH=0, int unstableTH=0) {
	def total= resultsList[0][1]?.toInteger()
	if (total == 0) { return "SUCCESS" }
	int passing= resultsList[0][2]?.toInteger()
	int failing= resultsList[0][3]?.toInteger()
	float passpct = ((float) passing)/total*100
	echo "Passing: ${passing}, Failing: ${failing}, percent pass ${passpct}"
	if (passpct >= successTH) {
        echo "Analyze Test Results->Success "+ passpct.toString()
		return 'SUCCESS'
	} else if (passpct > unstableTH) {
        echo "Analyze Test Results->Unstable"+ passpct.toString()
		return 'UNSTABLE'
	} else {
        echo "Analyze Test Results->Failure"+ passpct.toString()
		return 'FAILURE'
	}
}




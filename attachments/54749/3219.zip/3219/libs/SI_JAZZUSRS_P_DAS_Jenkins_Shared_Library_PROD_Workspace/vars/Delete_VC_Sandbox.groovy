/** 
* Deletes a Veracode Sandbox
* 
* @param sandboxId - the sandbox to be deleted
* 
**/
def call(String sandboxId, String appId) {
    echo "DSL->Delete VC Sandbox"
    def serviceAccount = (jenkinsEnvironment=="TEST")? "SI_JENKINS_T_ESCAPED":"SI_JENKINS_P"
    try {
        withCredentials([usernamePassword(credentialsId: serviceAccount, passwordVariable: 'pd', usernameVariable: 'uid')]) {
            def listcmd = "http --proxy=https:https://%uid%:%pd%@webproxy.bcbst.com:80 --auth-type=veracode_hmac \"https://analysiscenter.veracode.com/api/5.0/getsandboxlist.do\" \"app_id==${appId}\""
            def output = bat returnStdout:true, script:listcmd
            def outputlist=[]
            outputlist = output.split('\n') as List
            def i=0
            outputlist.subList(0,2).clear()
            output = outputlist.join('\n')
            if (IsDebug()) echo output
            def rootNode = new XmlSlurper()
            rootNode = rootNode.parseText(output)
            def curSand=""
            def httpcmd=""
            if (rootNode.sandbox.size()>3) {
                for (i=0; i<=rootNode.sandbox.size()-4; i++) {
                    curSand = rootNode.sandbox[i].@sandbox_id.text()
                    httpcmd = "http --proxy=https:https://%uid%:%pd%@webproxy.bcbst.com:80 --auth-type=veracode_hmac \"https://analysiscenter.veracode.com/api/5.0/deletesandbox.do\" \"sandbox_id==${curSand}\""
                    output2 = bat returnStdout:true, script:httpcmd
                    if (IsDebug()) echo output2
                    echo "Deleted Sandbox ${curSand}"
                    
                }
            }
//            rootNode.buildDefinition.eachWithIndex { buildDefinition , i ->
//                
//            }
            
        } //withCredentials
    } catch (e) {
        echo "ERROR: ${e.message}"
    }
}
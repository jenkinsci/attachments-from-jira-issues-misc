#!/usr/bin/env groovy
// 176851

/**
 * Perform unit testing on MSBuild processes using the build definition parameters
 * 
 * @param nUnitDLLName nunit dll name
 * @param nUnitNames 
 * @param nUnitListFile 
 * @param nUnitQuery 
 * @param nUnitFilter 
 * @param msTestDLLName MSTest dll name
 * @param msNames
 * @param msListFile 
 * @param msQuery 
 * @param msFilter 
 * 
 *
 */
 
void call(def nUnitDLLName="", def nUnitNames="", def nUnitListFile="", def nUnitQuery="", def nUnitFilter="",
	     def msTestDLLName="",def msNames="", def msListFile="", def msQuery="", def msFilter="") {

    echo "DSL->MSBuild_UnitTest()"
 	parallel ( "NUNIT": {
		if (nUnitDLLName != ""){
			def nUnitCmdLine = UnitTest_NUnit(nUnitDLLName,nUnitNames,nUnitListFile,nUnitQuery,nUnitFilter)
			bat nUnitCmdLine
		} else {
	    	echo "No NUnit tests"
		}
	}, // end parallel step 1
	"MSVSTEST": {
		if (msTestDLLName != ""){
            try {
                def msTestCmdLine = UnitTest_MSTest(msTestDLLName,msNames,msListFile,msQuery,msFilter)
                bat msTestCmdLine
            } catch(e) {
                echo "Could not run VSTest: ${e.message}"
            }
		} else {
		   	echo "No MSTests"
		}
	}) // end parallel step 2}
}



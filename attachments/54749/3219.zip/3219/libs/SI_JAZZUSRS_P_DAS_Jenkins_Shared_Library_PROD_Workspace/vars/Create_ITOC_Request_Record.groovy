#!groovy
/**Creates a record for the ITOC Smoke tests on DAS_MASTER_DVLP
*
* @param jobName		[String] (required)	used to identify the name of the job
* @param status			[String] (required) identifies the status of the job
* @param applicationName[String] (required) the application name
* 
* @return the database result
*
*/
 
 def call(def appList){
	 echo "DJSL->Create_ITOC_Request_Record()"
	 def dbReturnValue = null
	 def dbAcct = (jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "SQ_DASUcd_P" : "SQ_DASUcd_T"
	 def dbServer = (jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "wprc2211": "wnrc0811"
	 def dbDatabase = (jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "DAS_MASTER": "DAS_MASTER_DVLP"
	try {
 	withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: dbAcct, usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
		 dbReturnValue = bat(returnStdout: true, script:"cmd /c \"\"C:\\Program Files\\Microsoft SQL Server\\Client SDK\\ODBC\\130\\Tools\\Binn\\SQLCMD.EXE\" -S ${dbServer} -U %USERNAME% -P \"%PASSWORD%\" -Q \"EXEC ${dbDatabase}.dbo.SP_ITOC_CreateRequestRecord @pApplication='${appList.toString()}', @pRequesterID='${userId}', @pLibraryWorkspaceName='${libraryWorkspaceName}',@pStatus='running', @pEnvironment='${appEnvironment}', @pPatchset='${patchGroup}', @pServer='${server}', @pDry='${IsDryRun()}', @pDebug='${IsDebug()}'\" -h -1 -o dbReturn.txt 2> dbITOCErr.txt\"")
		 dbReturnValue= readFile('dbReturn.txt').trim()
		 if (fileExists("dbITOCErr.txt")){
		 def err = readFile('dbITOCErr.txt').trim()
		if ( err.contains("Error")){
		throw new Exception( err)
		}}
    }} catch (Exception ex){
	if (fileExists("dbITOCErr.txt"))
	{
	def err = readFile('dbITOCErr.txt').trim()
    env.errorMsg = err
	echo err
	bat(returnStdout: false, script: "DEL dbITOCErr.txt")
	}
	echo ex.getMessage()
	Send_Error_Email('Derald_Rogers@bcbst.com','Internal Jenkins Error - Create_ITOC_Request_Record')
	}
	return dbReturnValue
 }
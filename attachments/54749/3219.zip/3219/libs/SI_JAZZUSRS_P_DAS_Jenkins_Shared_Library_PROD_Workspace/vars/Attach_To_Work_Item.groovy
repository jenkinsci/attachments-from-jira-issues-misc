#!/usr/bin/env groovy
// 176851

/**
 * Attach file to one or more work items
 *  
 *  @param projectAreaName the name of the project area
 *  @param idString the work item id
 *  @param fileName the name of the file to attach
 *  
 * @return result (Integer)
 *
 */
 
def call(def projectAreaName, def idString, def fileName) {
    println "DSL->Attach_To_Work_Item()"
    try {
            if (idString=="") {
                // read work items from file if idString is blank
                idString = readFile("das/workitems.txt")
            }
            if (env.personalBuild=="true") external = "true"
            withCredentials([usernamePassword(credentialsId:'SI_JAZZUSRS_P', passwordVariable: 'pwd', usernameVariable:'uid')]) {
                env.RTC_USER_ID='SI_JAZZUSRS_P'
                env.RTC_PASSWORD=pwd
                def outPt = Run_Groovy_Script("das/Upload_Work_Item_Attachment.groovy", "\"%uid%\" \"%pwd%\" \"${projectAreaName}\" \"${idString}\" \"${fileName}\"", true, true)
                sleep time:10, unit:'SECONDS'
                if (IsDebug()) println outPt
                return idString
            }
    } catch (e) {
            echo "Could not attach file to work item (probably didn't have one attached to the change): ${e.message}"
            return ""
    }

}




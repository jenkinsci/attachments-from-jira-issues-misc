/** 
 * 
 * Creates incidents in SDM via the REST API for failed smoke tests
 *
 * @param appName [string] (required) The application name or names
 * @param envName [string] (required) The application environment being tested
 * @param descriptionString [string] (required) The description of the test and failures
 */

def call(def appName, def envName, def failedTests) {
	echo "DJSL-> Create_Performance_Incident(def appName, def descriptionString, boolean useTest = true)"
	if (params.incidentCreation == true) {
		def sdmApi = (envName.equalsIgnoreCase('PROD') && jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "http://sdmws.bcbst.com:8050/caisd-rest/in" : "http://sdmtest.bcbst.com:8050/caisd-rest/in"
		def sdmAcct = (envName.equalsIgnoreCase('PROD') && jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "SI_DASSdm_P" : "SI_DASSdm_T"
		def response = null
		def descriptionString = "Performances tests failed in application ${appName}.  See Activity Log for more detail."
		def xmlParser = new XmlSlurper();
		if ((jenkinsEnvironment.equalsIgnoreCase('PROD') && envName.equalsIgnoreCase('PROD') || (jenkinsEnvironment.equalsIgnoreCase('TEST') && envName.equalsIgnoreCase('NONPROD')) { 
			try {
    			def accessXML = Get_SDM_API_Access(sdmAcct)
    			def accessObj = xmlParser.parseText(accessXML)
    			def incidentXML = "<in><customer COMMON_NAME=\"System_Delivery_Automation_Services\"/><description>${descriptionString}</description><group COMMON_NAME=\"ITOC-IT OPERATIONS CENTER\"/><affected_resource COMMON_NAME=\"Non-CI\"/><zinquiry_type COMMON_NAME=\"Automated Alert\"/><affected_resource COMMON_NAME=\"Non-CI\"/><category COMMON_NAME=\"Software.Performance\"/><requested_by COMMON_NAME=\"System_Delivery_Automation_Services\"/></in>"
    			def access = accessObj["access_key"].toString()
    			if (IsDebug()){
    				echo incidentXML
    			}
    			response = httpRequest httpMode:'POST', url: "${sdmApi}", requestBody: incidentXML, customHeaders: [[name: "Content-Type", value: "application/xml"],[name:"Cache-Control",value:"no-cache"], [name:"x-obj-attrs", value:"ref_num"],[name: "X-AccessKey", value: access]]
    			if (IsDebug()) {echo response.content} 
    			def createdIncidentXML = xmlParser.parseText(response.content)
    			def incidentCRId = createdIncidentXML.attributes()['REL_ATTR'].toString();
    			failedTests.each{ failure ->
    				Create_Incident_Comment(incidentCRId,access,failure)
    			}
			} catch(Exception ex){
				echo "Exception in Create_Performance_Incident -> ${ex}"
				if (response != null) {
					echo "STATUS: ${response.status}"
					echo "CONTENT: ${response.content}"
				}
			}
		}
	}
}
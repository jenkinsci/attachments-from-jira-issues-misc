#!/usr/bin/env groovy
// 198354
/**
 *
 * @param buildDefId the name of the build definition ID
 *
 * @return String The uuid of the build definition
*/
String call(def buildDefId = "") {
    echo "DSL->Get_Build_Props()"
    def props=""
    if (fileExists("das/properties.txt")) {
        props = readFile("das/properties.txt")
//        fileOperations([fileDeleteOperation(excludes: '', includes: 'das/properties.txt')])
        if (IsDebug()) {echo "Get_Build_Props-> ${buildDefId} = ${props}"}
    }
    return props
}
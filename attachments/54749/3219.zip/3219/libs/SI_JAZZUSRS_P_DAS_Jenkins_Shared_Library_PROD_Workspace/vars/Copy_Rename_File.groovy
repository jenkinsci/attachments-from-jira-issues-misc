import hudson.Functions
/** 
* Copies a file.
* 
* @param sourcePath The path to the file to be copied
* @param targetPath The path to the new file
* @return 0 if successful, or 1 for error.
**/
int call(String sourcePath, String targetPath) {
    echo "DSL->Copy_Rename_File()"
    int exitCode = 1;
    try {
        if (fileExists("${sourcePath}")) {
            String data = readFile([
                file: "${sourcePath}"
            ]);
            writeFile([
                file: "${targetPath}",
                text: data
            ]);
            exitCode = 0;
        }
    } catch (Exception e) {
        StringBuilder sb = new StringBuilder();
        sb.append("* * * * * * ERROR EXECUTING PERFORMANCE TEST * * * * * *\n");
        sb.append("Method: Copy_Rename_File\n");
        sb.append("Message: Unable to copy and rename file ${sourcePath} to ${targetPath}.\n");
        sb.append("${Functions.printThrowable(e) }");
        println sb.toString();
    } finally {
        return exitCode;
    }
}
#!groovy
/**
 * Report results of nunit testing
 *
 */

def call() {
	try {
        echo "DSL->Report_Nunit_Results()"
		nunit testResultsPattern:'**/nunit2-results.xml', failIfNoResults: false
        def cases = Get_Unit_Test_Stats()
		bat "F:/ProgramFiles/ReportGenerator/net47/ReportGenerator.exe -reports:build-results/opencover-coverage.xml -targetDir:build-results/CodeCoverageHTML" 
		publishHTML (target: [
			allowMissing:true,
			alwaysLinkToLastBuild:false,
			keepAll:true,
			reportDir: 'build-results/CodeCoverageHTML',
			reportFiles: 'index.htm',
			reportName: 'NUnit Coverage'
		])
        return cases
	} catch (e) {
			echo "Couldn't find Nunit Results"
            return []
	}
}

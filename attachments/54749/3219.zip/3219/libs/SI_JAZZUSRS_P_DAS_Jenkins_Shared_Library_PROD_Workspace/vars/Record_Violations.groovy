#!/usr/bin/env groovy
// 176851

/**
 * Check for binaries, unauthorized scripts, and object directories in the source.
 *  
 * @param naughty the naughty list
 * @return numViolations 	[Integer] - The number of compiled/packaged files found on the server pre-build
 *
 */
 
def call(def naughty = null) {
    echo "DSL->Record_Violations()"
	if (naughty) {
		echo "Some policy violations found."
		def offensiveFiles=""
		naughty.each {
			offensiveFiles+="- ${it}\n"
		} //each
		fileOperations([fileCreateOperation(fileContent:offensiveFiles, fileName: "binaries_detected.txt")])
		offensiveFiles=""
		return naughty.size().toString()
	} else {
		return "0"
	}
}
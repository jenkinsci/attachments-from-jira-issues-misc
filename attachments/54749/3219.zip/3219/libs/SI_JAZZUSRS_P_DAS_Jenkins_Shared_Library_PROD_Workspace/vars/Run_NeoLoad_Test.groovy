/**
*   Run NeoLoad performance tests
* @param appName  the ALM domain
* @param envName the ALM project name
* @param serverName the NeoLoad server name
* @param resultsFile    the path to the test set
* @param NLX the neoload executable
* @param scenario 
* 
* @return status 0 or 1
* 
*/

def call(def appName, def envName, def serverName, String resultsFile, def NLX, def scenario){
    echo "Performance test Started for: ${appName}"
    //Executes NeoLoad tests
    neoloadRun executable: NLX,
        project: [server: serverName,
        name: "${appName}_${envName}",
        publishTestResult: false],
        //-exitCodeFailIgnore will help continue the build execution even if one of the application failed SLA
        commandLineOption: "-exportRaw ${WORKSPACE}\\performance-report\\${appName}_${envName}_rawresults.xml -exitCodeFailIgnore",
        scenario: scenario,
        sharedLicense: [server: serverName, duration: 2, vuCount: 50],
        autoArchive: 'false' // by default the plugin runs archiveArtifacts
    sleep 30 // 30 sec. Enough time to complete building the NeoLoad artifacts
    def content = readFile("${WORKSPACE}\\performance-report\\${appName}_${envName}_rawresults.xml")
    def readContent = readFile "${resultsFile}"
    //Read SLA status from report.xml file
    int SLA = 1
    def xml = readFile "${WORKSPACE}\\neoload-report\\report.xml"
    xml.split('status="').each {
        if (SLA == 2) {
            int status = 1
            SLAStatus = "${it}"
            SLAStatus.split('" std_start_time').each {
                if (status == 1) {
                    //Capture Fail or Pass SLA status for the whole project
                    SLAStatusFinal = "${it}"
                    echo "Performance SLA: ${it}"
                }
                status++
            } // for each sla status split value
        } // if SLA is 2
        SLA++
    }
    return SLAStatusFinal
}
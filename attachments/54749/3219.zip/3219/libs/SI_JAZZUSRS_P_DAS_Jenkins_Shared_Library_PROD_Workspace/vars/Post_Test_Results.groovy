#!/usr/bin/env groovy
// 356637

/**
 * Sends data to ITOC Portal as XML string, either containing ALM test results
 * or XML consumable by ITOC Portal indicative of failure. If sessionId is 
 * missing or undefined/null, execution is short-circuited.
 * 
 * @param resultsMap Map containing appNames/testResults as keys/values
 * 
 * @return int containing response.status 
 **/

int call(String jsonStr) {
    println "DJSL-> Post_Test_Results()"
    println 'Sending test results to ITOC Portal via HTTP POST'
    def status = -1;
    withCredentials([string(credentialsId: "portalAuthKey", variable: 'portalAuth')]) {
        def response = httpRequest consoleLogResponseBody: true,
            customHeaders: [[maskValue: true, name: 'itoc-portal-api', value: portalAuth.bytes.encodeBase64().toString()]],
            contentType: 'APPLICATION_JSON',
            httpMode: 'POST',
            ignoreSslErrors: true,
            requestBody: "${jsonStr}",
            responseHandle: 'NONE',
            url: "https://${portal_host}:8001/patchTestResults",	// pipeline param
            wrapAsMultipart: false
        status = response.status;
    }
    return status;
}
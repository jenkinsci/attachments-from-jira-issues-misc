#!groovy
/**
 * Get application version from pom file
 *
 * @param workingDir current working directory
 * @param pomXml the pom.xml filename
 * @param ver the version
 *
 * @return String maven version
 *
 */
import groovy.json.JsonSlurperClassic;

String call(def workingDir, def pomXml, def ver="1.0.0") {
    echo "DSL->Get_Maven_Version()"
	def versionFile = "${workingDir}/${pomXml}"
	if (fileExists(versionFile)) {
		def pomInfo = readFile "${versionFile}"
		def newVer = getMavenData(pomInfo)
        echo "Maven Data is ${newVer}"
		if ((ver == "" || ver == "1.0.0") && newVer) {
			return newVer
		} else {
			return "1.0.0"
		}
	} else { //no valid pom file
		echo "POM file not found!"
	}
    return "1.0.0"
}
/**
 * Get application data and see if it matches with version patterns
 *
 * @param assInfo the text contents of the pom file
 *
 * @return matched version
 *
 */
@NonCPS
String getMavenData(def assInfo) {
	def pattern = ~/<version>(.*)<\/version>/
	def match = pattern.matcher(assInfo)
	echo "Match size is "+ match.size()+", match count is "+match.getCount()
	if (match.size() > 0) {
		def gMinusOne=match.getCount()-1
		return match[0][1].toString()
	}
	return "1.0.0"
}

	
import net.sf.json.JSONObject
/** 
* Reads all test files from ALM and NeoLoad
* 
* @param appsJsonArray The apps being tested, parsed from root.apps in servers.json
* @param nodeName the label of the Jenkins node running the test
* @return map containing combined test results from ALM, NeoLoad
**/
LinkedHashMap call(ArrayList<JSONObject> appsJsonArray, String nodeName="neoload") {
    if (IsDebug()) println "DJSL->Read_Test_Result_Files()";
    XmlSlurper slurper = new XmlSlurper();
    LinkedHashMap ret = [
        "sessionId" : (params.sessionId.isEmpty()) ? null : params.sessionId,
        results : [:]
    ];
    String almDestFolder = "${env.WORKSPACE}\\${env.BUILD_ID}\\automation-tests";
    groovy.util.slurpersupport.NodeChild perfXml = null;
    
    if (params.performance == true) {   // read nl test files on performance node (only one perf result)
        node (nodeName) {
            String filePath = "${env.WORKSPACE}\\${env.BUILD_ID}\\neoload-results\\junit-sla-combined-results-${env.BUILD_ID}.xml";
            if (fileExists(filePath)) {
                perfXml = slurper.parseText(readFile(filePath));
            }
        }
    }
    appsJsonArray.each { app ->     // read alm test files on worker node (possibly many automation results)
        LinkedHashMap perfResults = null;
        JSONObject almResults = null;
        if (params.performance == true) perfResults = readPerfResults(perfXml, app.name);
        if (params.automation == true) almResults = readJSON file: "${almDestFolder}\\alm-results-${app.name}_${env.BUILD_ID}.json";
        LinkedHashMap combined = [automation : almResults, performance : perfResults];
        ret.results.put("${app.name}", combined);
    }
    return ret;
}


/** 
* Helper method to read performance test results
* @params xmlRoot The root xml node to be searched for a named testsuite child node.
* @params name The name of the application to match with a testsuite child node.
* @return null if not found, or the testsuite node having a matching name attribute. 
**/
LinkedHashMap readPerfResults(groovy.util.slurpersupport.NodeChild xmlRoot, String name) {
    try {
        LinkedHashMap map = [results : [:]];
        if (xmlRoot.name() == "no_test") {
            map.results.no_test = [:];
            xmlRoot.childNodes().each { it -> map.results.no_test.put(it.name(), it.text())};
        } else {
            groovy.util.slurpersupport.Node testSuite = xmlRoot.childNodes().find {it.attributes().name =~ /(?i)$name/ };
            if (testSuite != null) {
                testSuite.childNodes().each { testCase -> 
                    map.results.put("${testCase.attributes().name}", testCase.attributes().result);
                }
            } else throw new Exception("Unable to locate test results for ${name}.")
        }
        return map;
    } catch (e) {
        println e;
        return null;
    }
}
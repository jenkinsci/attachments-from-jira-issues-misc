import hudson.Functions
import net.sf.json.JSONArray
import groovy.json.*
import bcbst.das.ALMTestParams
/**
* Run patch tests, including automation and performance (if enabled).
* @param apps Application JSON, most likely framework.root.apps
* @param appNames A list of application names
* @param envName The name of the environment to test, such as Prod or NonProd
* @return none
**/

int call(JSONArray apps, ArrayList<String> appNames, String envName, String serverName) {
    int errorCode = 0;
    try {
        stage('Testing') {
            def serverList=[ test_server : serverName.split(',')[0], prod_server : serverName.split(',')[1] ]
            if (IsDebug()) {
                println "DJSL -> Run_Patch_Tests(JSONArray apps, ArrayList<String> appNames, String envName, String serverName)";
                println "[DEBUG] param -> apps (json): ${apps}";
                println "[DEBUG] param -> appNames (names): ${appNames}";
                println "[DEBUG] param -> envName: ${envName}";
                println "[DEBUG] param -> almNodes: ${serverName}";
            } 
            def nodeId = (jenkinsEnvironment=='PROD') ? ((envName=="NonProd") ? serverList['test_server'] : serverList['prod_server']) : "ITOC_NonProd_WN002447";
            def testAppsJson = apps.findAll { app -> appNames.contains(app.name) } // Reduce JSON to only the apps we are testing:
            def parallelStagesMap = [:];

            // Patch test parallel execution
            if (params.automation == true) {    // Prepare parallel execution for automation tests
                testAppsJson.each { appObj -> 
                    appObj['nodeName']= (envName=="NonProd") ? serverName.split(',')[0] : serverName.split(',')[1]
                    def almParams = new ALMTestParams(appObj,envName)                        
                    parallelStagesMap.put("${almParams.appName}", Run_Automation_Test_Parallel(almParams));
                }
            }
            if (params.performance == true && testAppsJson.size() > 0) {   // Prepare parallel execution for performance tests
                def performanceNode = (envName=="NonProd") ? "neoload_test":"neoload"
                parallelStagesMap.put("Performance", Run_NeoLoad_Test_Parallel(testAppsJson, envName, performanceNode));
            }
            parallel parallelStagesMap; // Execute

            // Combine *all* test results into single file
            def combinedFinalResults = Read_Test_Result_Files(testAppsJson, nodeId);
            def json = JsonOutput.toJson(combinedFinalResults);
            String savePath = "${env.WORKSPACE}\\${env.BUILD_ID}\\combinedFinalResults_${env.BUILD_ID}.json";
            writeFile(file:savePath, text:json);
            if (IsDebug()) println "[DEBUG] Saving combined final results file to: ${savePath}";
        }
    } catch (Exception e) {
        println Functions.printThrowable(e);
        errorCode = 1;
    } finally {
        return errorCode;
    }
}
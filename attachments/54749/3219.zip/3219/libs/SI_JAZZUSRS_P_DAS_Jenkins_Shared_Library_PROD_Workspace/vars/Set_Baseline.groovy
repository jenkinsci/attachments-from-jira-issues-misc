#!/usr/bin/env groovy
// 176851

/**
 * Set the baseline name of the workspace to a text value.
 *  
 * @param ws the name of the workspace in which to set the component baseline
 * @param comp the name of the component to set the baseline for
 * @param base the name of the baseline you wish to make current
 * @param libWS shared library workspace name
 *
 */
 
def call(def ws, def comp, def base,def libWS) {
    echo "DSL->Set_Baseline()"
    Checkout_RTC_WS(libWS, 'DAS_Jenkins_Shared_Library/baselines.loadrule')
    withCredentials([usernamePassword(credentialsId:'SI_RPTUSER_P', passwordVariable: 'pwd', usernameVariable:'uid')]) {
        Run_Groovy_Script("das/Set_Workspace_Baseline.groovy","\"%uid%\" \"%pwd%\" \"${ws}\" \"${comp}\" \"${base}\"", true, true)
        sleep time:15, unit:'SECONDS'
    }
}		
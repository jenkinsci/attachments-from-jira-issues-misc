/** Creates incidents in SDM via the REST API for failed smoke tests
 *
 * @param testXML the test data
 * @param almParams instance of ALMTestParams 
 * @param useTest whether to use test sdm
 */

def call(def testXML, def almParams, def recId) {
	echo "DJSL-> Create_Automation_Incident(def testXML, def almParams, def recId)";
	def response = null;
	try {
		// Get the test results
		def xmlParser = new XmlSlurper();
		def testResult = xmlParser.parseText(testXML);
		if (IsDryRun()) {
			echo "testXML : ${testXML}";
			if (testXML.toString().contains("dry_run_success")) Update_ITOC_Request_Record(recId, "SUCCESS");
			else Update_ITOC_Request_Record(recId, "FAILURE");
		}
		else if (testResult?.testsuite) {
			// Update the request record if the request passed or failed
			def recStatus = (testResult.testsuite['@failures'].toString().toInteger() > 0) ? "FAILURE":"SUCCESS"
			Update_ITOC_Request_Record(recId, recStatus)
			//Create records for request in the database
			Create_ITOC_Records(testXML, recId, almParams.appName)

			if (params.incidentCreation == true) {
				//See if there are any failed tests, and if so create an incident describing the application and failed tests
				if (testResult.testsuite['@failures'].toString().toInteger() > 0) {
					def sdmApi = (almParams.envName.equalsIgnoreCase('PROD') && jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "http://sdmws.bcbst.com:8050/caisd-rest/in" : "http://sdmtest.bcbst.com:8050/caisd-rest/in"
					def sdmAcct = (almParams.envName.equalsIgnoreCase('PROD') && jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "SI_DASSdm_P" : "SI_DASSdm_T"
					def accessXML = Get_SDM_API_Access(sdmAcct)
					accessObj = xmlParser.parseText(accessXML)
					def access = accessObj["access_key"].toString()
					descriptionString = "Smoke tests for ${almParams.appName} has ${testResult.testsuite['@failures'].toString()} failures. See Activity Log for more detail."
					incidentXML = "<in><customer COMMON_NAME=\"System_Delivery_Automation_Services\"/><description>${descriptionString}</description><group COMMON_NAME=\"ITOC-IT OPERATIONS CENTER\"/><affected_resource COMMON_NAME=\"Non-CI\"/><zinquiry_type COMMON_NAME=\"Automated Alert\"/><affected_resource COMMON_NAME=\"Non-CI\"/><category COMMON_NAME=\"Software.Performance\"/><requested_by COMMON_NAME=\"System_Delivery_Automation_Services\"/></in>"
					if (IsDebug()){
						echo "incidentXML : ${incidentXML}"
					}
					response = httpRequest httpMode:'POST', url: "${sdmApi}", requestBody: incidentXML, customHeaders: [[name: "Content-Type", value: "application/xml"],[name:"Cache-Control",value:"no-cache"], [name:"x-obj-attrs", value:"ref_num"],[name: "X-AccessKey", value: access]]
					if (IsDebug()) {
						echo "Incident creation http response: ${response.content}"
					} 
					def createdIncidentXML = xmlParser.parseText(response.content)
					testResult.testsuite.testcase.each {
						if (it['@status'].toString() == "fail") {
							Create_Incident_Comment(createdIncidentXML.attributes()['REL_ATTR'].toString(), almParams.envName, access, "${it['@name']} failed in class ${it['@classname']}\n")
						}
					}
				}
			}
		}
	} catch(Exception ex){
		if (params.incidentCreation == true) Update_ITOC_Request_Record(recId, "ERROR");
		echo "EXCEPTION: " + ex.getMessage()
		if (response != null) {
			echo "STATUS: ${response.status}"
			echo "CONTENT: ${response.content}"
		}
	}
}
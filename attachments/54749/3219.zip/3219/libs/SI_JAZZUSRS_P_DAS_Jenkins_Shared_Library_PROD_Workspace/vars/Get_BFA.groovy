#!/usr/bin/env groovy
// 176851

/**
 * Get a build failure analysis result
 *  
 * @return bfa 	[List of Strings] - The build failure results
 *
 */
 
def call() {
    if (IsDebug()) echo "DSL->Get_BFA()"
	String bfaResult = tm('${BUILD_FAILURE_ANALYZER, noFailureText="NO FAILURE CAUSE FOUND"}')
	try {
		bfaResult = bfaResult.replaceAll('Indication \\d:',' ')
	} catch (e) {
		echo e.message
	}
	return bfaResult
}




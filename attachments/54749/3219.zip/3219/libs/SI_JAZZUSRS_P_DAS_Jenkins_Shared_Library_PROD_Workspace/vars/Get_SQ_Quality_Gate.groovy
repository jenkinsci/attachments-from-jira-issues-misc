#!groovy
/**
 * Get Sonarqube quality gate name.
 *
 * @param sqProjectKey the sonarqube project key
 *
 * @return gateName [Object] - Sonarqube quality gate type
 *
 */
import groovy.json.JsonSlurperClassic;


def call(def sqProjectKey) {
echo "DSL->Get_SQ_Quality_Gate"
// variable declarations
def jsonData;

// API URLS
String sqUrlBase=""
withSonarQubeEnv("BCBST Sonarqube") {
 sqUrlBase="$SONAR_HOST_URL";
}

// metrics api
String sqApiMetrics="/api/qualitygates/get_by_project?project="

// urls
String metricsUrl = sqUrlBase + sqApiMetrics + sqProjectKey


//https://sonarqube.bcbst.com/api/project_analyses/search?project=ASQ_SLMTools_FLB_CLICalculator

/**
 * START METRICS REQUEST
 */
response= httpRequest(httpMode:'GET', authentication: 'si_jazzusrs_2', quiet: true, url: metricsUrl)
def jsonText = response.content
jsonData = readJSON(text: jsonText);
if (IsDebug()) {
	echo "QUALITY GATE NAME IS "+jsonData.qualityGate.name.value;
}
return jsonData.qualityGate.name.value;
}

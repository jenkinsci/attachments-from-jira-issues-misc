#!/usr/bin/env groovy
// 176851
// 276499

/**
  *
 * @return [Boolean] - Tells whether the project area is in the exclude list
 */
def call() {
	
	
	return "${STREAM_EXCLUDES}".contains(PROJECTAREA);
	
	
	
}


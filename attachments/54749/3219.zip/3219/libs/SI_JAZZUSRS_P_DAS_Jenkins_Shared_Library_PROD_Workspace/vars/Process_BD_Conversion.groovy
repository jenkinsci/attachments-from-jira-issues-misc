/**
 * Process build definition conversion (deprecated)
 * 
 * @param the build definition xml
 * 
 * @return the new build definition xml
 */


import groovy.xml.XmlUtil

def call (def xml) {
    echo "DSL->Process_BD_Conversion()"
    def object = new XmlSlurper().parseText(xml)
    // create a pretty string version of the Node object
    def revampedBD = XmlUtil.serialize(object)
    echo "Update build definition:"
    // print the pretty string if debug is turned on
    if (IsDebug()) {echo revampedBD}
    // generic build definition properties    
    def buildObject = object.target[0].createBuildDefinition
    def projectArea = Get_XML_Node_Value(buildObject,"processName",true)
    echo "project Area is ${projectArea}"
    
    // msbuild properties
    def msbBuildPropertyObject= object.target[0].createBuildDefinition.msbBuildProperty
    msBuildItem = msbBuildPropertyObject.msbBuildItem
    def buildCmd = Get_XML_Node_Value(msbBuildPropertyObject, "team.build.msbuild.buildCmd")
    def buildConfig = Get_XML_Node_Value(msBuildItem,"description",true)
    def solutionFile = Get_XML_Node_Value(msBuildItem,"solution",true)
    solutionFile="  <xt:buildProperty description='[required] Name of your solutions file. Example: My.sln' kind='com.ibm.team.build.property.string' name='slnFile' value='${solutionFile}'/>"
    def buildType = Get_XML_Node_Value(msBuildItem,"type",true)
    buildType=" <xt:buildProperty description='[required] Build the specified targets in the project. Specify each target separately, or use a semicolon or comma to separate multiple targets (/t)' kind='com.ibm.team.build.property.string' name='msBuildTarget' value='/t:${buildType}' />"
    def msBuildPath = Get_XML_Node_Value(msBuildItem,"directory", true)

    // mstest properties
    def msTestObject = object.target[0].createBuildDefinition.mstBuildProperty
    def msTestFile = Get_XML_Node_Value(msTestObject,"com.ibm.team.build.mstest.mstestFile")
    msTestFile="    <xt:buildProperty description='[optional] Path to your MSTest.dll' kind='com.ibm.team.build.property.string' name='msTestDLL' value='${msTestFile}' />"

    // nunit properties
    def nUnitObject = object.target[0].createBuildDefinition.nutBuildProperty
    def nunitFile = Get_XML_Node_Value(nUnitObject,"com.ibm.team.build.nunit.nUnitFile")
    nunitFile=" <xt:buildProperty description='[optional] Path to your NUnit.dll.' kind='com.ibm.team.build.property.string' name='nUnitDLL' value='${nunitFile}'/>"
    echo "nunit file is ${nunitFile}"
    def cmdBuildPropertyObject = object.target[0].createBuildDefinition.cmdBuildProperty
    def cmdDirectory = Get_XML_Node_Value(cmdBuildPropertyObject, "com.ibm.team.build.cmdline.workingDir")
    if (!cmdDirectory || cmdDirectory=="") { cmdDirectory = '${team.scm.fetchDestination}' }

    // maven properties
    def mvnBuildPropertyObject = object.target[0].createBuildDefinition.mvnBuildProperty
    def goals = Get_XML_Node_Value(mvnBuildPropertyObject, "com.ibm.team.build.maven.mavenGoals")
    goals = "       <xt:buildProperty description='[required] maven goals and command line options.&#x0D;&#x0A;example: clean install verify sonar:sonar -U' kind='com.ibm.team.build.property.string' name='mvnCommandLine' value='${goals}'/>"
    echo "maven goals: ${goals}"
    def projectLocation = Get_XML_Node_Value(mvnBuildPropertyObject, "com.ibm.team.build.maven.projectLocation")
    echo "maven project location = ${projectLocation}"

    // ucd properties
    def ucdpBuildPropertyObject = object.target[0].createBuildDefinition.ucdpBuildProperty
    def applicationName = Get_XML_Node_Value(ucdpBuildPropertyObject, "team.udeploy.application")
    applicationName = " <xt:buildProperty description='[optional] The name of the UCD Application (used in continuous delivery)' kind='com.ibm.team.build.property.string' name='ucdApplicationName' value='${applicationName}'/>"
    echo "application name is ${applicationName}"
    def componentName = Get_XML_Node_Value(ucdpBuildPropertyObject, "team.udeploy.component")
    componentName = "   <xt:buildProperty description='[optional] UCD Component name to deliver artifacts to' kind='com.ibm.team.build.property.string' name='ucdComponentName' value='${componentName}'/>"
    def deployEnabled = Get_XML_Node_Value(ucdpBuildPropertyObject, "team.udeploy.deployEnabled")
    if (deployEnabled=="") { deployEnabled="false" }
    def deliveryEnabled = Get_XML_Node_Value(ucdpBuildPropertyObject, "team.udeploy.enabled")
    if (deliveryEnabled=="") { deliveryEnabled="false" }
    def devEnvironment = Get_XML_Node_Value(ucdpBuildPropertyObject, "team.udeploy.environment")
    if (devEnvironment=="") { devEnvironment="DVLP 1" }
    def includeFiles = Get_XML_Node_Value(ucdpBuildPropertyObject, "team.udeploy.includeFiles")
    includeFiles = "    <xt:buildProperty description='[optional] UCD Include Files pattern' kind='com.ibm.team.build.property.string' name='ucdIncludePattern' value='${includeFiles}'/>"
    def excludeFiles = Get_XML_Node_Value(ucdpBuildPropertyObject, "team.udeploy.excludeFiles")
    excludeFiles = "    <xt:buildProperty description='[optional] UCD Exclude Files pattern' kind='com.ibm.team.build.property.string' name='ucdExcludePattern' value='${excludeFiles}'/>"
    def targetPath = Get_XML_Node_Value(ucdpBuildPropertyObject, "team.udeploy.baseDirectory")
    targetPath = "  <xt:buildProperty description='[optional] The relative path of the deployable artifacts, if applicable' kind='com.ibm.team.build.property.string' name='ucdTargetPath' value='${targetPath}'/>"
    def appProcess = Get_XML_Node_Value(ucdpBuildPropertyObject, "team.udeploy.process")
    appProcess = "  <xt:buildProperty description='[optional] The Name of the UCD Application Process (used in Continuous Delivery)' kind='com.ibm.team.build.property.string' name='ucdApplicationProcessName' value='${appProcess}'/>"
    echo "appProcess is ${appProcess}"

    // jazz source control properties
    def teamBuildPropertyObject = object.target[0].createBuildDefinition.teamBuildProperty
    def acceptBeforeFetch = Get_XML_Node_Value(teamBuildPropertyObject, "team.scm.acceptBeforeFetch")
    echo "accept before fetch is ${acceptBeforeFetch}"
    def buildIfChanges = Get_XML_Node_Value(teamBuildPropertyObject, "team.scm.buildOnlyIfChanges")
    echo "build only if changes is ${buildIfChanges}"
    def createFolders = Get_XML_Node_Value(teamBuildPropertyObject, "team.scm.createFoldersForComponents")
    echo "create folders for components is ${createFolders}"
    def fetchDestination = Get_XML_Node_Value(teamBuildPropertyObject, "team.scm.fetchDestination")
    def deleteDest = Get_XML_Node_Value(teamBuildPropertyObject, "team.scm.deleteDestinationBeforeFetch")
    echo "Delete Destination is ${deleteDest}"
    def loadComponents = Get_XML_Node_Value(teamBuildPropertyObject, "team.scm.loadComponents")
    echo "loadComponents is ${loadComponents}"
    def workspaceUUID = Get_XML_Node_Value(teamBuildPropertyObject, "team.scm.workspaceUUID")
    echo "workspace uuid is ${workspaceUUID}"
/***********************************************************************************************/
    // this is the name of the pipeline we want to use
    echo "build Choice is ${buildChoice}"
    switch (buildChoice) {
        case 'maven':
            pipelineType = 'Maven '
            break
        case 'msbuild':
            pipelineType = 'MSBuild '
            break
        case 'node':
            pipelineType = 'Node '
            break
        default:
            pipelineType = 'Delivery_'
    }
    def pipelineName = "${pipelineType}Pipeline"
    echo "Pipeline name is ${pipelineName}"

//          All the components we wish to exclude, join with commas
    def excludeComponents = "${loadComponents}"
    if (excludeComponents == "") {
        excludeComponents = ","
    }

    echo "Components to exclude: ${excludeComponents}"
    echo "solution file is ${solutionFile}, build config is ${buildConfig}, build type is ${buildType}"

    // export the variables so Ant can use them
    // Initial_XML_Import packages the fields into an map
    def initialfields = Initial_XML_Import(buildDefinitionName,workspaceUUID,projectArea,excludeComponents,deleteDest,
    acceptBeforeFetch,createFolders,buildIfChanges, fetchDestination,pipelineName,includeFiles,excludeFiles,
    deliveryEnabled,deployEnabled,componentName,applicationName,appProcess,devEnvironment)
    // add a bunch of extra, specialized fields
    if (buildChoice == 'maven') {
        initialfields += ["goals=${goals}","projectLocation=${projectLocation}"]
    }
    if (buildChoice == 'msbuild') {
         initialfields += ["msTestFile=${msTestFile}","nunitFile=${nunitFile}","buildFolder=${msBuildPath}","buildType=${buildType}",
             "solutionFile=${solutionFile}"]
    }
    if (buildChoice == 'node' || buildChoice == 'nonbuild') {
         initialfields += ["cmdDirectory=${cmdDirectory}"]
    }
    
    // export to a new build definition based on build type
    Run_Ant_Build_Task("build_def_${buildChoice}",initialfields)

    return revampedBD
}
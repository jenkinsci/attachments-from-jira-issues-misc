#!groovy
/** return a json array based on a matched field
*
* @param appsMap    the Map containing the applications (from the json file)
* @param searchTerm the term to search for
* @param searchField the field to search on
* 
* @return an array of results based on a matching field
*/
 
 def call(def appsMap, def searchTerm, searchField="name"){
     if (IsDebug()) echo "DSL->Filter_JSON_By_Field"
     return appsMap.find {it[searchField] == searchTerm}?.collect {it.value}
 }
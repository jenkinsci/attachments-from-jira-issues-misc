#!/usr/bin/env groovy
// 176851

/**
* Deploy using UCD.
* 
* @param appNM	The UCD application name
* @param processNM	The UCD application process name
* @param envNM	The environment name to deploy to
* @param versionNM the UCD Version to deploy
* @param componentNM The component name to deploy
* @param testUCD the ucd environment type test?
* 
*  
* @return Object Whatever the deploy returns.
*
*/
 
def call(def appNM, def processNM, def envNM, def versionNM, def componentNM, def testUCD="false") {
//, String buildDefinitionId, String buildTimeStamp
	String methodName = 'DJSL -> Deploy_UCD()';
	echo methodName
	def siteEnv = ("${testUCD}"=='true')? "UCDTest":"UCDProd"
	if (IsDebug()) {
		echo "deploying from ${siteEnv}"
	}
	def deployResults = null;
	try {
		deployResults=step([
		$class:'UCDeployPublisher',
		siteName: siteEnv,
		deploy: [
			$class: 'com.urbancode.jenkins.plugins.ucdeploy.DeployHelper$DeployBlock',
			deployApp: appNM,
			deployEnv: envNM,
			deployProc: processNM,
			createProcess: [
				   $class: 'com.urbancode.jenkins.plugins.ucdeploy.ProcessHelper$CreateProcessBlock',
				   processComponent: 'Deploy'
			],
			deployVersions: "${componentNM}:${versionNM}",
			deployOnlyChanged: false
		] //deploy
	]) // actual deploy step
	} catch (err) {
		echo "Problem delivering! "+ err.message
		return err
	}
	return deployResults
}

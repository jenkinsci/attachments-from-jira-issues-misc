/**The root method that calls the other methods that update the DAS_MASTER database with the ITOC portal test results
*
*/

def call(def testXML, def recId, def appName){
echo 'DJSL->Create_ITOC_Records()'
def failedTests = [];
try{
		def testFileText = testXML
		def testResult = new XmlSlurper()
		testResult = testResult.parseText(testFileText)
		if (testResult.testsuite['@failures']){
		echo "RECID: ${recId}"
		if (recId != null && recId.isInteger()){
				testResult.testsuite.testcase.each{
				Create_ITOC_Test_Record(recId,"${it['@name']}", "${it['@status']}", appName)
				if (it['@status'].toString().equalsIgnoreCase("fail")){
					failedTests.push("Smoke test ${appName} ${it['@name']} failed");
				}
				}
				def recStatus = (testResult.testsuite['@failures'].toString().toInteger() > 0) ? "FAILURE":"SUCCESS"
				Update_ITOC_Request_Record(recId, recStatus)
		}
		}
	return failedTests;
}catch(Exception e){
echo e.getMessage()
return failedTests
}

}
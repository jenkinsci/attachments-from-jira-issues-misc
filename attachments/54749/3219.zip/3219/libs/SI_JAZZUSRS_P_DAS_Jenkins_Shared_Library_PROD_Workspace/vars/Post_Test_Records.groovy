import groovy.json.JsonSlurper;

def call(def jsonStr){
	echo "DJSL->Post_Test_Records"
	try {
		if (!IsDryRun()){
				def jsonObj = new JsonSlurper().parseText(jsonStr);
				def failedTests = [applications:[],failures:[]]
				def appsList = jsonObj.results.keySet().join(', ');
				failedTests.applications = appsList.split(",");
				def recId = Create_ITOC_Request_Record(appsList);
				jsonObj?.results.each {
						def appName = it.key.toString()
						def app = jsonObj.results[appName]
						if (app?.automation?.results) {
							failedTests.failures += Create_ITOC_Records(app.automation.results, recId, appName);
						}
						if (app?.performance?.results) {
							failedTests.failures += Record_Performance_Results(recId, params.envName,appName,app.performance.results);
						}
				}
				Create_Request_Incident(failedTests)
				}
	} catch (ex) {
		echo ex.toString()
	}
}
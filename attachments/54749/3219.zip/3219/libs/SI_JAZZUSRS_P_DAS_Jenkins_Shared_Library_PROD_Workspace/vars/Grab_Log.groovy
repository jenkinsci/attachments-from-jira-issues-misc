#!/usr/bin/env groovy
	import java.util.stream.IntStream
	import java.util.stream.Collectors
// 176851

/**
 * Send the current build log to a list.
 *  
 * @param maxLines (int) the maximum number of lines to read, -1 to read the whole log
 * 
 * @return a list containing each line of the log being read
 */
@NonCPS 
def call(int maxLines=5000) {
    println "DSL->Grab_Log()"
    if (maxLines<1) {
        logList = currentBuild.rawBuild.getLog(Integer.MAX_VALUE)
    } else { 
        logList = currentBuild.rawBuild.getLog(maxLines)
    }
//	println "log:" + logList.toString()
	return logList
	
}




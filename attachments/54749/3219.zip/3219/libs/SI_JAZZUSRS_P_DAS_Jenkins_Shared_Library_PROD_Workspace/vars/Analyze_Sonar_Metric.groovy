#!groovy
/**
 * Get Sonarqube data in JSON format.
 *
 * @param metricPos metric position for arrays
 * @param metric metric name
 * @return jsonData [Object] - Sonarqube data
 *
 */
import groovy.json.JsonSlurperClassic;
if (IsDebug()) echo "DSL-> Analyze_Sonar_Metric"

def call(def metricPos, String metric="") {
String metricValue;
def rating = ['0','<span style="color:green"><b>A</b></span>',
	'<span style="color:#00FF82"><b>B</b></span>',
	'<span style="color:#FFD000"><b>C</b></span>',
	'<span style="color:#FF7800"><b>D</b></span>',
	'<span style="color:red"><b>E</b></span>']

if (metric.startsWith("new_")) {
	if (metric.endsWith("_rating")) {
		metricValue = rating[Math.round(Float.parseFloat(metricPos.periods[0].value))];
	} else if (metric.endsWith("_density")) {
		metricValue = Float.toString(Float.parseFloat(metricPos.periods[0].value).round(2))
		if (Float.parseFloat(metricValue) > 3) {
			metricValue = '<span style="color:red">'+metricValue+'</span>'
		}
	} else {
		metricValue = metricPos.periods[0].value;
	}
} else if (metric.endsWith("_rating")) {
	metricValue = rating[Math.round(Float.parseFloat(metricPos.value))];
} else if (metric.endsWith("_density")) {
	metricValue = Float.toString(Float.parseFloat(metricPos.value).round(2))
	if (Float.parseFloat(metricValue) > 3) {
		metricValue = '<span style="color:red">'+metricValue+'</span>'
	}
} else if (metric.endsWith("coverage")) {
	metricValue = metricPos.value
//	if (metricPos.value == '0.0') {
//		metricValue = '<span style="color:red">'+metricValue+'</span>'
//	}
} else {
	metricValue = metricPos.value;
} //if

return metricValue;
}

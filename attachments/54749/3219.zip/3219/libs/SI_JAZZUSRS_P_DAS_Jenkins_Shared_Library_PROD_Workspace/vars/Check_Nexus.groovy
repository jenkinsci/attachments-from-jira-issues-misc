#!/usr/bin/env groovy
// 176851

/**
 * Check the number of violations in Nexus and pass through a filter to determine pass/fail.
 *  
 * @param loadDir the rtc load directory
 * @param jenkinsEnv which jenkins we're running on (development, test, or prod)
 * @param nexusKey the nexus application key in Jenkins
 * 
 * @return String Pass status true/false
 */
 
String call(def loadDir="", def jenkinsEnv="PROD", def nexusKey="") {
        echo "DSL->Check_Nexus()"
        try {
    		def outPut = ""
            def thisJDK = tool name:'current', type:'jdk'
    		def nexusURL=(jenkinsEnv=="PROD")? "nexusiq":"nexusiq-test"
    		echo "Processing through NexusIQ..."
            if (env.NODE_LABELS.contains("aix")) {
                outPut = sh (script:"${thisJDK}/bin/java -Djavax.net.ssl.trustStore=/jenkins/cacerts -Djavax.net.ssl.trustStorePassword=changeit -jar /jenkins/nexus-cli/nexus-iq-cli-1.56.0-01.jar @/jenkins/nexus-cli/nexus-cli-credentials.txt -i ${nexusKey} -s https://${nexusURL}.bcbst.com ${loadDir}", returnStdout:true)
            } else {
                outPut = bat (script:"${thisJDK}/bin/java -jar F:/ProgramFiles/nexus-cli/nexus-iq-cli-1.56.0-01.jar @F:/ProgramFiles/nexus-cli/nexus-cli-credentials.txt -i ${nexusKey} -s https://${nexusURL}.bcbst.com ${loadDir}", returnStdout:true)
            }
    		echo outPut
    		def nexusPattern= ~/Number of open policy violations: (\d+) critical, (\d+) severe, (\d+) moderate/
    		def nexusPatternMatcher = nexusPattern.matcher(outPut)
    		def nexusCritical = (nexusPatternMatcher.size()>0)? nexusPatternMatcher[0][1]:0
    		def nexusSevere = (nexusPatternMatcher.size()>0)? nexusPatternMatcher[0][2]:0
    		def nexusModerate = (nexusPatternMatcher.size()>0)? nexusPatternMatcher[0][3]:0
            return "true"
        } catch (e) {
            throw new Exception("Nexus failed: ${e}")
        }
}




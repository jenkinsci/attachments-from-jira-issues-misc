#!/usr/bin/env groovy

def call(String component, String applications){

	echo "BEGIN Add_Component_To_Applications"

	def appList = applications.split(',')
try{
	for(String application : appList){
		echo "Adding " + component + " to " + application + "."
		Add_Component_To_Application(component, application)
	}
}catch(e){
	echo "Error in Add_Component_To_Applications:"
	echo e.toString()
}
}
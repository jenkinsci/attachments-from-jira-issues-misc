#!groovy
/**Sends success flag and naughty file (binaries) count to DAS_MASTER
*
* @param buildName		[String] (required)	used to identify the build
* @param successFlag	[String] (required)	"SUCCESS" gets converted into 1, all other are 0 when calling query
* @param ucdComponentSize	[int] (required)	
* @param naughtyCount   [int] (required)    number of binary files found in the build (should not be any)
*
*/
 
 void call(String buildName, String successFlag, def ucdComponentSize, int naughtyCount){
	echo "Send_Build_KPIs"
    String s = '{call DAS_MASTER.dbo.SP_DAS_InsertBuildMetricsByBuildUUID('+"'${buildName}',${successFlag == 'SUCCESS' ? 1 : 0},'${ucdComponentSize.toInteger()}', ${naughtyCount})"+'}'
    
	if (ucdComponentSize != null) {
    	try{
    		withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:'SQ_DASUcd_T', usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
                Run_JDBC_Query(USERNAME,PASSWORD,s)
    //			def dbCommand = bat(returnStdout: true, script:"cmd /c sqlcmd -S wnrc0811 -U %USERNAME% -P \"%PASSWORD%\" -Q \"EXEC DAS_MASTER.dbo.SP_DAS_InsertBuildMetricsByBuildUUID '${buildName}', ${successFlag == 'SUCCESS' ? 1 : 0}, '${ucdComponentSize.toInteger()}', ${naughtyCount}\" 2> dbErr.txt")
    		}
        } catch (Exception ex){
            echo ex.message
        }
    }
 }
#!/usr/bin/env groovy
// 176851

/**
 * Checkout source from RTC using the build definition parameters
 *  
 * @param buildDefId the name of the build definition to pull from
 * @param versionNumber the UCD version to mark snapshots with
 * @param buildtool the name of the build tool label in Jenkins
 * 
 */
 
def call(def buildDefId="NoBuild", def versionNumber= "NoVer") {
	String methodName = 'DJSL -> Checkout_RTC()';
	echo methodName + ' :: Retrieving source via build definition: ' + buildDefId;
	def result = checkout([
		$class: 'RTCScm', 
		avoidUsingToolkit: true, 
		buildTool: "build engine", 
		buildType: [addLinksToWorkItems:true, generateChangelogWithGoodBuild: true, buildDefinition: buildDefId, customizedSnapshotName: buildDefId + '_' + versionNumber, value: 'buildDefinition'], 
		credentialsId: 'SI_JAZZUSRS_P',
		overrideGlobal: true, 
		serverURI: 'https://rtcccm.bcbst.com/ccm', 
		timeout: 480]);
    if (IsDebug()) { echo "checkout result is ${result.requestUUID}" }
    return result //result is returned as a map to build information
}




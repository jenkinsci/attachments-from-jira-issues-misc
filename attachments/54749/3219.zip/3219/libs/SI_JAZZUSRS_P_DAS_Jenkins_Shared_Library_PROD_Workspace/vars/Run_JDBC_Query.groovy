import groovy.sql.Sql
def call(def userid, def pwd, def commandString) {
    def rowsChanged
        def db = [url:'jdbc:sqlserver://wnrc0811:1433;databaseName=DAS_MASTER', user:userid, password:pwd, driver:'com.microsoft.sqlserver.jdbc.SQLServerDriver']
        try{
            def sql = Sql.newInstance(db.url, db.user, db.password, db.driver)
            println "sql returned"+ sql.toString()
            rowsChanged = sql.call(commandString)
        } catch (Exception e){
            echo e.message
        }
    if (rowsChanged == null) rowsChanged = "No"
    println rowsChanged+" rows changed."
    return rowsChanged
}

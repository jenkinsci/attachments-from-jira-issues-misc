#!/usr/bin/env groovy
// 176851

/**
* Prepare a build definition for update by replacing appropriate text.
* 
* @param uid		[String] (required) userid to place in the build definition
* @param pwd     	[String] (required) password to place in the build definition
* @param stubName   [String] (required) the stub to replace
* @param stubValue  [String] (required) the value to replace the stub for the property
*
*  
* @return bdString 	[String] - The string with replaced values
*
*/
 
def call(String bdString, String uid,String pwd,String stubName,String stubValue) {
    echo "Replacing build definition strings"
    bdString= bdString.replaceAll(stubName,stubValue)
    bdString= bdString.replaceAll("BUILDPROPERTY","xt:buildProperty")
    bdString= bdString.replaceAll("TEAMBUILDPROP","xt:teamBuildProperty")
    bdString= bdString.replaceAll("PIPELINE","xt:hdsnBuildProperty")
    bdString= bdString.replaceAll("BUILDENGINE","xt:buildEngineDefine")
    bdString= bdString.replaceAll("xt:createBuildDefinition", "xt:updateBuildDefinition")
    bdString= bdString.replaceAll('templateId="com.ibm.rational.connector.hudson.ui.buildDefinitionTemplate"','')
    bdString= bdString.replaceFirst(/\$\{repositoryAddress\}/,'https://rtcccm.bcbst.com/ccm')
    bdString= bdString.replaceFirst(/must be set to .+true.+ for the upload to take place./,'must be set to true for the upload to take place')
    bdString= bdString.replaceFirst(/\$\{userId\}/,"${uid}")
    bdString= bdString.replaceFirst(/\$\{password\}/,"${pwd}")

    return bdString

}
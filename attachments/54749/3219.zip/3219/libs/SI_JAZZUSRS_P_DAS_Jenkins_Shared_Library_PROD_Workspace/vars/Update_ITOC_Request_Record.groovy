/* Updates the request record in the database with the status of the request
*
*	@param recId ID of the record to be updated
*	@param status The status of the request
*/

def call(def recId, def status){
	echo "DJSL -> Update_ITOC_Request_Record(def recId, def status)"
	def dbAcct = (jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "SQ_DASUcd_P" : "SQ_DASUcd_T"
	def dbServer = (jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "wprc2211": "wnrc0811"
	def dbDatabase = (jenkinsEnvironment.equalsIgnoreCase('PROD')) ? "DAS_MASTER": "DAS_MASTER_DVLP"
	try {
 	withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:dbAcct, usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
		 dbReturnValue = bat(returnStdout: true, script:"cmd /c \"\"C:\\Program Files\\Microsoft SQL Server\\Client SDK\\ODBC\\130\\Tools\\Binn\\SQLCMD.EXE\" -S ${dbServer} -U %USERNAME% -P \"%PASSWORD%\" -Q \"EXEC ${dbDatabase}.dbo.SP_ITOC_Update_Request_Status @pRecId=${recId}, @pStatus=${status} \" -h -1 -o dbReturn.txt 2> dbITOCErr.txt\"")
		 dbReturnValue= readFile('dbReturn.txt').trim()
		 if (fileExists("dbITOCErr.txt")){
		 def err = readFile('dbITOCErr.txt').trim()
		if ( err.contains("Error")){
		throw new Exception( err)
		}}
    }} catch (Exception ex){
	if (fileExists("dbITOCErr.txt"))
	{
	def err = readFile('dbITOCErr.txt').trim()
    env.errorMsg = err
	echo err
	bat(returnStdout: false, script: "DEL dbITOCErr.txt")
	}
	echo ex.getMessage()
	Send_Error_Email('Derald_Rogers@bcbst.com','Internal Jenkins Error - Create_ITOC_Request_Record')
	}
}

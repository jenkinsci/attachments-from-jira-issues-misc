#!/usr/bin/env groovy
// 176851

/**
 * Perform an MSBuild using the build definition parameters
 * 
 * @param configType				[String] (required) The configuration type (Debug or Release)
 *  
 *
 */
 
void call(String configType, def busy=0, def multiThread="false") {
//	dir ("${loadDirectory}") {
    echo "DSL->Perform_MSBuild()"
	def cType
	if ((env.msBuildConfigType == "Development") && (isExcludedSQ())) {
		cType=env.msBuildConfigType
	} else {
		cType=configType
	}
	String methodName = 'DJSL -> Perform_MSBuild()';
	echo methodName
	echo "old nuget is ${env.oldNuget}"
	echo "Executing Nuget Package Restore:"
	if (env.useLegacyMSBuild == "true") {
		msBuildCmd = (env.msBuild64 == "true")? "${tool 'MSBuild VS2017 64 bit'}":"${tool 'MSBuild VS2017 32 bit'}"	
	} else {
		msBuildCmd = (env.msBuild64 == "true")? "${tool 'MSBuild VS2019 64 bit'}":"${tool 'MSBuild VS2019 32 bit'}"
	}
	if (env.nugetRestore == 'null' || env.nugetRestore == null || env.nugetRestore == "") {
		if (env.oldNuget=="true") {
			bat "\"F:/ProgramFiles/NuGet/nuget-3.exe\" restore \"${env.workingDirectory}/${env.slnFile}\" -Project2ProjectTimeOut 20" //nuget restore
		} else {
			bat "\"F:/ProgramFiles/NuGet/nuget.exe\" restore \"${env.workingDirectory}/${env.slnFile}\" -Verbosity detailed -NonInteractive -MSBuildPath \"${msBuildCmd}\" -Project2ProjectTimeOut 20" //nuget restore
		}
	} else {
		bat "\"F:/ProgramFiles/NuGet/nuget.exe\" restore \"${env.workingDirectory}/${env.nugetRestore}\" -PackagesDirectory \"${workingDirectory}/packages\"  -Verbosity detailed -NonInteractive -MSBuildPath \"${msBuildCmd}\" -Project2ProjectTimeOut 20" //nuget restore
		if (env.nugetRestoreCopyDLL != "") {
//				bat "for /r \"${workingDirectory}/packages\" \%i in \(*.dll\) do mkdir \" ${workingDirectory}/${env.nugetRestoreCopyDLL}\" 2>NUL & copy/Y \"%~fi\" \"${workingDirectory}/${env.nugetRestoreCopyDLL}/\""
				bat 'for /r "'+workingDirectory+'/packages" %%i in (*.dll) do mkdir "'+"${env.workingDirectory}/${env.nugetRestoreCopyDLL}"+'" 2>NUL & copy/Y %%~fi "'+"${workingDirectory}/${env.nugetRestoreCopyDLL}"+'"'
							}
	}
	echo "Executing MSBuild ${msBuildCmd}"
	def trueTarget=(env.msBuildTarget?.startsWith("/t:"))?"":"/t:"
	def parallel = ""
	if (busy <3 && busy >=0 && multiThread == "true" ) {
		parallel = "/m:2"
		echo "Multithread on and ${busy} nodes busy. Running the build in 2 parallel threads..." 
	}
	bat "\"${msBuildCmd}/msbuild\" \"${workingDirectory}/${slnFile}\" ${trueTarget}${env.msBuildTarget} ${parallel} ${env.msBuildProperty} /p:Configuration="+cType //start build
//	}
}




#!/usr/bin/env groovy
// 176851

/**
 * Checkout source from nexus
 *  
 * @param workingDir the current working directory
 * @param groupId the nexus group Id
 * @param artifactId the nexus artifact Id
 * @param Packaging the nexus packaging type
 * @param ver the version to pull
 *
 * @return the output of the nexus retrieval
 */
 
def call(def workingDir,def GroupId,def ArtifactId,def Packaging,def ver) {
	String methodName = 'DJSL -> Collect_Nexus()';
	echo methodName + ' :: Retrieving source via Nexus '
	configFileProvider(
		[configFile(fileId: 'pomfile', targetLocation: "${workingDir}/pom.xml")]) {}
		powershell """(Get-Content ${workingDirectory}/pom.xml).replace('[groupId]', "${GroupId}") | Set-Content ${workingDirectory}/pom.xml"""
		powershell """(Get-Content ${workingDirectory}/pom.xml).replace('[artifactId]', "${ArtifactId}") | Set-Content ${workingDirectory}/pom.xml"""
		powershell """(Get-Content ${workingDirectory}/pom.xml).replace('[version]', "${ver}") | Set-Content ${workingDirectory}/pom.xml"""

	def outPut = bat returnStdout: true, script:"mvn org.apache.maven.plugins:maven-dependency-plugin:unpack -DremoteRepositories=http://nexus.bcbst.com/nexus/content/repositories/snapshots -Dartifact=${GroupId}:${ArtifactId}:${ver}:${Packaging} -Ddest=${workingDir}"
	
    return outPut
}




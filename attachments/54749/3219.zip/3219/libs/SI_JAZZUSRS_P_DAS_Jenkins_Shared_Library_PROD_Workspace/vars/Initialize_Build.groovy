/**
 * Initializes build environment and sets labels/names
 * 
 * @param buildDefId build definition name
 * @param libraryWS shared library workspace
 * @param uuid the buildresult uuid returned from RTC checkout
 * @param external whether this is an external nonbuild delivery
 * 
 * @return zero if successful
 */

def call(def buildDefId,def libraryWS,def uuid, def external=false, def fast=true) {
    echo "DSL->Initialize_Build()"
    echo "personalBuild = ${env.personalBuild}"
    echo "Requested by ${env.buildRequesterUserId}"
    Show_Environment_Variables()
    env.excludedFromSQ = isExcludedSQ()
    env.WSNAME = Get_Workspace_Name(uuid)
    echo "WS Name is ${env.WSNAME}"
    env.PROJECTAREA = Get_Project_Area(buildDefinitionId)
    echo "Project area is ${env.PROJECTAREA}"
    env.isBetaGroup = (IsBeta())? "true":"false"
    env.buildEngineHostName="${NODE_NAME}"    
    env.curTime = env.BUILD_TIMESTAMP
    env.VERSION_NOM=env.curTime
    def labelText = "${buildDefinitionId}_${env.VERSION_NOM}"
    buildName labelText //do not use with Build Name Plugin < v2.0
    buildDescription "Executed on ${env.buildEngineHostName}"
    ext = (external==true)?  "true":"false"
    echo "External Build is ${ext}, Version is ${VERSION_NOM}"
    if (!(labelText.contains("UnitTest") && env.PROJECTAREA.contains("SLMTools"))) {
        Checkout_RTC_WS(libraryWS, 'DAS_Jenkins_Shared_Library/loadjazz.loadrule')
        if (IsDebug()) echo "Running jazz initialization"
        def clist = Perform_Jazz_Initialization(buildDefinitionId, env.buildResultUUID, env.VERSION_NOM,ext,fast)
        echo "Initialization complete."
        return "Initialization complete."
    } else {
        echo "No initialization performed."
        return "No initialization performed."
    }
}
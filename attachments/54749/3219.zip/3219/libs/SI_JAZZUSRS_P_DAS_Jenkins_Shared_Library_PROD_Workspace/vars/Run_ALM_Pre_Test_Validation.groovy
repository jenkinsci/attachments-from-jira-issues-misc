import bcbst.das.ALMTestParams
/**
 * Performs ALM pre-test validation for test parameters.
 * 
 * @param almParams ALMTestParams instance containing test values.
 * @return A string containing pre-test validation status.
 **/
String call(ALMTestParams almParams) {
    echo "Performing Pre Test Validation"
    String status = 'ready';
    if (jenkinsEnvironment == "PROD") {
        jauth = "SI_JENKINS_P_API"
        jurl = "jenkins"
    } else {
        jauth="SI_JENKINS_T_API"
        jurl="jenkins-test"
    }
    Boolean invalidParams = almParams.getInvalidParams().size() > 0;
    def response = httpRequest authentication: jauth, ignoreSslErrors: true, url: "https://${jurl}.bcbst.com/computer/api/json?pretty=true"
    if (IsDebug()) {echo "Response: "+ response.getContent()}
    def jsonNodes = readJSON text:response.getContent()
    def jsonOffline = Get_JSON_Field_By_Search_Term(jsonNodes.computer, almParams.serverNode, "displayName", "offline")
    echo "Is ${almParams.serverNode} offline? ${jsonOffline}"
    if (jsonOffline == null) status = 'node_not_found';
    else if (jsonOffline == true) status = 'node_offline';
    else if (invalidParams) status = 'invalid_params';
    else if (IsDryRun()) status = 'dry_run_success';
    return status;
}
#!groovy
/**
 * Convert JSON String to JSON object
 *
 * @param jsonString the JSON string to convert
 * @return JSON Object
 *
 */
import groovy.json.JsonSlurperClassic;


def call(def jsonString) {
echo "DSL->Convert_String_To_JSON"

def jsonData;


jsonData = getOneData(jsonString);
return jsonData;
}

@NonCPS
def getOneData(def jtext="") {
	def slurper = new JsonSlurperClassic();
	return slurper.parseText(jtext);
}
	
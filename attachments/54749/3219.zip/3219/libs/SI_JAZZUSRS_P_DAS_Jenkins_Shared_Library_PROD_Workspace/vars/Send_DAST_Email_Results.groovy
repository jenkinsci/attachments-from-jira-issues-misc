#!/usr/bin/env groovy
// 176851

/**
 * Send an email notification of the results of Dynamic Scanning
 * 
 * @param contacts	The email recipient(s) of the notification
 *  
 *
 */
 
void call(def contacts, def sampleLog) {
        echo "DSL->Send_DAST_Email_Results()"
		def fileAtch = "*report.pdf"
		echo "sending email using jenkins-dast-email-html.template"
        echo "Current result is "+ currentBuild.result
        
        def variables = [ 
            job: currentBuild.fullDisplayName,
            result: currentBuild.result,
            timeInMillis: currentBuild.timeInMillis,
            rtcURL: "https://rtcccm.bcbst.com/ccm",
            buildResultUUID: buildResultUUID,
            timestampString:BUILD_TIMESTAMP,
            contacts: contacts,
            componentName: ucdComponentName,
            ucdVersionName: ucdVersionName,
            jenkinsEnvironment: env.jenkinsEnvironment,
            isBetaGroup: env.isBetaGroup,
            buildEngineServer: env.buildEngineHostName,
            projectArea: PROJECTAREA,
            veracodeResult: env.vcStatus,
//            veracodeResultURL: env.vcReportURL,
            projectName:projectName,
            jobName: env.JOB_NAME,
            departmentName:isDepartmentName,
            log:sampleLog,
            passFail:env.passFail,
            buildFailure: env.buildFailure
            ]
        if (IsDebug()) {
            variables.each { k,v -> 
                echo "Key ${k} found type ${v.getClass()}"
            }
        }
        template = libraryResource("jenkins-dast-email-html.template")
        report = Render_Template(template, variables)
		Send_Email_Results("${contacts}", "DAST Scan for ${projectName}- ${BUILD_TIMESTAMP}: ${passFail}",fileAtch, false, report)
}




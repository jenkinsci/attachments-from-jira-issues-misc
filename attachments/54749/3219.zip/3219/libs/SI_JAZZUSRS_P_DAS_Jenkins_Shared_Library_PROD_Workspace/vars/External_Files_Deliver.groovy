#!/usr/bin/env groovy
// 176851

/**
 * @param versionNM	[Object] (required) The version number in UCD for the component artifacts
 *
 */
 
def call(String versionNM, String buildDefId) {
	String methodName = 'DJSL -> External_Files_Deliver()';
	echo methodName

	def newTargetPath = "${env.ucdTargetPath}"
	if (Check_UCD_Version("${versionNM}")==false) { 
		echo "version doesn't exist"
		env.VERSION_NOM = "${versionNM}"
		if (sourceType == "file") {
			env.ucdTargetPath = "toUCD/${versionNM}"
		}
		def deliverResult = Deliver_UCD("${env.VERSION_NOM}")
		if (deliverResult instanceof hudson.AbortException) {
			echo 'Delivery failed because: ' + deliverResult.message;
			error deliverResult.message
		} else {
			// change link back to RTC from Jenkins
			Replace_UCD_Link("${env.VERSION_NOM}", "Jenkins%20Build%20${buildDefId}_${BUILD_TIMESTAMP}","Build%20Result",ucdComponentName, buildResultUUID, useTestUCD)
			if ((env.workItem != "") && (env.workItem != "000000")) {
				Set_UCD_Link(env.ucdComponentName,env.VERSION_NOM,"Release","https://rtcccm.bcbst.com/ccm/web/projects/${PROJECTAREA}%23action%3Dcom.ibm.team.workitem.viewWorkItem%26id%3D${env.workItem}",useTestUCD)
			} //if workitem is default or blank
		} // if exception/else
		def status = (env.sqStatus == "true") ? "PASS" : "FAIL"
		Set_UCD_Status (env.ucdComponentName,"${env.VERSION_NOM}","Code%20Quality%20-%20" + status, useTestUCD)
		Set_UCD_Status (env.ucdComponentName, "${env.VERSION_NOM}","Code%20Security%20-%20" + status, useTestUCD)
		status = ("${nexusStatus}" == "true") ? "PASS" : "FAIL"
		Set_UCD_Status (env.ucdComponentName, "${env.VERSION_NOM}","OSS%20Component%20Security%20-%20" + status, useTestUCD)
		Set_UCD_Status (env.ucdComponentName, "${env.VERSION_NOM}","Component%20Compliance%20-%20"+status, useTestUCD)
		def UCDVersionUUID = Get_UCD_Version_UUID(env.ucdComponentName,env.VERSION_NOM,useTestUCD)
		def ucdenv = ("${env.useTestUCD}".equalsIgnoreCase('true'))? "ucd-test":"ucd"
		Set_RTC_Build_Link("UCD Version ${env.VERSION_NOM}","https://${ucdenv}.bcbst.com/#version/${UCDVersionUUID}")
	} else { //make sure version doesn't already exist
		echo "version already exists"
        error "Attempted to duplicate version - please examine UCD to see if it needs to be deleted or renamed"
	} //end check if version already exists									
	if (sourceType == "file") {
		echo "copying ${versionNM} to archive"
		if (!(fileExists('archive'))) {
			fileOperations([folderCreateOperation("${sourcePath}/archive")])
		}
//		fileOperations([folderRenameOperation(source:"${sourcePath}/${versionNM}", destination:"${sourcePath}/archive/${versionNM}")])
		fileOperations([folderCopyOperation(sourceFolderPath:"${sourcePath}/${versionNM}", destinationFolderPath:"${sourcePath}/archive/${versionNM}")])
		fileOperations([folderDeleteOperation("${sourcePath}/${versionNM}")])
			}

}

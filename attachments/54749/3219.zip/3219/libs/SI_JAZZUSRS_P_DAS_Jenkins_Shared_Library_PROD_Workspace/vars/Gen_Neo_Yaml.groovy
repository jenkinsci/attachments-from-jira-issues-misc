import net.sf.json.*
import hudson.Functions

/** 
* Creates YAML files uses as input for NeoLoad. Required when testing applications in parallel using only one NeoLoad instance.
* Note that KERB apps must be run separately from NTLM apps, thus two config files are needed when testing both types of applications. 
*
* @param appObjList A list of all app objects extracted from servers.json to be tested.
* @param envName The name of the environment to test: Prod || NonProd
*
* @return Integer bitwise value indicating which operations were performed. 0 for error, 1 for NTLM, 2 for KERB, or 3 for NTLM & KERB.
*
**/
int call(ArrayList appObjList, String envName) { 
    try {
        println "DJSL-> Gen_Neo_Yaml()";
        int status = 0;
            String yamlPath = "${env.WORKSPACE}\\${env.BUILD_ID}\\neo-yaml-inputs\\Default_${env.BUILD_ID}.yaml";
            String yamlPathKerb = "${env.WORKSPACE}\\${env.BUILD_ID}\\neo-yaml-inputs\\DefaultKerb_${env.BUILD_ID}.yaml";
        String yamlNTLM = '';
        String yamlKERB = '';
        int execMode = 0;
        appObjList.each { JSONObject appObj -> 
            switch (appObj?.type?.toUpperCase()) {
                case 'KERB' : 
                    yamlKERB += genPopulationYaml(appObj, envName);
                    break;
                case 'NTLM' :
                    yamlNTLM += genPopulationYaml(appObj, envName);
                    // Start RTCA after Availity as they both use same login ID via Availity. This is done to avoid any clash due to multiple sessions
                    if (appObj.name == 'RTCA') yamlNTLM += "${spaces(4)}start_after: Availity_${envName}";
                    break;
                default : return 0;
            }
        }
        if (yamlNTLM.length() > 0) {
            writeFileHelper(yamlPath, genScenarioYaml("dynamic", yamlNTLM))
            status += 1;
        }
        if (yamlKERB.length() > 0) {
            writeFileHelper(yamlPathKerb, genScenarioYaml("dynamicKerb", yamlKERB))
            status += 2;
        }
        return status;
    } catch (Exception e) {
        StringBuilder sb = new StringBuilder();
        sb.append("* * * * * * * ERROR * * * * * * *");
        sb.append("Method: Gen_Neo_Yaml");
        sb.append("Unable to write YAML files.");
        sb.append("${Functions.printThrowable(e) }");
        println sb.toString();
        return 0;
    }
}

// * * * * * * * *
// Helper methods:
// * * * * * * * *

/** 
* Saves the yaml file so it wont be overwritten
* @param yamlPath Where to save the yaml file.
* @param yamlText The content to store in the yaml file. 
* @return void
**/
def writeFileHelper(String yamlPath, String yamlText) {
// create a dynamic sanity scenario. Please do not add space/tab or format the writeFile command below. It will invalidate the YAML structure.
    writeFile file: "${yamlPath}", text: yamlText
    println "File written to ${yamlPath}"
}

/** 
* Generate top-level yaml (a scenario) and adds the list of items for populations
* @param name The name of the scenario.
* @param yamlPopulations The applications to assign to populations
* @return a string containing yaml.
**/
String genScenarioYaml(String name, String yamlPopulations) {
    StringBuilder sb = new StringBuilder();
    sb.append("\nscenarios:\n- name: ${name}\n");
    sb.append("${spaces(2)}populations:${yamlPopulations}");
    return sb.toString();
}

/** 
* Generate yaml for applications being tested.
* @param app The JSON object extracted from root.apps[x] in servers.json
* @param envName The name of the environment to test
* @return A string containing yaml.
**/
String genPopulationYaml(JSONObject app, String envName) {
    StringBuilder sb = new StringBuilder();
    sb.append("\n${spaces(2)}- name: ${app.name}_${envName}\n");
    sb.append("${spaces(4)}constant_load:\n");
    sb.append("${spaces(6)}users: 1\n");
    sb.append("${spaces(6)}duration: 1 iteration");
    return sb.toString();
}

/** 
* Generate a string full of consecutive spaces.
* @param val The number of spaces to include in the string
* @param A string full of spaces
**/
String spaces(int val) {
    return ' ' * val;
}


/**
 *  Perform a veracode static scan
 * 
 * @param vcInclude the include pattern 
 * @param vcExclude the exclude pattern
 * @param vcApp the application name
 * @param appName the scan name prefix
 * @param buildDef the build definition name
 * 
 * @return the result of the scan
 * 
 */





def call(def vcInclude, def vcExclude="**/.jazz5/**", def vcApp, def vcDept, def appName, def buildDef) {
    def includeFiles = '**/VC.zip'
    def serviceAccount = (jenkinsEnvironment=="TEST")? "SI_JENKINS_T":"SI_JENKINS_P"
    //TODO when the password is fixed for groovy-safeness, use SI_JENKINS_T rather than SI_JAZZUSRS_P
    if (env.veracodeNoZip != "true") {
        zip dir: env.workingDirectory , glob:vcInclude, exclude:vcExclude, zipFile: 'VC.zip'
    } else {
        includeFiles = vcInclude
    }
    def debugging = IsDebug()
    echo "Department name is ${vcDept}"
    withCredentials([usernamePassword(credentialsId:serviceAccount, passwordVariable: 'pwd', usernameVariable:'uid')]) {
        withCredentials([usernamePassword(credentialsId:"vc_jenkins_api", passwordVariable: 'apiKey', usernameVariable: 'apiId')]) {
            veracode applicationName: "${vcApp}",
                canFailJob: false, createProfile: true,
                createSandbox: true, debug: debugging,
                criticality: 'High',
                fileNamePattern: '', replacementPattern: '',
                sandboxName: "${buildDef}_Automated",
                scanExcludesPattern: vcExclude, scanIncludesPattern: includeFiles,
                scanName: "${appName}_${BUILD_TIMESTAMP}",
                teams: vcDept, timeout: 60,
                uploadExcludesPattern: '**/.jazz5/**', uploadIncludesPattern: "${includeFiles}",
                vid: apiId, vkey: apiKey, waitForScan: true,
                useProxy:true,
                pHost: 'webproxy.bcbst.com', pPassword: pwd, pPort: '80', pUser: uid
        }
    }
    def curLog = Grab_Log(100).join("\n")
    def appPattern = /.*appid=(\d+)/
    def appMatcher = curLog =~ appPattern
    env.vcid = (appMatcher.size()>0)? appMatcher[0][1]:""
    def buildPattern = /The build_id of the new build is "(\d+)"/
    def buildMatcher = curLog =~ buildPattern
    env.vcbuildId = (buildMatcher.size()>0)? buildMatcher[0][1]:""
    if (manager.logContains(/.*The scan finished with policy status 'Pass'.*/)) {
        echo "Veracode passed"
        env.veracodeResult = "PASS"
    } else if ((manager.logContains(/.*The scan finished with policy status 'Fail'.*/)) ||
        (manager.logContains(/.*The policy status 'Did Not Pass' is not passing. Unable to continue.*/))) {
        echo "Veracode failed"
        env.veracodeResult = "FAIL"
    } else {
        env.veracodeResult = "NONE"
    }
    return env.veracodeResult
}
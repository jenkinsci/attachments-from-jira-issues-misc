#!groovy
/**
 * Get MSBuild application version
 *
 * @param workingDir the current working directory
 * 
 * @return String the guessed version number
 *
 */

String call(def workingDir) {
    echo "DSL->Get_MSBuild_Version()"
	if (fileExists("${workingDir}")) {
		dir("${workingDir}") {
			try {	
				def versionFile = findFiles(glob:"**/*AssemblyInfo.??")
				echo "found ${versionFile.length} AssemblyInfo files"
				if (IsDebug()) {
					versionFile.each {
						echo "Assembly Info file ${it.path}"
					}
				}
				if (versionFile.length>0) {
					def assInfo = readFile "${workingDir}/${versionFile[0].path}"
					def pattern = ~/.[Aa]ssembly: AssemblyVersion\("(.*)"\)/
					def match = pattern.matcher(assInfo)
					echo "Match size is "+ match.size()+", match count is "+match.getCount()
					if (match.size() > 0) {
						def gMinusOne=match.getCount()-1
						echo match[gMinusOne][1]
						return match[gMinusOne][1]
					} else {
						return "1.0.0"
					}
				} else {
					echo "couldn't find an Assemblyinfo file - resetting version"
					return "1.0.0"
				}
			} catch (Error e) {
				echo "Failed with ${e}"
				return "1.0.0"
			}
		} //dir
	} else {
		echo "Working directory does not exist"
		error "Working directory does not exist"
	}
}
/**
* Reads text from the first file found matching a glob pattern.
* Executes Jenkins steps: findFiles
*
* @param globPattern - The pattern to match for filename
* @throws FileNotFoundException
* @return string of text read from file
**/

String call(String globPattern) {
    if (IsDebug()) println "DJSL -> Read_ALM_Test_File(globPattern=${globPattern})";
    def files = findFiles(glob: globPattern);
    if (files.size() == 0) {
        throw new FileNotFoundException("File not found: ${globPattern}");
    } else {
        def targetFile = files.last();
        println "Reading targetFile: ${targetFile}";
        String xmlResults = readFile file:targetFile.toString();
        return xmlResults;
    } 
}
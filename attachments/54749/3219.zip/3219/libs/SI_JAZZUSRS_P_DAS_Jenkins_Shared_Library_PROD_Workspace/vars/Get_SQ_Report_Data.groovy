#!groovy
/**
 * Get Sonarqube data in JSON format.
 *
 * @param sqProjectKey the key of the sonarqube project
 *
 * @return jsonData [Object] - Sonarqube data
 *
 */
import groovy.json.JsonSlurperClassic;


def call(def sqProjectKey) {
echo "DSL->Get_SQ_Report_Data()"
if (IsDebug()) {
	echo "Declaring and initializing variables..."
}
// variable declarations
def jsonData;

// API URLS
String sqUrlBase=""
withSonarQubeEnv("BCBST Sonarqube") {
 sqUrlBase="$SONAR_HOST_URL";
}

// metrics api
String sqApiMetrics="/api/measures/component?component="

// metric keys
String sqByType="vulnerabilities,new_vulnerabilities,bugs,new_bugs,code_smells,new_code_smells,coverage,new_coverage,duplicated_lines_density,new_duplicated_lines_density";
String sqBySev="blocker_violations,critical_violations,major_violations,minor_violations,info_violations," + 
				"new_blocker_violations,new_critical_violations,new_major_violations,new_minor_violations,new_info_violations";
String sqRatings="security_rating,new_security_rating,reliability_rating,new_reliability_rating,sqale_rating,new_maintainability_rating";

// urls
String metricsUrl = sqUrlBase + sqApiMetrics + sqProjectKey + "&metricKeys=" + sqByType + "," + sqBySev + "," + sqRatings;

if (IsDebug()) {
	echo "metrics URL is ${metricsUrl}"
}

//https://sonarqube.bcbst.com/api/project_analyses/search?project=ASQ_SLMTools_FLB_CLICalculator

/**
 * START METRICS REQUEST
 */
response= httpRequest(httpMode:'GET', authentication: 'si_jazzusrs_2', quiet: true, url: metricsUrl)
def jsonText = response.content
if (IsDebug()) {
	echo jsonText
}
jsonData = readJSON(text: jsonText);
return jsonData;
}

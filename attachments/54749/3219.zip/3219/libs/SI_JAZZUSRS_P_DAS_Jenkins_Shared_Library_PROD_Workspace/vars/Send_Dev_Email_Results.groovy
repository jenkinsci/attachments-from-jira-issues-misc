#!/usr/bin/env groovy
// 176851

/**
 * Send an email notification
 * 
 * @param contacts	The email recipient(s) of the notification
 * @param requester the email requester
 * @param buildDefId the build definition id
 * @param warning displays "with warnings"
 * @param personal whether or not this is a personal build
 * @param useTemplate use the given email template
 * @param jcases array of junit cases
 * @param ncases array of nunit cases
 * @param external whether or not to check for changes
 *  
 *
 */
 
def call(def contacts, def requester, def buildDefId,def warning="", def personal= "false",def useTemplate="jenkins-matrix-email-html.template", def jcases=[], def ncases=[], def external = false) {
        echo "DSL->Send_Dev_Email_Results() v2"
		def fileAtch = "**/binaries_detected.txt,**/sonarqube-report.htm,**/junitdetail.xml,*report.pdf"
		if (IsDebug()) {
			fileAtch += ",**/static-report-*.htm"
		}
        def perBuild = (personal == "true")? "Personal_":''
        String changez =  (external==true)? "":Get_Changes()
		echo "sending email using ${useTemplate}, personal is ${personal}"
        echo "Current result is "+ currentBuild.result
        def sampleLog = Grab_Log(-1).join("\n")
//        fileOperations([fileCreateOperation(fileContent: Grab_Log(-1).join("\n"), fileName: "buildlog.txt")])
        
        def causes = currentBuild.getBuildCauses()

        def variables = [ 
            job: currentBuild.fullDisplayName,
            result: currentBuild.result,
            timeInMillis: currentBuild.timeInMillis,
            causes: causes,
            artifactList: [],
            hearye: Announcements,
            betahearye: betaAnnouncements,
            rtcURL: repositoryAddress,
            buildResultUUID: buildResultUUID,
            loadDirectory: loadDirectory,
            environmentNameDVLP: env.ucdEnvironmentNameDVLP,
            buildDefId: buildDefinitionId,
            mvnCommandLine: env.mvnCommandLine,
            componentName: env.ucdComponentName,
            versionNumber: env.version,
            nexusUpload: env.nexusUpload,
            nupkgFile: env.nupkgFile,
            personalBuild: env.personalBuild,
            jenkinsEnvironment: env.jenkinsEnvironment,
            testUCDUsed: env.useTestUCD,
            isBetaGroup: env.isBetaGroup,
            buildID: env.curTime,
            buildEngineServer: env.buildEngineHostName,
            workspaceName: env.WSNAME,
            projectArea: env.PROJECTAREA,
            buildFailure: env.buildFailure,
            nexusStatusMatch: env.nexusStatus,
            excludedFromSQ: env.excludedFromSq,
            veracodeResult: env.veracodeResult,
            veracode: env.veracode,
            veracodeSASTMode: env.veracodeSASTMode,
            veracodeResultURL: env.vcReportURL,
            changes: changez,
            violations: env.violations,
            sqEnvResult: env.SQ_QUALITY_GATE_STATE,
            sqEnvDuplicates:env.SQ_METRIC_DUPLICATED_LINES_DENSITY,
            sqEnvDuplicates_new:env.SQ_METRIC_NEW_DUPLICATED_LINES_DENSITY,
            sqEnvMaintainable:env.SQ_METRIC_SQALE_RATING,
            sqEnvMaintainable_new:env.SQ_METRIC_NEW_MAINTAINABILITY_RATING,
            sqEnvReliable:env.SQ_METRIC_RELIABILITY_RATING,
            sqEnvReliable_new:env.SQ_METRIC_NEW_RELIABILITY_RATING,
            sqEnvSecurity:env.SQ_METRIC_SECURITY_RATING,
            sqEnvSecurity_new:env.SQ_METRIC_NEW_SECURITY_RATING,
            sqEnvCoverage:env.SQ_METRIC_COVERAGE,
            sqEnvCoverage_new:env.SQ_METRIC_NEW_COVERAGE,
            sqStatus:env.sqStatus,
            sqQualityGate:env.qualityGate,
            projectName:env.JOB_NAME,
            timestampString:BUILD_TIMESTAMP,
            jTotalCount:env.jTotalCount,
            jFailCount:env.jFailCount,
            jSkipCount:env.jSkipCount,
            jPassCount:env.jPassCount,
            jUnitName:env.jUnitName,
            jcases:jcases.join("\n"),
            ncases:ncases.join("\n"),
            buildlog:sampleLog,
            ]
        if (IsDebug()) {
            variables.each { k,v -> 
                echo "Key ${k} found type ${v.getClass()}"
            }
        }
        Date start = new Date()
        template = libraryResource(useTemplate)
        Date point1 = new Date()
        println "Library resource took "+ groovy.time.TimeCategory.minus(point1,start)
        report = Render_Template(template, variables)
        Date point2 = new Date()
        println "Render took " + groovy.time.TimeCategory.minus(point2,point1)
		Send_Email_Results("${contacts},${requester}", currentBuild.result+warning+": ${buildDefId} - ${perBuild}Build ${BUILD_TIMESTAMP}",fileAtch, false, report)
        return 0
}




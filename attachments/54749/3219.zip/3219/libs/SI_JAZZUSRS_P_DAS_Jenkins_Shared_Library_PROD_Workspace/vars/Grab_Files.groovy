#!/usr/bin/env groovy

/**
* Check for unauthorized files
*  
* @param blob the file search wildcard blob 
* @return an array of found files
*  
*/

def call(blob) {
    if (IsDebug()) echo "Looking for unauthorized files..."
	def foundFiles = findFiles(glob: "**/*.${blob}", excludes:".jazz5**/*") //find files matching type
	if (IsDebug()) {
		echo "${blob}: ${foundFiles}"; //print the array for each type
	}
	return foundFiles; //return the array of found files
}
#!/usr/bin/env groovy
// 176851

/**
  *
 * @return [Boolean] - Tells whether the current team is in the beta list
 */
def call() {
    if (IsDebug()) echo "DSL->IsBeta()"
	return (env.BETAGROUPS.contains(PROJECTAREA))
}


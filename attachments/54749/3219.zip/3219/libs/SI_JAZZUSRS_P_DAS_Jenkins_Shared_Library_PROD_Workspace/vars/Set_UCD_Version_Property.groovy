#!/usr/bin/env groovy
// 176851

/**
 * Set a UCD version property for a component.
 * 
 * @param componentName the component to use
 * @param versionNM	The version number in UCD for the component artifacts
 * @param propName	the name of the property
 * @param propValue the value of the property
 * @param whether it's a secure value
 * 
 * @return RTC Link name
 *
 */
 
def call(def componentName, String versionNM,String propName,String propValue,def secure="false",def testUCD="false") {
	String methodName = 'DSL -> Setting UCD Version Property'
	echo methodName
	def quietValue = (!IsDebug())
    def ucdTestProd = (testUCD == "true")?"https://ucd-test.bcbst.com":"https://ucd.bcbst.com"
    try {
//        ucdPropUrl = "${ucdTestProd}/cli/version/versionProperties?component="+URLIFY(componentName)+"&version=${versionNM}&name=${propName}&value=${propValue}"

        ucdPropUrl = "${ucdTestProd}/cli/version/versionProperties"
        httpRequest authentication: 'UCDImport',acceptType: 'APPLICATION_JSON', httpMode: 'PUT', requestBody: """{
  \"component\": \"${componentName}\",
  \"isSecure\": \"${secure}\",
  \"name\": \"${propName}\",
  \"value\": \"${propValue}\",
  \"version\": \"${versionNM}\"
}""", 
        responseHandle: 'NONE', url: 'https://ucd.bcbst.com/cli/version/versionProperties', wrapAsMultipart: false        
    } catch (err) {
        echo "Encountered a problem setting property "+propName+":"+err.message
        return err;
    }	
    return [name:propName, value:propValue];
}




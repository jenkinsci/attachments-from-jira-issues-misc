#!/usr/bin/env groovy
// 176851

/**
 * @param versionNM	[Object] (required) The version number in UCD for the component artifacts
 *  
 * @return status 	[Boolean] - whether version was found
 *
 */
 
def call(String versionNM) {
	String methodName = "DJSL -> Checking UCD Version ${versionNM}";
	echo methodName
	def verList
	try {
		if (env.useTestUCD== "true"){
			verList=httpRequest httpMode:'GET', authentication: 'UCDImport', quiet:true, url: "https://ucd-test.bcbst.com/cli/version/getVersionId?component=${env.ucdComponentName}&version=${versionNM}"
		} else {
			verList=httpRequest httpMode:'GET', authentication: 'UCDImport', quiet:true, url: "https://ucd.bcbst.com/cli/version/getVersionId?component=${env.ucdComponentName}&version=${versionNM}"
		}
	} catch (err) {
			echo "Version not found"
			return false;
	}
	return true;
}




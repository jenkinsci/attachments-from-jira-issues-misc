#!/usr/bin/env groovy
// 176851

/**
 * Check for binaries, unauthorized scripts, and object directories in the source.
 *  
 * @param loadDir the current load directory 
 *  
 * @return Object a list of compiled/packaged files found in prebuild
 *
 */
 
def call(def loadDir="") {
        echo "DSL->Check_For_Violations()"
		def gv = bcbst.das.GlobalVars;
		echo "looking for obj and binary directories..."
		gv.DIRTYPES.each{ 
			//look for each of the dir names and remove
			grabDirs(it)
		}
		echo "looking for checked-in binaries"
		def directoryName = "${loadDir}"
		def naughtyList; // unformatted list of binaries
		def naughtyCount = 0; //number of binaries found
		def naughtyFiles = []; // list of binaries, formatted for html output
		gv.FILETYPES.each{
			naughtyList = Grab_Files(it)
			def naughtyType = naughtyList.size()
			if (naughtyType > 0) {
				naughtyCount+=naughtyType //update the count of naughty files by the number of binaries found
				naughtyList.each { that->
					if (that.toString() == ".npmrc") {
						echo "DANGER! NPMRC FOUND!"
					}
					if (that.toString().contains("jazz5")) {
						if (IsDebug()) {
							echo "jazz5 file"
						}
						naughtyCount--
					} else {
						naughtyFiles.push(that.toString())
					}
				} //naughtyList.each
			} //if
		} //filetypes.each
//		if (naughtyCount > 0) {
			echo "You have ${naughtyCount} compiled files in your source."
			return naughtyFiles //return the list of files
//		} //if
//		return null
	} //def
	/**
	 * Check for unauthorized directories
	 *
	 * @param blob the file search wildcard blob
	 *
	 */

	void grabDirs(blob) {
		if (IsDebug()) {
			echo "checking for ${blob}"
		}
		def foundDirs = findFiles(glob: "**/${blob}/") //get an array of all files matching this list
		if (foundDirs.size()>0) {
			if (IsDebug()) {
				echo "Found 1 or more ${blob} directory(s)."
			}
			if ((env.skipCleanup!="true") && (!(IsDebug()))) {
				//looks like we found some files
				def foundPaths = [foundDirs[0].path.toString().split("${blob}")[0]+"${blob}/"]
				foundDirs.each { //act on each because each parent path could be different
					foundPaths.add(it.path.toString().split("${blob}")[0]+"${blob}/") // extract the entire path without component files
				}
				def foundPathsUnique = foundPaths.unique()
				foundPathsUnique.each {
					fileOperations([folderDeleteOperation(it)])
				}
			} //if skipCleanup and debug are false
		} //if
	}
	


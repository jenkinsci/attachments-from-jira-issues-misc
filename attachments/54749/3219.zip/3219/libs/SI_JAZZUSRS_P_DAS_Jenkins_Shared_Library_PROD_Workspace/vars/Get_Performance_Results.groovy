def call(def appName){
    echo "DSL->Get_Performance_Results"
	try{
	def reportFile = readFile("${WORKSPACE}/performance-report/$BUILD_TIMESTAMP/neoload-report_${appName}_$BUILD_TIMESTAMP/junit-sla-results.xml")
	return reportFile
	}catch(ex){echo ex.getMessage(); return null}
}
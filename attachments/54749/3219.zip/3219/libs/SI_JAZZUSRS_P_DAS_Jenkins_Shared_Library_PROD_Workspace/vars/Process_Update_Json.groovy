#!/usr/bin/env groovy
    import java.util.stream.IntStream
    import java.util.stream.Collectors
// 176851

/**
 * Process the jenkins-update.json files to produce updated notifications.
 *  
 * @param manual whether the pipeline is run manually
 * @param buildCause the user that initiated the run
 * 
 * @return a list of all the plugins and versions currently on the server
 */
def call(def manual = "false",def buildCause="NULL") {
    echo "DSL->Process_Update_Json()"
        // get installed plugins
    
    if (jenkinsEnvironment == "PROD") {
        jauth = "SI_JENKINS_P_API"
        jurl = "jenkins"
    } else {
        jauth="SI_JENKINS_T_API"
        jurl="jenkins-test"
    }
    def aurl = "https://${jurl}.bcbst.com/pluginManager/api/json?depth=1&xpath=%2F*%2F*%2FshortName%7C%2F*%2F*%2Fversion&wrapper=plugins&pretty=true"
    def response = httpRequest authentication: jauth, ignoreSslErrors: true, url: aurl
    if (IsDebug()) {echo "Response: "+ response.getContent()}
    def jsonPlugins = readJSON text:response.getContent()
//        def plugins = jenkins.model.Jenkins.instance.getPluginManager().getPlugins()
        // get the cause of the build - user or daemon?
        def pluginInfo = []
//      writeFile file:"plugins_${jenkinsEnvironment}.text", text: plugins.join("\n")
        def manualBuild = ""
        def debug = false
        // turn on debug if manual build
        if (manual == "true") {
            echo "manual Build"
            manualBuild = ": MANUAL BUILD by ${buildCause}"
            debug = true
        }
        // pull the json file from RTC (for the moment)
        echo "Reading json file"
        def auth = (jenkinsEnvironment=='TEST')?'SI_JENKINS_T_API':'SI_JENKINS_T_API'
        httpRequest authentication: auth, contentType: 'APPLICATION_JSON', ignoreSslErrors: true, outputFile: 'update-center.json', responseHandle: 'NONE', url: 'https://jenkins-test.bcbst.com/job/Utilities/job/update-update-center/lastSuccessfulBuild/artifact/update-center.json'
        // drop the contents into a string
        String jsonFile = readFile 'F:/Jenkins/workspace/Utilities/list_plugins/update-center.json'
        // remove the excess header/footer
        jsonFile = jsonFile.replaceAll("updateCenter.post\\(", "")
        jsonFile = jsonFile.replace(');',"")
        // parse the json using the jenkins command
        echo "Parsing json file"
        def props = readJSON text:jsonFile
        echo "Parsing plugins"
        // filter out all the updated plugins into a new variable
        updated = props.plugins
        echo "Parsing warnings"
        // filter out all the vulnerabilities into a new variable
        getWarnings = props.warnings
        def jenkWarn = []
        echo "...Jenkins core"
        for (def i = 1; i< getWarnings.size(); i++) {
            //check for core vulnerabilities and add to jenkWarn
           if ((getWarnings.getJSONObject(i).getString("type") == "core") && (getWarnings.getJSONObject(i).getJSONArray("versions").size()>1)) {
               println "Found core vulnerability " + getWarnings.getJSONObject(i).get("versions").get(1).getString("lastVersion")
try {
       jenkWarn.add(getWarnings.getJSONObject(i).get("versions").get(1).getString('pattern'))
} catch (ex) {
}
           }
        }
        echo "...Plugins"
        // define 
        Map<String, Object> cargo = new HashMap<String,Object>();
        for (def i = 1; i < getWarnings.size(); i++) {
            Map<String,String> load = new HashMap<String,String>()
            String name = getWarnings.getJSONObject(i).getString("name")
            String cert = getWarnings.getJSONObject(i).getString('id')
            String ident = getWarnings.getJSONObject(i).getString("id")+','+getWarnings.getJSONObject(i).get('versions').get(0).getString('pattern')+','+getWarnings.getJSONObject(i).get('url')
    //        println "name is ${name}"
            if (cargo.containsKey(name)) {
                load = cargo.get(name);
            }
            load.put(cert,ident)
            cargo.put(name,load);
        }
    //    println cargo.toString()
        List<String> list = new ArrayList<String>()
        List<String> vlist = new ArrayList<String>()
        i = 0
        jsonPlugins.plugins.each() {
        println "ITEM: " +it.shortName+ " - "+ it.version
//        plugins.each {
        def fixed = ""
    //    echo fixed
          ++i
          curName = it.shortName
    //      echo "${curName}:"
          curVer = it.version
          // add plugins to array of plugins for later
          pluginInfo.add("${curName}:${curVer}")
          def newVer = ""
          def newURL = ""
           if (updated.containsKey(curName)) {
                         newVer =  updated.get("${curName}").get("version")
                        newURL =  updated.get("${curName}").get("url")
                        newWiki = updated.get("${curName}").get("wiki")
            
               if (cargo.containsKey(curName)) {
                   cargo.get(curName).each { individual->
    
    //                    println individual.getValue()
                        def warningFields = individual.getValue().split(",")
    //                    println warningFields[1]
                        if (curVer ==~ warningFields[1]) {
                            fixed = "Not Fixed"
    //                        echo "newVer is ${newVer}, warning field is ${warningFields[1]}"
                            // check for fixed vulnerabilities
                            if ((!(newVer ==~ warningFields[1])) && (newVer !="")) {
                                if (curVer != newVer) {
                                    vlist.add("<tr><td><b>${curName}</b></td><td><i>${curVer}</i></td><td>${warningFields[0]}</td><td>${warningFields[2]}</td><td><b>Fix available in <a href='${newURL}'>${newVer}</a></b></td></tr>")
                                }
                            } else {
                                vlist.add("<tr><td><b>${curName}</b></td><td><i>${curVer}</i></td><td>${warningFields[0]}</td><td>${warningFields[2]}</td><td>Not Fixed</td></tr>")
    
                            }
                            
                            if (debug=="true") { echo "<tr><td><b>${curName}</b></td><td><i>${curVer}</i></td><td>${warningFields[0]}</td><td>${warningFields[2]}</td><td>${fixed}</td></tr>" }
    
                        }
                   }
                }
            } else {
             newVer = ""
             newURL = ""
        }
          //check for new plugin versions
          if ((it.version != newVer) && (newVer!="") && (it.version.compareTo(newVer)<0)) {
              list.add('<tr><td><b><a href="'+newWiki+'">'+it.shortName+'</a></b></td><td><i>'+it.version+' -> '+newVer+'</i></td><td>'+newURL+'</td></tr>')
          }
        }
    //    writeFile file:"pluginver_${jenkinsEnvironment}.text", text: pluginInfo.join("\n")
//      writeFile file:"plugins_${jenkinsEnvironment}.text", text: pluginInfo.join("\n")
        //powershell "cp F:/Jenkins/workspace/Utilities/list_plugins/*.text ${pluginDir}"
        Sort_List(list)
        def header = ''' <style>
        table, th, td {
         border: 1px solid black;
         border-collapse: collapse;
         padding: 15px;
        }
        </style>
        <body>
        The following plugins have been updated recently and are newer than the plugins installed on the Jenkins server. <br />
        Please investigate each plugin update and update for quarterly task as applicable.<br /><br />
        '''
        def vheader = ''' <style>
        table, th, td {
         border: 1px solid black;
         border-collapse: collapse;
         padding: 15px;
        }
        </style>
        <body>
        The following vulnerabilities have been identified in Jenkins plugins. <br />
        Please investigate each vulnerability and update ASAP if the vulnerability is marked as fixed in the new version<br /><br />
        '''
        def toField = "Peter_Carenza@bcbst.com"
        if (emailUsers=='true') {
            toField = 'DeliveryAutomationSvcs@bcbst.com'
        }
        
        def jenkinsVersion = Get_Jenkins_Version()
        println "Jenkins Version is " + jenkinsVersion
        println "list size is "+jenkWarn.size()
        jenkWarn.each { eachver->
     //       echo "${eachver}:"
            if (jenkinsVersion ==~ eachver) {
                emailext body: "Vulnerability in current Jenkins version - <b>${jenkinsVersion}</b> Upgrade to newest stable version (<a href='${props.core.url}'>${props.core.version}</a>) as soon as possible!",subject: "ATTENTION: Jenkins ${jenkinsEnvironment} is currently vulnerable!", to:toField,attachLog:false
                echo "Vulnerability in ${jenkinsVersion}! Upgrade to newest stable version ${props.core.version} immediately!"
            } else {
                echo "No vulnerability found yet"
            }
        }
        println "comparison is "+jenkinsVersion.compareTo(props.core.getString('version'))
        if (jenkinsVersion != props.core.getString('version')) {
            echo "New LTS (Stable) Jenkins Version ${props.core.version} available!"
            emailext body: "Found new LTS Jenkins version - <b>${props.core.version}</b> ${props.core.url}", subject: "New Jenkins Stable Version Notification for ${jenkinsEnvironment}${manualBuild}", to:toField,attachLog:false
        }
        if (list.size()>0) {
            def emailPlugins = list.join("")
            emailext body: "${header} <table>${emailPlugins}</table></body>", subject: "${list.size()} Jenkins ${jenkinsEnvironment} Plugin Updates${manualBuild}", to: toField, attachLog:false
        }
        if (vlist.size()>0) {
            def emailWarnings = vlist.join("")
            emailext body: "${vheader} <table>${emailWarnings}</table></body>", subject: "${vlist.size()} Jenkins ${jenkinsEnvironment} Vulnerabilities Found${manualBuild}", to: toField, attachLog:false
        }
    
        i = 0
        for (String item : list) {
          i++
          println(" ${i} ${item}")
        }
        i = 0
        for (String item : vlist) {
          i++
          println(" ${i} ${item}")
        }
        
        return pluginInfo
    
    }




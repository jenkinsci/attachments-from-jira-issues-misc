#!/usr/bin/env groovy
// 198354
import groovy.json.JsonSlurperClassic
/**
 * Get UCD component memory usage
 * 
 * @param componentName the UCD component to analyze
 * @param version the UCD version number to analyze
 * @param useTest whether to use Test UCD
 *
 * @return usage in KB
 */

def call(String componentName, String version, def useTest = "true") {
    echo "DSL->Get_Process_Memory_Usage()"
	componentName = URLIFY(componentName)
	def env = (useTest.equalsIgnoreCase('true'))? "ucd-test":"ucd"
	def makeSilent = (!IsDebug())
	def response=httpRequest httpMode:'GET', authentication: 'UCDImport', quiet: makeSilent, outputFile: 'output.json', url: "https://${env}.bcbst.com/cli/version/listVersionArtifacts?component=${componentName}&version=${version}"
	def jsonData = new groovy.json.JsonSlurperClassic().parseText(response.content)
	if (IsDebug()) {
		echo "mars"
		println jsonData.toString()
		echo "saturn"
	}
	def totalBytes = 0
	for(def item in jsonData){
		if (IsDebug()) {
			echo item.toString()
		}
		if (item.totalSize != null) {
			totalBytes += item.totalSize
		} else {
			totalBytes += item.length
		}
		if (IsDebug()) {
			echo totalBytes.toString()
		}
	}
	
	return totalBytes / 1024	//convert to KB
}	
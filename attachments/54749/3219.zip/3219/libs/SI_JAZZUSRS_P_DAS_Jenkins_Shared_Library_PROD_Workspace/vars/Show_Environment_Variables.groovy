#!/usr/bin/env groovy
// 176851

/**
 * Show the environment variables in the log if debug.
 * 
 *
 */
 
void call() {
	if (IsDebug()) {
        echo "Showing environment variables for build:"
		bat 'set > env.txt'
		def envFile = readFile 'env.txt'
		def envArray = envFile.split("\r?\n")
		for (String i : envArray) {
			echo i
		} //for
	}
}



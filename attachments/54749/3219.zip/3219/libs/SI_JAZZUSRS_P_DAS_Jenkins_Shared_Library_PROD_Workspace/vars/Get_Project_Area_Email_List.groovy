#!/usr/bin/env groovy
// 198354

/**
 *
 * @param repoURL		[String] (required) The repository URL to run the API call against
 *
 * @param projectArea	[String] (required) The name OR the uuid of the project area to look in
 *  
 * @return emailList 	[String] - A comma-separated list of email addresses for users in the current project area
 *
 */
 

def call(String repoURL, String projectArea) {
	echo "Fetching project area contact list from RTC..."
	
	//if 'projectArea' is a uuid, check for project area uuid
	if (projectArea.startsWith('_')) {
		httpRequest authentication: 'RTC', ignoreSslErrors: true, outputFile: 'outputPA.log', responseHandle: 'NONE', url: repoURL + '/rpt/repository/foundation?fields=projectArea%2FprojectArea%5BitemId%3D' + projectArea + '%5D%2F%28itemId%7Carchived%7Cname%7C%28roleAssignments%2F%28contributor%2F%28itemId%7CemailAddress%7CuserId%7Cname%7Carchived%29%7CcontributorRoles%2F*%29%29%29&size=10000'
	}
	//otherwise check for project area name
	else {
		httpRequest authentication: 'RTC', ignoreSslErrors: true, outputFile: 'outputPA.log', responseHandle: 'NONE', url: repoURL + '/rpt/repository/foundation?fields=projectArea%2FprojectArea%5Bname%3D' + projectArea + '%5D%2F%28itemId%7Carchived%7Cname%7C%28roleAssignments%2F%28contributor%2F%28itemId%7CemailAddress%7CuserId%7Cname%7Carchived%29%7CcontributorRoles%2F*%29%29%29&size=10000'
	}
	
	def outputH = steps.readFile "outputPA.log"
	def rootNode = new XmlSlurper()
	def emailList = ""
	def emailExclusion = ["IS_SQA_GM@BCBST.com", "Roberto_Congmon@BCBST.com", "Alaykumar_Patel@bcbst.com", "Edwin_Hulbert@bcbst.com", "Abhishek_Chauhan@bcbst.com", "Corey_Bradley@bcbst.com", "PraveenKumar_Miriyala@bcbst.com", "Sherry_Crawford@bcbst.com", "Michael_Saunders@bcbst.com", "Melissa_Blazek@bcbst.com", "Courtney_Bramlett@bcbst.com", "Jessie_Collins@bcbst.com", "Samuel_Moore@bcbst.com", "Stephanie_Pickett@bcbst.com", "David_Rowe@bcbst.com", "Siena_Siegel@bcbst.com", "Mary_Gause@bcbst.com", "Johnathon_Johnson@bcbst.com", "Madhu_Gadipally@bcbst.com", "Darrell_Simpson@bcbst.com", "Deep_Thakur@bcbst.com"]
	
	rootNode.setFeature("http://apache.org/xml/features/disallow-doctype-decl", false) 
	rootNode = rootNode.parseText(outputH)
	rootNode.projectArea.roleAssignments.eachWithIndex { roleAssignments , i -> 
		//if user is archived, skip
		if (roleAssignments.contributor.archived.text() == 'false') {
			//check if user has the specified roles
			if (roleAssignments.contributorRoles.id.toString().contains('team_member') || roleAssignments.contributorRoles.id.toString().contains('team_coach')) {
				//if email is formatted improperly (i.e. service accounts), skip
				if (!roleAssignments.contributor.emailAddress.text().startsWith('_') && roleAssignments.contributor.emailAddress.text().contains('@') && !emailExclusion.contains(roleAssignments.contributor.emailAddress.text())) {
					//if list is empty, add email address
					if (emailList == "") {
						emailList += roleAssignments.contributor.emailAddress.text()
					}
					//otherwise add email and comma
					else {
						emailList += ',' + roleAssignments.contributor.emailAddress.text()
					}
				}
			}
		}
	}
	emailList = emailList.trim()
	return emailList
}
/**
*	Used to safely check the length of a list, returning 0 if it is null
* @param l the list to be measured
* @return the size of the list
* 
*/

def call(List l){
	if(l != null){
		return l.size()
	}
	return 0;	//default
}
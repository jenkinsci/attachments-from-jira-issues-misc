#!/usr/bin/env groovy

def call(String component, String application){

	echo "BEGIN Add_Component_To_Application"

	def ucdEnv = "ucd.bcbst.com"
	if(env.useTestUCD != null && env.useTestUCD?.equalsIgnoreCase('true')){
		ucdEnv = "ucd-test.bcbst.com"
	}
		
//	def sb = new StringBuilder("");
//	sb.append("https://")
//	sb.append(ucdEnv)
//	sb.append("/cli/application/addComponentToApp")
//	sb.append("?component=")
//	sb.append(component)
//	sb.append("&application=")
//	sb.append(application)
//  def ucdUrl = sb.toString()
//	TODO: use stringbuilder.
	
	def ucdUrl = "https://" + ucdEnv + "/cli/application/addComponentToApp?component=" + component + "&application=" + application
	//sb.toString()
	
	def response = httpRequest httpMode:'PUT', authentication: 'UCDImport',  url: URLIFY(ucdUrl)	//quiet:quietValue,
	echo response.toString()
}
import net.sf.json.JSONObject

/** 
* Get a JSON object out of a JSON array.
* 
* @param jsonRoot The JSON array
* @param searchTerm The value to match the correct element in the JSON array.
* @param searchField The name of the field within each array element to look for a match. 
* @return The JSON object extracted from the JSON array.
**/
JSONObject call(def jsonRoot, String searchTerm, String searchField = "name") {
    if (IsDebug()) println "[DEBUG] Reached method : JSONObject Get_JSON_Item(def jsonRoot, String searchTerm, String searchField = 'name')";
    return jsonRoot.find {it[searchField]?.equalsIgnoreCase(searchTerm)}
}
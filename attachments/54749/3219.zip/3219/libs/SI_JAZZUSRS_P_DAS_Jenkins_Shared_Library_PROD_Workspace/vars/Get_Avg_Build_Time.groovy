#!/usr/bin/env groovy
// 176851

/**
 *
 * @param buildDefId The build definition Id 
 * @param printOut (currently unused) 
 *  
 * @return Object the average time in mins
 *
 */
 
def call(def buildDefId, def printOut="false") {
    if (IsDebug()) echo "Get_Avg_Build_Time"
//	try {
//		echo "Build Definition id is ${buildDefinitionId}"
		httpRequest authentication: 'RTC', ignoreSslErrors: true, quiet: !printOut, outputFile: "times_${buildDefinitionId}.log", responseHandle: 'NONE', url: 'https://rtcccm.bcbst.com/ccm/rpt/repository/build?fields=build/buildResult[buildDefinition/id='+buildDefinitionId+'%20and%20buildStatus=OK%20and%20buildState=COMPLETED]/(timeTaken)'
		def outputH = readFile "times_${buildDefinitionId}.log"
//		echo outputH
		def build = new XmlSlurper().parseText(outputH)
		def sum=0
		def count=0
		def avg=0
		build.buildResult.each { buildResult->
			buildResult.timeTaken.each { timeTaken->
				sum+=timeTaken.toInteger()
				count++
			}
		}
		echo "sum = ${sum}, count= ${count}"
		avg = sum.div(count)/1000/60;
		echo "Average build time is ${avg} minutes"
		return avg
//	} catch (error) {
//		return -1
//	} 
}




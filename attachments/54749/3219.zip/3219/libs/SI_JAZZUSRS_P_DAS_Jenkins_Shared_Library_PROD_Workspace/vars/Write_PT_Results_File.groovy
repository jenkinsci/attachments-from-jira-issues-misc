/**
*   Write to Performance Test results report file
* @param environmentName the environment being tested
* @param resultsFile    the path to the test set
* @param apps The application being tested
* @param slaStatus the status of the test
* @return text of the performance report
* 
*/

def call(String environmentNm, String resultsFile, String apps, def slaStatus) {

    def content = readFile("${WORKSPACE}\\performance-report\\${apps}_${environmentNm}_rawresults.xml")
    def readContent = readFile "${resultsFile}"
    int i = 1 // defined to capture the 1st transaction name
    int j = 0 // defined to capture the 2nd, 3rd and nth transaction - 8th instance
    int iterations = 4 // defined to capture the 2 metrics of transactions - name, response time

    if (slaStatus == "PASS") {
        writeFile file: "${resultsFile}", text: readContent+"\r\n\r\n ${apps} : <span style=\"color:MediumSeaGreen\">${slaStatus}</span>\r\n\r\n<span style=\"background-color:rgb(240, 240, 240)\">Response Time (ms)           Transaction</span>\r\n"
        readContent = readFile "${resultsFile}"
    } else {
        writeFile file: "${resultsFile}", text: readContent+"\r\n ${apps} : <span style=\"color:Tomato\">${slaStatus}</span>\r\n\r\n<span style=\"background-color:rgb(240, 240, 240)\">Response Time (ms)           Transaction</span>\r\n"
        readContent = readFile "${resultsFile}"
    }
    content.split(';').each {
        // Capture 1st transaction
        if (i == 15) {
            Transaction = "${it}"
        }
        if (i == 16) {
            //Add a new line
            writeFile file: "${resultsFile}", text: readContent+"${it}                  "+"${Transaction}"+"\r\n"
            readContent = readFile "${resultsFile}"
        }
        if (i > 16) {
            j++
        }
        if ((i > 16) && ((j % 8 == 0) || (iterations < 3))) {
            // Capture 2nd, 3rd,..nth  transaction
            // additional tabs at the end for formatting the results
            //writeFile file: "${resultsFile}", text: readContent+"${it}                        "
            //readContent = readFile "${resultsFile}"
            if (j % 8 == 0) {
                iterations = 1
                Transaction = "${it}"
            }   
            iterations ++
            if (iterations == 3) {
                j = 0
                //writeFile file: "${resultsFile}", text: readContent+"\r\n \r\n"
                writeFile file: "${resultsFile}", text: readContent+"${it}                  "+"${Transaction}"+"\r\n"
                readContent = readFile "${resultsFile}"
            }
        } // i greater than 16 and j is divisible by 8 and iterations less thn 3
        i++
    } //content each
    sleep 10 // 10 sec
    //Copy and Rename NeoLoad reports with application name and timestamp
    fileOperations([folderCopyOperation(destinationFolderPath: "${WORKSPACE}\\performance-report\\$BUILD_TIMESTAMP\\neoload-report_${apps}_$BUILD_TIMESTAMP", sourceFolderPath: "${WORKSPACE}\\neoload-report")])
    PerformanceReport = tm('${FILE, path="\\\\performance-report\\\\PerformanceResults.txt"}')
    return PerformanceReport
}
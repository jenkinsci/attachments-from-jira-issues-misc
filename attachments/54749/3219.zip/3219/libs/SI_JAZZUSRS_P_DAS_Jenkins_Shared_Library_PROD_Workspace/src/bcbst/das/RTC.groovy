/*
 * Script to print a report about build definitions in the repository, grouped by project area.
 * To run:
 *   - set/export env vars for RTC_REPO_URL, RTC_USER_ID and RTC_PASSWORD
 *   - run: groovy -cp "<buildsystem/buildtoolkit dir>/*" BuildDefinitionsReport.groovy
 */
package das
import com.ibm.team.filesystem.common.workitems.*
import com.ibm.team.foundation.common.text.XMLString
import com.ibm.team.repository.common.*
import com.ibm.team.repository.common.query.*
import com.ibm.team.repository.common.query.ast.*
import com.ibm.team.repository.client.*
import com.ibm.team.repository.client.login.*
import com.ibm.team.repository.service.*
import com.ibm.team.links.common.*
import com.ibm.team.process.common.*
import com.ibm.team.process.client.*
import com.ibm.team.scm.common.*
import com.ibm.team.scm.common.dto.*
import com.ibm.team.scm.common.internal.*
import com.ibm.team.scm.common.internal.dto.*
import com.ibm.team.scm.common.links.ChangeSetLinks;
import com.ibm.team.scm.common.providers.ProviderFactory;
import com.ibm.team.scm.client.*
import com.ibm.team.build.common.*
import com.ibm.team.build.common.builddefinition.*
import com.ibm.team.build.internal.common.builddefinition.IJazzScmConfigurationElement;
import com.ibm.team.build.common.model.*
import com.ibm.team.build.internal.common.model.dto.*
import com.ibm.team.build.common.model.query.IBaseBuildResultQueryModel.IBuildResultQueryModel
import com.ibm.team.build.common.model.query.IBaseBuildEngineQueryModel.IBuildEngineQueryModel;
import com.ibm.team.build.internal.common.model.query.BaseBuildDefinitionQueryModel.BuildDefinitionQueryModel
import com.ibm.team.build.client.*
import com.ibm.team.build.internal.client.ITeamBuildRecordClient
import com.ibm.team.build.internal.client.iterator.ItemQueryIterator
import com.ibm.team.build.internal.client.workitem.*
import com.ibm.team.repository.common.service.IQueryService
import com.ibm.team.workitem.client.*
import com.ibm.team.workitem.common.*
import com.ibm.team.workitem.common.model.*;
import java.security.AlgorithmParameters;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import groovy.json.JsonSlurper
import groovy.time.*


/**
 * 
 * A class that includes a whole bunch of RTC helper functions.
 * 
 * 
 */
class RTC {
    def repo
    /** the build client class */
    ITeamBuildClient buildClient
    /** the build record client class */
    ITeamBuildRecordClient buildRecordClient
    /** the process client class */
    IProcessItemService processClient
    /** the work item client class */
    IWorkItemClient workItemClient
    /** the workspace manager class */
    IWorkspaceManager workspaceManager

    class LoginHandler implements ILoginHandler2 {
        def userId, password
        
        def ILoginInfo2 challenge(ITeamRepository repo) {
            new UsernameAndPasswordLoginInfo(userId, password)
        }
    }
/**
 * 
 *         Constructor.
 */
    RTC(repoUrl, userId, password) {
        repo = TeamPlatform.teamRepositoryService.getUnmanagedRepository(repoUrl)
        repo.registerLoginHandler(new LoginHandler(userId: userId, password: password))
        buildClient = ClientFactory.getTeamBuildClient(repo)
        buildRecordClient = repo.getClientLibrary(ITeamBuildRecordClient.class)
        processClient = repo.getClientLibrary(IProcessItemService.class)
        workItemClient = repo.getClientLibrary(IWorkItemClient.class)
        workspaceManager= SCMPlatform.getWorkspaceManager(repo)
    
    
    }
    
    def login(monitor = null) {
        repo.login(monitor)
    }

    def logout(monitor = null) {
        repo.logout(monitor)
    }

/**
 * Fetch an item
 * 
 * @param itemHandle
 * @param properties
 * @param flags
 * 
 * @return [IItem] the item with properties being fetched
 */
    def fetch(itemHandle, properties = null, flags = IItemManager.DEFAULT, monitor = null) {
        if (properties == null)
            repo.itemManager.fetchCompleteItem(itemHandle, flags, monitor)
        else
            repo.itemManager.fetchPartialItem(itemHandle, flags, properties, monitor)
    }

/**
 * Fetch multiple items
 * 
 * @param itemHandles
 * @param properties
 * @param flags
 * 
 * @return [IItem] items being retrieved
 */
    def fetchMulti(itemHandles, properties = null, flags = IItemManager.DEFAULT, monitor = null) {
        if (properties == null)
            repo.itemManager.fetchCompleteItemsPermissionAware(itemHandles, flags, monitor).retrievedItems
        else
            repo.itemManager.fetchPartialItemsPermissionAware(itemHandles, flags, properties, monitor).retrievedItems
    }

/**
 * Fetch list of items
 * 
 * @param iter
 * @param properties
 * @param flags
 * 
 * @return [IItem[]] List of items
 */
    def fetchAll(ItemQueryIterator iter, properties = null, flags = IItemManager.DEFAULT, monitor = null) {
        def items = []
        while (iter?.hasNext(monitor)) {
            def handles = iter.next(100, monitor)
            items.addAll(fetchMulti(handles, properties, flags, monitor))
        }
        items
    }
    
    /**
     * Return a list of project area objects in RTC.
     * 
     * @param properties the properties to include
     *
     * @return [IProjectArea[]] List of project areas
     */
    
    def projectAreas(properties = null, monitor = null) {
        processClient.findAllProjectAreas(properties, monitor)
    }

/**
 * Return a list of build definition objects in a project area
 * 
 * @param projectArea the project area to query
 * @param properties the properties to include
 * @param flags
 * 
 * @return [IBuildDefinition[]] List of build definitions
 */
    def buildDefinitionsInProjectArea(projectArea, properties = null, flags = IItemManager.DEFAULT, monitor = null) {
        def queryModel = BuildDefinitionQueryModel.ROOT
        def query = IItemQuery.FACTORY.newInstance(queryModel)
        query.filter(queryModel.processArea().projectArea()._eq(query.newItemHandleArg()))
        def iter = new ItemQueryIterator(buildClient, query, [projectArea] as Object[])
        fetchAll(iter, properties, flags, monitor)
    }
    
/**
 * Returns the workspace used by the build definition
 * 
 * @param definition the build definition
 * 
 * @return [String] the build workspace name
 */
    def getWorkspace(definition) {
        try {
            UUID wsUUID = UUID.valueOf(definition.getPropertyValue("team.scm.workspaceUUID", null));
            IWorkspaceHandle wsHandle = (IWorkspaceHandle) IWorkspace.ITEM_TYPE.createItemHandle(wsUUID, null);
            def workspace = (IWorkspace) repo.itemManager().fetchCompleteItem(wsHandle, IItemManager.DEFAULT, null);
            workspace.getName()
        } catch (e){
//            definition.getPropertyValue("team.scm.workspaceUUID",null).toString()
            return "NONE"
        }
    }
    
/**
 * Change the name of a build snapshot in a result.
 * 
 * @param buildResultUUID the build result id
 * @param snapText the text to change the snapshot name to
 * 
 * @return
 */
    def mutateSnapshot(String buildResultUUID, String snapText,monitor=null) {
        IBuildResultHandle parentBuild = IBuildResult.ITEM_TYPE.createItemHandle(UUID.valueOf(buildResultUUID), null);
        IBuildResultContribution[] snapshotContribs = buildClient.getBuildResultContributions(parentBuild, ScmConstants.EXTENDED_DATA_TYPE_ID_BUILD_SNAPSHOT, monitor);
        IWorkspaceManager wkspcMgr = (IWorkspaceManager)repo.getClientLibrary(IWorkspaceManager.class);
        if(snapshotContribs != null) {
           IBaselineSetHandle bsHandle = (IBaselineSetHandle)snapshotContribs[0].getExtendedContribution();
           IBaselineSet snapshot = (IBaselineSet)repo.itemManager.fetchCompleteItem(bsHandle, IItemManager.REFRESH, monitor);
           wkspcMgr.setName(snapshot, snapText, monitor);
        }
    }
    
/**
 * Set the build label text 
 * 
 * @param buildResultUUID the UUID of the build result
 * @param labelText the text to change the build label to
 * 
 * @return
 */
    def setBuildLabel(String buildResultUUID, String labelText, monitor=null) {
        String properties = IBuildResult.PROPERTY_LABEL;
        IBuildResultHandle parentBuild = IBuildResult.ITEM_TYPE.createItemHandle(UUID.valueOf(buildResultUUID), null);
        IBuildResult buildResult = (IBuildResult) repo.itemManager().fetchPartialItem(parentBuild, IItemManager.REFRESH, Arrays.asList(properties), monitor);
        String label = "${labelText}";
        buildResult=(IBuildResult) buildResult.getWorkingCopy();
        buildResult.setLabel(label);
        buildClient.save(buildResult, monitor);
    }
    
/**
 * Create a build folder in a build definition's project area
 * 
 * @param bd the build definition (to find the process area to place the folder)
 * @param folderName the folder
 * @param
 * 
 * @return [IBuildFolder] the new folder object
 */
    def createBuildFolder(IBuildDefinition bd, String folderName, monitor=null) {
        IBuildFolder newFolder = BuildItemFactory.createBuildFolder()
        newFolder.setName(folderName)
        newFolder.setProcessArea(bd.getProcessArea())
        newFolder.setParent(null)
        println "Build folder is "+ newFolder.toString()
//        getBuildFolderHandle(bd,"Archived")
        buildClient.save(newFolder.getWorkingCopy(),monitor)
        return newFolder
    }
    
/**
 * Create a build definition in the same project area as a given build definition
 * 
 * @param bd the build definition
 * @param bdName the name to call the build definition
 * 
 * @return
 */
    def createBuildDefinitionFromBD(IBuildDefinition bd,String bdName, monitor=null) {
        IBuildDefinition newbd = null
        newbd = BuildItemFactory.createBuildDefinition()
        IBuildDefinitionTemplate HJTemplate = BuildConfigurationRegistry.getInstance().getBuildDefinitionTemplate("com.ibm.rational.connector.hudson.ui.buildDefinitionTemplate");
        newbd.initializeConfiguration(HJTemplate)
        IBuildConfigurationElement SCM = BuildConfigurationRegistry.getInstance().getBuildConfigurationElement(IJazzScmConfigurationElement.ELEMENT_ID)
        newbd.initializeConfiguration(SCM)
        newbd.setProcessArea(bd.getProcessArea())
        newbd.setId(bdName)
        println "Creating build definition ${bdName}"
        buildClient.save(newbd,monitor)
        }

/**
 * get the process area of a build definition
 * 
 * @param bd the build definition
 * 
 * @return [IProcessArea] the process area
 */
    def getProcessArea(IBuildDefinition bd) {
        bd.getProcessArea()
    }
    
/**
 * get the process area name of a build definition
 * 
 * @param bd the build definition
 * 
 * @return String the process area name
 */
    def getProcessAreaName(IBuildDefinition bd) {
        IProcessAreaHandle ipah = bd.getProcessArea()
        def ipa = (IProcessArea) repo.itemManager().fetchCompleteItem(ipah, IItemManager.DEFAULT, null);
        ipa.getName()
    }
    
/**
 * get the handle of a build folder by name
 * 
 * @param bd the build definition
 * @param folderName 
 * 
 * @return the build folder handle
 */
    def getBuildFolderHandle(IBuildDefinition bd, String folderName, monitor=null) {
        IBuildItemNamePair[] pair = buildClient.getChildrenOfFolder(null,[bd.getProcessArea()] as IProcessAreaHandle[], monitor)
        IBuildFolder buildFolder = null
        pair.each {
            def bf = repo.itemManager().fetchCompleteItem(it.getItem(),IItemManager.DEFAULT,monitor)
//            println bf.getItemType().getName()
            if (bf.getItemType().getName() == "BuildFolder" && bf.getName()==folderName) {
                println bf.getName()+" "+bf.getClass()
                buildFolder = (IBuildFolder) bf
            }
        }
        return buildFolder        
    }
    
/**
 * move a build definition into a given folder
 * 
 * @param bd build definition object
 * @param folder the build folder object
 * 
 * @return
 */
    def moveBuildDefinition(IBuildDefinition bd, IBuildFolder folder, monitor=null) {
        IBuildDefinition wcDefinition = bd.getWorkingCopy()
        IItemHandle defHandle = (IItemHandle) wcDefinition.getItemHandle()
        IBuildFolderHandle folderHandle = (IBuildFolderHandle) folder.getItemHandle()
//        IBuildFolderHandle buildFolder = wcDefinition.getParent()
        buildClient.moveItemsToFolder([defHandle] as IItemHandle[],folderHandle,monitor)
    }
    
/**
 * get build definition object by name
 * 
 * @param buildDefinitionId the name of the build definition
 * 
 * @return the build definition object
 */
    def getBuildDefinition (String buildDefinitionId, monitor=null) {
        IBuildDefinition buildDefinition = buildClient.getBuildDefinition(buildDefinitionId, monitor)
        return buildDefinition
    }
    
/**
 * Get a list of templates 
 * 
 * @return a list of build templates (coming soon)
 */
    def getBuildDefinitionTemplates() {
        def templatesList=[[:]]
        IBuildDefinitionTemplate[] templates = BuildConfigurationRegistry.getInstance().getBuildDefinitionTemplates();
        for (IBuildDefinitionTemplate template : templates) {
                println("  Template Name: "+template.getName());
                println("  Template Id  : "+template.getId());
                templatesList.add(["name":template.getName(), id:template.getId()])
        }
        return templatesList
    }
    
/**
 * get all the properties of a build definition
 * 
 * @param buildDefinition
 * 
 * @return a list of build definition properties
 */
    def getBuildProperties(IBuildDefinition buildDefinition, monitor=null) {
        def properties = buildDefinition.getProperties()
        properties.each() {
            println it.getName()+" \""+it.getValue()+"\""
        }
        return properties
    }

/**
 * Get a list of configuration elements in a build definition
 * 
 * @param build definition
 * 
 * @return a list of build configuration elements
 */
    def getBuildConfigurations(IBuildDefinition buildDefinition, monitor=null) {
            def elements = buildDefinition.getConfigurationElements()
            elements.each() {
                def configProps = it.getConfigurationProperties()
                println "Configuration name: "+ it.getName()+ " "+ it.getElementId()
                configProps.each() { prop->
                    println prop.getName()+" = "+ prop.getValue()
                }
            }
            return elements
    }
    
/**
 * get the value of a configuration property
 * 
 * @param buildDefinition the build definition
 * @param elementName the name of the configuration element
 * @param propertyName the name of the configuration property
 * 
 * @return [String] the configuration property value
 */
    def getBuildConfigurationProperty(IBuildDefinition buildDefinition, String elementName, String propertyName, monitor=null) {
        buildDefinition.getConfigurationPropertyValue(elementName,propertyName,"none")
    }


/**
 * get the build definition's UUID value
 * 
 * @param buildDefinition the build definition
 * 
 * @return [String] the UUID of the build definition
 */
    
    def getBuildDefinitionUUID(IBuildDefinition buildDefinition,monitor=null) {
        buildDefinition.getItemId().getUuidValue()
    }
/**
 * get the value of a build property
 * 
 * @param buildDefinition the build definition
 * @param propertyName the name of the property
 * 
 * @return [String] the property value
 */
    def getBuildProperty(IBuildDefinition buildDefinition, String propertyName, monitor=null) {
        buildDefinition.getProperty(propertyName)?.getValue()
    }
    
/**
 * get a property object
 * 
 * @param buildDefinition
 * @param propertyName
 * 
 * @return [IProperty] the property
 */
    def retrieveProperty(IBuildDefinition buildDefinition, String propertyName) {
        buildDefinition.getProperty(propertyName)
    }
    
/**
 * Set a build property 
 * 
 * @param buildDefinition the build definition
 * @param paramName the property name
 * @param paramValue the property value
 * 
 * @return
 */
    def setBuildProperty(IBuildDefinition buildDefinition, String paramName, String paramValue,  monitor=null) {
        IBuildDefinition writeBuildDefinition = buildDefinition.getWorkingCopy()
        writeBuildDefinition.setProperty(paramName, paramValue)  
        if (paramValue == "") paramValue = "<none>"
        println "Set property ${paramName} to ${paramValue}"
        buildClient.save(writeBuildDefinition, monitor)
    }
    
/**
 * Set a build property description
 * 
 * @param buildDefinition the build definition
 * @param paramName the property name
 * @param descValue the description of the property
 * 
 * @return
 */
    def setBuildPropertyDesc(IBuildDefinition buildDefinition, String paramName, String descValue, monitor=null) {
        IBuildDefinition writeBuildDefinition = buildDefinition.getWorkingCopy()
        writeBuildDefinition.getProperty(paramName).setDescription(descValue)
        if (descValue == "") descValue = "<none>"
        println "Set property description ${paramName} to ${descValue}"
        buildClient.save(writeBuildDefinition, monitor)
        
    }
/**
 * Set a build configuration property
 * 
 * @param buildDefinition the build definition
 * @param elementName the element name
 * @param paramName the property name
 * @param parmValue the property value
 * 
 * @return
 */
    def setBuildConfigurationProperty(IBuildDefinition buildDefinition, String elementName, String paramName, String paramValue, monitor=null) {
        IBuildDefinition writeBuildDefinition = buildDefinition.getWorkingCopy()
        writeBuildDefinition.setConfigurationProperty(elementName, paramName, paramValue)
        println "Setting property ${elementName}/${paramName} to ${paramValue}"
        buildClient.save(writeBuildDefinition, monitor)
    }

/**
 * Get a build engine object when given its name
 * 
 * @param buildEngineName the name of the build engine
 * 
 * @return [IBuildEngine] the build engine object
 */
    def getBuildEngine(String buildEngineName, monitor=null) {
        IBuildEngine buildEngine = buildClient.getBuildEngine(buildEngineName, monitor)
        return buildEngine
    }
    
/**
 * Add a build engine to a build definition
 * 
 * @param be the build engine
 * @param buildDefinition the build definition
 * 
 * @return
 */
    def addBuildDefinitionToBuildEngine(IBuildEngine be, IBuildDefinition buildDefinition, monitor=null) {
        IBuildEngine workingCopy = (IBuildEngine) be.getWorkingCopy()
        List buildDefinitionHandles = workingCopy.getSupportedBuildDefinitions()
        def exists = false
        for (int j=0; j<buildDefinitionHandles.size();j++) {
            IBuildDefinitionHandle handle = (IBuildDefinitionHandle) buildDefinitionHandles.get(j)
            if (buildDefinition.getItemId().getUuidValue().equals(handle.getItemId().getUuidValue())) {
                exists = true
            } 
        }
        if (exists == false) {
            workingCopy.getSupportedBuildDefinitions().add(buildDefinition)
            buildClient.save(workingCopy, monitor)
        }
    }
    
/**
 * Remove a build engine from a build definition
 * 
 * @param beID the name of the build engine
 * @param buildDefinition the build definition
 * 
 * @return
 */
    def removeBuildDefinitionFromBuildEngine(String beID, IBuildDefinition buildDefinition, monitor=null) {
            def buildClient = ClientFactory.getTeamBuildClient(repo)
            IBuildEngine be= buildClient.getBuildEngine(beID, monitor)
            IBuildEngine workingCopy = (IBuildEngine) be.getWorkingCopy()
            List buildDefinitionHandles = workingCopy.getSupportedBuildDefinitions()
            println "Old size: "+ workingCopy.getSupportedBuildDefinitions().size()
            for (int j=0; j<buildDefinitionHandles.size(); j++) {
                IBuildDefinitionHandle handle = (IBuildDefinitionHandle) buildDefinitionHandles.get(j)
                if (buildDefinition.getItemId().getUuidValue().equals(handle.getItemId().getUuidValue())) {
                    workingCopy.getSupportedBuildDefinitions().remove(j)
                    println "MATCH REMOVED"                }
            }
            println "New size: "+ workingCopy.getSupportedBuildDefinitions().size()
            buildClient.save(workingCopy,monitor)
    }
        
/**
 * Get a list of build engine names for a build definition
 * 
 * @param buildDefinition
 * 
 * @return a list of build engine names
 */
    def getBuildEnginesForBuildDefinition(IBuildDefinition buildDefinition,monitor=null) {
        IBuildEngineQueryModel queryModel = IBuildEngineQueryModel.ROOT;
        IItemQuery query = IItemQuery.FACTORY.newInstance(queryModel);
        IPredicate supportsDef = queryModel.supportedBuildDefinitions().itemId()._eq(query.newUUIDArg());
        query.filter(supportsDef);
        IItemQueryPage queryPage = buildClient.queryItems(query, [buildDefinition.getItemId()] as Object[], IQueryService.ITEM_QUERY_MAX_PAGE_SIZE, monitor);
        if (queryPage.getResultSize() == 0) {
           println("Zero build engines found for build definition '" + buildDefinition.getId() + "'");
           return null
        } else {
           println("Found " + queryPage.getResultSize() + " build engine(s) for build definition '" + buildDefinition.getId() + "':");
           int pageNum = 1;
           List buildEngineNames = []
           while (queryPage != null) {
//              println("Page:" + pageNum++);
              // print out a page of IDs of the retrieved build engines
              String[] properties = [IBuildEngine.PROPERTY_ID] as String[];
              IFetchResult fetchResult = repo.itemManager().fetchPartialItemsPermissionAware(queryPage.getItemHandles(), IItemManager.DEFAULT,
                    Arrays.asList(properties), monitor);
              List buildEngines = fetchResult.getRetrievedItems();
              for (IBuildEngine buildEngine : buildEngines) {
                 def beID = buildEngine.getId()
                 if (!buildEngineNames.contains(beID)) {
                     println(beID);
                     buildEngineNames.add(beID)
                 }
              }
              if (queryPage.hasNext()) {
                 queryPage = (IItemQueryPage) buildClient.fetchPage(queryPage.getToken(), queryPage.getNextStartPosition(), queryPage.getSize(), monitor);
              } else {
                 queryPage = null;
              }
           }
           return buildEngineNames
        }
    }
    
/**
 * Get a list of x number of last build results.
 * 
 * @param buildDefinition the build definition
 * @param numItems the number of items to retrieve
 * 
 * @return a list of build result strings and status/state
 */
    def getBuildResultList(IBuildDefinition buildDefinition, def numItems=2, monitor=null) {
       UUID currDefinitionUUID = buildDefinition.getItemId()
       IBuildResultQueryModel buildResultQueryModel = IBuildResultQueryModel.ROOT
       IItemQuery query = IItemQuery.FACTORY.newInstance(buildResultQueryModel)
       query.filter((buildResultQueryModel.buildDefinition()._eq(query.newItemHandleArg()))._and(
            buildResultQueryModel.personalBuild()._isFalse())) 
       query.orderByDsc(buildResultQueryModel.buildStartTime())
       IItemQueryPage queryPage = buildClient.queryItems(query, [currDefinitionUUID] as Object[],
            numItems, monitor)
       if (queryPage.getSize() == 0) {
           println "Zero builds found with tag '"+ currDefinitionUUID + "'"
           return null
       } else {
           IFetchResult fetchResult = repo.itemManager().fetchCompleteItemsPermissionAware(queryPage.getItemHandles(),
               IItemManager.DEFAULT, null)
           List<IBuildResult> buildResults = fetchResult.getRetrievedItems()
           buildResults.each {
                println it.getLabel() + "," + it.getStatus() + "," + it.getState()
           }
           return buildResults
        }
        
    }
 
/**
 * Add a link on the build result
 * 
 * @param buildResultUUID the UUID of the build result
 * @param label the link label
 * @param theURL the link URL
 * 
 * @return
 */
    def addBuildResultLink(String buildResultUUID, String label="link", String theURL="https://jenkins.bcbst.com", monitor=null) {
        String properties = IBuildResult.PROPERTY_LABEL;
        IBuildResultHandle parentBuild = IBuildResult.ITEM_TYPE.createItemHandle(UUID.valueOf(buildResultUUID), null);
        IBuildResult buildResult = (IBuildResult) repo.itemManager().fetchPartialItem(parentBuild, IItemManager.REFRESH, Arrays.asList(properties), monitor);
        IBuildResultContribution link = BuildItemFactory.createBuildResultContribution();
        link.setLabel(label);
        link.setExtendedContributionTypeId(IBuildResultContribution.LINK_EXTENDED_CONTRIBUTION_ID);
        link.setExtendedContributionProperty(IBuildResultContribution.PROPERTY_NAME_URL, theURL);
        buildClient.addBuildResultContribution((IBuildResultHandle) buildResult.getItemHandle(), link, null);
     }
       
/**
 * get the changes between current and last build
 * 
 * @param result1 the first build result
 * @param result2 the second build result
 * 
 * @return a map of changes and work item ids
 */
    def compareChanges(IBuildResult result1, IBuildResult result2, monitor=null) {
        def changeList = []
        def idList=[]
        IWorkspaceManager workspaceManager = (IWorkspaceManager)repo.getClientLibrary(IWorkspaceManager.class);
        ProviderFactory providerFactory = (ProviderFactory)repo.getClientLibrary(ProviderFactory.class)
        IBuildResultContribution[] snapshotContribution1 = buildClient.getBuildResultContributions(result1,
            [ScmConstants.EXTENDED_DATA_TYPE_ID_BUILD_SNAPSHOT] as String[], monitor)
        IBuildResultContribution[] snapshotContribution2 = buildClient.getBuildResultContributions(result2,
            [ScmConstants.EXTENDED_DATA_TYPE_ID_BUILD_SNAPSHOT] as String[], monitor)
        if (snapshotContribution1.length > 0 && snapshotContribution2.length > 0) {
            IBaselineSetHandle baselineSetHandle1 = (IBaselineSetHandle) snapshotContribution1[0].getExtendedContribution()
            IBaselineSetHandle baselineSetHandle2 = (IBaselineSetHandle) snapshotContribution2[0].getExtendedContribution()
            IChangeHistorySyncReport syncReport = workspaceManager.compareBaselineSets(baselineSetHandle1,
                baselineSetHandle2, null, monitor)
            for (Object o:syncReport.outgoingChangeSets()) {
                IChangeSetHandle csHandle = (IChangeSetHandle)o
                List<ILink> linksFetched = ChangeSetLinks.findLinks(providerFactory,csHandle, 
                    [ILinkConstants.CHANGESET_WORKITEM_LINKTYPE_ID] as String[], monitor)
                
                IChangeSet cs = (IChangeSet)repo.itemManager().fetchCompleteItem(csHandle, IItemManager.DEFAULT, monitor)
                def authorHandle = cs.getAuthor()
                def author = (IContributor)repo.itemManager().fetchCompleteItem(authorHandle, IItemManager.DEFAULT,monitor)
//                println author.getUserId()+" "+author.getName()+" "+cs.getComment()
                for (final ILink link:linksFetched) {
                    final Object resolved = link.getTargetRef().resolve()
                    if (resolved instanceof IWorkItemHandle) {
                        IWorkItem wi = (IWorkItem)repo.itemManager().fetchPartialItem(resolved,IItemManager.DEFAULT, 
                            IWorkItem.SMALL_PROFILE.getProperties(), monitor)
                        println wi.getId().toString()+","+wi.getHTMLSummary().getPlainText()+","+author.getName()
                        def comment = (cs.getComment()==null || cs.getComment() == "")? "":" - "+cs.getComment()
                        def workItemId = wi.getId()
                        def wiidts = workItemId.toString()
                        println workItemId +","+wiidts
                        changeList?.add("<tr><td>Revision "+wi.getId().toString()+ " by <b>"+author.getName()+"</b></td><td>"+wi.getHTMLSummary().getPlainText()+ "<i>"+comment+"</i></td></tr>")
                        idList.add(workItemId.toString())
                    }
                }
           }
           return [changes:changeList, id:idList]
        } else {
            return "No contributions were made"
        }
    }
    
/**
 * attach a file to a work item
 * 
 * @param projectAreaName the project area name
 * @param idString the work item id
 * @param attachmentName the filename of the attachment
 * @param fContentType the content type of the attachment
 * @param fEncoding the encoding of the attachment
 * 
 * @return [boolean] pass/fail
 */
    def attachFileToWorkItem(def projectAreaName, def idString, def attachmentName, def fContentType=IContent.CONTENT_TYPE_UNKNOWN, def fEncoding=IContent.ENCODING_UTF_8,monitor=null) {
        try {
            if (idString!='null') {
                URI uri = URI.create(projectAreaName.replaceAll(" ", "%20"));
                IProjectArea projectArea = (IProjectArea) processClient.findProcessArea(uri, null, null);
                if (projectArea == null) {
                    System.out.println("Project not found.");
                    return false;
                }
                int id = new Integer(idString).intValue();
                IWorkItem workItem = workItemClient.findWorkItemById(id, IWorkItem.FULL_PROFILE, null);
                IWorkItemHandle handle = (IWorkItemHandle) workItem?.getItemHandle()
                IWorkItemWorkingCopyManager wcm = workItemClient.getWorkItemWorkingCopyManager()
                wcm?.connect(handle, IWorkItem.FULL_PROFILE, monitor)
                WorkItemWorkingCopy wc
                wc = wcm?.getWorkingCopy(handle)
                IWorkItem wi = wc?.getWorkItem()
                File attachmentFile = new File(attachmentName)
                FileInputStream fis = new FileInputStream(attachmentFile)
                try {
                    IAttachment newAttachment = workItemClient.createAttachment(wi?.getProjectArea(), attachmentFile.getName(), "", fContentType, fEncoding,fis,monitor)
                    newAttachment = (IAttachment) newAttachment?.getWorkingCopy()
                    newAttachment = workItemClient.saveAttachment(newAttachment, monitor)
                    IItemReference reference = WorkItemLinkTypes.createAttachmentReference(newAttachment)
                    wc?.getReferences().add(WorkItemEndPoints.ATTACHMENT, reference)
                    wc?.save(monitor)
                } finally {
                    if (fis != null) fis.close()
                }
                    
                System.out.println("Modified item " + workItem.getId() + ".");
                return true
            } else {
                System.out.println "no work items found"
            }
        } catch (e) {
            e.printStackTrace()
            println e.message
            return false
        }
    }
    
    def checkAndRemoveAttachment(def idString,def checkName, boolean deleteIt = false,monitor=null) {
        try {
            boolean finalValue = false
            if (idString!= "null") {
                int id = new Integer(idString).intValue();
                IWorkItem workItem = workItemClient.findWorkItemById(id, IWorkItem.FULL_PROFILE, null);
                IWorkItemCommon common = (IWorkItemCommon) repo.getClientLibrary(IWorkItemCommon.class);
                IWorkItemReferences workItemReferences = common.resolveWorkItemReferences(workItem, null)
                List references = workItemReferences.getReferences(WorkItemEndPoints.ATTACHMENT)
                println "Attachments for "+idString
                for (IReference iReference: references) {
                    IAttachmentHandle attachHandle = (IAttachmentHandle) iReference.resolve()
                    IAuditableClient auditableClient = (IAuditableClient) repo.getClientLibrary(IAuditableClient.class);
                    IAttachment attachment = (IAttachment) auditableClient.resolveAuditable((IAttachmentHandle) attachHandle,
                        IAttachment.DEFAULT_PROFILE, null);
                    println attachment.getName()
                    if (attachment.getName() == checkName && checkName != "") {
                        finalValue = true
                        println "this is where we remove "+ attachment.getName()
                        if (deleteIt == true) {
                            common.deleteAttachment(attachHandle, null)
                        }
                    }
                }
                return finalValue
            } else {
                return false
            }
        } catch (e) {
            e.printStackTrace()
            println e.message
            return false
        }
    }
    // setBaseline requires SI_RPTUSER_P or workspace owner to be logged in
    def setBaseline(String wsName, String compName, String baselineName) {
        IWorkspaceManager wm = (IWorkspaceManager)repo.getClientLibrary(IWorkspaceManager.class);
        IWorkspaceHandle wsHandle = getWorkspaceFromName(wsName)
        IWorkspaceConnection wsConn = wm.getWorkspaceConnection(wsHandle, null)
        IComponentHandle compHandle = getComponentFromName(compName)
        IBaselineSearchCriteria blCriteria = IBaselineSearchCriteria.FACTORY.newInstance()
        blCriteria.setComponentRequired(compHandle)
        blCriteria.setExactName(baselineName)
        long DAY_IN_MS = 1000 * 60 * 60 * 24;
        Date beforeDate = new Date(System.currentTimeMillis() - (7 * DAY_IN_MS))
        blCriteria.setModifiedAfterOptional(beforeDate)
    def marker1 = new Date()
        List<IBaselineHandle> blHandles = wm.findBaselines(blCriteria, Integer.MAX_VALUE, null);
    def marker2 = new Date()
        Collections.reverse(blHandles)
    def marker3 = new Date()
        for (IBaselineHandle blHandle: blHandles) {
            IBaseline desiredBaseline = (IBaseline) repo.itemManager().fetchCompleteItem(blHandle, IItemManager.DEFAULT, null)
            println desiredBaseline.getName()
            if (baselineName.equalsIgnoreCase(desiredBaseline.getName())) {
                    def marker4 = new Date()
                    println "FOUND^"
                    IBaselineConnection blConnection = wm.getBaselineConnection(blHandle, null)
                    def marker5 = new Date()
                    wsConn.applyComponentOperations(Collections.singletonList(wsConn.componentOpFactory().replaceComponent(compHandle,blConnection,false)),true,null)
                    def marker6 = new Date()
//                    TimeDuration duration1 = TimeCategory.minus(marker2, marker1)
//                    println "creating list: "+duration1
//                    TimeDuration duration2 = TimeCategory.minus(marker3, marker2)
//                    println "reverse list: "+duration1
//                    TimeDuration duration3 = TimeCategory.minus(marker4, marker3)
//                    println "found marker: "+duration1
//                    TimeDuration duration4 = TimeCategory.minus(marker5, marker4)
//                    println "baseline connection created: "+duration1
//                    TimeDuration duration5 = TimeCategory.minus(marker6, marker5)
//                    println "apply component operation to replace: "+duration1
                    return
            }
        }
    }
    
  
    def getWorkspaceFromName(String name) throws TeamRepositoryException {
        IWorkspaceManager wm = SCMPlatform.getWorkspaceManager(repo);
        IWorkspaceSearchCriteria criteria = IWorkspaceSearchCriteria.FACTORY
                .newInstance().setKind(IWorkspaceSearchCriteria.ALL);
        if (name != null) {
            criteria.setExactName(name);
        }
        List<IWorkspaceHandle>workspaces= wm.findWorkspaces(criteria,
                Integer.MAX_VALUE, null);
        return workspaces.get(0);
        }
    
    def getComponentFromName(String componentName) {
        IWorkspaceManager wm = (IWorkspaceManager)repo.getClientLibrary(IWorkspaceManager.class);
        IComponentSearchCriteria search = IComponentSearchCriteria.FACTORY.newInstance()
        wm.findComponents(search.setExactName(componentName), Integer.MAX_VALUE, null).get(0)
    }
 
    def createSecretKey(char[] password, byte[] salt, int iterationCount, int keyLength) throws
    NoSuchAlgorithmException, InvalidKeySpecException {
      SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA512");
      PBEKeySpec keySpec = new PBEKeySpec(password, salt, iterationCount, keyLength);
      SecretKey keyTmp = keyFactory.generateSecret(keySpec);
      return new SecretKeySpec(keyTmp.getEncoded(), "AES");
  }
      def base64Encode(byte[] bytes) {
      return Base64.getEncoder().encodeToString(bytes);
  }
      def base64Decode(String property) throws IOException {
      return Base64.getDecoder().decode(property);
  }

  def encrypt(String property) throws GeneralSecurityException, UnsupportedEncodingException {
      SecretKeySpec key = createSecretKey((new JsonSlurper().parseText('{ "masterPassword": "MyMasterPwd" }')["masterPassword"]).toCharArray(), new String("12345678").getBytes(), 40000, 128)
      Cipher pbeCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
      pbeCipher.init(Cipher.ENCRYPT_MODE, key);
      AlgorithmParameters parameters = pbeCipher.getParameters();
      IvParameterSpec ivParameterSpec = parameters.getParameterSpec(IvParameterSpec.class);
      byte[] cryptoText = pbeCipher.doFinal(property.getBytes("UTF-8"));
      byte[] iv = ivParameterSpec.getIV();
      return base64Encode(iv) + ":" + base64Encode(cryptoText);
  }
  
  def decrypt(String string) throws GeneralSecurityException, IOException {
      SecretKeySpec key = createSecretKey((new JsonSlurper().parseText('{ "masterPassword": "MyMasterPwd" }')["masterPassword"]).toCharArray(), new String("12345678").getBytes(), 40000, 128)
      String iv = string.split(":")[0];
      String property = string.split(":")[1];
      Cipher pbeCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
      pbeCipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(base64Decode(iv)));
      return new String(pbeCipher.doFinal(base64Decode(property)), "UTF-8");
  }
    
}



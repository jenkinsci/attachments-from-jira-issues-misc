#!/usr/bin/env groovy
package bcbst.das

class GlobalVars {

	static String UCD_TEST = 'https://ucd-test.bcbst.com';
	static String UCD_PROD = 'https://ucd.bcbst.com';
	static String NUNIT2_RESULTS_FILE = 'nunit2-results.xml';
	static String NUNIT3_RESULTS_FILE = 'nunit3-results.xml';
	static String OPENCOVER_RESULTS_FILE = 'opencover-coverage.xml';
	
	// check for certain directory and filetypes on fetch - this is a list of all the prohibited names/types
	static String[] DIRTYPES = ["obj","bin","target","deleteme"]
	static String[] FILETYPES = ["exe","dll","msi", "cab", "zip","?ar","obj","dat","pdb","*gz*","7z*",".npmrc"]
		// build logs, unit test results, unit test coverage, scan resutls, etc. all 
	// go into this <project-path>/build-results folder  
	static String BUILD_RESULTS_DIR_NAME = 'build-results';

	// static values to reference from local library /var scripts and pipelines  
	static String LOAD_BASE = 'F:/Jenkins/workspace/';
	static String BASE_DOMAIN = 'bcbst.com';
	static String CURRENT_USER = ""

	/** NOTE -> Many of the _ARG constants start with a blank space (' ') - this is deliberate! **/
	
	// nUnit exe and base arguments
	static String NUNIT_EXE = 'F:/ProgramFiles/NUnit/nunit-console/nunit3-console.exe';
	static String NUNIT_ARGS = '--result:' + BUILD_RESULTS_DIR_NAME + '/' + NUNIT2_RESULTS_FILE + ';format=nunit2 --result:' + BUILD_RESULTS_DIR_NAME + '/' + NUNIT3_RESULTS_FILE + ';format=nunit3';
	
	// VSTest exe and base arguments
//Is VSTEST_EXE being used? If not it should be removed
	static String VSTEST_EXE = 'C:/Users/SI_Jenkins_P/.nuget/packages/Microsoft.TestPlatform.15.9.0/tools/net451/Common7/IDE/Extensions/TestPlatform/vstest.console.exe';
	static String VSTEST_ARGS = '/ResultsDirectory:TestResults /Logger:trx';
//	static String VSTEST_ARGS = '/ResultsDirectory:' + BUILD_RESULTS_DIR_NAME + ' /Logger:trx';
	// OpenCover exe and base arguments (and default filters) 
	static String OPENCOVER_EXE = 'F:/ProgramFiles/opencover.4.7.922/OpenCover.Console.exe';
	static String OPENCOVER_ARGS = ' -output:' + BUILD_RESULTS_DIR_NAME + '/' + OPENCOVER_RESULTS_FILE + ' -register:Path64 -mergeoutput -mergebyhash';
	static String OPENCOVER_FILTER_NUNIT = ' -filter:"+[*]* -[nunit*]*"'; // default filter for OpenCover calls to nUnit
	static String OPENCOVER_FILTER_VSTEST = ' -filter:"+[*]* -[Moq*]*"'; // default filter for OpenCover calls to VSTest
	
	// SonarQube exe and base arguments 
	static String SONARQUBE_MSBUILD_EXE = 'F:/ProgramFiles/sonarqube-build-tools/sonar-scanner-4.4.1.1530/SonarScanner.MSBuild.exe';
	static String SONARQUBE_MSBUILD_ARGS = '/d:"sonar.cs.opencover.reportsPaths=' + BUILD_RESULTS_DIR_NAME + '/coverage.xml" /d:"sonar.cs.vstest.reportsPaths=' + BUILD_RESULTS_DIR_NAME + '/*.trx'

	// Nuget exe, config, and base arguments
	static String NUGET_EXE = 'F:/ProgramFiles/NuGet/NuGet.exe';
	static String NUGET_CONFIG_FILE = /F:\ProgramFiles\NuGet\Configs\NuGet.config/;
	static String NUGET_ARGS = ' -ConfigFile ' + NUGET_CONFIG_FILE;

	// Domain Mappings 
	static def TeamMap = [CCS:"CLINICALCOMMUNICATIONSVCS",CCSP:"CLAIMSCUSTOMERSERVICEPROVIDER",CS:"CORPORATESYSTEMS",MBC:"MEMBERSHIPBILLINGCLINICAL",SMB:"SALESMARKETINGEBUSINESS",SEA:"SERVICEENABLINGAPPLICATIONS"] 

}
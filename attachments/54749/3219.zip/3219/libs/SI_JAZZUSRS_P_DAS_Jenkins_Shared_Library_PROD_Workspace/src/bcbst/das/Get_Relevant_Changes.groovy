import com.ibm.team.repository.client.TeamPlatform
import com.ibm.team.build.common.model.*
import das.*
def REPO_URL = System.getenv("RTC_REPO_URL") ?: "https://rtcccm.bcbst.com/ccm"
def USER_ID = args[0]
def PASSWORD = args[1]
def RESULTUUID = args[2]


def p(obj) {
    println "${obj}"
}
TeamPlatform.startup()
def rtc = new RTC(REPO_URL, USER_ID, PASSWORD)
rtc.login()
def bd = rtc.getBuildDefinition(RESULTUUID)
def twoResults = rtc.getBuildResultList(bd)
def changeList = rtc.compareChanges(twoResults[0],twoResults[1])
File changeFile = new File("das/changelist.txt")
if (changeList.size()==0) {
    changeFile << "No changes found since last build."
} else {
    changeFile << changeList.join("\n")
}
changeList.each() {
    println it
}
//def newbd= rtc.createBuildDefinitionFromBD(bd,"SampleBuildDef")
//IBuildFolder bf = rtc.getBuildFolderHandle(bd,"Jenkins_Converted")
//rtc.moveBuildDefinition(newbd,bf)
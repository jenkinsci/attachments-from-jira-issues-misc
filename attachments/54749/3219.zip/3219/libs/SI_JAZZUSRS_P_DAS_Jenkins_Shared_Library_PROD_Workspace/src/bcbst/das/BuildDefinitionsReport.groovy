import com.ibm.team.repository.client.TeamPlatform
import com.ibm.team.build.common.model.*
import das.*

def REPO_URL = System.getenv("RTC_REPO_URL") ?: "https://rtcccm.bcbst.com/ccm"
def USER_ID = args[0]
def PASSWORD = args[1]

println "Using REPO_URL: ${REPO_URL}, USER_ID: ${USER_ID}, PASSWORD: ${'*' * PASSWORD.length()}"

TeamPlatform.startup()
def rtc = new RTC(REPO_URL, USER_ID, PASSWORD)
rtc.login()
def wsArray = []
def totalDefinitions = 0
def jazzDefinitions = 0
def jenkinsDefinitions = 0
def totalBuilds = 0
def projectAreas = rtc.projectAreas(['name', 'archived']).sort({it.name})
for (projectArea in projectAreas) {
    println "Reading build definitions in project area '${projectArea.name}'${projectArea.archived ? ' (archived)' : ''}..."
    if (!projectArea.archived) {
        def definitions = rtc.buildDefinitionsInProjectArea(projectArea)
        for (definition in definitions) {
            List<IBuildProperty> properties = definition.getProperties()
            wsName =  rtc.getWorkspace(definition)
            wsType = rtc.getBuildProperty(definition,"com.ibm.team.build.internal.template.id")
            switch (wsType) {
                case 'com.ibm.rational.connector.hudson.ui.buildDefinitionTemplate':
                    def bdType= rtc.getBuildConfigurationProperty(definition,"com.ibm.rational.connector.hudson","com.ibm.rational.connector.hudson.job")
                    jenkinsDefinitions++
                    if (bdType?.contains('MSBuild')) {
                        println definition.id + " is an MSBuild type."
                        bdType = "MSBuild"
                    } else if (bdType?.contains('Maven')) {
                        println definition.id + " is a Maven type."
                        bdType= "Maven"
                    } else if (bdType?.contains('Node')) {
                        println definition.id + " is a Node type."
                        bdType = "Node"
                    } else if (bdType?.contains('External')) {
                        println definition.id + " is an External type."
                        bdType = "External"
                    } else if (bdType?.contains('Delivery')) {
                        println definition.id + " is a Nonbuild type."
                        bdType = "NonBuild"
                    } else if (bdType?.contains('IIB')) {
                        println definition.id + " is an IIB type."
                        bdType = "IIB"
                    } else if (bdType?.contains('Smoke')) {
                        println definition.id + " is a Nonbuild type."
                        bdType = "SmokeTest"
                    } else {
                        println definition.id + " is another Jenkins type."
                        bdType = "Other"
                    }
                    wsType = "Jenkins_${bdType}"
                    break
                case 'com.ibm.team.build.cmdline':
                    jazzDefinitions++
                    wsType = "Jazz_CommandLine"
                    break
                case 'com.ibm.team.build.maven':
                    jazzDefinitions++
                    wsType = "Jazz_Maven"
                    break
                case 'com.ibm.team.build.msbuild':
                    jazzDefinitions++
                    wsType = "Jazz_MSBuild"
                    break
                case 'com.ibm.team.build.ant':
                    jazzDefinitions++
                    wsType = "Jazz_Ant"
                    break
                default:
                    jazzDefinitions++
                    wsType = "Jazz_Other"
            }
            wsArray.add("${definition.id},${wsName},${wsType}")
//        p "  ${definition.id},${wsName}"
        }
        totalDefinitions += definitions.size()
    }
}
println "---"
def myFile = new File('buildWorkspaceslist.csv')
def buildDefList = wsArray.join("\n")
println buildDefList
println "Total projects: ${projectAreas.size()}"
println "Total build definitions: ${totalDefinitions}"
println "Jazz build definitions: ${jazzDefinitions}"
println "Jenkins build definitions: ${jenkinsDefinitions}"
myFile.write(buildDefList)
println "COMPLETE."

#!/usr/bin/env groovy
package bcbst.das

//BuildUtils - All the utilities you could ever hope for in a Jenkins Library
class BuildUtils implements Serializable {

//steps refers to the list of declarative steps available to the library
	def steps
	BuildUtils(steps) {this.steps = steps}
	
//this is a sample maven command. Doesn't do much at the moment; ignore.	
	def mvn(args) {
		steps.bat "${steps.tool 'Maven'}/bin/mvn ${args}"
	}

//here we go. Retrieve the build definition load information and fetch the source into the workspace
//helpful hint: params is the script parameters object and env is the environment variables object.
	def rtcfetch(script) {
		steps.teamconcert([
                   	buildType: [
                       	buildDefinition: "${script.params.buildDefinitionId}",
                       	value: 'buildDefinition',
                    	overrideDefaultSnapshotName: true,
                       	customizedSnapshotName: "${script.params.buildDefinitionId}_${script.env.BUILD_TIMESTAMP}",
                       	createFoldersForComponents:false
                    ], 	 //buildType parameter
                ]) //teamconcert step
	}

// checkNaughty
// takes care of recognizing and/or removing unwanted items from the workspace before build.
// 1. Removes the .jazz5 directory once and for all
// 2. Removes any object and bin directories since they won't be used in the build
// 3. Finally, tattles on precompiled/prepackaged binaries included in the build - since should use nexus for binaries
//    Will send an email if binaries are found before a build.
	def checkNaughty(script) {
//		steps.echo "Gonna find out if you're naughty or nice."
		steps.echo "Deleting .jazz5 if it's there"
		steps.dir(path: "./.jazz5") {
			steps.deleteDir()
		}
		steps.echo "removing obj and binary directories"
		def dirTypes = ["obj","bin","target","deleteme"]
		dirTypes.each{ 
			//look for each of the dir names and remove
			grabDirs it
		}
		steps.echo "looking for checked-in binaries (naughty!)"
		def filetypes = ["exe","dll",".msi", "cab", "zip","?ar","obj","dat","pdb","gz*"]
		def directoryName = "${script.params.WorkingDirectory}"
//		println "Working directory is: ${script.params.WorkingDirectory}"
		def naughtyList; // unformatted list of binaries
		def naughtyCount = 0; //number of binaries found
		def naughtyFiles = []; // list of binaries, formatted for html output
		filetypes.each{
			naughtyList = grabFiles(it)
			if (naughtyList.size() > 0) {
				naughtyCount+=naughtyList.size() //update the count of naughty files by the number of binaries found
				naughtyList.each { that->
					naughtyFiles.push(that.toString()+"<br/>")
				} //naughtyList.each
			} //if
		} //filetypes.each
		if (naughtyCount > 0) {
			steps.echo "You have ${naughtyCount} compiled files in your source."
			return naughtyFiles //return the list of files
		} //if
		return null
	} //def
	
	def grabDirs(blob) {
		steps.echo "checking for ${blob}"
		def foundPath
		def foundDirs = steps.findFiles(glob: "**/${blob}/") //get an array of all files matching this list
		if (foundDirs.size()>0) {
			steps.echo "Found 1 or more ${blob} directory(s). Deleting..."
			//looks like we found some files
		}
		foundDirs.each { //act on each because each parent path could be different
			foundPath=it.path.toString().split("${blob}")[0]+"${blob}/" // extract the entire path without component files
			steps.echo "${foundPath}"
			steps.dir(foundPath) {
				steps.deleteDir()
			}
		}
	}
	
	def grabFiles(blob) {
		def foundFiles = steps.findFiles(glob: "**/*.${blob}") //find files matching type
		steps.echo "${blob}: ${foundFiles}"; //print the array for each type
		return foundFiles; //return the array of found files
	}
	
//Deliver artifacts to UCD. 
		
	def ucdDeliver(script) {
		steps.echo "component name is ${script.params.ucdComponentName}"
		steps.step([$class: 'UCDeployPublisher',
			siteName: 'UCDTest',
			component: [
			   $class: 'com.urbancode.jenkins.plugins.ucdeploy.VersionHelper$VersionBlock',
				componentName: "${script.params.ucdComponentName}",
				createComponent: [
					$class: 'com.urbancode.jenkins.plugins.ucdeploy.ComponentHelper$CreateComponentBlock',
					componentTemplate: '~SLMTools_BlankTemplate',
				 componentApplication: "${script.params.ucdApplicationName}"
				], //createComponent Parameter
				delivery: [
					$class: 'com.urbancode.jenkins.plugins.ucdeploy.DeliveryHelper$Push',
					pushVersion: "${script.env.VERSION_NOM}",
					baseDir: "${script.params.WorkingDirectory}/${script.params.ucdTargetPath}",
					fileIncludePatterns: "${script.params.ucdIncludePattern}",
					fileExcludePatterns: "${script.params.ucdExcludePattern}",
					pushProperties: "jenkins.server=${script.env.NODE_NAME}\njenkins.reviewed=false",
					pushDescription: 'Pushed from Jenkins',
					pushIncremental: false
				] // delivery parameter
			] //component
		]) //steps.step
	}
	
// deploy to an environment via UCD. Needs the name of the environment and specific version number as additional
// parameters because they can change with this new pipeline.
	def ucdDeploy(script,envNM,versionNM) {
		steps.step([$class: 'UCDeployPublisher',
			siteName: 'UCDTest',
			deploy: [
				$class: 'com.urbancode.jenkins.plugins.ucdeploy.DeployHelper$DeployBlock',
				deployApp: "${script.params.ucdApplicationName}",
				deployEnv: "${envNM}",
				deployProc: "${script.params.ucdApplicationProcessName}",
				createProcess: [
					   $class: 'com.urbancode.jenkins.plugins.ucdeploy.ProcessHelper$CreateProcessBlock',
					   processComponent: 'Deploy'
				],
				deployVersions: "${script.params.ucdComponentName}:${versionNM}",
				deployOnlyChanged: false
			] //deploy
		]) // actual deploy step
		
	}

//send a PUT request to UCD to change a version status. Status can be any string. Version is the current version id.	
	def setUCDStatus(script,versionNM,status) {
		steps.httpRequest httpMode:'PUT', authentication: 'UCDImport', url: "https://ucd-test.bcbst.com/cli/version/addStatus?component=${script.params.ucdComponentName}&version=${versionNM}&status=${status}"
	}	

// send a notification email
	def sendNotification(script,recipient,notsubject,notBody) {
//        notBody = '${SCRIPT, template="jenkins-warn-email-html.template"}'
		//steps.echo "${notBody}"
		steps.emailext body:notBody, subject: notsubject, to: recipient
	}
	
	def getWorkspaceName(script) {
		steps.echo "UUID is ${script.params.uuid}"
		steps.httpRequest authentication: 'RTC', ignoreSslErrors: true, outputFile: 'output.log', responseHandle: 'NONE', url: 'https://rtcccm.bcbst.com/ccm/rpt/repository/scm?fields=workspace/workspace[itemId='+script.params.uuid+']/name'
		def outputH = steps.readFile "output.log"
		def rootNode = new XmlSlurper().parseText(outputH)
		return rootNode.workspace.text()
	}

	def getProjectArea(script) {
		steps.echo "id is ${script.params.buildDefinitionId}"
		steps.httpRequest authentication: 'RTC', ignoreSslErrors: true, outputFile: 'output.log', responseHandle: 'NONE', url: 'https://rtcccm.bcbst.com/ccm/rpt/repository/build?fields=buildDefinition/buildDefinition[id='+script.params.buildDefinitionId+']/projectArea/name'
		def outputH = steps.readFile "output.log"
		def rootNode = new XmlSlurper().parseText(outputH)
		return rootNode.buildDefinition.projectArea.name.text()
	}
	
	def getBuildDefinitionUUID(script){
		steps.echo "id is ${script.params.buildDefinitionId}"
		steps.httpRequest authentication: 'RTC', ignoreSslErrors: true, outputFile: 'output.log', responseHandle: 'NONE', url: 'https://rtcccm.bcbst.com/ccm/rpt/repository/build?fields=buildDefinition/buildDefinition[id='+script.params.buildDefinitionId+']/itemId'
		def outputH = steps.readFile "output.log"
		def rootNode = new XmlSlurper().parseText(outputH)
		return rootNode.buildDefinition.itemId.text()
	}
		
	def performNexusAnalysis(script) {
		try {
			def policyEvaluation = steps.nexusPolicyEvaluation failBuildOnNetworkError: false, iqApplication: "${script.params.nexusIQApplication}", iqStage: 'build', jobCredentialsId: ''
			return policyEvaluation
		} catch (error) {
			def policyEvaluation = error.policyEvaluation
			throw error
		}
	}

	// define this function outside the pipeline because it references a %build() object in Jenkins.
	// This will replace an existing parameter value with a new value. Invaluable to create Build Parameters for Shared Library methods.
		def setParam(String paramName, String paramValue) {
			List<ParameterValue> newParams = new ArrayList<>()
			newParams.add(new StringParameterValue(paramName, paramValue))
			$build().addOrReplaceAction($build().getAction(ParametersAction.class).createUpdated(newParams))
		}
//	def getAllStreams(script) {
//		steps.echo "Fetching stream list from RTC..."
//		steps.httpRequest authentication: 'RTC', ignoreSslErrors: true, outputFile: 'output.log', responseHandle: 'NONE', url: 'https://rtcccm.bcbst.com/ccm/rpt/repository/scm?fields=workspace%2F%28workspace%5Bstream%3Dtrue%5D%2F%28reportableUrl%7CitemId%7Cname%7Cstream%29%29&size=100000'
//		def outputH = steps.readFile "output.log"
//		def rootNode = new XmlSlurper()
//		def uuidList = ""
//		rootNode.setFeature("http://apache.org/xml/features/disallow-doctype-decl", false) 
//		rootNode = rootNode.parseText(outputH)
//		rootNode.workspace.eachWithIndex { workspace , i -> 
//			uuidList += workspace.itemId.text() + '\n'
//		}
//		uuidList = uuidList.trim()
//		return uuidList
//
//	}
}
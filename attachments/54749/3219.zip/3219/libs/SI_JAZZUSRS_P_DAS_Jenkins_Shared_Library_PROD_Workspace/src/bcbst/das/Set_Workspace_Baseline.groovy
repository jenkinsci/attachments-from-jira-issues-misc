import com.ibm.team.repository.client.TeamPlatform
import das.*
def REPO_URL = System.getenv("RTC_REPO_URL") ?: "https://rtcccm.bcbst.com/ccm"
def USER_ID = args[0]
def PASSWORD = args[1]
def WORKSPACENAME = args[2]
def COMPONENTNAME = args[3]
def BASELINENAME = args[4]


TeamPlatform.startup()
def rtc = new RTC(REPO_URL, USER_ID, PASSWORD)
rtc.login()
rtc.setBaseline(WORKSPACENAME, COMPONENTNAME, BASELINENAME)
rtc.logout()

import com.ibm.team.repository.client.TeamPlatform
import das.*
def REPO_URL = System.getenv("RTC_REPO_URL") ?: "https://rtcccm.bcbst.com/ccm"
def USER_ID = args[0]
def PASSWORD = args[1]
def RESULTUUID = args[2]
def TEXTVALUE = args[3]


def p(obj) {
    println "${obj}"
}

TeamPlatform.startup()
def rtc = new RTC(REPO_URL, USER_ID, PASSWORD)
rtc.login()
rtc.mutateSnapshot(RESULTUUID, TEXTVALUE)


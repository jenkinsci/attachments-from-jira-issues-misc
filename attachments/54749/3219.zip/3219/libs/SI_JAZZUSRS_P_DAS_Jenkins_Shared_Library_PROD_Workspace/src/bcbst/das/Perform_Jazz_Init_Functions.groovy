import com.ibm.team.repository.client.TeamPlatform
import das.*
import groovy.time.*
def REPO_URL = System.getenv("RTC_REPO_URL") ?: "https://rtcccm.bcbst.com/ccm"
def USER_ID = args[0]
def PASSWORD = args[1]
def DEFINITIONID = args[2]
def RESULTUUID = args[3]
def VERSION = args[4]
def TEXTVALUE = DEFINITIONID+"_"+VERSION
def EXTERNAL = args[5]
println "Start"
TeamPlatform.startup()
def rtc = new RTC(REPO_URL, USER_ID, PASSWORD)
rtc.login()

//set the build label to timestamp
println "Setting build Label"
setBuildLabel(rtc,RESULTUUID, "${VERSION}")

//get build definition uuid
println "Build Definition"
def bdid = rtc.getBuildDefinition(DEFINITIONID)
//set snapshot name and get changes (if build isn't an external build)
File changeFile = new File("das/uuid.txt")
if (EXTERNAL != "true") {
    println "setting snapshot name"
    changeSnapshot(rtc,RESULTUUID,"${TEXTVALUE}")
    println "getting changes"
    def cList = getChanges(rtc,DEFINITIONID)
    def uuid = rtc.getBuildDefinitionUUID(bdid)
    changeFile << uuid
} else {
    changeFile << ""
}

//get build properties
println "getting build properties"
getBuildProps(rtc,bdid)
rtc.logout()
println "Finish"
def getBuildProps(def RTC, def bdefid) {
    File propertiesFile = new File("das/properties.txt")
    def properties = RTC.getBuildProperties(bdefid)
    properties.each { property ->
        propertiesFile << property.getName()+"=\""+property.getValue()+"\"\n"
    }
}

def setBuildLabel(def RTC, def result, def textValue) {
    RTC.setBuildLabel(result, textValue)
}

def changeSnapshot(def RTC, def result, def textValue) {
    RTC.mutateSnapshot(result, textValue)
}

def getChanges(def RTC, def buildDef) {
    def marker1 = new Date()
    def bd = RTC.getBuildDefinition(buildDef)
    def marker2 = new Date()
    def twoResults = RTC.getBuildResultList(bd)
    def marker3 = new Date()
    def mapp = RTC.compareChanges(twoResults[0],twoResults[1])
    def marker4 = new Date()
    def changeList = mapp?.changes
    def iidList = mapp.id
    iidList.unique()
    File changeFile = new File("das/changelist.txt")
    File wiFile = new File ("das/workitems.txt")
    if (changeList.size()<0) {
        changeFile << "No changes found since last build."
    } else {
        def thirdlist = new ArrayList<>(new HashSet<>(changeList))
        changeFile << thirdlist.join("\n")
    }
    def marker5 = new Date()
    
    println "SIZE:" + iidList?.size()
    if (iidList?.size()>0) {
        wiFile << iidList.join(',')
    }
    def marker6 = new Date()
    TimeDuration duration1 = TimeCategory.minus(marker2, marker1)
    println "getBuildDefinition:"+duration1
    TimeDuration duration2 = TimeCategory.minus(marker3, marker2)
    println "getBuildResultList:"+duration1
    TimeDuration duration3 = TimeCategory.minus(marker4, marker3)
    println "compareChanges:"+duration1
    TimeDuration duration4 = TimeCategory.minus(marker5, marker4)
    println "write changes file with joined id array:"+duration1
    TimeDuration duration5 = TimeCategory.minus(marker6, marker5)
    println "write to the file with joined id array:"+duration1
    changeList.each() {
        println it
    }
    return iidList
}
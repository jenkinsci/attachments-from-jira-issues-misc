import com.ibm.team.repository.client.TeamPlatform
import com.ibm.team.build.common.model.*
import com.ibm.team.build.common.*
import das.*
def REPO_URL = System.getenv("RTC_REPO_URL") ?: "https://rtcccm.bcbst.com/ccm"
def USER_ID = args[0]
def PASSWORD = args[1]
def RESULTUUID = args[2]
def BUILDTYPE = args[3]

def domainNames= [ServiceEnablingApplications:'SEA',
                    ApplicationSupportQuality:'ASQ',
                    ClaimsCustomerServiceProvider:'CCSP',
                    CorporateSystems:'CS',
                    MembershipBillingClinical:'MBC',
                    SalesMarketingeBusiness:'SMB',
                    SalesMarketingBusiness:'SMB']

//try {
    TeamPlatform.startup()
    def rtc = new RTC(REPO_URL, USER_ID, PASSWORD)
    rtc.login()
    IBuildDefinition bd = rtc.getBuildDefinition(RESULTUUID)
    IBuildDefinition newbd= rtc.createBuildDefinitionFromBD(bd,"${RESULTUUID}_Jenkins")
    IBuildFolder bf = rtc.getBuildFolderHandle(bd,"Jenkins_Converted")
    if (bf == null) bf = rtc.createBuildFolder(bd,"Jenkins_Converted")
    rtc.moveBuildDefinition(newbd,bf)
    IBuildFolder archive = rtc.getBuildFolderHandle(bd,"Archive")
    if (archive == null) {
        archive = rtc.createBuildFolder(bd, "Archive")
    }
    rtc.moveBuildDefinition(bd,archive)
    def fullTeamName = rtc.getProcessAreaName(bd)
    def teamName=""
    def teamDomain=""
    if (fullTeamName.contains('_')) {
        def fullTeamList = fullTeamName.split("_")
        teamDomain = fullTeamList[0]
        teamName = fullTeamList[1]
    } else {
        teamName=fullTeamName
    }

    //set common fields
    //Jazz Source Control
    setBuildPropSet(rtc,newbd, "team.scm.workspaceUUID", rtc.getBuildProperty(bd,"team.scm.workspaceUUID"))
    setBuildPropSet(rtc,newbd, "team.scm.fetchDestination",rtc.getBuildProperty(bd,"team.scm.fetchDestination"))
    setBuildPropSet(rtc,newbd, "loadDirectory", rtc.getBuildProperty(bd,"team.scm.fetchDestination"))
    setBuildPropSet(rtc,newbd, "team.scm.deleteDestinationBeforeFetch",rtc.getBuildProperty(bd,"team.scm.deleteDestinationBeforeFetch"))
    setBuildPropSet(rtc,newbd, "team.scm.acceptBeforeFetch",rtc.getBuildProperty(bd,"team.scm.acceptBeforeFetch"))
    setBuildPropSet(rtc,newbd, "team.scm.buildOnlyIfChanges",rtc.getBuildProperty(bd,"team.scm.buildOnlyIfChanges"))
    setBuildPropSet(rtc,newbd, "team.scm.componentLoadRules",rtc.getBuildProperty(bd,"team.scm.componentLoadRules"))
    setBuildPropSet(rtc,newbd, "team.scm.includeComponents",rtc.getBuildProperty(bd,"team.scm.includeComponents"))
    setBuildPropSet(rtc,newbd, "team.scm.loadComponents",rtc.getBuildProperty(bd,"team.scm.loadComponents"))
    setBuildPropSet(rtc,newbd, "team.scm.loadMethod", (rtc.getBuildProperty(bd,"team.scm.loadMethod")==null)? "fullLoad":rtc.getBuildProperty(bd,"team.scm.loadMethod"))
    setBuildPropSet(rtc,newbd, "team.scm.loadPolicy", (rtc.getBuildProperty(bd,"team.scm.loadPolicy")==null)? "useComponentLoadConfig":rtc.getBuildProperty(bd,"team.scm.loadPolicy"))
    setBuildPropSet(rtc,newbd, "team.scm.componentLoadConfig", (rtc.getBuildProperty(bd,"team.scm.componentLoadConfig")==null)? "loadAllComponents":rtc.getBuildProperty(bd, "team.scm.componentLoadConfig"))
    setBuildPropSet(rtc,newbd, "team.scm.createFoldersForComponents",(rtc.getBuildProperty(bd,"team.scm.createFoldersForComponents")!="true")? "false": rtc.getBuildProperty(bd,"createFoldersForComponents"))
    
    //UCD
    setBuildPropSet(rtc,newbd, "ucdApplicationProcessName",rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.udeploy", "team.udeploy.process") ,"[optional] The Name of the UCD Application Process (used in Continuous Delivery)")
    setBuildPropSet(rtc,newbd, "ucdApplicationName",rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.udeploy", "team.udeploy.application") ,"[optional] The name of the UCD Application (used in continuous delivery)")
    setBuildPropSet(rtc,newbd, "ucdComponentName",rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.udeploy", "team.udeploy.component") ,"[optional] UCD Component name to deliver artifacts")
    setBuildPropSet(rtc,newbd, "ucdDeliverSwitch",rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.udeploy", "team.udeploy.enabled") ,"[required] true/false�toggle automatic delivery to UCD. Does not control running deployment processes.")
    setBuildPropSet(rtc,newbd, "ucdDeploySwitch",rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.udeploy", "team.udeploy.deployEnabled") ,"[required] true/false (this is the continuous delivery switch) - only required if true")
    def dvlpEnv = rtc.getBuildConfigurationProperty(bd,"com.ibm.team.build.udeploy","team.udeploy.environment")
    setBuildPropSet(rtc,newbd, "ucdEnvironmentNameDVLP",(dvlpEnv=="")? "DVLP_CI":dvlpEnv,"[optional] Environment name for QA Deployment")
    setBuildPropSet(rtc,newbd, "ucdEnvironmentNameTEST","TEST_CI","[optional] Environment name for QA Deployment")
    setBuildPropSet(rtc,newbd, "ucdExcludePattern",rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.udeploy", "team.udeploy.excludeFiles") ,"[optional] UCD Exclude Files Pattern (multiple patterns comma separated)")
    setBuildPropSet(rtc,newbd, "ucdIncludePattern",rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.udeploy", "team.udeploy.includeFiles") ,"[optional] UCD Include Files Pattern (multiple patterns comma separated)")
    setBuildPropSet(rtc,newbd, "ucdTargetPath",rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.udeploy", "team.udeploy.baseDirectory") ,"[optional] The relative path of the deployable artifacts to the working directory, if applicable")
    setBuildPropSet(rtc,newbd, "ucdVersionPrefix", "","[optional] Prefix the UCDversion number with a string of your choice.\nRTC properties are supported.")
    
    //Miscellaneous
    setBuildPropSet(rtc,newbd, "contactEmail", "","[optional] one or more emails to send deployment reports")
    setBuildPropSet(rtc,newbd, "isApplicationName", rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.udeploy", "team.udeploy.component"),)
    setBuildPropSet(rtc,newbd, "isDomainName", domainNames[teamDomain],"[required] **Abbreviated** domain name for your team. i.e. SEA (Services Enabling Applications)")
    setBuildPropSet(rtc,newbd, "isTeamName", teamName,"[required] The name of your team as it appears in RTC. NO SPACES!")
    
    switch(BUILDTYPE) {
    
        case 'msbuild':    
            //msbuild properties
            def msbuildItem = rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.msbuild","com.ibm.team.build.msbuild.buildItem")
            println msbuildItem
            def buildParams = msbuildItem.split("-E_o_T-")
            //buildParams.each() {
            //    println "Parameter: "+it
            //}
            // -e_M_p_T_y_T_o_K_e_N- should be blank
            if (buildParams.length == 6) {
                msbuildParameters = [slnFile:buildParams[0], configuration: buildParams[1], type:buildParams[2], arguments:buildParams[3],logfile:buildParams[4], workingDir:buildParams[5]]
                setBuildPropSet(rtc,newbd, "slnFile", msbuildParameters.slnFile,"[required] Name of your solutions file. Example: My.sln")
                setBuildPropSet(rtc,newbd, "msBuildTarget", "/t:${msbuildParameters.type}","[required] Build the specified targets in the project. Specify each target separately, or use a semicolon or comma to separate multiple targets (/t)")
                setBuildPropSet(rtc,newbd, "msBuildProperty", msbuildParameters.arguments.replaceAll("-e_M_p_T_y_T_o_K_e_N-",""),"[optional] Set or override the specified project-level properties, where name is the property name and value is the property value. Specify each property separately, or use a semicolon or comma to separate multiple properties (/p)")
            } else {
                setBuildPropSet(rtc,newbd, "slnFile", "","[required] Name of your solutions file. Example: My.sln")
                setBuildPropSet(rtc,newbd, "msBuildTarget", "/t:Build","[required] Build the specified targets in the project. Specify each target separately, or use a semicolon or comma to separate multiple targets (/t)")
                setBuildPropSet(rtc,newbd, "msBuildProperty", "","[optional] Set or override the specified project-level properties, where name is the property name and value is the property value. Specify each property separately, or use a semicolon or comma to separate multiple properties (/p)")
            }

            setBuildPropSet(rtc,newbd, "msBuild64","false","[required] Are you using 64bit MSBuild? true or false")
            setBuildPropSet(rtc,newbd, "workingDirectory","","[optional] absolute path to the solution")
            //nunit
            setBuildPropSet(rtc,newbd, "nUnitDLL",rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.nunit.config","com.ibm.team.build.nunit.nunitFile"),"[optional] Path to your NUnit.dll.")
            setBuildPropSet(rtc,newbd, "nUnitOpenCoverFilter","","[optional] A list of filters to apply to selectively include or exclude assemblies and classes from coverage results. Using PartCover syntax, where (+|-)[Assembly-Filter]Type-Filter.")
            setBuildPropSet(rtc,newbd, "nUnitTestListFile","","[optional] A text file containing NEWLINE-delimited list of test-cases to run")
            setBuildPropSet(rtc,newbd, "nUnitTestNames","","[optional] A COMMA-delimited list of test-cases to run")
            setBuildPropSet(rtc,newbd, "nUnitTestQuery","","[optional] A nUnit query expression to select a subset of test cases")
            //mstest
            setBuildPropSet(rtc,newbd, "msTestDLL",rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.mstest.config","com.ibm.team.build.mstest.msTestFile"),"[optional] Path to your MSTest.dll.")
            setBuildPropSet(rtc,newbd, "msTestOpenCoverFilter","","[optional] A list of filters to apply to selectively include or exclude assemblies and classes from coverage results. Using PartCover syntax, where (+|-)[Assembly-Filter]Type-Filter.")
            setBuildPropSet(rtc,newbd, "msTestListFile","","[optional] A text file containing NEWLINE-delimited list of test-cases to run")
            setBuildPropSet(rtc,newbd, "msTestNames","","[optional] A COMMA-delimited list of test-cases to run")
            setBuildPropSet(rtc,newbd, "msTestQuery","","[optional] A query expression to select a subset of test cases")
            rtc.setBuildConfigurationProperty(newbd, "com.ibm.rational.connector.hudson", "com.ibm.rational.connector.hudson.job", "MSBuild Pipeline")
            break
        case 'maven':
            //maven
            setBuildPropSet(rtc,newbd, "mvnCommandLine",rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.maven", "com.ibm.team.build.maven.mavenGoals"),"[required] maven goals and command line options.\nexample: clean install verify -U")
            setBuildPropSet(rtc,newbd, "workingDirectory",rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.maven", "com.ibm.team.build.maven.projectLocation"),"[optional] absolute path to the build")
            setBuildPropSet(rtc,newbd, "pomXmlName","pom.xml","[required] Name of your pom.xml. Default is usually correct.")
            rtc.setBuildConfigurationProperty(newbd, "com.ibm.rational.connector.hudson", "com.ibm.rational.connector.hudson.job", "Maven Pipeline")
            break
        case 'node':
            //node
            setBuildPropSet(rtc,newbd, "nodeBuildScript","","[optional] The target for the npm run command. Skips npm run if blank.")
            setBuildPropSet(rtc,newbd, "coberturaTestResultDirectory","","[optional] The location of any cobertura code coverage xml results.")
            setBuildPropSet(rtc,newbd, "workingDirectory",rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.cmdline", "com.ibm.team.build.cmdline.workingDir"),"[optional] absolute path to the build")
            rtc.setBuildConfigurationProperty(newbd, "com.ibm.rational.connector.hudson", "com.ibm.rational.connector.hudson.job", "Node Pipeline")
            break
        case 'nonbuild':
            println "found nonbuild"
            setBuildPropSet(rtc,newbd, "workingDirectory",rtc.getBuildConfigurationProperty(bd, "com.ibm.team.build.cmdline", "com.ibm.team.build.cmdline.workingDir"),"[optional] absolute path to the build")
            rtc.setBuildConfigurationProperty(newbd, "com.ibm.rational.connector.hudson", "com.ibm.rational.connector.hudson.job", "Delivery_Pipeline")
            break
        case 'external':
            setBuildPropSet(rtc,newbd, "sourcePath","","[required for file] the path including network path to the top level file directory.")
            setBuildPropSet(rtc,newbd, "sourceType","file","[required] enter file for filesystem, enter nexus for nexus.\nNo other value is accepted.")
            setBuildPropSet(rtc,newbd, "workItem","Enter RTC work item #","[required] An RTC work item number. Required for external builds.")
            rtc.setBuildConfigurationProperty(newbd, "com.ibm.rational.connector.hudson", "com.ibm.rational.connector.hudson.job", "ExternalFileDelivery_Pipeline")
            break
        case 'iib':
			def componentVersion = rtc.getBuildProperty(bd, "component.version")
			setBuildPropSet(rtc,newbd, "team.scm.fetchDestination", "F:\\Jazz\\Applications\\\${buildDefinitionId}")
			setBuildPropSet(rtc,newbd, "approveList", "", "List of approvers for CI/CD")
			setBuildPropSet(rtc,newbd, "componentType", rtc.getBuildProperty(bd, "component.type"), "The type of integration project being built. Options are \"a\" for application or \"l\" for library (without quotes).")
			setBuildPropSet(rtc,newbd, "componentVersion", componentVersion, "The version of the component being built.")
			setBuildPropSet(rtc,newbd, "componentName", rtc.getBuildProperty(bd, "component.name"), "Component name")
			setBuildPropSet(rtc,newbd, "enableApproval", "false", "Toggle approval for CI/CD.")
			setBuildPropSet(rtc,newbd, "enableIntegration", "false", "Enables automated deploy of the component to the configured development environment(s) after a successful build. Configure the desired development environments(s) using the \"deployment.destinations\" property.")
			setBuildPropSet(rtc,newbd, "teamScmFetchDestination", "\${team.scm.fetchDestination}", "It is strongly advised that you do not change this.")
			setBuildPropSet(rtc,newbd, "ucdResourceMaps", rtc.getBuildProperty(bd, "ucd.resource.maps"), "The name of the resource(s) to map the component to within UrbanCode Deploy. Multiple resources can be specified when seperated by a comma.")
			setBuildPropSet(rtc,newbd, "versioningEnabled", rtc.getBuildProperty(bd, "versioning.enabled"), "Enables versioning for the component being build. This is useful for Integration Services (SOAP) and REST APIs to allow multiple versions of a service to exist on the same Integration Server.")
		    setBuildPropSet(rtc,newbd, "ucdVersionPrefix", "\${componentVersion}","[optional] Prefix the UCDversion number with a string of your choice.\nRTC properties are supported.")
		    setBuildPropSet(rtc,newbd, "ucdComponentName", rtc.getBuildProperty(bd, "component.name"), "[optional] UCD Component name to deliver artifacts")
		    setBuildPropSet(rtc,newbd, "isApplicationName", "\${componentName}", "team.udeploy.component")
		    setBuildPropSet(rtc,newbd, "loadDirectory", "\${team.scm.fetchDestination}")
            setBuildPropSet(rtc,newbd, "workingDirectory","\${team.scm.fetchDestination}","[optional] absolute path to the solution")
		    setBuildPropSet(rtc,newbd, "ucdTargetPath","\\BARFiles\\\${componentName}_\${componentVersion}" ,"[optional] The relative path of the deployable artifacts to the working directory, if applicable")
		    setBuildPropSet(rtc,newbd, "ucdIncludePattern", "**\\*" ,"[optional] The relative path of the deployable artifacts to the working directory, if applicable")
            rtc.setBuildConfigurationProperty(newbd, "com.ibm.rational.connector.hudson", "com.ibm.rational.connector.hudson.job", "SOA/IIB_Pipeline")
        	break
        default:
            println "build type not found"
    }
    IBuildEngine be = rtc.getBuildEngine("Placeholder_Jenkins_Engine")
    rtc.addBuildDefinitionToBuildEngine(be, newbd)
    echo "COMPLETED BUILD DEFINITION CONVERSION"



    //} catch (e) {
//    println "ERROR:"+e.message
//    throw new Exception(e.message)
//}

def setBuildPropSet(def r, def bdef,String prop,String val="",String desc="") {
    r.setBuildProperty(bdef, prop, val)
    r.setBuildPropertyDesc(bdef, prop, desc)    
}
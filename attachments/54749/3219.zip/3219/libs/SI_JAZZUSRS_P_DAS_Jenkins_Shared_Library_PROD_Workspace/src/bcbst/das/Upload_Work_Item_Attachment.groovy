import com.ibm.team.repository.client.TeamPlatform
import com.ibm.team.build.common.model.*
import com.ibm.team.build.common.*
import das.*


if (args.length != 5) {
    System.out.println("UsageifyWorkItem ");
    return false;
}
def repositoryURI = System.getenv("RTC_REPO_URL") ?: "https://rtcccm.bcbst.com/ccm"
println "Begin"
String userId = args[0];
String password = args[1];
String projectAreaName = args[2];
String idString = args[3];
String filename = args[4];
def ids = []
TeamPlatform.startup()
def rtc = new RTC(repositoryURI, userId, password)
rtc.login()
if (idString == "") {
//    println "Using work item given"
//    rtc.attachFileToWorkItem(projectAreaName, idString, filename)
} else {
    println "searching from uuid"
    ids = idString.split(',')
    if (ids?.size()>0) {
        ids.each() {
            println "checking to see if ${filename} already exists and removing duplicates"
            rtc.checkAndRemoveAttachment(it,filename, true)
            println "adding ${filename} to work item ${it}"
            rtc.attachFileToWorkItem(projectAreaName, it, filename)
        }
    } else {
        println "No work items found"
    }
}
println "End"

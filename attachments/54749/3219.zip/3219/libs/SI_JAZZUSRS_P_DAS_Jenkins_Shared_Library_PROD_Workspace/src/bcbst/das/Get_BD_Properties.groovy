import com.ibm.team.repository.client.TeamPlatform
import com.ibm.team.build.common.model.*
import das.*
def REPO_URL = System.getenv("RTC_REPO_URL") ?: "https://rtcccm.bcbst.com/ccm"
def USER_ID = args[0]
def PASSWORD = args[1]
def USER_2 = args[2]
def PASSWORD_2 = args[3]
def RESULTUUID = args[4]


def p(obj) {
    println "${obj}"
}

TeamPlatform.startup()
def rtc = new RTC(REPO_URL, USER_ID, PASSWORD)
def rtc2 = new RTC(REPO_URL, USER_2, PASSWORD_2)
println "decrypted is "+ rtc.decrypt("TrIpXkJjU0+guJyYaWSkDQ==:sznTVRl9mWwTquhkvVMlPw==")
rtc.login()
def bd = rtc.getBuildDefinition(RESULTUUID)
rtc.getBuildProperties(bd)
rtc.getBuildConfigurations(bd)
rtc.getBuildEnginesForBuildDefinition(bd)
rtc.getBuildDefinitionTemplates()
rtc.checkAndRemoveAttachment('418788','a.json', true)
println rtc.getProcessAreaName(bd)
def twoResults = rtc.getBuildResultList(bd)
if (twoResults != null) {
    def changeList = rtc.compareChanges(twoResults[0],twoResults[1])

    changeList.each() {
        println it
    }
}

rtc2.login()
println "Setting baseline"
rtc2.setBaseline("p28826cTest","DAS_Jenkins_Shared_Library","Move_To_Prod_01-27-2021")
rtc2.logout()
rtc.logout()
//def newbd= rtc.createBuildDefinitionFromBD(bd,"SampleBuildDef")
//IBuildFolder bf = rtc.getBuildFolderHandle(bd,"Jenkins_Converted")
//rtc.moveBuildDefinition(newbd,bf)
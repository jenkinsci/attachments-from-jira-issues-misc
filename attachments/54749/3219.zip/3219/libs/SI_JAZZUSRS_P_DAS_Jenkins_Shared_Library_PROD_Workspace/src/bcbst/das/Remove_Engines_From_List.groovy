import com.ibm.team.repository.client.TeamPlatform
import com.ibm.team.build.common.model.*
import das.*
def REPO_URL = System.getenv("RTC_REPO_URL") ?: "https://rtcccm.bcbst.com/ccm"
def USER_ID = args[0]
def PASSWORD = args[1]
def CSVFILE = args[2]
def DELETE = args[3]


def p(obj) {
    println "${obj}"
}

TeamPlatform.startup()

def rtc = new RTC(REPO_URL, USER_ID, PASSWORD)
rtc.login()
File file = new File(CSVFILE)
String fileContent = file.text
def lines = fileContent.split('\n')
lines.each { 
    try {
        def bd = rtc.getBuildDefinition(it.split(',')[0])
        println "Verifying: "+ bd.getId()
        def engineList = rtc.getBuildEnginesForBuildDefinition(bd)
        engineList.each { engine ->
            if (DELETE == "true") {
              rtc.removeBuildDefinitionFromBuildEngine(engine, bd)
                println "- Removed build engine ${engine}"
            }
        }
    } catch (e) {
        println e.message
    }
}
import com.ibm.team.repository.client.TeamPlatform
import das.*
import groovy.time.*
def REPO_URL = System.getenv("RTC_REPO_URL") ?: "https://rtcccm.bcbst.com/ccm"
def USER_ID = args[0]
def PASSWORD = args[1]
def RESULTUUID = args[3]

TeamPlatform.startup()
def rtc = new RTC(REPO_URL, USER_ID, PASSWORD)
rtc.login()

def bd = RTC.getBuildDefinition(buildDef)
def twoResults = RTC.getBuildResultList(bd)
def mapp = RTC.compareChanges(twoResults[0],twoResults[1])
def iidList = mapp.id
File wiFile = new File ("das/workitems.txt")
println "SIZE:" + iidList?.size()
if (iidList?.size()>0) {
    wiFile << iidList.join(',')
}
changeList.each() {
    println it
}
return iidList

#!/usr/bin/env groovy
package bcbst.das
import net.sf.json.JSONObject


/** 
* @class ALMTestParams Used to store/transport ALM test parameters.
* You can call the constructor from the pipeline using lib.bcbst.das.ALMTestParams.new(), assuming
* the pipeline is fetching the shared library dynamically, and the variable named 'lib' contains the return 
* value from the library() step. 
**/
class ALMTestParams {
    // Read-only fields - getters autocreated as feature of groovy.
    final String appName;
    final String envName;
    final String testSetPath;
    final String domainName;
    final String projectName;
    final String serverNode;
    
    // Valid JSON keys for objects in servers.json, used to validate test parameters
        // Application keys
        static final ArrayList APP_JSON_KEY_LIST = ['appName','envName','testSetPath','domainName','projectName','serverNode']


    /** 
    * No-arg constructor
    **/
    ALMTestParams() {
        this.appName = null;
        this.envName = null;
        this.testSetPath = null;
        this.domainName = null;
        this.projectName = null;
        this.serverNode = null;
    }

    /** 
    * Arg-driven constructor generates a new instance from JSON
    *
    * @param obj The JSON object containing test values
    * @param envName Contains the name of the environment, 'Prod' or 'NonProd'
    **/
    ALMTestParams(JSONObject obj, String envName) {
        this.appName = obj['name'];
        this.envName = envName;
        this.testSetPath =  (envName.toUpperCase() == "NONPROD") ? obj['test_path'] : obj['prod_path'];
        this.domainName = (envName.toUpperCase() == "PROD") ? "SERVICEENABLINGAPPLICATIONS" : obj['test_domain'];
        this.projectName = (envName.toUpperCase() == "PROD") ? "PatchValidation" : obj['test_project'];
        this.serverNode = obj['nodeName'];
    }

    /** 
    * Generates a new LinkedHashMap containing instance members as key/value pairs
    * 
    * @return A new LinkedHashMap containing all test values
    **/
    LinkedHashMap toHashMap() {
        LinkedHashMap map = [:];
        map.put('appName', this.appName);
        map.put('envName', this.envName);
        map.put('testSetPath', this.testSetPath);
        map.put('domainName', this.domainName);
        map.put('projectName', this.projectName);
        map.put('serverNode', this.serverNode);
        return map;
    }


   /**
    * Checks instance members (ALM test parameters) for validity, such as null values, 'null' values, 
    * strings <= 2 characters, and if any keys belonging to map aren't within the valid keyList
    *
    * @return LinkedHashMap containing key/value pairs of invalid test parameters
    **/
    LinkedHashMap getInvalidParams() {
        LinkedHashMap map = [:];
        this.toHashMap().each { entry ->
            if ((entry.value)
                && (entry.value instanceof String)
                    && (entry.value != 'null')
                        && (entry.value.length() > 1) ) {
                            return;
            } else {
                map.put(entry.key, entry.value);
            }
        }
        return map;
    }

    /** 
     * Returns a nice string containing instance members
     * 
     * @return A String containing instance members, formatted for the console.
     **/
    String toString() { // TODO try with StringBuilder
        String ret = "(application) ${this.appName}, " +
                     "(environment) ${this.envName}, " +
                     "(path) ${this.testSetPath}, " +
                     "(domain) ${this.domainName}, " +
                     "(project) ${this.projectName}, " +
                     "(node) ${this.serverNode}";
        return ret;
    }

    /** 
     * Converts test params to XML.
     * @return Returns test parameters represented as an XML string
     **/
     String toXmlString() {
        String ret = "<ALMTestParams>" +
                        "<application>${this.appName}</application>" +
                        "<environment>${this.envName}</environment>" +
                        "<path>${this.testSetPath}</path>" +
                        "<domain>${this.domainName}</domain>" +
                        "<project>${this.projectName}</project>" +
                        "<node>${this.serverNode}</node>" +
                     "</ALMTestParams>";
        return ret;
     }
}
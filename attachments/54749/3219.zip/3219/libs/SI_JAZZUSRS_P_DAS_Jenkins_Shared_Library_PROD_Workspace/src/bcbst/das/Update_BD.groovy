import com.ibm.team.repository.client.TeamPlatform
import das.*
def REPO_URL = System.getenv("RTC_REPO_URL") ?: "https://rtcccm.bcbst.com/ccm"
def USER_ID = args[0]
def PASSWORD = args[1]
def BDNAME = args[2]
def CODEBLOCK = args[3]
def UPDATE = args[4]
def BUILDTYPE = args[5]


TeamPlatform.startup()
def rtc = new RTC(REPO_URL, USER_ID, PASSWORD)
rtc.login()
def bd = rtc.getBuildDefinition(BDNAME)
println "Build Definition Name: "+ BDNAME
def bdType= rtc.getBuildConfigurationProperty(bd,"com.ibm.rational.connector.hudson","com.ibm.rational.connector.hudson.job")
println "Type is ${bdType}"
if (bdType?.contains('MSBuild')) { 
    println BDNAME + " is an MSBuild type."
    bdType = "MSBuild"
} else if (bdType?.contains('Maven')) {
    println BDNAME + " is a Maven type."
    bdType= "Maven"
} else if (bdType?.contains('Node')) {
    println BDNAME + " is a Node type."
    bdType = "Node"
} else if (bdType?.contains('External')) {
    println BDNAME + " is an External type."
    bdType = "External"
} else if (bdType?.contains('Delivery')) {
    println BDNAME + " is a Nonbuild type."
    bdType = "NonBuild"
} else if (bdType?.contains('IIB')) {
    println BDNAME + " is a Nonbuild type."
    bdType = "IIB"
} else if (bdType?.contains('Smoke')) {
    println BDNAME + " is a Nonbuild type."
    bdType = "SmokeTest"
} else {
    println BDNAME + " is another type."
    bdType = "Other"
}
File file = new File("type.txt")
file.write(bdType)
file << "\nCode block: ${CODEBLOCK}\n"
CODEBLOCK.split(",").each() { codeline->
    codeName = codeline.split('=')[0]
    codeValue = codeline.split('=')[1]
    if (UPDATE.equalsIgnoreCase("true") && (BUILDTYPE.equalsIgnoreCase(bdType) || BUILDTYPE == "All")) {
        rtc.setBuildProperty(bd,codeName,codeValue)
        file << "Updated property ${codeName}.\n"
    } else {
        file << "Did not set property ${codeName}.\n"
//        file << "${bdType}=${BUILDTYPE}?"
    }
}

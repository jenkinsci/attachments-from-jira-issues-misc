def envVars = run.getEnvironment(listener)
logger.println envVars.get("BUILD_ID") + " is the build id returned to email"
def blocklist = envVars.get("EMAIL_BLOCKLIST")
def debug = envVars.get("debug")
recipients = msg.getRecipients(javax.mail.Message.RecipientType.TO)
if (debug == "true") {
 recipients.each { addr -> 
 logger.println(addr)
 }
}
filtered = recipients.findAll { addr -> (!(addr.toString().toUpperCase()?.contains('SI_JAZZUSRS_P')) && !(addr.toString().toUpperCase()?.contains('SI_JENKINS')) && !(blocklist?.contains(addr.getAddress().split('@')[0]))) }
msg.setRecipients(javax.mail.Message.RecipientType.TO, filtered as javax.mail.Address[])
if(run.result.toString().equals("FAILURE")) {
 msg.addHeader("X-Priority","1 (Highest)");
 msg.addHeader("Importance", "High");
}
cancel=run.result.toString().equals("ABORTED");
package org.mcnair;

import org.junit.Test;

public class SomeTest
{
    @Test
    public void someMethod()
    {
    }
}

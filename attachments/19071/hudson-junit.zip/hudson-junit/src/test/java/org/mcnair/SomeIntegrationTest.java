package org.mcnair;

import org.junit.Test;

public class SomeIntegrationTest
{
    @Test
    public void someMethod()
    {
    }
}

Node statistics
===============

  * Total number of nodes
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of nodes online
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0
  * Total number of executors in use
      - Sample size:        0
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      4
      - FS root:        `/var/lib/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Java
          + Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_79
          + Maximum memory:   481.44 MB (504823808)
          + Allocated memory: 197.14 MB (206712832)
          + Free memory:      68.16 MB (71475312)
          + In-use memory:    128.97 MB (135237520)
          + PermGen used:     99.39 MB (104215944)
          + PermGen max:      166.00 MB (174063616)
          + GC strategy:      SerialGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.79-b02
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.16.0-38-generic
          + Distribution: Ubuntu 14.04.2 LTS
      - Process ID: 1075 (0x433)
      - Process started: 2015-05-25 17:38:06.964-0300
      - Process uptime: 20 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Djava.awt.headless=true`


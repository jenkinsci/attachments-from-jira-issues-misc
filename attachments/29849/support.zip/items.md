Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 6
    - Number of builds per job: 1.8333333333333333 [n=6, s=2.0]

Total job statistics
======================

  * Number of jobs: 6
  * Number of builds per job: 1.8333333333333333 [n=6, s=2.0]

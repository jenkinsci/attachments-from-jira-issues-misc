Browser
=======

  * Screen size: 1920x1080
  * User Agent
      - Type:     Browser
      - Name:     Firefox
      - Family:   FIREFOX
      - Producer: Mozilla Foundation
      - Version:  40.0
      - Raw:      `Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:40.0) Gecko/20100101 Firefox/40.0`
  * Operating System
      - Name:     Windows 8.1
      - Family:   WINDOWS
      - Producer: Microsoft Corporation.
      - Version:  6.3


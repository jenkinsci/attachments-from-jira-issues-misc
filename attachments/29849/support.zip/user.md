User
====

Authentication
--------------

  * Authenticated: true
  * Name: davividal
  * Authorities 
      - `authenticated`
  * Raw: `org.jenkinsci.plugins.BitbucketAuthenticationToken@f0d8d1e7: Username: davividal; Password: [PROTECTED]; Authenticated: true; Details: null; Granted Authorities: authenticated`


Jenkins
=======

Version details
---------------

  * Version: `1.614`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.8`
  * Java
      - Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_79
      - Maximum memory:   481.44 MB (504823808)
      - Allocated memory: 197.14 MB (206712832)
      - Free memory:      69.17 MB (72531360)
      - In-use memory:    127.97 MB (134181472)
      - PermGen used:     99.37 MB (104196472)
      - PermGen max:      166.00 MB (174063616)
      - GC strategy:      SerialGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.79-b02
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.16.0-38-generic
      - Distribution: Ubuntu 14.04.2 LTS
  * Process ID: 1075 (0x433)
  * Process started: 2015-05-25 17:38:06.964-0300
  * Process uptime: 20 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`

Important configuration
---------------

  * Security realm: `org.jenkinsci.plugins.BitbucketSecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`

Active Plugins
--------------

  * analysis-core:1.71 'Static Analysis Utilities'
  * ansicolor:0.4.1 'AnsiColor'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * backup:1.6.1 'Backup plugin'
  * bitbucket:1.1.0 'Jenkins Bitbucket Plugin'
  * bitbucket-approve:1.0.3 'Bitbucket Approve Plugin'
  * bitbucket-oauth:0.4 'Bitbucket OAuth Plugin'
  * build-pipeline-plugin:1.4.7 'Build Pipeline Plugin'
  * buildgraph-view:1.1.1 'buildgraph-view'
  * checkstyle:3.42 'Checkstyle Plug-in'
  * claim:2.7 'Jenkins Claim Plugin'
  * cloverphp:0.4 'Jenkins Clover PHP plugin'
  * crap4j:0.9 'Jenkins Crap4J plugin'
  * credentials:1.22 'Credentials Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.4 'Dashboard View'
  * delivery-pipeline-plugin:0.9.1 'Delivery Pipeline Plugin'
  * dry:2.41 'Duplicate Code Scanner Plug-in'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * gcal:0.4 'Google Calendar plugin'
  * git:2.3.5 'Jenkins GIT plugin'
  * git-client:1.17.1 'Jenkins GIT client plugin'
  * google-login:1.1 'Google Login Plugin'
  * google-metadata-plugin:0.2 'Google Metadata plugin'
  * google-oauth-plugin:0.3 'Google OAuth Credentials plugin'
  * google-storage-plugin:0.8 'Google Cloud Storage plugin'
  * gravatar:2.1 'Jenkins Gravatar plugin'
  * greenballs:1.14 'Green Balls'
  * html5-notifier-plugin:1.5 'HTML5 Notifier Plugin'
  * htmlpublisher:1.4 'HTML Publisher plugin'
  * http-post:1.2 'HTTP POST Plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * jdepend:1.2.4 'Jenkins JDepend Plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * junit:1.6 'JUnit Plugin'
  * ldap:1.11 'LDAP Plugin'
  * mailer:1.15 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * matrix-auth:1.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.4.1 'Matrix Project Plugin'
  * maven-plugin:2.9 'Maven Integration plugin'
  * metrics:3.0.10 'Metrics Plugin'
  * nodejs:0.2.1 'NodeJS Plugin'
  * oauth-credentials:0.3 'OAuth Credentials plugin'
  * pam-auth:1.2 'PAM Authentication plugin'
  * parameterized-trigger:2.26 'Jenkins Parameterized Trigger plugin'
  * php:1.0 'php'
  * plot:1.9 'Plot plugin'
  * pmd:3.41 'PMD Plug-in'
  * pragprog:1.0.4 'Pragprog Plugin'
  * promoted-builds:2.21 'Jenkins promoted builds plugin'
  * python:1.2 'Python Plugin'
  * rebuild:1.24 'Rebuilder'
  * ruby:1.2 'Hudson Ruby Plugin'
  * ruby-runtime:0.12 'ruby-runtime'
  * scm-api:0.2 'SCM API Plugin'
  * script-security:1.14 'Script Security Plugin'
  * semantic-versioning-plugin:1.7 'Semantic Versioning Plugin'
  * slack:1.8 'Slack Notification Plugin'
  * sonar:2.2.1 'Jenkins SonarQube Plugin'
  * ssh-agent:1.6 'SSH Agent Plugin'
  * ssh-credentials:1.11 'SSH Credentials Plugin'
  * ssh-slaves:1.9 'Jenkins SSH Slaves plugin'
  * subversion:2.5 'Jenkins Subversion Plug-in'
  * support-core:2.22 'Support Core Plugin'
  * token-macro:1.10 'Token Macro Plugin'
  * translation:1.12 'Jenkins Translation Assistance plugin'
  * violations:0.7.11 'Jenkins Violations plugin'
  * warnings:4.47 'Warnings Plug-in'
  * windows-slaves:1.0 'Windows Slaves Plugin'
  * xunit:1.95 'xUnit plugin'

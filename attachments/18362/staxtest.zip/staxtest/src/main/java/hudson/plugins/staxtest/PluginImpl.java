package hudson.plugins.staxtest;

import hudson.Plugin;

import javax.xml.stream.XMLInputFactory;

/**
 * @plugin
 * 
 */
public class PluginImpl extends Plugin {

    @Override
    public void start() throws Exception {
        System.out.println("hello");
        XMLInputFactory fac = XMLInputFactory.newInstance();
        System.out.println("Got " + fac.getClass().getName());
    }

}

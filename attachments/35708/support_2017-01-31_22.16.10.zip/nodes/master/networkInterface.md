-----------
 * Name docker0
 ** Hardware Address - 56847afe9799
 ** Index - 3
 ** InetAddress - /172.17.42.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 0aba20d76e00
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:8ba:20ff:fed7:6e00%eth0
 ** InetAddress - /172.30.0.13
 ** MTU - 9001
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

User
====

Authentication
--------------

  * Authenticated: true
  * Name: admin
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.rememberme.RememberMeAuthenticationToken@5d95b89a: Username: hudson.security.HudsonPrivateSecurityRealm$Details@31bb116b; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@ffffe21a: RemoteIpAddress: 172.18.64.72; SessionId: null; Granted Authorities: authenticated`


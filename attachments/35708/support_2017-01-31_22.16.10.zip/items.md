Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 2
    - Number of items per container: 3.0 [n=2, s=1.0]
  * `jenkins.branch.OrganizationFolder`
    - Number of items: 3
    - Number of items per container: 3.3333333333333335 [n=3, s=0.6]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 111
    - Number of builds per job: 1.018018018018018 [n=111, s=0.19]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 13
    - Number of items per container: 8.538461538461538 [n=13, s=20.0]

Total job statistics
======================

  * Number of jobs: 111
  * Number of builds per job: 1.018018018018018 [n=111, s=0.19]

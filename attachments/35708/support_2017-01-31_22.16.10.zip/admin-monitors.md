Monitors
========

`OldData`
--------------
  * Problematic object: `jenkins.branch.OrganizationFolder@439e89e[GitHub/1--kshultzCB--org--folder]`
    - MissingFieldException: No field 'url' found in class 'org.jenkinsci.plugins.orgfolder.github.GitHubOrgAction', MissingFieldException: No field 'name' found in class 'org.jenkinsci.plugins.orgfolder.github.GitHubOrgAction', MissingFieldException: No field 'bundle' found in class 'org.jenkinsci.plugins.orgfolder.github.CustomNameJobColumn', MissingFieldException: No field 'key' found in class 'org.jenkinsci.plugins.orgfolder.github.CustomNameJobColumn', MissingFieldException: No field 'folder' found in class 'org.jenkinsci.plugins.orgfolder.github.GitHubOrgIcon'

`hudson.model.UpdateCenter$CoreUpdateMonitor`
--------------
(active and enabled)

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)

Jenkins
=======

Version details
---------------

  * Version: `2.42`
  * Mode:    WAR
  * Url:     null
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.2.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_45-internal
      - Maximum memory:   3.26 GB (3504865280)
      - Allocated memory: 1.27 GB (1365245952)
      - Free memory:      688.71 MB (722160816)
      - In-use memory:    613.29 MB (643085136)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.45-b02
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.19.0-30-generic
      - Distribution: Ubuntu 15.04
  * Process ID: 20988 (0x51fc)
  * Process started: 2017-01-31 22:04:17.212+0000
  * Process uptime: 11 min
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Djava.awt.headless=true`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ant:1.4 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * blueocean:1.0.0-b21-beta-1 'Blue Ocean beta'
  * blueocean-autofavorite:0.6 'blueocean-autofavorite'
  * blueocean-commons:1.0.0-b21-beta-1 'Common API for Blue Ocean'
  * blueocean-config:1.0.0-b21-beta-1 'Config API for Blue Ocean'
  * blueocean-dashboard:1.0.0-b21-beta-1 'Dashboard for Blue Ocean'
  * blueocean-display-url:1.4 'BlueOcean Display URL plugin'
  * blueocean-events:1.0.0-b21-beta-1 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.0.0-b21-beta-1 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.0.0-b21-beta-1 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.0.0-b21-beta-1 'i18n for Blue Ocean'
  * blueocean-jwt:1.0.0-b21-beta-1 'JWT for Blue Ocean'
  * blueocean-personalization:1.0.0-b21-beta-1 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.0.0-b21-beta-1 'Pipeline REST API for Blue Ocean'
  * blueocean-rest:1.0.0-b21-beta-1 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.0.0-b21-beta-1 'REST Implementation for Blue Ocean'
  * blueocean-web:1.0.0-b21-beta-1 'Web for Blue Ocean'
  * bootstrap:1.3.2 'JavaScript GUI Lib: Twitter Bootstrap bundle plugin'
  * bouncycastle-api:2.16.0 'bouncycastle API Plugin'
  * branch-api:2.0.2-beta-4 'Branch API Plugin'
  * build-timeout:1.18 'Jenkins build timeout plugin'
  * cloudbees-bitbucket-branch-source:2.0.2-beta-1 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:5.17-beta-1 'Folders Plugin'
  * credentials:2.1.11 'Credentials Plugin'
  * credentials-binding:1.10 'Credentials Binding Plugin'
  * display-url-api:1.0.1 'Display URL API'
  * docker-commons:1.6 'Docker Commons Plugin'
  * docker-workflow:1.9.1 'Docker Pipeline'
  * durable-task:1.13 'Durable Task Plugin'
  * email-ext:2.54 'Email Extension Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * favorite:2.0.4 'Favorite'
  * git:3.0.3 'Jenkins Git plugin'
  * git-client:2.2.1 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.25.1 'GitHub plugin'
  * github-api:1.84 'GitHub API Plugin'
  * github-branch-source:2.0.1-beta-6 'GitHub Branch Source Plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * gradle:1.25 'Gradle Plugin'
  * greenballs:1.15 'Green Balls'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * junit:1.19 'JUnit Plugin'
  * ldap:1.14 'LDAP Plugin'
  * mailer:1.18 *(update available)* 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.4 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.8 'Matrix Project Plugin'
  * mercurial:1.58 'Jenkins Mercurial plugin'
  * metrics:3.1.2.9 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * pipeline-build-step:2.4 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.3 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.5 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3 'Pipeline: Milestone Step'
  * pipeline-model-api:0.9.1 'Pipeline: Model API'
  * pipeline-model-declarative-agent:0.9.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:0.9.1 'Pipeline: Model Definition'
  * pipeline-rest-api:2.4 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.2 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:0.9.1 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.4 'Pipeline: Stage View Plugin'
  * plain-credentials:1.3 'Plain Credentials Plugin'
  * pubsub-light:1.6 'Jenkins Pub-Sub "light" Bus'
  * resource-disposer:0.6 'Resource Disposer Plugin'
  * scm-api:2.0.2-beta-2 'SCM API Plugin'
  * script-security:1.25 'Script Security Plugin'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-credentials:1.12 *(update available)* 'SSH Credentials Plugin'
  * ssh-slaves:1.13 'Jenkins SSH Slaves plugin'
  * structs:1.5 'Structs Plugin'
  * subversion:2.7.1 'Jenkins Subversion Plug-in'
  * support-core:2.38 'Support Core Plugin'
  * timestamper:1.8.8 'Timestamper'
  * token-macro:2.0 'Token Macro Plugin'
  * variant:1.1 'Variant Plugin'
  * windows-slaves:1.2 'Windows Slaves Plugin'
  * workflow-aggregator:2.4 'Pipeline'
  * workflow-api:2.8 'Pipeline: API'
  * workflow-basic-steps:2.3 'Pipeline: Basic Steps'
  * workflow-cps:2.24 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.5 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.8 'Pipeline: Nodes and Processes'
  * workflow-job:2.9 'Pipeline: Job'
  * workflow-multibranch:2.11-beta-1 'Pipeline: Multibranch'
  * workflow-scm-step:2.3 'Pipeline: SCM Step'
  * workflow-step-api:2.7 'Pipeline: Step API'
  * workflow-support:2.12 'Pipeline: Supporting APIs'
  * ws-cleanup:0.32 'Jenkins Workspace Cleanup Plugin'

Item statistics
===============

  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 1
    - Number of builds per job: 4 [n=1]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 1
    - Number of items per container: 1 [n=1]

Total job statistics
======================

  * Number of jobs: 1
  * Number of builds per job: 4 [n=1]

# Properties

This report contains the Beekeeper related properties that are set to a value different from the default one.

### Property: fsProfiles

 * Property Name: cb.IMProp.fsProfiles
 * Property Description: Plugin profiles stored in the file system
 * Property Value: [/cloudbees-plugins-profile.json]


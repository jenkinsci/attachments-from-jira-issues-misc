Node monitors
=============
Approved Folders
----
 - Is Ignored: false
 - Computers:
   * master: null
   * jdk7-node: null
   * jdk8-node: null
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * jdk7-node: Linux (amd64)
   * jdk8-node: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * jdk7-node: In sync
   * jdk8-node: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 34.628GB left on /home/jenkins.
   * jdk7-node: Disk space is too low. Only 34.628GB left on /home/jenkins.
   * jdk8-node: Disk space is too low. Only 34.628GB left on /home/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:444/3950MB  Swap:1023/1023MB
   * jdk7-node: Memory:443/3950MB  Swap:1023/1023MB
   * jdk8-node: Memory:443/3950MB  Swap:1023/1023MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 34.628GB left on /tmp.
   * jdk7-node: Disk space is too low. Only 34.628GB left on /tmp.
   * jdk8-node: Disk space is too low. Only 34.628GB left on /tmp.
Node owners
----
 - Is Ignored: false
 - Computers:
   * master: null
   * jdk7-node: null
   * jdk8-node: null
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * jdk7-node: 52ms
   * jdk8-node: 50ms

User
====

Authentication
--------------

  * Authenticated: true
  * Name: butler
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@40a76a06: Username: hudson.security.HudsonPrivateSecurityRealm$Details@7e942615; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@0: RemoteIpAddress: 10.0.1.111; SessionId: node015hcal2q0ac25a357pc39gb8v12; Granted Authorities: authenticated`


Monitors
========

`com.cloudbees.jenkins.plugins.assurance.UpgradesWatch`
--------------
(active and enabled)

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)

CloudBees Support Bundle Manifest
=================================

Generated on 2018-02-06 17:42:26.621+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2018-02-03_07.27.09.log`

      - `nodes/master/logs/all_2018-02-06_16.14.06.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Check if license is expired.log`

      - `other-logs/Check if license is expired.log.1`

      - `other-logs/Download metadata.log`

      - `other-logs/Download metadata.log.1`

      - `other-logs/Download metadata.log.2`

      - `other-logs/Download metadata.log.3`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Fingerprint cleanup.log.1`

      - `other-logs/SharedConfigurationSynchronizer.log`

      - `other-logs/SharedConfigurationSynchronizer.log.1`

      - `other-logs/SharedConfigurationSynchronizer.log.2`

      - `other-logs/SharedConfigurationSynchronizer.log.3`

      - `other-logs/SharedConfigurationSynchronizer.log.4`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/Workspace clean-up.log.1`

      - `other-logs/com.cloudbees.jenkins.plugin.metrics.views.Alerter.log`

      - `other-logs/com.cloudbees.jenkins.plugin.metrics.views.Alerter.log.1`

      - `other-logs/com.cloudbees.jenkins.plugin.metrics.views.Alerter.log.2`

      - `other-logs/com.cloudbees.jenkins.plugin.metrics.views.Alerter.log.3`

      - `other-logs/com.cloudbees.jenkins.plugin.metrics.views.Alerter.log.4`

      - `other-logs/com.cloudbees.opscenter.client.cloud.CloudImpl$PeriodicWorkImpl.log`

      - `other-logs/com.cloudbees.opscenter.client.cloud.CloudImpl$PeriodicWorkImpl.log.1`

      - `other-logs/com.cloudbees.opscenter.client.cloud.CloudImpl$PeriodicWorkImpl.log.2`

      - `other-logs/com.cloudbees.opscenter.client.cloud.CloudImpl$PeriodicWorkImpl.log.3`

      - `other-logs/com.cloudbees.opscenter.client.cloud.CloudImpl$PeriodicWorkImpl.log.4`

      - `other-logs/copy_reference_file.log`

      - `other-logs/health-checker.log`

  * Agent Log Recorders

      - `nodes/slave/jdk7-node/jenkins.log`

      - `nodes/slave/jdk7-node/logs/all_2018-02-03_07.27.39.log`

      - `nodes/slave/jdk7-node/logs/all_2018-02-03_09.28.29.log`

      - `nodes/slave/jdk7-node/logs/all_2018-02-03_12.30.30.log`

      - `nodes/slave/jdk7-node/logs/all_2018-02-03_18.49.29.log`

      - `nodes/slave/jdk7-node/logs/all_2018-02-04_06.28.30.log`

      - `nodes/slave/jdk7-node/logs/all_2018-02-05_00.38.31.log`

      - `nodes/slave/jdk7-node/logs/all_2018-02-06_13.48.29.log`

      - `nodes/slave/jdk7-node/logs/all_2018-02-06_16.14.25.log`

      - `nodes/slave/jdk7-node/logs/all_memory_buffer.log`

      - `nodes/slave/jdk8-node/jenkins.log`

      - `nodes/slave/jdk8-node/logs/all_2018-02-03_07.27.39.log`

      - `nodes/slave/jdk8-node/logs/all_2018-02-03_12.30.31.log`

      - `nodes/slave/jdk8-node/logs/all_2018-02-04_06.28.31.log`

      - `nodes/slave/jdk8-node/logs/all_2018-02-05_00.38.31.log`

      - `nodes/slave/jdk8-node/logs/all_2018-02-06_05.46.29.log`

      - `nodes/slave/jdk8-node/logs/all_2018-02-06_16.14.25.log`

      - `nodes/slave/jdk8-node/logs/all_memory_buffer.log`

  * Garbage Collection Logs

  * CloudBees Assurance Program

      - `cap/beekeeper.md`

      - `cap/properties.md`

  * Agents config files (Encrypted secrets are redacted)

      - `nodes/slave/jdk7-node/config.xml`

      - `nodes/slave/jdk8-node/config.xml`

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.jsync.archiver.JSyncArtifactManagerFactory.xml`

      - `jenkins-root-configuration-files/com.infradna.hudson.plugins.backup.store.DAVStore.xml`

      - `jenkins-root-configuration-files/com.infradna.hudson.plugins.backup.store.SftpStore.xml`

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/jenkins.CLI.xml`

      - `jenkins-root-configuration-files/jenkins.model.ArtifactManagerConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.model.JenkinsLocationConfiguration.xml`

      - `jenkins-root-configuration-files/license.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugin.gitea.servers.GiteaServers.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.flow.FlowExecutionList.xml`

      - `jenkins-root-configuration-files/support-core.xml`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/jdk7-node/checksums.md5`

      - `nodes/slave/jdk8-node/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump agent export tables (could reveal some memory leaks)

      - `nodes/slave/jdk7-node/exportTable.txt`

      - `nodes/slave/jdk8-node/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/jdk7-node/environment.txt`

      - `nodes/slave/jdk8-node/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/jdk7-node/file-descriptors.txt`

      - `nodes/slave/jdk8-node/file-descriptors.txt`

  * Master Heap Histogram

      - `nodes/master/heap-histogram.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/jdk7-node/proc/meminfo.txt`

      - `nodes/slave/jdk7-node/proc/self/cmdline`

      - `nodes/slave/jdk7-node/proc/self/environ`

      - `nodes/slave/jdk7-node/proc/self/limits.txt`

      - `nodes/slave/jdk7-node/proc/self/mountstats.txt`

      - `nodes/slave/jdk7-node/proc/self/status.txt`

      - `nodes/slave/jdk8-node/proc/meminfo.txt`

      - `nodes/slave/jdk8-node/proc/self/cmdline`

      - `nodes/slave/jdk8-node/proc/self/environ`

      - `nodes/slave/jdk8-node/proc/self/limits.txt`

      - `nodes/slave/jdk8-node/proc/self/mountstats.txt`

      - `nodes/slave/jdk8-node/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/java-7/gnuplot`

      - `load-stats/label/java-7/hour.csv`

      - `load-stats/label/java-7/min.csv`

      - `load-stats/label/java-7/sec10.csv`

      - `load-stats/label/java-8/gnuplot`

      - `load-stats/label/java-8/hour.csv`

      - `load-stats/label/java-8/min.csv`

      - `load-stats/label/java-8/sec10.csv`

      - `load-stats/label/java/gnuplot`

      - `load-stats/label/java/hour.csv`

      - `load-stats/label/java/min.csv`

      - `load-stats/label/java/sec10.csv`

      - `load-stats/label/java7/gnuplot`

      - `load-stats/label/java7/hour.csv`

      - `load-stats/label/java7/min.csv`

      - `load-stats/label/java7/sec10.csv`

      - `load-stats/label/java8/gnuplot`

      - `load-stats/label/java8/hour.csv`

      - `load-stats/label/java8/min.csv`

      - `load-stats/label/java8/sec10.csv`

      - `load-stats/label/jdk-7/gnuplot`

      - `load-stats/label/jdk-7/hour.csv`

      - `load-stats/label/jdk-7/min.csv`

      - `load-stats/label/jdk-7/sec10.csv`

      - `load-stats/label/jdk-8/gnuplot`

      - `load-stats/label/jdk-8/hour.csv`

      - `load-stats/label/jdk-8/min.csv`

      - `load-stats/label/jdk-8/sec10.csv`

      - `load-stats/label/jdk7-node/gnuplot`

      - `load-stats/label/jdk7-node/hour.csv`

      - `load-stats/label/jdk7-node/min.csv`

      - `load-stats/label/jdk7-node/sec10.csv`

      - `load-stats/label/jdk7/gnuplot`

      - `load-stats/label/jdk7/hour.csv`

      - `load-stats/label/jdk7/min.csv`

      - `load-stats/label/jdk7/sec10.csv`

      - `load-stats/label/jdk8-node/gnuplot`

      - `load-stats/label/jdk8-node/hour.csv`

      - `load-stats/label/jdk8-node/min.csv`

      - `load-stats/label/jdk8-node/sec10.csv`

      - `load-stats/label/jdk8/gnuplot`

      - `load-stats/label/jdk8/hour.csv`

      - `load-stats/label/jdk8/min.csv`

      - `load-stats/label/jdk8/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/maven-jdk7/gnuplot`

      - `load-stats/label/maven-jdk7/hour.csv`

      - `load-stats/label/maven-jdk7/min.csv`

      - `load-stats/label/maven-jdk7/sec10.csv`

      - `load-stats/label/maven-jdk8/gnuplot`

      - `load-stats/label/maven-jdk8/hour.csv`

      - `load-stats/label/maven-jdk8/min.csv`

      - `load-stats/label/maven-jdk8/sec10.csv`

      - `load-stats/label/maven/gnuplot`

      - `load-stats/label/maven/hour.csv`

      - `load-stats/label/maven/min.csv`

      - `load-stats/label/maven/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/jdk7-node/metrics.json`

      - `nodes/slave/jdk8-node/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/jdk7-node/networkInterface.md`

      - `nodes/slave/jdk8-node/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/jdk7-node/dmesg.txt`

      - `nodes/slave/jdk7-node/dmi.txt`

      - `nodes/slave/jdk7-node/proc/cpuinfo.txt`

      - `nodes/slave/jdk7-node/proc/mounts.txt`

      - `nodes/slave/jdk7-node/proc/net/rpc/nfs.txt`

      - `nodes/slave/jdk7-node/proc/net/rpc/nfsd.txt`

      - `nodes/slave/jdk7-node/proc/swaps.txt`

      - `nodes/slave/jdk7-node/proc/system-uptime.txt`

      - `nodes/slave/jdk7-node/sysctl.txt`

      - `nodes/slave/jdk7-node/userid.txt`

      - `nodes/slave/jdk8-node/dmesg.txt`

      - `nodes/slave/jdk8-node/dmi.txt`

      - `nodes/slave/jdk8-node/proc/cpuinfo.txt`

      - `nodes/slave/jdk8-node/proc/mounts.txt`

      - `nodes/slave/jdk8-node/proc/net/rpc/nfs.txt`

      - `nodes/slave/jdk8-node/proc/net/rpc/nfsd.txt`

      - `nodes/slave/jdk8-node/proc/swaps.txt`

      - `nodes/slave/jdk8-node/proc/system-uptime.txt`

      - `nodes/slave/jdk8-node/sysctl.txt`

      - `nodes/slave/jdk8-node/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/jdk7-node/system.properties`

      - `nodes/slave/jdk8-node/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Operations Center Connector Logs

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/jdk7-node/thread-dump.txt`

      - `nodes/slave/jdk8-node/thread-dump.txt`


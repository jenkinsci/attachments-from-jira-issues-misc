=== Sites ===
 - Url: file:/home/jenkins/war/WEB-INF/plugins/update-center.json
 - Connection Url: file:/home/jenkins/war/WEB-INF/plugins/update-center.json
 - Implementation Type: com.cloudbees.jenkins.plugins.license.nectar.CloudBeesUpdateSite
 - Url: http://jenkins-updates.cloudbees.com/update-center/envelope-cje/update-center.json
 - Connection Url: null
 - Implementation Type: com.cloudbees.jenkins.plugins.license.nectar.CloudBeesUpdateSite
======
Last updated: 1 hr 28 min
=== Proxy ===

Node statistics
===============

  * Total number of nodes
      - Sample size:        352
      - Average (mean):     1.9999999999999996
      - Average (median):   2.0
      - Standard deviation: 4.4408920985006257E-16
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of nodes online
      - Sample size:        352
      - Average (mean):     1.9999999999999996
      - Average (median):   2.0
      - Standard deviation: 4.4408920985006257E-16
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors
      - Sample size:        352
      - Average (mean):     3.9999999999999996
      - Average (median):   4.0
      - Standard deviation: 4.4408920985006257E-16
      - Minimum:            4
      - Maximum:            4
      - 95th percentile:    4.0
      - 99th percentile:    4.0
  * Total number of executors in use
      - Sample size:        352
      - Average (mean):     2.143981326494931E-15
      - Average (median):   0.0
      - Standard deviation: 4.6303145967579E-8
      - Minimum:            0
      - Maximum:            1
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      0
      - FS root:        `/home/jenkins`
      - Labels:         master
      - Usage:          `EXCLUSIVE`
      - Slave Version:  3.14
      - Java
          + Home:           `/usr/lib/jvm/java-1.8-openjdk/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_121
          + Maximum memory:   988.00 MB (1035993088)
          + Allocated memory: 988.00 MB (1035993088)
          + Free memory:      782.54 MB (820555920)
          + In-use memory:    205.46 MB (215437168)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.121-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.4.0-1050-aws
      - Process ID: 5 (0x5)
      - Process started: 2018-02-06 16:13:32.178+0000
      - Process uptime: 1 hr 28 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/resources.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/rt.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jce.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8-openjdk/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64/server:/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64:/usr/lib/jvm/java-1.8-openjdk/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Djenkins.install.runSetupWizard=false`
          + arg[1]: `-Dcb.IMProp.fsProfiles=/cloudbees-plugins-profile.json`
          + arg[2]: `-Dhudson.TcpSlaveAgentListener.hostName=jenkins`
          + arg[3]: `-Dhudson.TcpSlaveAgentListener.port=8080`
          + arg[4]: `-Xms1024m`
          + arg[5]: `-Xmx1024m`

  * jdk7-node (`hudson.slaves.DumbSlave`)
      - Description:    _Agent node for JDK7_
      - Executors:      2
      - Remote FS root: `/home/jenkins`
      - Labels:         jdk7 jdk-7 java7 java-7 maven-jdk7
      - Usage:          `NORMAL`
      - Launch method:  `com.cloudbees.jenkins.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.14
      - Java
          + Home:           `/usr/lib/jvm/java-1.8-openjdk/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_151
          + Maximum memory:   878.50 MB (921174016)
          + Allocated memory: 90.00 MB (94371840)
          + Free memory:      35.44 MB (37156896)
          + In-use memory:    54.56 MB (57214944)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.151-b12
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.4.0-1050-aws
      - Process ID: 2176 (0x880)
      - Process started: 2018-02-06 16:14:19.573+0000
      - Process uptime: 1 hr 28 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/resources.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/rt.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jce.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8-openjdk/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64/server:/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64:/usr/lib/jvm/java-1.8-openjdk/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * jdk8-node (`hudson.slaves.DumbSlave`)
      - Description:    _Agent node for JDK8_
      - Executors:      2
      - Remote FS root: `/home/jenkins`
      - Labels:         maven jdk8 jdk-8 java8 java-8 maven-jdk8 java
      - Usage:          `NORMAL`
      - Launch method:  `com.cloudbees.jenkins.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.14
      - Java
          + Home:           `/usr/lib/jvm/java-1.8-openjdk/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_151
          + Maximum memory:   878.50 MB (921174016)
          + Allocated memory: 89.00 MB (93323264)
          + Free memory:      62.48 MB (65516184)
          + In-use memory:    26.52 MB (27807080)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.151-b12
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.4.0-1050-aws
      - Process ID: 2168 (0x878)
      - Process started: 2018-02-06 16:14:19.842+0000
      - Process uptime: 1 hr 28 min
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/resources.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/rt.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jce.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8-openjdk/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8-openjdk/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64/server:/usr/lib/jvm/java-1.8-openjdk/jre/lib/amd64:/usr/lib/jvm/java-1.8-openjdk/jre/../lib/amd64:/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`


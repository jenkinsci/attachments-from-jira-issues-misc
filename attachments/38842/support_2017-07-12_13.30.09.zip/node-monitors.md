Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * JGMachine: Windows 10 (amd64)
   * LDMachine: Windows 10 (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * JGMachine: In sync
   * LDMachine: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 25.134GB left on /var/lib/jenkins.
   * JGMachine: Disk space is too low. Only 372.059GB left on C:\Jenkins.
   * LDMachine: Disk space is too low. Only 386.950GB left on C:\Jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:504/1744MB  Swap:2047/2047MB
   * JGMachine: Memory:8590/16324MB  Swap:8016/18756MB
   * LDMachine: Memory:8316/16321MB  Swap:7096/18753MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 25.134GB left on /tmp.
   * JGMachine: Disk space is too low. Only 372.059GB left on C:\Users\jgodbout\AppData\Local\Temp.
   * LDMachine: Disk space is too low. Only 386.952GB left on C:\Users\ldgrondin\AppData\Local\Temp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * JGMachine: 4ms
   * LDMachine: 1023ms

Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 5
    - Number of items per container: 2.0 [n=5, s=0.7]
  * `hudson.model.FreeStyleProject`
    - Number of items: 5
    - Number of builds per job: 37.0 [n=5, s=30.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 5
    - Number of builds per job: 49.8 [n=5, s=60.0]

Total job statistics
======================

  * Number of jobs: 10
  * Number of builds per job: 43.4 [n=10, s=50.0]

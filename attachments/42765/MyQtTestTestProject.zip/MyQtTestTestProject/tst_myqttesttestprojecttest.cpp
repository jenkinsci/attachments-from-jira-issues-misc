#include <QString>
#include <QtTest>
#include <stdlib.h>

class MyQtTestTestProjectTest : public QObject
{
    Q_OBJECT

public:
    MyQtTestTestProjectTest();

private Q_SLOTS:
    void testCase1();
    void sort_test();
    void sort_test_data();
};

MyQtTestTestProjectTest::MyQtTestTestProjectTest()
{
}

void MyQtTestTestProjectTest::testCase1()
{
    QVERIFY2(true, "Failure");
}

void MyQtTestTestProjectTest::sort_test_data()
{
    QTest::addColumn<int>("input");
    QTest::addColumn<int>("result");

    QTest::newRow("set 1") << 1 << 0;

    QTest::newRow("set 2") << 1 << 0;

    QTest::newRow("set 3") << 1 << 0;
}

void MyQtTestTestProjectTest::sort_test()
{
    QFETCH(int, input);
    QFETCH(int, result);

    QCOMPARE(input, result);
}

QTEST_APPLESS_MAIN(MyQtTestTestProjectTest)

#include "tst_myqttesttestprojecttest.moc"

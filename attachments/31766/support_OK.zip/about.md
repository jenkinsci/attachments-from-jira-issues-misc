Jenkins
=======

Version details
---------------

  * Version: `1.646`
  * Mode:    Webapp Directory
  * Url:     http://gcagobuilder02/jenkins/
  * Servlet container
      - Specification: 3.0
      - Name:          `Apache Tomcat/7.0.52`
  * Java
      - Home:           `C:\tools\jdk1.7.0_51\jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_51
      - Maximum memory:   4.44 GB (4772069376)
      - Allocated memory: 1.34 GB (1434976256)
      - Free memory:      776.58 MB (814307656)
      - In-use memory:    591.92 MB (620668600)
      - PermGen used:     104.11 MB (109167040)
      - PermGen max:      1.00 GB (1073741824)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.51-b03
  * Operating system
      - Name:         Windows Server 2008 R2
      - Architecture: amd64
      - Version:      6.1
  * Process ID: 43516 (0xa9fc)
  * Process started: 2016-02-04 14:33:09.114+0100
  * Process uptime: 46 min
  * JVM startup parameters:
      - Boot classpath: `C:\tools\jdk1.7.0_51\jre\lib\resources.jar;C:\tools\jdk1.7.0_51\jre\lib\rt.jar;C:\tools\jdk1.7.0_51\jre\lib\sunrsasign.jar;C:\tools\jdk1.7.0_51\jre\lib\jsse.jar;C:\tools\jdk1.7.0_51\jre\lib\jce.jar;C:\tools\jdk1.7.0_51\jre\lib\charsets.jar;C:\tools\jdk1.7.0_51\jre\lib\jfr.jar;C:\tools\jdk1.7.0_51\jre\classes`
      - Classpath: `C:\tomcat\bin\bootstrap.jar;C:\tomcat\bin\tomcat-juli.jar;C:\tomcat\bin\tomcat-juli.jar`
      - Library path: `C:\tomcat\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\tools\svn;C:\Program Files\TortoiseSVN\bin;C:\tools\Graphviz 2.28\bin;C:\tools\zip;C:\tools\svn;C:\tools\unzip\bin;;.`
      - arg[0]: `-XX:MaxPermSize=1024m`
      - arg[1]: `-Dcatalina.base=C:\tomcat`
      - arg[2]: `-Dcatalina.home=C:\tomcat`
      - arg[3]: `-Djava.endorsed.dirs=C:\tomcat\endorsed`
      - arg[4]: `-Djava.io.tmpdir=C:\tomcat\temp`
      - arg[5]: `-Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager`
      - arg[6]: `-Djava.util.logging.config.file=C:\tomcat\conf\logging.properties`
      - arg[7]: `exit`
      - arg[8]: `-Xms1024m`
      - arg[9]: `-Xmx5120m`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `com.michelin.cio.hudson.plugins.rolestrategy.RoleBasedAuthorizationStrategy`

Active Plugins
--------------

  * analysis-core:1.75 'Static Analysis Utilities'
  * antisamy-markup-formatter:1.3 'OWASP Markup Formatter Plugin'
  * any-buildstep:0.1 'Any Build Step Plugin'
  * artifactdeployer:0.33 'Jenkins Artifact Deployer Plug-in'
  * build-name-setter:1.5.1 'build-name-setter'
  * build-pipeline-plugin:1.4.9 'Build Pipeline Plugin'
  * build-timeout:1.16 'Jenkins build timeout plugin'
  * buildgraph-view:1.1.1 'buildgraph-view'
  * categorized-view:1.8 'categorized-view'
  * checkstyle:3.44 'Checkstyle Plug-in'
  * cloudbees-folder:5.1 'CloudBees Folders Plugin'
  * conditional-buildstep:1.3.3 'conditional-buildstep'
  * copyartifact:1.37 'Copy Artifact Plugin'
  * credentials:1.24 'Credentials Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.7 'Dashboard View'
  * dependencyanalyzer:0.7 'Jenkins Dependency Analyzer Plugin'
  * depgraph-view:0.11 'Dependency Graph Viewer Plugin'
  * disk-usage:0.28 'Jenkins disk-usage plugin'
  * email-ext:2.40.5 'Email Extension Plugin'
  * envinject:1.92.1 'Environment Injector Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * flexible-publish:0.15.2 'Flexible Publish Plugin'
  * greenballs:1.15 'Green Balls'
  * groovy:1.29 'Groovy'
  * hudsontrayapp:0.7.3 'Hudson Tray Application Plugin'
  * jackson2-api:2.5.4 'Jackson 2 API Plugin'
  * javadoc:1.3 'Javadoc Plugin'
  * jenkins-multijob-plugin:1.20 'Jenkins Multijob plugin'
  * job-dsl:1.40 *(update available)* 'Job DSL'
  * jobConfigHistory:2.12 'Jenkins Job Configuration History Plugin'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * jslint-checkstyle:3.35 'JSLint Report Plug-in'
  * junit:1.10 'JUnit Plugin'
  * ldap:1.11 'LDAP Plugin'
  * locale:1.2 'Locale plugin'
  * m2release:0.14.0 'Jenkins Maven Release Plug-in Plug-in'
  * mailer:1.16 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.6.0 'MapDB API Plugin'
  * matrix-auth:1.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.6 'Matrix Project Plugin'
  * maven-info:0.2.0 'Jenkins Maven Info Plugin'
  * maven-plugin:2.12.1 'Maven Integration plugin'
  * metrics:3.1.2.2 *(update available)* 'Metrics Plugin'
  * monitoring:1.58.0 'Monitoring'
  * pam-auth:1.2 'PAM Authentication plugin'
  * parameterized-trigger:2.30 'Jenkins Parameterized Trigger plugin'
  * plugin-usage-plugin:0.3 'Plugin Usage - Plugin'
  * project-stats-plugin:0.4 'Project statistics Plugin'
  * promoted-builds:2.24.1 'Jenkins promoted builds plugin'
  * publish-over-ftp:1.11 'Publish Over FTP'
  * publish-over-ssh:1.13 'Publish Over SSH'
  * repository-connector:1.1.2 'Repository Connector'
  * role-strategy:2.2.0 'Role-based Authorization Strategy'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:1.0 'SCM API Plugin'
  * script-security:1.17 'Script Security Plugin'
  * simple-theme-plugin:0.3 'Simple Theme Plugin'
  * sonar:2.3 'Jenkins SonarQube Plugin'
  * ssh-credentials:1.11 'SSH Credentials Plugin'
  * ssh-slaves:1.10 'Jenkins SSH Slaves plugin'
  * subversion:2.5.7 'Jenkins Subversion Plug-in'
  * support-core:2.30 'Support Core Plugin'
  * timestamper:1.7.3 *(update available)* 'Timestamper'
  * token-macro:1.12.1 'Token Macro Plugin'
  * translation:1.12 'Jenkins Translation Assistance plugin'
  * view-job-filters:1.27 'View Job Filters'
  * windows-slaves:1.1 'Windows Slaves Plugin'
  * ws-cleanup:0.28 'Jenkins Workspace Cleanup Plugin'
  * xunit:1.100 'xUnit plugin'

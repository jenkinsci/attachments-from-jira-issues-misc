Node statistics
===============

  * Total number of nodes
      - Sample size:        184
      - Average (mean):     0.9999999999999999
      - Average (median):   1.0
      - Standard deviation: 1.1102230246251564E-16
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of nodes online
      - Sample size:        184
      - Average (mean):     0.9999999999999999
      - Average (median):   1.0
      - Standard deviation: 1.1102230246251564E-16
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        184
      - Average (mean):     8.0
      - Average (median):   8.0
      - Standard deviation: 0.0
      - Minimum:            8
      - Maximum:            8
      - 95th percentile:    8.0
      - 99th percentile:    8.0
  * Total number of executors in use
      - Sample size:        184
      - Average (mean):     1.9858338721260622
      - Average (median):   2.0
      - Standard deviation: 0.16772264959504352
      - Minimum:            0
      - Maximum:            3
      - 95th percentile:    2.0
      - 99th percentile:    2.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      8
      - FS root:        `C:\Jenkins2`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  2.53.2
      - Java
          + Home:           `C:\tools\jdk1.7.0_51\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_51
          + Maximum memory:   4.44 GB (4772069376)
          + Allocated memory: 1.34 GB (1434976256)
          + Free memory:      765.22 MB (802386800)
          + In-use memory:    603.28 MB (632589456)
          + PermGen used:     104.11 MB (109168760)
          + PermGen max:      1.00 GB (1073741824)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.51-b03
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 43516 (0xa9fc)
      - Process started: 2016-02-04 14:33:09.114+0100
      - Process uptime: 46 min
      - JVM startup parameters:
          + Boot classpath: `C:\tools\jdk1.7.0_51\jre\lib\resources.jar;C:\tools\jdk1.7.0_51\jre\lib\rt.jar;C:\tools\jdk1.7.0_51\jre\lib\sunrsasign.jar;C:\tools\jdk1.7.0_51\jre\lib\jsse.jar;C:\tools\jdk1.7.0_51\jre\lib\jce.jar;C:\tools\jdk1.7.0_51\jre\lib\charsets.jar;C:\tools\jdk1.7.0_51\jre\lib\jfr.jar;C:\tools\jdk1.7.0_51\jre\classes`
          + Classpath: `C:\tomcat\bin\bootstrap.jar;C:\tomcat\bin\tomcat-juli.jar;C:\tomcat\bin\tomcat-juli.jar`
          + Library path: `C:\tomcat\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;C:\tools\svn;C:\Program Files\TortoiseSVN\bin;C:\tools\Graphviz 2.28\bin;C:\tools\zip;C:\tools\svn;C:\tools\unzip\bin;;.`
          + arg[0]: `-XX:MaxPermSize=1024m`
          + arg[1]: `-Dcatalina.base=C:\tomcat`
          + arg[2]: `-Dcatalina.home=C:\tomcat`
          + arg[3]: `-Djava.endorsed.dirs=C:\tomcat\endorsed`
          + arg[4]: `-Djava.io.tmpdir=C:\tomcat\temp`
          + arg[5]: `-Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager`
          + arg[6]: `-Djava.util.logging.config.file=C:\tomcat\conf\logging.properties`
          + arg[7]: `exit`
          + arg[8]: `-Xms1024m`
          + arg[9]: `-Xmx5120m`


Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 12
    - Number of items per container: 6.333333333333333 [n=12, s=10.0]
  * `hudson.maven.MavenModule`
    - Number of items: 376
    - Number of builds per job: 5.507978723404255 [n=376, s=13.0]
  * `hudson.maven.MavenModuleSet`
    - Number of items: 80
    - Number of builds per job: 15.9375 [n=80, s=30.0]
    - Number of items per container: 4.7 [n=80, s=10.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 24
    - Number of builds per job: 35.125 [n=24, s=90.0]

Total job statistics
======================

  * Number of jobs: 480
  * Number of builds per job: 8.727083333333333 [n=480, s=27.0]

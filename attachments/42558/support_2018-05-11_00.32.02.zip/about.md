Jenkins
=======

Version details
---------------

  * Version: `2.116`
  * Mode:    WAR
  * Url:     http://cje.adama.local:8080/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_144
      - Maximum memory:   3.56 GB (3817865216)
      - Allocated memory: 1.53 GB (1646788608)
      - Free memory:      487.34 MB (511014752)
      - In-use memory:    1.06 GB (1135773856)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    Java HotSpot(TM) 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.144-b01
  * Operating system
      - Name:         Mac OS X
      - Architecture: x86_64
      - Version:      10.13.4
  * Process ID: 98934 (0x18276)
  * Process started: 2018-05-10 06:06:22.648+0000
  * Process uptime: 3 hr 26 min
  * JVM startup parameters:
      - Boot classpath: `/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/lib/resources.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/lib/rt.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/lib/sunrsasign.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/lib/jsse.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/lib/jce.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/lib/charsets.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/lib/jfr.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/classes`
      - Classpath: `/Users/cloudbees/Workspace/CloudBees/Support/cases/60938/jenkins-home/jenkins.war`
      - Library path: `/Users/cloudbees/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.`
      - arg[0]: `-Djenkins.install.runSetupWizard=false`
      - arg[1]: `-Djava.security.egd=file:/dev/./urandom`
      - arg[2]: `-Xdebug`
      - arg[3]: `-Xrunjdwp:transport=dt_socket,suspend=n,server=y,address=127.0.0.1:8000`
      - arg[4]: `-XX:MaxPermSize=512m`
      - arg[5]: `-Xms256m`
      - arg[6]: `-Dhudson.DNSMultiCast.disabled=true`

Important configuration
---------------

  * Security realm: `org.jenkinsci.plugins.mocksecurityrealm.MockSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * ant:1.8 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.5-2.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * aws-credentials:1.23 'CloudBees Amazon Web Services Credentials Plugin'
  * aws-java-sdk:1.11.264 'Amazon Web Services SDK'
  * blueocean:1.5.0 'Blue Ocean'
  * blueocean-autofavorite:1.2.2 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.5.0 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.5.0 'Common API for Blue Ocean'
  * blueocean-config:1.5.0 'Config API for Blue Ocean'
  * blueocean-core-js:1.5.0 'Blue Ocean Core JS'
  * blueocean-dashboard:1.5.0 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.2.0 'Display URL for Blue Ocean'
  * blueocean-events:1.5.0 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.5.0 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.5.0 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.5.0 'i18n for Blue Ocean'
  * blueocean-jira:1.5.0 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.5.0 'JWT for Blue Ocean'
  * blueocean-personalization:1.5.0 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.5.0 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.5.0 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.5.0 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.5.0 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.5.0 'REST Implementation for Blue Ocean'
  * blueocean-web:1.5.0 'Web for Blue Ocean'
  * bouncycastle-api:2.16.2 'bouncycastle API Plugin'
  * branch-api:2.0.20 'Branch API Plugin'
  * cloudbees-bitbucket-branch-source:2.2.11 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.4 'Folders Plugin'
  * command-launcher:1.2 'Command Agent Launcher Plugin'
  * conditional-buildstep:1.3.6 'Conditional BuildStep'
  * credentials:2.1.16 'Credentials Plugin'
  * credentials-binding:1.16 'Credentials Binding Plugin'
  * display-url-api:2.2.0 'Display URL API'
  * docker-commons:1.11 'Docker Commons Plugin'
  * docker-workflow:1.15.1 'Docker Pipeline'
  * durable-task:1.22 'Durable Task Plugin'
  * envinject:2.1.5 'Environment Injector Plugin'
  * envinject-api:1.5 'EnvInject API Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * favorite:2.3.1 'Favorite'
  * git:3.8.0 'Jenkins Git plugin'
  * git-client:2.7.1 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.29.0 'GitHub plugin'
  * github-api:1.90 'GitHub API Plugin'
  * github-branch-source:2.3.4 'GitHub Branch Source Plugin'
  * google-cloudbuild:0.1 (2017-10-30T14:37:56Z) 'Google Cloud Container Builder Plugin'
  * google-metadata-plugin:0.2 'Google Metadata plugin'
  * google-oauth-plugin:0.5 *(update available)* 'Google OAuth Credentials plugin'
  * google-storage-plugin:1.1 'Google Cloud Storage plugin'
  * gradle:1.28 'Gradle Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * handy-uri-templates-2-api:2.1.6-1.0 'Handy Uri Templates 2.x API Plugin'
  * htmlpublisher:1.16 'HTML Publisher plugin'
  * jackson2-api:2.8.11.1 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jdk-tool:1.1 'JDK Tool Plugin'
  * jenkins-design-language:1.5.0 'Jenkins Design Language'
  * jira:2.5.2 'Jenkins JIRA plugin'
  * job-dsl:1.69 'Job DSL'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.54.2 'Jenkins JSch dependency plugin'
  * junit:1.24 'JUnit Plugin'
  * ldap:1.20 'LDAP Plugin'
  * mailer:1.21 'Jenkins Mailer Plugin'
  * matrix-auth:2.2 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.13 'Matrix Project Plugin'
  * maven-plugin:3.1.2 'Maven Integration plugin'
  * mercurial:2.3 'Jenkins Mercurial plugin'
  * metrics:3.1.2.11 'Metrics Plugin'
  * mock-security-realm:1.3 'Mock Security Realm'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * oauth-credentials:0.3 'OAuth Credentials plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * pipeline-build-step:2.7 'Pipeline: Build Step'
  * pipeline-githubnotify-step:1.0.4 'Pipeline GitHub Notify Step Plugin'
  * pipeline-graph-analysis:1.6 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.2.9 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.2.9 'Pipeline: Declarative'
  * pipeline-model-extensions:1.2.9 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.10 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.2.9 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.10 'Pipeline: Stage View Plugin'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * prometheus:1.2.0 'Prometheus metrics plugin'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * reverse-proxy-auth-plugin:1.6.3 'Jenkins Reverse Proxy Auth Plugin'
  * run-condition:1.0 'Run Condition Plugin'
  * scm-api:2.2.7 'SCM API Plugin'
  * script-security:1.44 'Script Security Plugin'
  * slack:2.3 'Slack Notification Plugin'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.26 'Jenkins SSH Slaves plugin'
  * structs:1.14 'Structs Plugin'
  * support-core:2.47 'Support Core Plugin'
  * token-macro:2.5 'Token Macro Plugin'
  * variant:1.1 'Variant Plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.27 'Pipeline: API'
  * workflow-basic-steps:2.7 'Pipeline: Basic Steps'
  * workflow-cps:2.52 *(update available)* 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.9 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.19 'Pipeline: Nodes and Processes'
  * workflow-job:2.21 'Pipeline: Job'
  * workflow-multibranch:2.18 'Pipeline: Multibranch'
  * workflow-scm-step:2.6 'Pipeline: SCM Step'
  * workflow-step-api:2.14 'Pipeline: Step API'
  * workflow-support:2.18 'Pipeline: Supporting APIs'

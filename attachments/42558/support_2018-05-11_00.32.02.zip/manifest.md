Support Bundle Manifest
=======================

Generated on 2018-05-11 00:32:02.466+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2018-05-10_05.44.53.log`

      - `nodes/master/logs/all_2018-05-10_06.06.27.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Download metadata.log`

      - `other-logs/Download metadata.log.1`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Fingerprint cleanup.log.1`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/health-checker.log`

      - `other-logs/jobAnalytics.log`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * Build queue

      - `buildqueue.md`

  * Dump agent export tables (could reveal some memory leaks)

  * Environment variables

      - `nodes/master/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

  * Master JVM process system metrics (Linux only)

  * Load Statistics

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Agent Command Statistics

  * Master system configuration (Linux only)

  * System properties

      - `nodes/master/system.properties`

  * Update Center

      - `update-center.md`

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`


Node statistics
===============

  * Total number of nodes
      - Sample size:        824
      - Average (mean):     NaN
      - Average (median):   1.0
      - Standard deviation: NaN
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of nodes online
      - Sample size:        824
      - Average (mean):     NaN
      - Average (median):   1.0
      - Standard deviation: NaN
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        824
      - Average (mean):     NaN
      - Average (median):   2.0
      - Standard deviation: NaN
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors in use
      - Sample size:        824
      - Average (mean):     NaN
      - Average (median):   0.0
      - Standard deviation: NaN
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/Users/cloudbees/Workspace/CloudBees/Support/cases/60938/jenkins-home`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.19
      - Java
          + Home:           `/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_144
          + Maximum memory:   3.56 GB (3817865216)
          + Allocated memory: 1.53 GB (1646788608)
          + Free memory:      486.05 MB (509662184)
          + In-use memory:    1.06 GB (1137126424)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.144-b01
      - Operating system
          + Name:         Mac OS X
          + Architecture: x86_64
          + Version:      10.13.4
      - Process ID: 98934 (0x18276)
      - Process started: 2018-05-10 06:06:22.648+0000
      - Process uptime: 3 hr 26 min
      - JVM startup parameters:
          + Boot classpath: `/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/lib/resources.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/lib/rt.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/lib/sunrsasign.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/lib/jsse.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/lib/jce.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/lib/charsets.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/lib/jfr.jar:/Library/Java/JavaVirtualMachines/jdk1.8.0_144.jdk/Contents/Home/jre/classes`
          + Classpath: `/Users/cloudbees/Workspace/CloudBees/Support/cases/60938/jenkins-home/jenkins.war`
          + Library path: `/Users/cloudbees/Library/Java/Extensions:/Library/Java/Extensions:/Network/Library/Java/Extensions:/System/Library/Java/Extensions:/usr/lib/java:.`
          + arg[0]: `-Djenkins.install.runSetupWizard=false`
          + arg[1]: `-Djava.security.egd=file:/dev/./urandom`
          + arg[2]: `-Xdebug`
          + arg[3]: `-Xrunjdwp:transport=dt_socket,suspend=n,server=y,address=127.0.0.1:8000`
          + arg[4]: `-XX:MaxPermSize=512m`
          + arg[5]: `-Xms256m`
          + arg[6]: `-Dhudson.DNSMultiCast.disabled=true`


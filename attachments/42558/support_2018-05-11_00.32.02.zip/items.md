Item statistics
===============

  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 1
    - Number of builds per job: 2 [n=1]

Total job statistics
======================

  * Number of jobs: 1
  * Number of builds per job: 2 [n=1]

Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Mac OS X (x86_64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 17.932GB left on /Users/cloudbees/Workspace/CloudBees/Support/cases/60938/jenkins-home.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:0/0MB  Swap:1220/9216MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 17.932GB left on /private/var/folders/7f/5w2ygpk15kl230_lhc5m40rm0000gp/T.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms

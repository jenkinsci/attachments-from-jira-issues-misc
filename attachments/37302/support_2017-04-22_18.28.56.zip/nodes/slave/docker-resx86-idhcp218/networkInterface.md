-----------
 * Name veth584939f
 ** Hardware Address - 969e5422c23d
 ** Index - 5
 ** InetAddress - /fe80:0:0:0:949e:54ff:fe22:c23d%veth584939f
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vethf8e8def
 ** Hardware Address - 9608aad0595e
 ** Index - 7
 ** InetAddress - /fe80:0:0:0:9408:aaff:fed0:595e%vethf8e8def
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 02426cd2d6a0
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:42:6cff:fed2:d6a0%docker0
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 005056bc5626
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:250:56ff:febc:5626%eth0
 ** InetAddress - /10.13.204.218
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

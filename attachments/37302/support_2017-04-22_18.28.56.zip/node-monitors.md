Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * docker-gesx36-idhcp84: null
   * docker-gesx37-idhcp225: null
   * docker-resx62-idhcp87: null
   * docker-resx64-idhcp96: null
   * docker-resx84-idhcp83: null
   * docker-resx85-idhcp65: null
   * docker-resx85-idhcp84: null
   * docker-resx86-idhcp218: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * docker-gesx36-idhcp84: null
   * docker-gesx37-idhcp225: null
   * docker-resx62-idhcp87: null
   * docker-resx64-idhcp96: null
   * docker-resx84-idhcp83: null
   * docker-resx85-idhcp65: null
   * docker-resx85-idhcp84: null
   * docker-resx86-idhcp218: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 179.640GB left on /var/jenkins_home.
   * docker-gesx36-idhcp84: null
   * docker-gesx37-idhcp225: null
   * docker-resx62-idhcp87: null
   * docker-resx64-idhcp96: null
   * docker-resx84-idhcp83: null
   * docker-resx85-idhcp65: null
   * docker-resx85-idhcp84: null
   * docker-resx86-idhcp218: Disk space is too low. Only 69.078GB left on /emc/build/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:880/5967MB  Swap:2034/2053MB
   * docker-gesx36-idhcp84: null
   * docker-gesx37-idhcp225: null
   * docker-resx62-idhcp87: null
   * docker-resx64-idhcp96: null
   * docker-resx84-idhcp83: null
   * docker-resx85-idhcp65: null
   * docker-resx85-idhcp84: null
   * docker-resx86-idhcp218: Memory:4007/7884MB  Swap:8192/8197MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 0.5GB
 - Computers:
   * master: Disk space is too low. Only 179.640GB left on /tmp.
   * docker-gesx36-idhcp84: null
   * docker-gesx37-idhcp225: null
   * docker-resx62-idhcp87: null
   * docker-resx64-idhcp96: null
   * docker-resx84-idhcp83: null
   * docker-resx85-idhcp65: null
   * docker-resx85-idhcp84: null
   * docker-resx86-idhcp218: Disk space is too low. Only 69.078GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * docker-gesx36-idhcp84: Time out for last 5 try
   * docker-gesx37-idhcp225: Time out for last 5 try
   * docker-resx62-idhcp87: Time out for last 5 try
   * docker-resx64-idhcp96: Time out for last 5 try
   * docker-resx84-idhcp83: Time out for last 5 try
   * docker-resx85-idhcp65: Time out for last 5 try
   * docker-resx85-idhcp84: Time out for last 5 try
   * docker-resx86-idhcp218: 6ms

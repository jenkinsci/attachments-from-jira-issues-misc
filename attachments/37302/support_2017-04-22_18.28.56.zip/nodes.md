Node statistics
===============

  * Total number of nodes
      - Sample size:        3549
      - Average (mean):     9.0
      - Average (median):   9.0
      - Standard deviation: 0.0
      - Minimum:            9
      - Maximum:            9
      - 95th percentile:    9.0
      - 99th percentile:    9.0
  * Total number of nodes online
      - Sample size:        3549
      - Average (mean):     2.0
      - Average (median):   2.0
      - Standard deviation: 0.0
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors
      - Sample size:        3549
      - Average (mean):     5.0
      - Average (median):   5.0
      - Standard deviation: 0.0
      - Minimum:            5
      - Maximum:            5
      - 95th percentile:    5.0
      - 99th percentile:    5.0
  * Total number of executors in use
      - Sample size:        3549
      - Average (mean):     0.05066731860463362
      - Average (median):   0.0
      - Standard deviation: 0.21931744442713666
      - Minimum:            0
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      3
      - FS root:        `/var/jenkins_home`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  3.7
      - Java
          + Home:           `/usr/lib/jvm/java-8-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_121
          + Maximum memory:   1.30 GB (1390936064)
          + Allocated memory: 657.50 MB (689438720)
          + Free memory:      226.82 MB (237843128)
          + In-use memory:    430.68 MB (451595592)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.121-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.12.49-11-default
      - Process ID: 7 (0x7)
      - Process started: 2017-04-22 03:41:21.653+0000
      - Process uptime: 14 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-8-openjdk-amd64/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Duser.timezone=America/Los_Angeles`

  * docker-gesx36-idhcp84 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `/emc/build/jenkins`
      - Labels:         docker-hosts
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

  * docker-gesx37-idhcp225 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `/emc/build/jenkins`
      - Labels:         docker-hosts
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

  * docker-resx62-idhcp87 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `/emc/build/jenkins`
      - Labels:         docker-hosts
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

  * docker-resx64-idhcp96 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/emc/build/jenkins`
      - Labels:         danlinux-slaves
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

  * docker-resx84-idhcp83 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/emc/build/jenkins`
      - Labels:         docker
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * docker-resx85-idhcp65 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/emc/build/jenkins`
      - Labels:         docker
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         off-line

  * docker-resx85-idhcp84 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      1
      - Remote FS root: `/emc/build/jenkins`
      - Labels:         dockerX
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Demand`
      - Status:         off-line

  * docker-resx86-idhcp218 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `/emc/build/jenkins`
      - Labels:         docker
      - Usage:          `NORMAL`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.7
      - Java
          + Home:           `/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_121
          + Maximum memory:   1.71 GB (1838153728)
          + Allocated memory: 110.50 MB (115867648)
          + Free memory:      83.43 MB (87484528)
          + In-use memory:    27.07 MB (28383120)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.121-b13
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      3.12.69-60.64.32-default
      - Process ID: 31326 (0x7a5e)
      - Process started: 2017-04-22 03:41:36.972+0000
      - Process uptime: 14 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/resources.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/rt.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/sunrsasign.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/jsse.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/jce.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/charsets.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/lib/jfr.jar:/usr/lib64/jvm/java-1.8.0-openjdk-1.8.0/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`


Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 2
    - Number of items per container: 2.0 [n=2, s=0.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 16
    - Number of builds per job: 4.75 [n=16, s=10.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 17
    - Number of builds per job: 4.411764705882353 [n=17, s=7.0]

Total job statistics
======================

  * Number of jobs: 33
  * Number of builds per job: 4.575757575757576 [n=33, s=9.0]

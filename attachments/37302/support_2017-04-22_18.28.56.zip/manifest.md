Support Bundle Manifest
=======================

Generated on 2017-04-22 18:28:56.247+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2017-04-22_18.14.27.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Out of order build detection.log`

      - `other-logs/copy_reference_file.log`

      - `other-logs/health-checker.log`

  * Garbage Collection Logs

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/docker-gesx36-idhcp84/checksums.md5`

      - `nodes/slave/docker-gesx37-idhcp225/checksums.md5`

      - `nodes/slave/docker-resx62-idhcp87/checksums.md5`

      - `nodes/slave/docker-resx64-idhcp96/checksums.md5`

      - `nodes/slave/docker-resx84-idhcp83/checksums.md5`

      - `nodes/slave/docker-resx85-idhcp65/checksums.md5`

      - `nodes/slave/docker-resx85-idhcp84/checksums.md5`

      - `nodes/slave/docker-resx86-idhcp218/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump slave export tables (could reveal some memory leaks)

      - `nodes/slave/docker-gesx36-idhcp84/exportTable.txt`

      - `nodes/slave/docker-gesx37-idhcp225/exportTable.txt`

      - `nodes/slave/docker-resx62-idhcp87/exportTable.txt`

      - `nodes/slave/docker-resx64-idhcp96/exportTable.txt`

      - `nodes/slave/docker-resx84-idhcp83/exportTable.txt`

      - `nodes/slave/docker-resx85-idhcp65/exportTable.txt`

      - `nodes/slave/docker-resx85-idhcp84/exportTable.txt`

      - `nodes/slave/docker-resx86-idhcp218/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/docker-gesx36-idhcp84/environment.txt`

      - `nodes/slave/docker-gesx37-idhcp225/environment.txt`

      - `nodes/slave/docker-resx62-idhcp87/environment.txt`

      - `nodes/slave/docker-resx64-idhcp96/environment.txt`

      - `nodes/slave/docker-resx84-idhcp83/environment.txt`

      - `nodes/slave/docker-resx85-idhcp65/environment.txt`

      - `nodes/slave/docker-resx85-idhcp84/environment.txt`

      - `nodes/slave/docker-resx86-idhcp218/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/docker-resx86-idhcp218/file-descriptors.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/docker-resx86-idhcp218/proc/meminfo.txt`

      - `nodes/slave/docker-resx86-idhcp218/proc/self/cmdline`

      - `nodes/slave/docker-resx86-idhcp218/proc/self/environ`

      - `nodes/slave/docker-resx86-idhcp218/proc/self/limits.txt`

      - `nodes/slave/docker-resx86-idhcp218/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/danlinux-slaves/gnuplot`

      - `load-stats/label/danlinux-slaves/hour.csv`

      - `load-stats/label/danlinux-slaves/min.csv`

      - `load-stats/label/danlinux-slaves/sec10.csv`

      - `load-stats/label/docker-gesx36-idhcp84/gnuplot`

      - `load-stats/label/docker-gesx36-idhcp84/hour.csv`

      - `load-stats/label/docker-gesx36-idhcp84/min.csv`

      - `load-stats/label/docker-gesx36-idhcp84/sec10.csv`

      - `load-stats/label/docker-gesx37-idhcp225/gnuplot`

      - `load-stats/label/docker-gesx37-idhcp225/hour.csv`

      - `load-stats/label/docker-gesx37-idhcp225/min.csv`

      - `load-stats/label/docker-gesx37-idhcp225/sec10.csv`

      - `load-stats/label/docker-hosts/gnuplot`

      - `load-stats/label/docker-hosts/hour.csv`

      - `load-stats/label/docker-hosts/min.csv`

      - `load-stats/label/docker-hosts/sec10.csv`

      - `load-stats/label/docker-resx62-idhcp87/gnuplot`

      - `load-stats/label/docker-resx62-idhcp87/hour.csv`

      - `load-stats/label/docker-resx62-idhcp87/min.csv`

      - `load-stats/label/docker-resx62-idhcp87/sec10.csv`

      - `load-stats/label/docker-resx64-idhcp96/gnuplot`

      - `load-stats/label/docker-resx64-idhcp96/hour.csv`

      - `load-stats/label/docker-resx64-idhcp96/min.csv`

      - `load-stats/label/docker-resx64-idhcp96/sec10.csv`

      - `load-stats/label/docker-resx84-idhcp83/gnuplot`

      - `load-stats/label/docker-resx84-idhcp83/hour.csv`

      - `load-stats/label/docker-resx84-idhcp83/min.csv`

      - `load-stats/label/docker-resx84-idhcp83/sec10.csv`

      - `load-stats/label/docker-resx85-idhcp65/gnuplot`

      - `load-stats/label/docker-resx85-idhcp65/hour.csv`

      - `load-stats/label/docker-resx85-idhcp65/min.csv`

      - `load-stats/label/docker-resx85-idhcp65/sec10.csv`

      - `load-stats/label/docker-resx85-idhcp84/gnuplot`

      - `load-stats/label/docker-resx85-idhcp84/hour.csv`

      - `load-stats/label/docker-resx85-idhcp84/min.csv`

      - `load-stats/label/docker-resx85-idhcp84/sec10.csv`

      - `load-stats/label/docker-resx86-idhcp218/gnuplot`

      - `load-stats/label/docker-resx86-idhcp218/hour.csv`

      - `load-stats/label/docker-resx86-idhcp218/min.csv`

      - `load-stats/label/docker-resx86-idhcp218/sec10.csv`

      - `load-stats/label/docker/gnuplot`

      - `load-stats/label/docker/hour.csv`

      - `load-stats/label/docker/min.csv`

      - `load-stats/label/docker/sec10.csv`

      - `load-stats/label/dockerX/gnuplot`

      - `load-stats/label/dockerX/hour.csv`

      - `load-stats/label/dockerX/min.csv`

      - `load-stats/label/dockerX/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/docker-gesx36-idhcp84/metrics.json`

      - `nodes/slave/docker-gesx37-idhcp225/metrics.json`

      - `nodes/slave/docker-resx62-idhcp87/metrics.json`

      - `nodes/slave/docker-resx64-idhcp96/metrics.json`

      - `nodes/slave/docker-resx84-idhcp83/metrics.json`

      - `nodes/slave/docker-resx85-idhcp65/metrics.json`

      - `nodes/slave/docker-resx85-idhcp84/metrics.json`

      - `nodes/slave/docker-resx86-idhcp218/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/docker-gesx36-idhcp84/networkInterface.md`

      - `nodes/slave/docker-gesx37-idhcp225/networkInterface.md`

      - `nodes/slave/docker-resx62-idhcp87/networkInterface.md`

      - `nodes/slave/docker-resx64-idhcp96/networkInterface.md`

      - `nodes/slave/docker-resx84-idhcp83/networkInterface.md`

      - `nodes/slave/docker-resx85-idhcp65/networkInterface.md`

      - `nodes/slave/docker-resx85-idhcp84/networkInterface.md`

      - `nodes/slave/docker-resx86-idhcp218/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/docker-resx86-idhcp218/dmesg.txt`

      - `nodes/slave/docker-resx86-idhcp218/dmi.txt`

      - `nodes/slave/docker-resx86-idhcp218/proc/cpuinfo.txt`

      - `nodes/slave/docker-resx86-idhcp218/proc/mounts.txt`

      - `nodes/slave/docker-resx86-idhcp218/proc/swaps.txt`

      - `nodes/slave/docker-resx86-idhcp218/proc/system-uptime.txt`

      - `nodes/slave/docker-resx86-idhcp218/sysctl.txt`

      - `nodes/slave/docker-resx86-idhcp218/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/docker-gesx36-idhcp84/system.properties`

      - `nodes/slave/docker-gesx37-idhcp225/system.properties`

      - `nodes/slave/docker-resx62-idhcp87/system.properties`

      - `nodes/slave/docker-resx64-idhcp96/system.properties`

      - `nodes/slave/docker-resx84-idhcp83/system.properties`

      - `nodes/slave/docker-resx85-idhcp65/system.properties`

      - `nodes/slave/docker-resx85-idhcp84/system.properties`

      - `nodes/slave/docker-resx86-idhcp218/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/docker-gesx36-idhcp84/thread-dump.txt`

      - `nodes/slave/docker-gesx37-idhcp225/thread-dump.txt`

      - `nodes/slave/docker-resx62-idhcp87/thread-dump.txt`

      - `nodes/slave/docker-resx64-idhcp96/thread-dump.txt`

      - `nodes/slave/docker-resx84-idhcp83/thread-dump.txt`

      - `nodes/slave/docker-resx85-idhcp65/thread-dump.txt`

      - `nodes/slave/docker-resx85-idhcp84/thread-dump.txt`

      - `nodes/slave/docker-resx86-idhcp218/thread-dump.txt`


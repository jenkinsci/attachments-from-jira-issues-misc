Node statistics
===============

  * Total number of nodes
      - Sample size:        6
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of nodes online
      - Sample size:        6
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        6
      - Average (mean):     0.9999999999999999
      - Average (median):   1.0
      - Standard deviation: 1.1102230246251564E-16
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors in use
      - Sample size:        6
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      1
      - FS root:        `/home/jenkins`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Slave Version:  2.59
      - Java
          + Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_101
          + Maximum memory:   341.50 MB (358088704)
          + Allocated memory: 211.50 MB (221773824)
          + Free memory:      109.18 MB (114484624)
          + In-use memory:    102.32 MB (107289200)
          + PermGen used:     99.27 MB (104088432)
          + PermGen max:      256.00 MB (268435456)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.95-b01
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.5.5-x86_64-linode69
          + Distribution: Ubuntu 14.04.4 LTS
      - Process ID: 4659 (0x1233)
      - Process started: 2016-07-04 19:44:35.459+0200
      - Process uptime: 1 min 56 sec
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
          + Classpath: `/usr/share/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
          + arg[0]: `-Xmx384m`
          + arg[1]: `-XX:MaxPermSize=256m`


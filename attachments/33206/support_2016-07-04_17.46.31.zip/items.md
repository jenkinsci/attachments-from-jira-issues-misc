Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 13
    - Number of builds per job: 109.07692307692308 [n=13, s=300.0]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 8
    - Number of builds per job: 2.0 [n=8, s=2.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 2
    - Number of items per container: 4.0 [n=2, s=3.0]

Total job statistics
======================

  * Number of jobs: 21
  * Number of builds per job: 68.28571428571429 [n=21, s=200.0]

User
====

Authentication
--------------

  * Authenticated: true
  * Name: vladdu
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@e101f413: Username: hudson.security.HudsonPrivateSecurityRealm$Details@65c4d3; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@b364: RemoteIpAddress: 155.4.129.46; SessionId: i2veirth3nbv1xt1cvqr0cgpo; Granted Authorities: authenticated`


Jenkins
=======

Version details
---------------

  * Version: `1.651.3`
  * Mode:    WAR
  * Url:     https://ci.erlide.org/
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/winstone-2.9`
  * Java
      - Home:           `/usr/lib/jvm/java-7-openjdk-amd64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_101
      - Maximum memory:   341.50 MB (358088704)
      - Allocated memory: 211.50 MB (221773824)
      - Free memory:      110.57 MB (115942048)
      - In-use memory:    100.93 MB (105831776)
      - PermGen used:     99.27 MB (104087896)
      - PermGen max:      256.00 MB (268435456)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.95-b01
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.5.5-x86_64-linode69
      - Distribution: Ubuntu 14.04.4 LTS
  * Process ID: 4659 (0x1233)
  * Process started: 2016-07-04 19:44:35.459+0200
  * Process uptime: 1 min 56 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/resources.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rt.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jsse.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jce.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/charsets.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/rhino.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/lib/jfr.jar:/usr/lib/jvm/java-7-openjdk-amd64/jre/classes`
      - Classpath: `/usr/share/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib/x86_64-linux-gnu/jni:/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:/usr/lib/jni:/lib:/usr/lib`
      - arg[0]: `-Xmx384m`
      - arg[1]: `-XX:MaxPermSize=256m`

Important configuration
---------------

  * Security realm: `hudson.security.HudsonPrivateSecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`
  * CSRF Protection: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-collector:1.48 'Static Analysis Collector Plug-in'
  * analysis-core:1.78 'Static Analysis Utilities'
  * ansicolor:0.4.2 'AnsiColor'
  * ant:1.3 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * authorize-project:1.2.2 'Authorize Project'
  * bouncycastle-api:1.648.3 'bouncycastle API Plugin'
  * branch-api:1.10 'Branch API Plugin'
  * build-environment:1.6 'Build Environment Plugin'
  * build-name-setter:1.6.5 'build-name-setter'
  * build-pipeline-plugin:1.5.3.1 'Build Pipeline Plugin'
  * build-timeout:1.17 'Jenkins build timeout plugin'
  * cloudbees-folder:5.12 'Folders Plugin'
  * cobertura:1.9.8 'Jenkins Cobertura Plugin'
  * conditional-buildstep:1.3.5 'Conditional BuildStep'
  * copyartifact:1.38 'Copy Artifact Plugin'
  * create-fingerprint:1.2 'Fingerprint Plugin'
  * credentials:2.1.4 'Credentials Plugin'
  * cvs:2.12 'Jenkins CVS Plug-in'
  * description-setter:1.10 'Jenkins description setter plugin'
  * disk-usage:0.28 'Jenkins disk-usage plugin'
  * docker-build-step:1.35 'docker-build-step'
  * docker-commons:1.4.0 'Docker Commons Plugin'
  * docker-custom-build-environment:1.6.5 'CloudBees Docker Custom Build Environment Plugin'
  * docker-plugin:0.16.0 'Docker plugin'
  * docker-traceability:1.2 'CloudBees Docker Traceability'
  * docker-workflow:1.6 'CloudBees Docker Pipeline'
  * durable-task:1.11 'Durable Task Plugin'
  * eclipse-update-site:1.2 'Eclipse Update Site plugin'
  * embeddable-build-status:1.9 'embeddable-build-status'
  * emma:1.29 'Jenkins Emma plugin'
  * envinject:1.92.1 'Environment Injector Plugin'
  * external-monitor-job:1.4 'External Monitor Job Type Plugin'
  * extra-columns:1.17 'Extra Columns Plugin'
  * fail-the-build-plugin:1.0 'Fail The Build Plugin'
  * flexible-publish:0.15.2 'Flexible Publish Plugin'
  * ghprb:1.32.8 'GitHub Pull Request Builder'
  * git:2.5.0 *(update available)* 'Jenkins Git plugin'
  * git-changelog:1.32 'Git Changelog'
  * git-client:1.19.6 'Jenkins Git client plugin'
  * git-parameter:0.5.1 'Git Parameter Plug-In'
  * git-server:1.6 'Git server plugin'
  * github:1.19.2 'GitHub plugin'
  * github-api:1.76 'GitHub API Plugin'
  * github-branch-source:1.7 'GitHub Branch Source Plugin'
  * github-oauth:0.24 'GitHub Authentication plugin'
  * github-organization-folder:1.3 'GitHub Organization Folder Plugin'
  * github-pullrequest:0.1.0-rc7 'GitHub Pull Request Plugin'
  * gradle:1.24 'Jenkins Gradle plugin'
  * greenballs:1.15 'Green Balls'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * html5-notifier-plugin:1.5 'HTML5 Notifier Plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 'Jackson 2 API Plugin'
  * jacoco:2.0.1 'Jenkins JaCoCo plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * JDK_Parameter_Plugin:1.0 'JDK Parameter Plugin'
  * jenkins-multijob-plugin:1.21 'Jenkins Multijob plugin'
  * job-dsl:1.48 'Job DSL'
  * jquery:1.11.2-0 'Jenkins jQuery plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jquery-ui:1.0.2 'Jenkins jQuery UI plugin'
  * junit:1.13 'JUnit Plugin'
  * ldap:1.12 'LDAP Plugin'
  * locks-and-latches:0.6 'Hudson Locks and Latches plugin'
  * log-parser:2.0 'Log Parser Plugin'
  * mailer:1.17 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.4 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.7.1 'Matrix Project Plugin'
  * maven-plugin:2.13 'Maven Integration plugin'
  * metrics:3.1.2.8 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * parallel-test-executor:1.8 'Jenkins Parallel Test Executor Plugin'
  * parameterized-trigger:2.31 'Jenkins Parameterized Trigger plugin'
  * pipeline-build-step:2.1 'Pipeline: Build Step'
  * pipeline-input-step:2.0 'Pipeline: Input Step'
  * pipeline-rest-api:1.5 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.1 'Pipeline: Stage Step'
  * pipeline-stage-view:1.5 'Pipeline: Stage View Plugin'
  * plain-credentials:1.2 'Plain Credentials Plugin'
  * project-description-setter:1.1 'Project Description Setter'
  * project-inheritance:1.5.3 'inheritance-plugin'
  * promoted-builds:2.27 'Jenkins promoted builds plugin'
  * publish-over-ftp:1.12 'Publish Over FTP'
  * rebuild:1.25 'Rebuilder'
  * remote-terminal-access:1.6 'Remote Terminal Access plugin'
  * ruby-runtime:0.12 'ruby-runtime'
  * run-condition:1.0 'Run Condition Plugin'
  * saferestart:0.3 'Safe Restart Plugin'
  * scm-api:1.2 'SCM API Plugin'
  * scp:1.8 'Hudson SCP publisher plugin'
  * script-security:1.20 'Script Security Plugin'
  * seed:1.0.0 'Seed Jenkins plug-in'
  * simple-build-for-pipeline:0.2 'Simple Build DSL for Pipeline'
  * simple-theme-plugin:0.3 'Simple Theme Plugin'
  * sloccount:1.21 'Jenkins SLOCCount Plug-in'
  * ssh-agent:1.13 'SSH Agent Plugin'
  * ssh-credentials:1.12 'SSH Credentials Plugin'
  * ssh-slaves:1.11 'Jenkins SSH Slaves plugin'
  * structs:1.2 'Structs Plugin'
  * subversion:2.6 'Jenkins Subversion Plug-in'
  * support-core:2.32 'Support Core Plugin'
  * tasks:4.49 'Task Scanner Plug-in'
  * thinBackup:1.7.4 'ThinBackup'
  * timestamper:1.8.4 'Timestamper'
  * token-macro:1.12.1 'Token Macro Plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * warnings:4.56 'Warnings Plug-in'
  * windows-slaves:1.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.2 'Pipeline'
  * workflow-api:2.1 'Pipeline: API'
  * workflow-basic-steps:2.0 'Pipeline: Basic Steps'
  * workflow-cps:2.8 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.1 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.3 'Pipeline: Nodes and Processes'
  * workflow-job:2.3 'Pipeline: Job'
  * workflow-multibranch:2.8 'Pipeline: Multibranch'
  * workflow-scm-step:2.1 'Pipeline: SCM Step'
  * workflow-step-api:2.2 'Pipeline: Step API'
  * workflow-support:2.1 'Pipeline: Supporting APIs'
  * xvfb:1.1.3 'Jenkins Xvfb plugin'
  * zentimestamp:4.2 'Jenkins Zentimestamp plugin'

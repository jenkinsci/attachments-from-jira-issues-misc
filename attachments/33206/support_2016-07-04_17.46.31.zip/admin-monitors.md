Monitors
========

`jenkins.security.s2m.MasterKillSwitchWarning`
--------------
(active and enabled)

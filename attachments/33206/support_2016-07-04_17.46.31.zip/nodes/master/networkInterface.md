-----------
 * Name docker0
 ** Hardware Address - 024203c26772
 ** Index - 13
 ** InetAddress - /172.17.0.1
 ** MTU - 1500
 ** Is Up - false
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - f23c91503d68
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:f03c:91ff:fe50:3d68%3
 ** InetAddress - /2a01:7e00:0:0:f03c:91ff:fe50:3d68%3
 ** InetAddress - /192.168.136.244
 ** InetAddress - /88.80.187.146
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%1
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

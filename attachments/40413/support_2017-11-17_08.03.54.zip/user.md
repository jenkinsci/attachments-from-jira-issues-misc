User
====

Authentication
--------------

  * Authenticated: true
  * Name: seckler
  * Authorities 
      - `authenticated`
  * Raw: `org.acegisecurity.providers.UsernamePasswordAuthenticationToken@722cce55: Username: hudson.security.HudsonPrivateSecurityRealm$Details@35ba2502; Password: [PROTECTED]; Authenticated: true; Details: org.acegisecurity.ui.WebAuthenticationDetails@0: RemoteIpAddress: 0:0:0:0:0:0:0:1; SessionId: 8mebwam383u01e6etegxpyh1w; Granted Authorities: authenticated`


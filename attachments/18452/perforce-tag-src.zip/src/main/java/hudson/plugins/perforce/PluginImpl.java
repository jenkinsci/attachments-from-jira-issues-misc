package hudson.plugins.perforce;

import hudson.Plugin;
import hudson.scm.SCMS;
import hudson.scm.RepositoryBrowsers;
import hudson.tasks.MailAddressResolver;
import hudson.tasks.BuildStep;
import hudson.model.Descriptor;
import hudson.tasks.Publisher;

import hudson.plugins.perforce.browsers.*;
import hudson.plugins.perforce.perforce_tag.*;

/**
 *
 * @author Mike Wille
 */
public class PluginImpl extends Plugin {
    public void start() throws Exception {
		//BuildStep.PUBLISHERS.add(PerforceTagPublisher.DESCRIPTOR);
		Descriptor<Publisher> test = PerforceTagPublisher.DESCRIPTOR;
		BuildStep.PUBLISHERS.addNotifier(test);
        SCMS.SCMS.add(PerforceSCM.DESCRIPTOR);
        RepositoryBrowsers.LIST.add(P4Web.DESCRIPTOR);
        RepositoryBrowsers.LIST.add(FishEyePerforce.DESCRIPTOR);
		MailAddressResolver.LIST.add(new PerforceMailResolver());
		super.start();
    }
}

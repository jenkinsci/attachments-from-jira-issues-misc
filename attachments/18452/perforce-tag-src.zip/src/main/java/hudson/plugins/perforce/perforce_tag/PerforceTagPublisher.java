package hudson.plugins.perforce.perforce_tag;

import hudson.Launcher;
import hudson.util.FormFieldValidator;
import hudson.model.*;
import hudson.tasks.*;
import net.sf.json.JSONObject;

import org.kohsuke.stapler.StaplerRequest;
import org.kohsuke.stapler.StaplerResponse;

import javax.servlet.ServletException;
import java.io.IOException;
import static hudson.plugins.perforce.perforce_tag.PerforceTagPlugin.CONFIG_PREFIX;
import static hudson.plugins.perforce.perforce_tag.PerforceTagPlugin.DESCRIPTION;


/**
 * Sample {@link Builder}.
 *
 * <p>
 * When the user configures the project and enables this builder,
 * {@link DescriptorImpl#newInstance(StaplerRequest)} is invoked
 * and a new {@link HelloWorldBuilder} is created. The created
 * instance is persisted to the project configuration XML by using
 * XStream, so this allows you to use instance fields (like {@link #name})
 * to remember the configuration.
 *
 * <p>
 * When a build is performed, the {@link #perform(Build, Launcher, BuildListener)} method
 * will be invoked.
 *
 * @author Kohsuke Kawaguchi
 */
public class PerforceTagPublisher extends Publisher {
    /**
     * The tag name
     */
    private String tagName;

    public static final PerforceTagDescriptorImpl DESCRIPTOR = new PerforceTagDescriptorImpl();

    /**
     * @return the tag name
     */
    public String getTagName()
    {
        if (tagName == null || tagName.length() == 0)
        {
            return DESCRIPTOR.getDefaultTagName();
        }

        return tagName;
    }

    /**
     * Set the tag name
     * @param tagName the tag name
     */
    public void setTagName(String tagName)
    {
        this.tagName = tagName;
    }

    public boolean perform(AbstractBuild<?, ?> build, Launcher launcher, BuildListener listener) throws InterruptedException, IOException
    {
        return PerforceTagPlugin.perform(build, launcher, listener, tagName);
    }

    @Override
    public boolean needsToRunAfterFinalized()
    {
        return true;
    }

    public Descriptor<Publisher> getDescriptor()
    {
        return DESCRIPTOR;
    }

    public static final class PerforceTagDescriptorImpl extends Descriptor<Publisher>
    {

        private String defaultTagName;

        private PerforceTagDescriptorImpl()
        {
            super(PerforceTagPublisher.class);
            this.defaultTagName = "BLD_5_2_01_" + "${env['BUILD_NUMBER']}";

            load();
        }

        @Override
        public String getDisplayName()
        {
            return DESCRIPTION;
        }

        @Override
        public Publisher newInstance(StaplerRequest req, JSONObject formData) throws FormException
        {
            PerforceTagPublisher perforceTagPublisher = new PerforceTagPublisher();
            perforceTagPublisher.setTagName(formData.getString("tagName"));

            return perforceTagPublisher;
        }

        @Override
        public boolean configure(StaplerRequest req) throws FormException
        {
             this.defaultTagName = req.getParameter(CONFIG_PREFIX + "tagName");

            save();

            return super.configure(req);
        }

        public String getDefaultTagName()
        {
            return defaultTagName;
        }

        public void setDefaultTagName(String defaultTagName)
        {
            this.defaultTagName = defaultTagName;
        }

        public void doTagNameCheck(final StaplerRequest req, StaplerResponse resp) throws IOException, ServletException
        {
            new FormFieldValidator(req, resp, false)
            {
                protected void check() throws IOException, ServletException
                {
                    String tagName = req.getParameter("value");

                    if (tagName == null || tagName.length() == 0)
                    {
                        error("Please specify a name for this tag.");
                    }
                }
            }.process();
        }
    }
}


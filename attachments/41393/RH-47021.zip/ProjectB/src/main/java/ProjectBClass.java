public class ProjectBClass {
	public static void main(String[] args) {
		ProjectAClass a = new ProjectAClass();
		ProjectBClass b = new ProjectBClass();
	}
}

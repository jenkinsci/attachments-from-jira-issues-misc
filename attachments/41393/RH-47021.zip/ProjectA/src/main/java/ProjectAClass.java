public class ProjectAClass {
}

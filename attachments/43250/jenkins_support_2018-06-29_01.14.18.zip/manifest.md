Support Bundle Manifest
=======================

Generated on 2018-06-29 01:14:18.544+0000

Requested components:

  * Master Log Recorders

      - `nodes/master/logs/all_2018-06-25_01.58.21.log`

      - `nodes/master/logs/all_2018-06-25_02.07.38.log`

      - `nodes/master/logs/all_2018-06-25_03.30.35.log`

      - `nodes/master/logs/all_2018-06-26_04.33.17.log`

      - `nodes/master/logs/all_2018-06-28_06.32.21.log`

      - `nodes/master/logs/all_2018-06-28_23.46.07.log`

      - `nodes/master/logs/all_2018-06-29_00.22.59.log`

      - `nodes/master/logs/all_memory_buffer.log`

      - `nodes/master/logs/jenkins.log`

      - `other-logs/Connection Activity monitoring to agents.log`

      - `other-logs/Connection Activity monitoring to agents.log.1`

      - `other-logs/Connection Activity monitoring to agents.log.2`

      - `other-logs/Connection Activity monitoring to agents.log.3`

      - `other-logs/Connection Activity monitoring to agents.log.4`

      - `other-logs/Connection Activity monitoring to agents.log.5`

      - `other-logs/Download metadata.log`

      - `other-logs/Download metadata.log.1`

      - `other-logs/Download metadata.log.2`

      - `other-logs/Download metadata.log.3`

      - `other-logs/Download metadata.log.4`

      - `other-logs/Download metadata.log.5`

      - `other-logs/Fingerprint cleanup.log`

      - `other-logs/Fingerprint cleanup.log.1`

      - `other-logs/Fingerprint cleanup.log.2`

      - `other-logs/Fingerprint cleanup.log.3`

      - `other-logs/Fingerprint cleanup.log.4`

      - `other-logs/Fingerprint cleanup.log.5`

      - `other-logs/Workspace clean-up.log`

      - `other-logs/Workspace clean-up.log.1`

      - `other-logs/Workspace clean-up.log.2`

      - `other-logs/Workspace clean-up.log.3`

      - `other-logs/Workspace clean-up.log.4`

      - `other-logs/Workspace clean-up.log.5`

      - `other-logs/health-checker.log`

      - `other-logs/jenkins.branch.MultiBranchProject.log`

      - `other-logs/jenkins.branch.MultiBranchProject.log.1`

      - `other-logs/jenkins.branch.MultiBranchProject.log.2`

      - `other-logs/jenkins.branch.MultiBranchProject.log.3`

      - `other-logs/jenkins.branch.MultiBranchProject.log.4`

      - `other-logs/jenkins.branch.OrganizationFolder.log`

      - `other-logs/jenkins.branch.OrganizationFolder.log.1`

      - `other-logs/jenkins.branch.OrganizationFolder.log.2`

      - `other-logs/jenkins.branch.OrganizationFolder.log.3`

      - `other-logs/jenkins.branch.OrganizationFolder.log.4`

      - `other-logs/jobAnalytics.log`

      - `other-logs/jobAnalytics.log.1`

      - `other-logs/jobAnalytics.log.2`

      - `other-logs/jobAnalytics.log.3`

      - `other-logs/jobAnalytics.log.4`

      - `other-logs/jobAnalytics.log.5`

  * Agent Log Recorders

      - `nodes/slave/devbuild10/jenkins.log`

      - `nodes/slave/devbuild10/logs/all_2018-06-25_02.01.50.log`

      - `nodes/slave/devbuild10/logs/all_2018-06-28_06.44.48.log`

      - `nodes/slave/devbuild10/logs/all_2018-06-28_23.39.49.log`

      - `nodes/slave/devbuild10/logs/all_2018-06-28_23.47.49.log`

      - `nodes/slave/devbuild10/logs/all_memory_buffer.log`

      - `nodes/slave/devbuild9/jenkins.log`

      - `nodes/slave/devbuild9/logs/all_2018-06-25_02.00.34.log`

      - `nodes/slave/devbuild9/logs/all_2018-06-25_02.00.48.log`

      - `nodes/slave/devbuild9/logs/all_2018-06-28_23.39.50.log`

      - `nodes/slave/devbuild9/logs/all_2018-06-28_23.47.50.log`

      - `nodes/slave/devbuild9/logs/all_2018-06-29_00.17.52.log`

      - `nodes/slave/devbuild9/logs/all_2018-06-29_00.34.48.log`

      - `nodes/slave/devbuild9/logs/all_memory_buffer.log`

      - `nodes/slave/expert/jenkins.log`

      - `nodes/slave/expert/logs/all_2018-06-25_01.58.39.log`

      - `nodes/slave/expert/logs/all_2018-06-28_06.54.48.log`

      - `nodes/slave/expert/logs/all_2018-06-28_07.10.48.log`

      - `nodes/slave/expert/logs/all_2018-06-29_00.17.49.log`

      - `nodes/slave/expert/logs/all_memory_buffer.log`

      - `nodes/slave/secure/jenkins.log`

      - `nodes/slave/secure/logs/all_2018-06-25_02.00.34.log`

      - `nodes/slave/secure/logs/all_2018-06-25_02.00.48.log`

      - `nodes/slave/secure/logs/all_2018-06-28_23.39.50.log`

      - `nodes/slave/secure/logs/all_2018-06-28_23.47.50.log`

      - `nodes/slave/secure/logs/all_2018-06-29_00.17.52.log`

      - `nodes/slave/secure/logs/all_2018-06-29_00.34.48.log`

      - `nodes/slave/secure/logs/all_memory_buffer.log`

  * Garbage Collection Logs

  * Agents config files (Encrypted secrets are redacted)

      - `nodes/slave/devbuild10/config.xml`

      - `nodes/slave/devbuild9/config.xml`

      - `nodes/slave/expert/config.xml`

      - `nodes/slave/secure/config.xml`

  * Jenkins Global Configuration File (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/config.xml`

  * Other Jenkins Configuration Files (Encrypted secrets are redacted)

      - `jenkins-root-configuration-files/cloudbees-disk-usage-simple.xml`

      - `jenkins-root-configuration-files/com.cloudbees.jenkins.plugins.bitbucket.endpoints.BitbucketEndpointConfiguration.xml`

      - `jenkins-root-configuration-files/com.myyearbook.hudson.plugins.confluence.ConfluencePublisher.xml`

      - `jenkins-root-configuration-files/com.sonyericsson.rebuild.RebuildDescriptor.xml`

      - `jenkins-root-configuration-files/com.tikal.jenkins.plugins.multijob.PhaseJobsConfig.xml`

      - `jenkins-root-configuration-files/envInject.xml`

      - `jenkins-root-configuration-files/github-plugin-configuration.xml`

      - `jenkins-root-configuration-files/hudson.ivy.IvyBuildTrigger.xml`

      - `jenkins-root-configuration-files/hudson.ivy.IvyModuleSet.xml`

      - `jenkins-root-configuration-files/hudson.maven.MavenModuleSet.xml`

      - `jenkins-root-configuration-files/hudson.model.UpdateCenter.xml`

      - `jenkins-root-configuration-files/hudson.plugins.ansicolor.AnsiColorBuildWrapper.xml`

      - `jenkins-root-configuration-files/hudson.plugins.build_timeout.operations.BuildStepOperation.xml`

      - `jenkins-root-configuration-files/hudson.plugins.claim.ClaimConfig.xml`

      - `jenkins-root-configuration-files/hudson.plugins.copyartifact.TriggeredBuildSelector.xml`

      - `jenkins-root-configuration-files/hudson.plugins.emailext.ExtendedEmailPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitSCM.xml`

      - `jenkins-root-configuration-files/hudson.plugins.git.GitTool.xml`

      - `jenkins-root-configuration-files/hudson.plugins.jira.JiraProjectProperty.xml`

      - `jenkins-root-configuration-files/hudson.plugins.logparser.LogParserPublisher.xml`

      - `jenkins-root-configuration-files/hudson.plugins.promoted_builds.GlobalBuildPromotedBuilds.xml`

      - `jenkins-root-configuration-files/hudson.plugins.sonar.SonarGlobalConfiguration.xml`

      - `jenkins-root-configuration-files/hudson.plugins.timestamper.TimestamperConfig.xml`

      - `jenkins-root-configuration-files/hudson.scm.CVSSCM.xml`

      - `jenkins-root-configuration-files/hudson.scm.SubversionSCM.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Mailer.xml`

      - `jenkins-root-configuration-files/hudson.tasks.Shell.xml`

      - `jenkins-root-configuration-files/hudson.triggers.SCMTrigger.xml`

      - `jenkins-root-configuration-files/jenkins.advancedqueue.PriorityConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.advancedqueue.PrioritySorterConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.metrics.api.MetricsAccessKey.xml`

      - `jenkins-root-configuration-files/jenkins.model.ArtifactManagerConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.model.DownloadSettings.xml`

      - `jenkins-root-configuration-files/jenkins.model.JenkinsLocationConfiguration.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.hipchat.HipChatNotifier.xml`

      - `jenkins-root-configuration-files/jenkins.plugins.linkedjobs.settings.GlobalSettings.xml`

      - `jenkins-root-configuration-files/jenkins.security.QueueItemAuthenticatorConfiguration.xml`

      - `jenkins-root-configuration-files/jobConfigHistory.xml`

      - `jenkins-root-configuration-files/nodeMonitors.xml`

      - `jenkins-root-configuration-files/org.jenkins_ci.plugins.flexible_publish.FlexiblePublisher.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.conditionalbuildstep.singlestep.SingleConditionalBuilder.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.corsfilter.AccessControlsFilter.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.github_branch_source.GitHubConfiguration.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.pipeline.modeldefinition.config.GlobalConfig.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.resourcedisposer.AsyncResourceDisposer.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.flow.FlowExecutionList.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.flow.GlobalDefaultFlowDurabilityLevel.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.libs.GlobalLibraries.xml`

      - `jenkins-root-configuration-files/org.jenkinsci.plugins.workflow.support.steps.StageStep.xml`

      - `jenkins-root-configuration-files/org.jfrog.hudson.ArtifactoryBuilder.xml`

      - `jenkins-root-configuration-files/org.jvnet.hudson.plugins.SSHBuildWrapper.xml`

      - `jenkins-root-configuration-files/org.jvnet.hudson.plugins.collapsingconsolesections.CollapsingSectionNote.xml`

      - `jenkins-root-configuration-files/queue.xml`

      - `jenkins-root-configuration-files/scriptApproval.xml`

      - `jenkins-root-configuration-files/support-core.xml`

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/devbuild10/checksums.md5`

      - `nodes/slave/devbuild9/checksums.md5`

      - `nodes/slave/expert/checksums.md5`

      - `nodes/slave/secure/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump agent export tables (could reveal some memory leaks)

      - `nodes/slave/devbuild10/exportTable.txt`

      - `nodes/slave/devbuild9/exportTable.txt`

      - `nodes/slave/expert/exportTable.txt`

      - `nodes/slave/secure/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/devbuild10/environment.txt`

      - `nodes/slave/devbuild9/environment.txt`

      - `nodes/slave/expert/environment.txt`

      - `nodes/slave/secure/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/devbuild10/file-descriptors.txt`

      - `nodes/slave/devbuild9/file-descriptors.txt`

      - `nodes/slave/expert/file-descriptors.txt`

      - `nodes/slave/secure/file-descriptors.txt`

  * Master Heap Histogram

      - `nodes/master/heap-histogram.txt`

  * Agent JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/devbuild10/proc/meminfo.txt`

      - `nodes/slave/devbuild10/proc/self/cmdline`

      - `nodes/slave/devbuild10/proc/self/environ`

      - `nodes/slave/devbuild10/proc/self/limits.txt`

      - `nodes/slave/devbuild10/proc/self/mountstats.txt`

      - `nodes/slave/devbuild10/proc/self/status.txt`

      - `nodes/slave/devbuild9/proc/meminfo.txt`

      - `nodes/slave/devbuild9/proc/self/cmdline`

      - `nodes/slave/devbuild9/proc/self/environ`

      - `nodes/slave/devbuild9/proc/self/limits.txt`

      - `nodes/slave/devbuild9/proc/self/mountstats.txt`

      - `nodes/slave/devbuild9/proc/self/status.txt`

      - `nodes/slave/expert/proc/meminfo.txt`

      - `nodes/slave/expert/proc/self/cmdline`

      - `nodes/slave/expert/proc/self/environ`

      - `nodes/slave/expert/proc/self/limits.txt`

      - `nodes/slave/expert/proc/self/mountstats.txt`

      - `nodes/slave/expert/proc/self/status.txt`

      - `nodes/slave/secure/proc/meminfo.txt`

      - `nodes/slave/secure/proc/self/cmdline`

      - `nodes/slave/secure/proc/self/environ`

      - `nodes/slave/secure/proc/self/limits.txt`

      - `nodes/slave/secure/proc/self/mountstats.txt`

      - `nodes/slave/secure/proc/self/status.txt`

  * Master JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/devbuild10/proc/meminfo.txt`

      - `nodes/slave/devbuild10/proc/self/cmdline`

      - `nodes/slave/devbuild10/proc/self/environ`

      - `nodes/slave/devbuild10/proc/self/limits.txt`

      - `nodes/slave/devbuild10/proc/self/mountstats.txt`

      - `nodes/slave/devbuild10/proc/self/status.txt`

      - `nodes/slave/devbuild9/proc/meminfo.txt`

      - `nodes/slave/devbuild9/proc/self/cmdline`

      - `nodes/slave/devbuild9/proc/self/environ`

      - `nodes/slave/devbuild9/proc/self/limits.txt`

      - `nodes/slave/devbuild9/proc/self/mountstats.txt`

      - `nodes/slave/devbuild9/proc/self/status.txt`

      - `nodes/slave/expert/proc/meminfo.txt`

      - `nodes/slave/expert/proc/self/cmdline`

      - `nodes/slave/expert/proc/self/environ`

      - `nodes/slave/expert/proc/self/limits.txt`

      - `nodes/slave/expert/proc/self/mountstats.txt`

      - `nodes/slave/expert/proc/self/status.txt`

      - `nodes/slave/secure/proc/meminfo.txt`

      - `nodes/slave/secure/proc/self/cmdline`

      - `nodes/slave/secure/proc/self/environ`

      - `nodes/slave/secure/proc/self/limits.txt`

      - `nodes/slave/secure/proc/self/mountstats.txt`

      - `nodes/slave/secure/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/6.6/gnuplot`

      - `load-stats/label/6.6/hour.csv`

      - `load-stats/label/6.6/min.csv`

      - `load-stats/label/6.6/sec10.csv`

      - `load-stats/label/CentOS%26%26%21restricted/gnuplot`

      - `load-stats/label/CentOS%26%26%21restricted/hour.csv`

      - `load-stats/label/CentOS%26%26%21restricted/min.csv`

      - `load-stats/label/CentOS%26%26%21restricted/sec10.csv`

      - `load-stats/label/CentOS-6.6%26%26%21restricted%26%26%21dot/gnuplot`

      - `load-stats/label/CentOS-6.6%26%26%21restricted%26%26%21dot/hour.csv`

      - `load-stats/label/CentOS-6.6%26%26%21restricted%26%26%21dot/min.csv`

      - `load-stats/label/CentOS-6.6%26%26%21restricted%26%26%21dot/sec10.csv`

      - `load-stats/label/CentOS-6.6%26%26%21restricted%26%26uiTests/gnuplot`

      - `load-stats/label/CentOS-6.6%26%26%21restricted%26%26uiTests/hour.csv`

      - `load-stats/label/CentOS-6.6%26%26%21restricted%26%26uiTests/min.csv`

      - `load-stats/label/CentOS-6.6%26%26%21restricted%26%26uiTests/sec10.csv`

      - `load-stats/label/CentOS-6.6%26%26%21restricted/gnuplot`

      - `load-stats/label/CentOS-6.6%26%26%21restricted/hour.csv`

      - `load-stats/label/CentOS-6.6%26%26%21restricted/min.csv`

      - `load-stats/label/CentOS-6.6%26%26%21restricted/sec10.csv`

      - `load-stats/label/CentOS-6.6/gnuplot`

      - `load-stats/label/CentOS-6.6/hour.csv`

      - `load-stats/label/CentOS-6.6/min.csv`

      - `load-stats/label/CentOS-6.6/sec10.csv`

      - `load-stats/label/CentOS/gnuplot`

      - `load-stats/label/CentOS/hour.csv`

      - `load-stats/label/CentOS/min.csv`

      - `load-stats/label/CentOS/sec10.csv`

      - `load-stats/label/CentOSNR/gnuplot`

      - `load-stats/label/CentOSNR/hour.csv`

      - `load-stats/label/CentOSNR/min.csv`

      - `load-stats/label/CentOSNR/sec10.csv`

      - `load-stats/label/Sydney/gnuplot`

      - `load-stats/label/Sydney/hour.csv`

      - `load-stats/label/Sydney/min.csv`

      - `load-stats/label/Sydney/sec10.csv`

      - `load-stats/label/amd64-CentOS-6.6/gnuplot`

      - `load-stats/label/amd64-CentOS-6.6/hour.csv`

      - `load-stats/label/amd64-CentOS-6.6/min.csv`

      - `load-stats/label/amd64-CentOS-6.6/sec10.csv`

      - `load-stats/label/amd64-CentOS/gnuplot`

      - `load-stats/label/amd64-CentOS/hour.csv`

      - `load-stats/label/amd64-CentOS/min.csv`

      - `load-stats/label/amd64-CentOS/sec10.csv`

      - `load-stats/label/amd64/gnuplot`

      - `load-stats/label/amd64/hour.csv`

      - `load-stats/label/amd64/min.csv`

      - `load-stats/label/amd64/sec10.csv`

      - `load-stats/label/devbuild10/gnuplot`

      - `load-stats/label/devbuild10/hour.csv`

      - `load-stats/label/devbuild10/min.csv`

      - `load-stats/label/devbuild10/sec10.csv`

      - `load-stats/label/devbuild9/gnuplot`

      - `load-stats/label/devbuild9/hour.csv`

      - `load-stats/label/devbuild9/min.csv`

      - `load-stats/label/devbuild9/sec10.csv`

      - `load-stats/label/expert/gnuplot`

      - `load-stats/label/expert/hour.csv`

      - `load-stats/label/expert/min.csv`

      - `load-stats/label/expert/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/mastermind/gnuplot`

      - `load-stats/label/mastermind/hour.csv`

      - `load-stats/label/mastermind/min.csv`

      - `load-stats/label/mastermind/sec10.csv`

      - `load-stats/label/performanceTest/gnuplot`

      - `load-stats/label/performanceTest/hour.csv`

      - `load-stats/label/performanceTest/min.csv`

      - `load-stats/label/performanceTest/sec10.csv`

      - `load-stats/label/restricted/gnuplot`

      - `load-stats/label/restricted/hour.csv`

      - `load-stats/label/restricted/min.csv`

      - `load-stats/label/restricted/sec10.csv`

      - `load-stats/label/rnd_coretools/gnuplot`

      - `load-stats/label/rnd_coretools/hour.csv`

      - `load-stats/label/rnd_coretools/min.csv`

      - `load-stats/label/rnd_coretools/sec10.csv`

      - `load-stats/label/secure/gnuplot`

      - `load-stats/label/secure/hour.csv`

      - `load-stats/label/secure/min.csv`

      - `load-stats/label/secure/sec10.csv`

      - `load-stats/label/sydney/gnuplot`

      - `load-stats/label/sydney/hour.csv`

      - `load-stats/label/sydney/min.csv`

      - `load-stats/label/sydney/sec10.csv`

      - `load-stats/label/uiTests/gnuplot`

      - `load-stats/label/uiTests/hour.csv`

      - `load-stats/label/uiTests/min.csv`

      - `load-stats/label/uiTests/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/devbuild10/networkInterface.md`

      - `nodes/slave/devbuild9/networkInterface.md`

      - `nodes/slave/expert/networkInterface.md`

      - `nodes/slave/secure/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * Agent Command Statistics

      - `nodes/slave/devbuild10/command-stats.md`

      - `nodes/slave/devbuild9/command-stats.md`

      - `nodes/slave/expert/command-stats.md`

      - `nodes/slave/secure/command-stats.md`

  * Agent system configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/devbuild10/dmesg.txt`

      - `nodes/slave/devbuild10/dmi.txt`

      - `nodes/slave/devbuild10/proc/cpuinfo.txt`

      - `nodes/slave/devbuild10/proc/mounts.txt`

      - `nodes/slave/devbuild10/proc/net/rpc/nfs.txt`

      - `nodes/slave/devbuild10/proc/net/rpc/nfsd.txt`

      - `nodes/slave/devbuild10/proc/swaps.txt`

      - `nodes/slave/devbuild10/proc/system-uptime.txt`

      - `nodes/slave/devbuild10/sysctl.txt`

      - `nodes/slave/devbuild10/userid.txt`

      - `nodes/slave/devbuild9/dmesg.txt`

      - `nodes/slave/devbuild9/dmi.txt`

      - `nodes/slave/devbuild9/proc/cpuinfo.txt`

      - `nodes/slave/devbuild9/proc/mounts.txt`

      - `nodes/slave/devbuild9/proc/net/rpc/nfs.txt`

      - `nodes/slave/devbuild9/proc/net/rpc/nfsd.txt`

      - `nodes/slave/devbuild9/proc/swaps.txt`

      - `nodes/slave/devbuild9/proc/system-uptime.txt`

      - `nodes/slave/devbuild9/sysctl.txt`

      - `nodes/slave/devbuild9/userid.txt`

      - `nodes/slave/expert/dmesg.txt`

      - `nodes/slave/expert/dmi.txt`

      - `nodes/slave/expert/proc/cpuinfo.txt`

      - `nodes/slave/expert/proc/mounts.txt`

      - `nodes/slave/expert/proc/net/rpc/nfs.txt`

      - `nodes/slave/expert/proc/net/rpc/nfsd.txt`

      - `nodes/slave/expert/proc/swaps.txt`

      - `nodes/slave/expert/proc/system-uptime.txt`

      - `nodes/slave/expert/sysctl.txt`

      - `nodes/slave/expert/userid.txt`

      - `nodes/slave/secure/dmesg.txt`

      - `nodes/slave/secure/dmi.txt`

      - `nodes/slave/secure/proc/cpuinfo.txt`

      - `nodes/slave/secure/proc/mounts.txt`

      - `nodes/slave/secure/proc/net/rpc/nfs.txt`

      - `nodes/slave/secure/proc/net/rpc/nfsd.txt`

      - `nodes/slave/secure/proc/swaps.txt`

      - `nodes/slave/secure/proc/system-uptime.txt`

      - `nodes/slave/secure/sysctl.txt`

      - `nodes/slave/secure/userid.txt`

  * Master system configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/devbuild10/dmesg.txt`

      - `nodes/slave/devbuild10/dmi.txt`

      - `nodes/slave/devbuild10/proc/cpuinfo.txt`

      - `nodes/slave/devbuild10/proc/mounts.txt`

      - `nodes/slave/devbuild10/proc/net/rpc/nfs.txt`

      - `nodes/slave/devbuild10/proc/net/rpc/nfsd.txt`

      - `nodes/slave/devbuild10/proc/swaps.txt`

      - `nodes/slave/devbuild10/proc/system-uptime.txt`

      - `nodes/slave/devbuild10/sysctl.txt`

      - `nodes/slave/devbuild10/userid.txt`

      - `nodes/slave/devbuild9/dmesg.txt`

      - `nodes/slave/devbuild9/dmi.txt`

      - `nodes/slave/devbuild9/proc/cpuinfo.txt`

      - `nodes/slave/devbuild9/proc/mounts.txt`

      - `nodes/slave/devbuild9/proc/net/rpc/nfs.txt`

      - `nodes/slave/devbuild9/proc/net/rpc/nfsd.txt`

      - `nodes/slave/devbuild9/proc/swaps.txt`

      - `nodes/slave/devbuild9/proc/system-uptime.txt`

      - `nodes/slave/devbuild9/sysctl.txt`

      - `nodes/slave/devbuild9/userid.txt`

      - `nodes/slave/expert/dmesg.txt`

      - `nodes/slave/expert/dmi.txt`

      - `nodes/slave/expert/proc/cpuinfo.txt`

      - `nodes/slave/expert/proc/mounts.txt`

      - `nodes/slave/expert/proc/net/rpc/nfs.txt`

      - `nodes/slave/expert/proc/net/rpc/nfsd.txt`

      - `nodes/slave/expert/proc/swaps.txt`

      - `nodes/slave/expert/proc/system-uptime.txt`

      - `nodes/slave/expert/sysctl.txt`

      - `nodes/slave/expert/userid.txt`

      - `nodes/slave/secure/dmesg.txt`

      - `nodes/slave/secure/dmi.txt`

      - `nodes/slave/secure/proc/cpuinfo.txt`

      - `nodes/slave/secure/proc/mounts.txt`

      - `nodes/slave/secure/proc/net/rpc/nfs.txt`

      - `nodes/slave/secure/proc/net/rpc/nfsd.txt`

      - `nodes/slave/secure/proc/swaps.txt`

      - `nodes/slave/secure/proc/system-uptime.txt`

      - `nodes/slave/secure/sysctl.txt`

      - `nodes/slave/secure/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/devbuild10/system.properties`

      - `nodes/slave/devbuild9/system.properties`

      - `nodes/slave/expert/system.properties`

      - `nodes/slave/secure/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Timing data about recently completed Pipeline builds

      - `nodes/master/pipeline-timings.txt`

  * Thread dumps of running Pipeline builds

      - `nodes/master/pipeline-thread-dump.txt`

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/devbuild10/thread-dump.txt`

      - `nodes/slave/devbuild9/thread-dump.txt`

      - `nodes/slave/expert/thread-dump.txt`

      - `nodes/slave/secure/thread-dump.txt`


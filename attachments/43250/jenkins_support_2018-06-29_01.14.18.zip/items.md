Item statistics
===============

  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 133
    - Number of builds per job: 11.308270676691729 [n=133, s=18.0]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 30
    - Number of items per container: 4.366666666666666 [n=30, s=9.0]

Total job statistics
======================

  * Number of jobs: 133
  * Number of builds per job: 11.308270676691729 [n=133, s=18.0]

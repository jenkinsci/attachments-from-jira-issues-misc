Node statistics
===============

  * Total number of nodes
      - Sample size:        22863
      - Average (mean):     5.000000000000001
      - Average (median):   5.0
      - Standard deviation: 8.881784197001252E-16
      - Minimum:            5
      - Maximum:            5
      - 95th percentile:    5.0
      - 99th percentile:    5.0
  * Total number of nodes online
      - Sample size:        22863
      - Average (mean):     4.999999999999999
      - Average (median):   5.0
      - Standard deviation: 1.742533914467578E-8
      - Minimum:            3
      - Maximum:            5
      - 95th percentile:    5.0
      - 99th percentile:    5.0
  * Total number of executors
      - Sample size:        22863
      - Average (mean):     14.0
      - Average (median):   14.0
      - Standard deviation: 6.970134539618123E-8
      - Minimum:            6
      - Maximum:            14
      - 95th percentile:    14.0
      - 99th percentile:    14.0
  * Total number of executors in use
      - Sample size:        22863
      - Average (mean):     2.4056571526793874E-16
      - Average (median):   0.0
      - Standard deviation: 3.102562293893354E-8
      - Minimum:            0
      - Maximum:            12
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the master Jenkins node_
      - Executors:      2
      - FS root:        `/var/jenkins`
      - Labels:         restricted mastermind sydney Sydney uiTests
      - Usage:          `NORMAL`
      - Slave Version:  3.21
      - Java
          + Home:           `/usr/java/jdk1.8.0_40/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_40
          + Maximum memory:   1.78 GB (1908932608)
          + Allocated memory: 627.00 MB (657457152)
          + Free memory:      190.48 MB (199733536)
          + In-use memory:    436.52 MB (457723616)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.40-b25
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.16.2.el6.x86_64
          + Distribution: "CentOS release 6.6 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 32204 (0x7dcc)
      - Process started: 2018-06-25 01:58:09.527+0000
      - Process uptime: 3 days 23 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_40/jre/lib/resources.jar:/usr/java/jdk1.8.0_40/jre/lib/rt.jar:/usr/java/jdk1.8.0_40/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_40/jre/lib/jsse.jar:/usr/java/jdk1.8.0_40/jre/lib/jce.jar:/usr/java/jdk1.8.0_40/jre/lib/charsets.jar:/usr/java/jdk1.8.0_40/jre/lib/jfr.jar:/usr/java/jdk1.8.0_40/jre/classes`
          + Classpath: `/var/jenkins/jenkins.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Xmx2048m`
          + arg[1]: `-XX:MaxPermSize=256m`
          + arg[2]: `-Dcors.origin=*`
          + arg[3]: `-Dcors.methods=GET,POST,PUT,DELETE`
          + arg[4]: `-Dcors.headers=Authorization`
          + arg[5]: `-Djava.io.tmpdir=/var/tmp`
          + arg[6]: `-DJENKINS_HOME=/var/jenkins`

  * devbuild10 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      4
      - Remote FS root: `/data/jenkinssecure`
      - Labels:         CentOSNR sydney Sydney performanceTest uiTests
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.21
      - Java
          + Home:           `/usr/java/jdk1.8.0_40/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_40
          + Maximum memory:   3.46 GB (3715629056)
          + Allocated memory: 1.36 GB (1456996352)
          + Free memory:      849.05 MB (890293568)
          + In-use memory:    540.45 MB (566702784)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.40-b25
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.16.2.el6.x86_64
          + Distribution: "CentOS release 6.6 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 127621 (0x1f285)
      - Process started: 2018-06-28 23:47:46.693+0000
      - Process uptime: 1 hr 26 min
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_40/jre/lib/resources.jar:/usr/java/jdk1.8.0_40/jre/lib/rt.jar:/usr/java/jdk1.8.0_40/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_40/jre/lib/jsse.jar:/usr/java/jdk1.8.0_40/jre/lib/jce.jar:/usr/java/jdk1.8.0_40/jre/lib/charsets.jar:/usr/java/jdk1.8.0_40/jre/lib/jfr.jar:/usr/java/jdk1.8.0_40/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * devbuild9 (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      4
      - Remote FS root: `/data/jenkinssecure`
      - Labels:         CentOSNR sydney Sydney performanceTest uiTests
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.21
      - Java
          + Home:           `/usr/java/jdk1.8.0_40/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_40
          + Maximum memory:   1.71 GB (1834483712)
          + Allocated memory: 119.00 MB (124780544)
          + Free memory:      99.38 MB (104204032)
          + In-use memory:    19.62 MB (20576512)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.40-b25
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.16.2.el6.x86_64
          + Distribution: "CentOS release 6.6 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 27310 (0x6aae)
      - Process started: 2018-06-29 00:34:46.665+0000
      - Process uptime: 39 min
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_40/jre/lib/resources.jar:/usr/java/jdk1.8.0_40/jre/lib/rt.jar:/usr/java/jdk1.8.0_40/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_40/jre/lib/jsse.jar:/usr/java/jdk1.8.0_40/jre/lib/jce.jar:/usr/java/jdk1.8.0_40/jre/lib/charsets.jar:/usr/java/jdk1.8.0_40/jre/lib/jfr.jar:/usr/java/jdk1.8.0_40/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * expert (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `/fast/jenkinssecure`
      - Labels:         CentOSNR sydney Sydney performanceTest uiTests
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.21
      - Java
          + Home:           `/usr/java/jdk1.8.0_40/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_40
          + Maximum memory:   13.96 GB (14987821056)
          + Allocated memory: 556.00 MB (583008256)
          + Free memory:      484.18 MB (507704152)
          + In-use memory:    71.82 MB (75304104)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.40-b25
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.12.2.el6.x86_64
          + Distribution: "CentOS release 6.6 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 76700 (0x12b9c)
      - Process started: 2018-06-29 00:17:46.928+0000
      - Process uptime: 56 min
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_40/jre/lib/resources.jar:/usr/java/jdk1.8.0_40/jre/lib/rt.jar:/usr/java/jdk1.8.0_40/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_40/jre/lib/jsse.jar:/usr/java/jdk1.8.0_40/jre/lib/jce.jar:/usr/java/jdk1.8.0_40/jre/lib/charsets.jar:/usr/java/jdk1.8.0_40/jre/lib/jfr.jar:/usr/java/jdk1.8.0_40/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`

  * secure (`hudson.slaves.DumbSlave`)
      - Description:    __
      - Executors:      2
      - Remote FS root: `/data/jenkinssecure`
      - Labels:         rnd_coretools restricted sydney Sydney
      - Usage:          `EXCLUSIVE`
      - Launch method:  `hudson.plugins.sshslaves.SSHLauncher`
      - Availability:   `hudson.slaves.RetentionStrategy$Always`
      - Status:         on-line
      - Version:        3.21
      - Java
          + Home:           `/usr/java/jdk1.8.0_40/jre`
          + Vendor:           Oracle Corporation
          + Version:          1.8.0_40
          + Maximum memory:   1.71 GB (1834483712)
          + Allocated memory: 297.50 MB (311951360)
          + Free memory:      186.35 MB (195405968)
          + In-use memory:    111.15 MB (116545392)
          + GC strategy:      ParallelGC
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 25.40-b25
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      2.6.32-504.16.2.el6.x86_64
          + Distribution: "CentOS release 6.6 (Final)"
          + LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
      - Process ID: 31728 (0x7bf0)
      - Process started: 2018-06-25 02:00:46.239+0000
      - Process uptime: 3 days 23 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/java/jdk1.8.0_40/jre/lib/resources.jar:/usr/java/jdk1.8.0_40/jre/lib/rt.jar:/usr/java/jdk1.8.0_40/jre/lib/sunrsasign.jar:/usr/java/jdk1.8.0_40/jre/lib/jsse.jar:/usr/java/jdk1.8.0_40/jre/lib/jce.jar:/usr/java/jdk1.8.0_40/jre/lib/charsets.jar:/usr/java/jdk1.8.0_40/jre/lib/jfr.jar:/usr/java/jdk1.8.0_40/jre/classes`
          + Classpath: `slave.jar`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`


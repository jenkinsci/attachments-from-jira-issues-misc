Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * devbuild10: Linux (amd64)
   * devbuild9: Linux (amd64)
   * expert: Linux (amd64)
   * secure: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * devbuild10: In sync
   * devbuild9: In sync
   * expert: In sync
   * secure: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 27.019GB left on /var/jenkins.
   * devbuild10: Disk space is too low. Only 11.631GB left on /data/jenkinssecure.
   * devbuild9: Disk space is too low. Only 83.258GB left on /data/jenkinssecure.
   * expert: Disk space is too low. Only 52.915GB left on /fast/jenkinssecure.
   * secure: Disk space is too low. Only 83.258GB left on /data/jenkinssecure.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:413/7871MB  Swap:9919/10048MB
   * devbuild10: Memory:5105/15936MB  Swap:8957/10048MB
   * devbuild9: Memory:4253/7871MB  Swap:9543/10048MB
   * expert: Memory:2841/64318MB  Swap:33892/34178MB
   * secure: Memory:4253/7871MB  Swap:9543/10048MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 27.019GB left on /var/tmp.
   * devbuild10: Disk space is too low. Only 22.448GB left on /tmp.
   * devbuild9: Disk space is too low. Only 32.250GB left on /tmp.
   * expert: Disk space is too low. Only 52.915GB left on /tmp.
   * secure: Disk space is too low. Only 32.250GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * devbuild10: 87ms
   * devbuild9: 209ms
   * expert: 209ms
   * secure: 103ms
JVM Version
----
 - Is Ignored: false
 - Computers:
   * master: 1.8.0_40
   * devbuild10: 1.8.0_40
   * devbuild9: 1.8.0_40
   * expert: 1.8.0_40
   * secure: 1.8.0_40
Remoting Version
----
 - Is Ignored: false
 - Computers:
   * master: 3.21
   * devbuild10: 3.21
   * devbuild9: 3.21
   * expert: 3.21
   * secure: 3.21

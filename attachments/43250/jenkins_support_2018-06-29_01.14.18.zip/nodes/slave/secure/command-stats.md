# Totals
* Writes: 36077
  * sent 97.0Mb
* Reads: 101790
  * received 220.9Mb
* Responses: 24903
  * waited 2 min 33 sec

# Commands sent
* `GC`: 2
  * sent 0.0Mb
* `Pipe.Chunk`: 30
  * sent 0.1Mb
* `ProxyOutputStream.Ack`: 5540
  * sent 0.9Mb
* `ProxyOutputStream.EOF`: 30
  * sent 0.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 792
  * sent 2.2Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 56
  * sent 0.1Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 1143
  * sent 2.2Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$ListAll`: 29
  * sent 0.1Mb
* `Unexport`: 3533
  * sent 5.8Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 414
  * sent 5.0Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 58
  * sent 0.4Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 58
  * sent 0.3Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 29
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 58
  * sent 0.3Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 58
  * sent 0.3Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 58
  * sent 0.4Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 570
  * sent 1.6Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 95
  * sent 0.3Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 94
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 190
  * sent 0.6Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 190
  * sent 0.5Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 94
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 380
  * sent 0.9Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 208
  * sent 0.5Mb
* `UserRequest:hudson.FilePath$Chmod`: 444
  * sent 2.8Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 52
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$CopyTo`: 2268
  * sent 6.1Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 443
  * sent 1.4Mb
* `UserRequest:hudson.FilePath$Exists`: 1025
  * sent 2.8Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 1384
  * sent 4.2Mb
* `UserRequest:hudson.FilePath$LastModified`: 2356
  * sent 6.2Mb
* `UserRequest:hudson.FilePath$Length`: 58
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$ListGlob`: 87
  * sent 0.3Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 1076
  * sent 6.2Mb
* `UserRequest:hudson.FilePath$Read`: 257
  * sent 0.8Mb
* `UserRequest:hudson.FilePath$RenameTo`: 29
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Touch`: 30
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Write`: 414
  * sent 2.7Mb
* `UserRequest:hudson.FilePath$WritePipe`: 30
  * sent 0.1Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 414
  * sent 4.9Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 29
  * sent 0.1Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 104
  * sent 0.2Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 104
  * sent 0.2Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 104
  * sent 0.2Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 104
  * sent 0.2Mb
* `UserRequest:hudson.plugin.versioncolumn.JVMVersionMonitor$JavaVersion`: 104
  * sent 0.2Mb
* `UserRequest:hudson.plugin.versioncolumn.VersionMonitor$SlaveVersion`: 104
  * sent 0.2Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 1143
  * sent 2.1Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 95
  * sent 0.2Mb
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 163
  * sent 0.9Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 43
  * sent 0.2Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 5735
  * sent 14.9Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 414
  * sent 2.5Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 1179
  * sent 3.9Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 1593
  * sent 5.2Mb
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$1`: 58
  * sent 0.3Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$1`: 174
  * sent 1.2Mb
* `UserRequest:org.jenkinsci.plugins.pipeline.utility.steps.zip.ZipStepExecution$ZipItFileCallable`: 52
  * sent 0.2Mb
* `UserRequest:org.jvnet.hudson.plugins.platformlabeler.PlatformDetailsTask`: 1
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 5540
  * received 8.9Mb
* `Pipe.Flush`: 2157
  * received 0.4Mb
* `ProxyOutputStream.Ack`: 30
  * received 0.0Mb
* `ProxyOutputStream.EOF`: 2580
  * received 4.9Mb
* `ProxyOutputStream.Unexport`: 2279
  * received 3.0Mb
* `ProxyWriter.EOF`: 29
  * received 0.1Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 792
  * received 0.5Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 15
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 3
  * received 0.0Mb
* `Response`: 24903
  * received 107.2Mb
* `Unexport`: 62233
  * received 93.4Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 56
  * received 0.4Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 1143
  * received 2.1Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 1
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$ListAll`: 29
  * received 0.1Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 414
  * waited 0.8 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 58
  * waited 0.59 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 58
  * waited 0.46 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 29
  * waited 0.42 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 58
  * waited 0.11 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 58
  * waited 0.84 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 58
  * waited 2.3 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 95
  * waited 0.11 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 1
  * waited 0.27 sec
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 570
  * waited 6.4 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 95
  * waited 4.2 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 95
  * waited 0.46 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 95
  * waited 0.26 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 95
  * waited 0.16 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 95
  * waited 0.47 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 95
  * waited 0.19 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 94
  * waited 0.45 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 190
  * waited 0.72 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 190
  * waited 0.44 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 94
  * waited 0.15 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 95
  * waited 4.5 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 380
  * waited 0.54 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 1
  * waited 23 ms
* `UserRequest:hudson.FilePath$2`: 3
  * waited 37 ms
* `UserRequest:hudson.FilePath$CallableWith`: 208
  * waited 1.1 sec
* `UserRequest:hudson.FilePath$Chmod`: 444
  * waited 0.63 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 52
  * waited 0.32 sec
* `UserRequest:hudson.FilePath$CopyTo`: 2268
  * waited 3.7 sec
* `UserRequest:hudson.FilePath$DeleteRecursive`: 443
  * waited 0.89 sec
* `UserRequest:hudson.FilePath$Exists`: 1025
  * waited 1.2 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 1384
  * waited 2.4 sec
* `UserRequest:hudson.FilePath$LastModified`: 2356
  * waited 4 sec
* `UserRequest:hudson.FilePath$Length`: 58
  * waited 65 ms
* `UserRequest:hudson.FilePath$ListGlob`: 87
  * waited 0.44 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 1076
  * waited 1.9 sec
* `UserRequest:hudson.FilePath$Read`: 257
  * waited 0.45 sec
* `UserRequest:hudson.FilePath$RenameTo`: 29
  * waited 43 ms
* `UserRequest:hudson.FilePath$Touch`: 30
  * waited 0.11 sec
* `UserRequest:hudson.FilePath$Write`: 414
  * waited 1.5 sec
* `UserRequest:hudson.FilePath$WritePipe`: 30
  * waited 42 ms
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 414
  * waited 2.9 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 29
  * waited 20 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 104
  * waited 0.39 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 104
  * waited 0.23 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 104
  * waited 0.33 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 104
  * waited 0.6 sec
* `UserRequest:hudson.plugin.versioncolumn.JVMVersionMonitor$JavaVersion`: 104
  * waited 0.41 sec
* `UserRequest:hudson.plugin.versioncolumn.VersionMonitor$SlaveVersion`: 104
  * waited 0.3 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 1143
  * waited 2.1 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 1
  * waited 21 ms
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 95
  * waited 0.55 sec
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 163
  * waited 0.23 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 43
  * waited 0.4 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 1
  * waited 0.17 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 1
  * waited 85 ms
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 5735
  * waited 40 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 1
  * waited 18 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 1
  * waited 0.19 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 1
  * waited 20 ms
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 1
  * waited 11 ms
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 414
  * waited 0.58 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 1179
  * waited 1.4 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 1593
  * waited 2 sec
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 1
  * waited 42 ms
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 1
  * waited 6 ms
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$1`: 58
  * waited 3.1 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$1`: 174
  * waited 30 sec
* `UserRequest:org.jenkinsci.plugins.pipeline.utility.steps.zip.ZipStepExecution$ZipItFileCallable`: 52
  * waited 0.76 sec
* `UserRequest:org.jvnet.hudson.plugins.platformlabeler.PlatformDetailsTask`: 1
  * waited 37 ms

# JARs sent
* `jna-4.2.1.jar`: 1137285b
* `libpam4j-1.8.jar`: 19925b
* `launchd-slave-installer-1.2.jar`: 22663b
* `support-core.jar`: 284176b
* `systemd-slave-installer-1.1.jar`: 11541b
* `slave-installer-1.6.jar`: 27374b
* `upstart-slave-installer-1.1.jar`: 10798b
* `commons-io-2.4.jar`: 185140b
* `commons-compress-1.10.jar`: 409475b
* `ant-1.9.2.jar`: 2000557b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `envinject.jar`: 153357b
* `envinject-lib-1.29.jar`: 20599b
* `platformlabeler.jar`: 10838b
* `monitoring.jar`: 41563b
* `itext-2.1.7.jar`: 1130070b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `versioncolumn.jar`: 24498b
* `commons-lang-2.6.jar`: 284220b
* `git-client.jar`: 212094b
* `org.eclipse.jgit-4.5.4.201711221230-r.jar`: 2384093b
* `xpp3-1.1.4c.jar`: 120069b
* `icon-set-1.0.5.jar`: 17567b
* `jcl-over-slf4j-1.7.25.jar`: 16515b
* `slf4j-jdk14-1.7.25.jar`: 8460b
* `git.jar`: 638384b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `task-reactor-1.5.jar`: 22114b
* `commons-jelly-1.1-jenkins-20120928.jar`: 170642b
* `antlr-2.7.6.jar`: 443432b
* `stapler-jelly-1.254.jar`: 87292b
* `durable-task.jar`: 48525b
* `pipeline-utility-steps.jar`: 458150b
* `workflow-step-api.jar`: 75707b
* `junit.jar`: 441990b
* `dom4j-1.6.1-jenkins-4.jar`: 254359b
* `commons-codec-1.9.jar`: 263965b

# Totals
* Writes: 61496
  * sent 188.6Mb
* Reads: 177063
  * received 343.1Mb
* Responses: 43328
  * waited 10 min

# Commands sent
* `GC`: 3
  * sent 0.0Mb
* `Pipe.Chunk`: 172
  * sent 0.6Mb
* `ProxyOutputStream.Ack`: 8015
  * sent 1.2Mb
* `ProxyOutputStream.EOF`: 114
  * sent 0.2Mb
* `ProxyWriter.Ack`: 2
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 3181
  * sent 8.6Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 57
  * sent 0.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 12
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 223
  * sent 0.4Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 1144
  * sent 2.2Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 4
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$ListAll`: 36
  * sent 0.1Mb
* `Unexport`: 5200
  * sent 8.9Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 984
  * sent 11.9Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 111
  * sent 0.7Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 111
  * sent 0.6Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 32
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 113
  * sent 0.7Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 111
  * sent 0.7Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 111
  * sent 0.7Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 4
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 570
  * sent 1.6Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 95
  * sent 0.3Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 94
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 190
  * sent 0.6Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 190
  * sent 0.5Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 94
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 380
  * sent 0.9Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 12
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 1
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 206
  * sent 0.5Mb
* `UserRequest:hudson.FilePath$Chmod`: 1098
  * sent 6.7Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 134
  * sent 0.5Mb
* `UserRequest:hudson.FilePath$CopyTo`: 2268
  * sent 6.1Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 1007
  * sent 3.2Mb
* `UserRequest:hudson.FilePath$Exists`: 1267
  * sent 3.6Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 5143
  * sent 15.6Mb
* `UserRequest:hudson.FilePath$LastModified`: 2653
  * sent 7.2Mb
* `UserRequest:hudson.FilePath$Length`: 208
  * sent 0.7Mb
* `UserRequest:hudson.FilePath$ListGlob`: 90
  * sent 0.3Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 2535
  * sent 14.7Mb
* `UserRequest:hudson.FilePath$Read`: 531
  * sent 1.7Mb
* `UserRequest:hudson.FilePath$RenameTo`: 27
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Touch`: 114
  * sent 0.4Mb
* `UserRequest:hudson.FilePath$Write`: 984
  * sent 6.5Mb
* `UserRequest:hudson.FilePath$WritePipe`: 114
  * sent 0.4Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 984
  * sent 11.8Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 71
  * sent 0.2Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 103
  * sent 0.2Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 103
  * sent 0.2Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 103
  * sent 0.2Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 103
  * sent 0.2Mb
* `UserRequest:hudson.plugin.versioncolumn.JVMVersionMonitor$JavaVersion`: 103
  * sent 0.2Mb
* `UserRequest:hudson.plugin.versioncolumn.VersionMonitor$SlaveVersion`: 103
  * sent 0.2Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 1144
  * sent 2.1Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 4
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 95
  * sent 0.2Mb
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 462
  * sent 2.7Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 52
  * sent 0.2Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 4
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 4
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 5723
  * sent 14.8Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 4
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 4
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 4
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 4
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 984
  * sent 5.9Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 4695
  * sent 15.5Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 5674
  * sent 18.7Mb
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 4
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 4
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$1`: 113
  * sent 0.6Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$1`: 297
  * sent 2.0Mb
* `UserRequest:org.jenkinsci.plugins.pipeline.utility.steps.zip.ZipStepExecution$ZipItFileCallable`: 134
  * sent 0.4Mb
* `UserRequest:org.jvnet.hudson.plugins.platformlabeler.PlatformDetailsTask`: 4
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 8015
  * received 14.9Mb
* `Pipe.Flush`: 3900
  * received 0.7Mb
* `ProxyOutputStream.Ack`: 172
  * received 0.0Mb
* `ProxyOutputStream.EOF`: 2934
  * received 5.6Mb
* `ProxyOutputStream.Unexport`: 7509
  * received 9.8Mb
* `ProxyWriter.Chunk`: 2
  * received 0.0Mb
* `ProxyWriter.EOF`: 34
  * received 0.1Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 3181
  * received 1.9Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 57
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 12
  * received 0.0Mb
* `Response`: 43328
  * received 146.4Mb
* `Unexport`: 106512
  * received 159.9Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 223
  * received 1.6Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 1144
  * received 2.1Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 4
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$ListAll`: 36
  * received 0.1Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 984
  * waited 2.6 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 111
  * waited 6.5 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 111
  * waited 2 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 32
  * waited 0.23 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 113
  * waited 0.32 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 111
  * waited 0.97 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 111
  * waited 23 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 95
  * waited 0.15 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 4
  * waited 3 sec
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 570
  * waited 22 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 95
  * waited 2.5 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 95
  * waited 0.68 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 95
  * waited 0.33 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 95
  * waited 0.22 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 95
  * waited 0.65 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 95
  * waited 0.29 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 94
  * waited 0.89 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 190
  * waited 1.7 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 190
  * waited 0.84 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 94
  * waited 0.22 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 95
  * waited 13 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 380
  * waited 0.85 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 12
  * waited 0.85 sec
* `UserRequest:hudson.FilePath$2`: 1
  * waited 17 ms
* `UserRequest:hudson.FilePath$CallableWith`: 206
  * waited 3.1 sec
* `UserRequest:hudson.FilePath$Chmod`: 1098
  * waited 1.9 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 134
  * waited 1 sec
* `UserRequest:hudson.FilePath$CopyTo`: 2268
  * waited 4.9 sec
* `UserRequest:hudson.FilePath$DeleteRecursive`: 1007
  * waited 1.9 sec
* `UserRequest:hudson.FilePath$Exists`: 1267
  * waited 1.6 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 5142
  * waited 9.7 sec
* `UserRequest:hudson.FilePath$LastModified`: 2653
  * waited 4.1 sec
* `UserRequest:hudson.FilePath$Length`: 208
  * waited 0.28 sec
* `UserRequest:hudson.FilePath$ListGlob`: 90
  * waited 1 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 2535
  * waited 6.5 sec
* `UserRequest:hudson.FilePath$Read`: 531
  * waited 0.91 sec
* `UserRequest:hudson.FilePath$RenameTo`: 27
  * waited 41 ms
* `UserRequest:hudson.FilePath$Touch`: 114
  * waited 0.46 sec
* `UserRequest:hudson.FilePath$Write`: 984
  * waited 4.9 sec
* `UserRequest:hudson.FilePath$WritePipe`: 114
  * waited 0.25 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 984
  * waited 3.8 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 67
  * waited 3 min 26 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 103
  * waited 1.3 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 103
  * waited 0.35 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 103
  * waited 1.5 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 103
  * waited 1.8 sec
* `UserRequest:hudson.plugin.versioncolumn.JVMVersionMonitor$JavaVersion`: 103
  * waited 1.6 sec
* `UserRequest:hudson.plugin.versioncolumn.VersionMonitor$SlaveVersion`: 103
  * waited 1.5 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 1144
  * waited 2.9 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 4
  * waited 0.16 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 95
  * waited 7.3 sec
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 462
  * waited 0.93 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 52
  * waited 1 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 4
  * waited 1.4 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 4
  * waited 0.99 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 5723
  * waited 2 min 31 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 4
  * waited 95 ms
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 4
  * waited 2.3 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 4
  * waited 0.24 sec
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 4
  * waited 0.12 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 984
  * waited 1.5 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 4695
  * waited 7.2 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 5674
  * waited 7.6 sec
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 4
  * waited 0.6 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 4
  * waited 70 ms
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$1`: 113
  * waited 23 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$1`: 297
  * waited 50 sec
* `UserRequest:org.jenkinsci.plugins.pipeline.utility.steps.zip.ZipStepExecution$ZipItFileCallable`: 134
  * waited 2.7 sec
* `UserRequest:org.jvnet.hudson.plugins.platformlabeler.PlatformDetailsTask`: 4
  * waited 0.31 sec

# JARs sent
* `jna-4.2.1.jar`: 1137285b
* `libpam4j-1.8.jar`: 19925b
* `launchd-slave-installer-1.2.jar`: 22663b
* `support-core.jar`: 284176b
* `systemd-slave-installer-1.1.jar`: 11541b
* `slave-installer-1.6.jar`: 27374b
* `upstart-slave-installer-1.1.jar`: 10798b
* `commons-io-2.4.jar`: 185140b
* `commons-compress-1.10.jar`: 409475b
* `ant-1.9.2.jar`: 2000557b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `envinject.jar`: 153357b
* `envinject-lib-1.29.jar`: 20599b
* `platformlabeler.jar`: 10838b
* `monitoring.jar`: 41563b
* `itext-2.1.7.jar`: 1130070b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `versioncolumn.jar`: 24498b
* `commons-lang-2.6.jar`: 284220b
* `git-client.jar`: 212094b
* `org.eclipse.jgit-4.5.4.201711221230-r.jar`: 2384093b
* `xpp3-1.1.4c.jar`: 120069b
* `icon-set-1.0.5.jar`: 17567b
* `jcl-over-slf4j-1.7.25.jar`: 16515b
* `slf4j-jdk14-1.7.25.jar`: 8460b
* `git.jar`: 638384b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `task-reactor-1.5.jar`: 22114b
* `commons-jelly-1.1-jenkins-20120928.jar`: 170642b
* `antlr-2.7.6.jar`: 443432b
* `stapler-jelly-1.254.jar`: 87292b
* `durable-task.jar`: 48525b
* `pipeline-utility-steps.jar`: 458150b
* `workflow-step-api.jar`: 75707b
* `junit.jar`: 441990b
* `dom4j-1.6.1-jenkins-4.jar`: 254359b
* `commons-codec-1.9.jar`: 263965b

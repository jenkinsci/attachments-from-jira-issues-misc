-----------
 * Name veth6e18b2b
 ** Hardware Address - a6a027505f76
 ** Index - 1373
 ** InetAddress - /fe80:0:0:0:a4a0:27ff:fe50:5f76%veth6e18b2b
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vethfd38a61
 ** Hardware Address - ce34083bbc4f
 ** Index - 1280
 ** InetAddress - /fe80:0:0:0:cc34:8ff:fe3b:bc4f%vethfd38a61
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vethc255b7d
 ** Hardware Address - 8691c9bc7c36
 ** Index - 1283
 ** InetAddress - /fe80:0:0:0:8491:c9ff:febc:7c36%vethc255b7d
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name vethca86cef
 ** Hardware Address - 96e2f8a2227e
 ** Index - 1298
 ** InetAddress - /fe80:0:0:0:94e2:f8ff:fea2:227e%vethca86cef
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name veth8c6c25b
 ** Hardware Address - 96599659bd9d
 ** Index - 1277
 ** InetAddress - /fe80:0:0:0:9459:96ff:fe59:bd9d%veth8c6c25b
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name docker0
 ** Hardware Address - 8691c9bc7c36
 ** Index - 3
 ** InetAddress - /fe80:0:0:0:8464:b8ff:fee0:34e6%docker0
 ** InetAddress - /172.17.42.1
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name eth0
 ** Hardware Address - 0050562b552a
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:250:56ff:fe2b:552a%eth0
 ** InetAddress - /192.168.85.42
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

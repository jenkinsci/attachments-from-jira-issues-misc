-----------
 * Name eth0
 ** Hardware Address - 0050562b5527
 ** Index - 2
 ** InetAddress - /fe80:0:0:0:250:56ff:fe2b:5527%eth0
 ** InetAddress - /192.168.85.39
 ** MTU - 1500
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - false
 ** Is Point to Point - false
 ** Supports multicast - true
-----------
 * Name lo
 ** Index - 1
 ** InetAddress - /0:0:0:0:0:0:0:1%lo
 ** InetAddress - /127.0.0.1
 ** MTU - 65536
 ** Is Up - true
 ** Is Virtual - false
 ** Is Loopback - true
 ** Is Point to Point - false
 ** Supports multicast - false

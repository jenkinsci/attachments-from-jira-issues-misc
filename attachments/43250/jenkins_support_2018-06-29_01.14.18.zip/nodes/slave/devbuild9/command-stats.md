# Totals
* Writes: 72711
  * sent 231.9Mb
* Reads: 212524
  * received 385.8Mb
* Responses: 51391
  * waited 5 min 51 sec

# Commands sent
* `GC`: 3
  * sent 0.0Mb
* `Pipe.Chunk`: 271
  * sent 0.9Mb
* `ProxyOutputStream.Ack`: 9690
  * sent 1.5Mb
* `ProxyOutputStream.EOF`: 184
  * sent 0.4Mb
* `ProxyWriter.Ack`: 4
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 3372
  * sent 9.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 59
  * sent 0.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 13
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 250
  * sent 0.5Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 1143
  * sent 2.2Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 5
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$ListAll`: 89
  * sent 0.2Mb
* `Unexport`: 6233
  * sent 10.9Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 1354
  * sent 16.3Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 155
  * sent 1.0Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 155
  * sent 0.9Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 52
  * sent 0.3Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 159
  * sent 0.9Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 155
  * sent 0.9Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 155
  * sent 1.0Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 5
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 570
  * sent 1.6Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 95
  * sent 0.3Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 94
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 190
  * sent 0.6Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 190
  * sent 0.5Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 94
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 380
  * sent 0.9Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 5
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 3
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 210
  * sent 0.5Mb
* `UserRequest:hudson.FilePath$Chmod`: 1538
  * sent 9.3Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 171
  * sent 0.6Mb
* `UserRequest:hudson.FilePath$CopyTo`: 2268
  * sent 6.1Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 1396
  * sent 4.4Mb
* `UserRequest:hudson.FilePath$Exists`: 1534
  * sent 4.4Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 6117
  * sent 18.6Mb
* `UserRequest:hudson.FilePath$LastModified`: 2778
  * sent 7.6Mb
* `UserRequest:hudson.FilePath$Length`: 300
  * sent 1.0Mb
* `UserRequest:hudson.FilePath$ListGlob`: 153
  * sent 0.5Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 3604
  * sent 20.6Mb
* `UserRequest:hudson.FilePath$Read`: 740
  * sent 2.4Mb
* `UserRequest:hudson.FilePath$RenameTo`: 46
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$Touch`: 184
  * sent 0.6Mb
* `UserRequest:hudson.FilePath$Write`: 1354
  * sent 8.9Mb
* `UserRequest:hudson.FilePath$WritePipe`: 184
  * sent 0.6Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 1354
  * sent 16.2Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 95
  * sent 0.3Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 105
  * sent 0.2Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 105
  * sent 0.2Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 105
  * sent 0.3Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 105
  * sent 0.2Mb
* `UserRequest:hudson.plugin.versioncolumn.JVMVersionMonitor$JavaVersion`: 105
  * sent 0.2Mb
* `UserRequest:hudson.plugin.versioncolumn.VersionMonitor$SlaveVersion`: 105
  * sent 0.2Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 1143
  * sent 2.1Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 5
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 95
  * sent 0.2Mb
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 626
  * sent 3.6Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 95
  * sent 0.3Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 5
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 5
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 5723
  * sent 14.8Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 5
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 5
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 5
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 5
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 1354
  * sent 8.1Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 5537
  * sent 18.3Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 6885
  * sent 22.7Mb
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 5
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 5
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$1`: 159
  * sent 0.8Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$1`: 425
  * sent 2.9Mb
* `UserRequest:org.jenkinsci.plugins.pipeline.utility.steps.zip.ZipStepExecution$ZipItFileCallable`: 171
  * sent 0.6Mb
* `UserRequest:org.jvnet.hudson.plugins.platformlabeler.PlatformDetailsTask`: 5
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 9690
  * received 15.5Mb
* `Pipe.Flush`: 5451
  * received 0.9Mb
* `ProxyOutputStream.Ack`: 271
  * received 0.0Mb
* `ProxyOutputStream.EOF`: 3182
  * received 6.1Mb
* `ProxyOutputStream.Unexport`: 9187
  * received 12.0Mb
* `ProxyWriter.Chunk`: 4
  * received 0.0Mb
* `ProxyWriter.EOF`: 56
  * received 0.1Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 3372
  * received 2.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 59
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 13
  * received 0.0Mb
* `Response`: 51391
  * received 152.3Mb
* `Unexport`: 128361
  * received 192.7Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 250
  * received 1.8Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 1143
  * received 2.1Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 5
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$ListAll`: 89
  * received 0.2Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 1354
  * waited 2.9 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 155
  * waited 2.8 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 155
  * waited 2.6 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 52
  * waited 0.85 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 159
  * waited 0.32 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 155
  * waited 3.2 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 155
  * waited 9.8 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 95
  * waited 0.11 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 5
  * waited 4.1 sec
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 570
  * waited 7.6 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 95
  * waited 4.2 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 95
  * waited 0.67 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 95
  * waited 0.32 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 95
  * waited 0.17 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 95
  * waited 0.59 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 95
  * waited 0.22 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 94
  * waited 0.59 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 190
  * waited 0.96 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 190
  * waited 0.55 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 94
  * waited 0.18 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 95
  * waited 5 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 380
  * waited 0.55 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 5
  * waited 0.72 sec
* `UserRequest:hudson.FilePath$2`: 3
  * waited 16 ms
* `UserRequest:hudson.FilePath$CallableWith`: 210
  * waited 4.3 sec
* `UserRequest:hudson.FilePath$Chmod`: 1538
  * waited 2.5 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 171
  * waited 1.1 sec
* `UserRequest:hudson.FilePath$CopyTo`: 2268
  * waited 3.6 sec
* `UserRequest:hudson.FilePath$DeleteRecursive`: 1396
  * waited 2.4 sec
* `UserRequest:hudson.FilePath$Exists`: 1534
  * waited 2 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 6117
  * waited 12 sec
* `UserRequest:hudson.FilePath$LastModified`: 2778
  * waited 3.2 sec
* `UserRequest:hudson.FilePath$Length`: 300
  * waited 0.38 sec
* `UserRequest:hudson.FilePath$ListGlob`: 153
  * waited 1.4 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 3604
  * waited 8.5 sec
* `UserRequest:hudson.FilePath$Read`: 740
  * waited 1.5 sec
* `UserRequest:hudson.FilePath$RenameTo`: 46
  * waited 72 ms
* `UserRequest:hudson.FilePath$Touch`: 184
  * waited 0.74 sec
* `UserRequest:hudson.FilePath$Write`: 1354
  * waited 6 sec
* `UserRequest:hudson.FilePath$WritePipe`: 184
  * waited 0.25 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 1354
  * waited 11 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 91
  * waited 1 min 0 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 105
  * waited 2.4 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 105
  * waited 1.3 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 105
  * waited 2.7 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 105
  * waited 2.7 sec
* `UserRequest:hudson.plugin.versioncolumn.JVMVersionMonitor$JavaVersion`: 105
  * waited 2.2 sec
* `UserRequest:hudson.plugin.versioncolumn.VersionMonitor$SlaveVersion`: 105
  * waited 2 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 1143
  * waited 3.3 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 5
  * waited 0.24 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 95
  * waited 1.1 sec
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 626
  * waited 1.2 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 95
  * waited 1.2 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 5
  * waited 2.2 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 5
  * waited 1.7 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 5723
  * waited 42 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 5
  * waited 0.18 sec
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 5
  * waited 3 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 5
  * waited 0.38 sec
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 5
  * waited 0.3 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 1354
  * waited 2.5 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 5537
  * waited 8.2 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 6885
  * waited 9.7 sec
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 5
  * waited 0.65 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 5
  * waited 60 ms
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$1`: 159
  * waited 9.2 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$1`: 425
  * waited 1 min 13 sec
* `UserRequest:org.jenkinsci.plugins.pipeline.utility.steps.zip.ZipStepExecution$ZipItFileCallable`: 171
  * waited 2.6 sec
* `UserRequest:org.jvnet.hudson.plugins.platformlabeler.PlatformDetailsTask`: 5
  * waited 0.73 sec

# JARs sent
* `jna-4.2.1.jar`: 1137285b
* `libpam4j-1.8.jar`: 19925b
* `launchd-slave-installer-1.2.jar`: 22663b
* `support-core.jar`: 284176b
* `systemd-slave-installer-1.1.jar`: 11541b
* `slave-installer-1.6.jar`: 27374b
* `upstart-slave-installer-1.1.jar`: 10798b
* `commons-io-2.4.jar`: 185140b
* `commons-compress-1.10.jar`: 409475b
* `ant-1.9.2.jar`: 2000557b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `envinject.jar`: 153357b
* `envinject-lib-1.29.jar`: 20599b
* `platformlabeler.jar`: 10838b
* `monitoring.jar`: 41563b
* `itext-2.1.7.jar`: 1130070b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `versioncolumn.jar`: 24498b
* `commons-lang-2.6.jar`: 284220b
* `git-client.jar`: 212094b
* `org.eclipse.jgit-4.5.4.201711221230-r.jar`: 2384093b
* `xpp3-1.1.4c.jar`: 120069b
* `icon-set-1.0.5.jar`: 17567b
* `jcl-over-slf4j-1.7.25.jar`: 16515b
* `slf4j-jdk14-1.7.25.jar`: 8460b
* `git.jar`: 638384b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `task-reactor-1.5.jar`: 22114b
* `commons-jelly-1.1-jenkins-20120928.jar`: 170642b
* `antlr-2.7.6.jar`: 443432b
* `stapler-jelly-1.254.jar`: 87292b
* `durable-task.jar`: 48525b
* `pipeline-utility-steps.jar`: 458150b
* `workflow-step-api.jar`: 75707b
* `junit.jar`: 441990b
* `dom4j-1.6.1-jenkins-4.jar`: 254359b
* `commons-codec-1.9.jar`: 263965b
* `ezmorph-1.0.6.jar`: 86487b

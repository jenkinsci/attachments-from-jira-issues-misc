# Totals
* Writes: 44164
  * sent 123.8Mb
* Reads: 122299
  * received 253.6Mb
* Responses: 29236
  * waited 6 min 32 sec

# Commands sent
* `GC`: 2
  * sent 0.0Mb
* `Pipe.Chunk`: 113
  * sent 0.4Mb
* `ProxyOutputStream.Ack`: 6009
  * sent 0.9Mb
* `ProxyOutputStream.EOF`: 78
  * sent 0.2Mb
* `Request.Cancel`: 1
  * sent 0.0Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 3103
  * sent 8.4Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 57
  * sent 0.1Mb
* `Response:RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 12
  * sent 0.0Mb
* `Response:UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 223
  * sent 0.4Mb
* `Response:UserRequest:hudson.remoting.PingThread$Ping`: 1144
  * sent 2.2Mb
* `Response:UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 4
  * sent 0.0Mb
* `Response:UserRequest:hudson.util.ProcessTree$ListAll`: 46
  * sent 0.1Mb
* `Unexport`: 4133
  * sent 6.8Mb
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 533
  * sent 6.4Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 80
  * sent 0.5Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 80
  * sent 0.5Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 30
  * sent 0.2Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 80
  * sent 0.5Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 80
  * sent 0.5Mb
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 80
  * sent 0.5Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 96
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 4
  * sent 0.0Mb
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 576
  * sent 1.6Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 96
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 96
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 96
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 96
  * sent 0.3Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 96
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 96
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 191
  * sent 0.6Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 192
  * sent 0.5Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 95
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 96
  * sent 0.2Mb
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 384
  * sent 1.0Mb
* `UserRequest:hudson.EnvVars$GetEnvVars`: 7
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$2`: 2
  * sent 0.0Mb
* `UserRequest:hudson.FilePath$CallableWith`: 214
  * sent 0.5Mb
* `UserRequest:hudson.FilePath$Chmod`: 611
  * sent 3.7Mb
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 59
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$CopyTo`: 2292
  * sent 6.2Mb
* `UserRequest:hudson.FilePath$DeleteRecursive`: 553
  * sent 1.7Mb
* `UserRequest:hudson.FilePath$Exists`: 1001
  * sent 2.8Mb
* `UserRequest:hudson.FilePath$IsDirectory`: 2218
  * sent 6.7Mb
* `UserRequest:hudson.FilePath$LastModified`: 2546
  * sent 6.8Mb
* `UserRequest:hudson.FilePath$Length`: 132
  * sent 0.4Mb
* `UserRequest:hudson.FilePath$ListGlob`: 75
  * sent 0.2Mb
* `UserRequest:hudson.FilePath$Mkdirs`: 1465
  * sent 8.3Mb
* `UserRequest:hudson.FilePath$Read`: 294
  * sent 1.0Mb
* `UserRequest:hudson.FilePath$RenameTo`: 23
  * sent 0.1Mb
* `UserRequest:hudson.FilePath$Touch`: 78
  * sent 0.3Mb
* `UserRequest:hudson.FilePath$Write`: 533
  * sent 3.5Mb
* `UserRequest:hudson.FilePath$WritePipe`: 78
  * sent 0.3Mb
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 533
  * sent 6.4Mb
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 51
  * sent 0.1Mb
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 107
  * sent 0.2Mb
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 107
  * sent 0.2Mb
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 107
  * sent 0.3Mb
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 107
  * sent 0.2Mb
* `UserRequest:hudson.plugin.versioncolumn.JVMVersionMonitor$JavaVersion`: 107
  * sent 0.2Mb
* `UserRequest:hudson.plugin.versioncolumn.VersionMonitor$SlaveVersion`: 107
  * sent 0.2Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 1144
  * sent 2.1Mb
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 4
  * sent 0.0Mb
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 96
  * sent 0.2Mb
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 245
  * sent 1.4Mb
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 39
  * sent 0.1Mb
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 4
  * sent 0.0Mb
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 4
  * sent 0.0Mb
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 5729
  * sent 14.8Mb
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 4
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 4
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 4
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 4
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 533
  * sent 3.2Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 1924
  * sent 6.3Mb
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 2454
  * sent 8.1Mb
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 4
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 4
  * sent 0.0Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$1`: 80
  * sent 0.4Mb
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$1`: 221
  * sent 1.5Mb
* `UserRequest:org.jenkinsci.plugins.pipeline.utility.steps.zip.ZipStepExecution$ZipItFileCallable`: 59
  * sent 0.2Mb
* `UserRequest:org.jvnet.hudson.plugins.platformlabeler.PlatformDetailsTask`: 4
  * sent 0.0Mb

# Commands received
* `Pipe.Chunk`: 6009
  * received 9.7Mb
* `Pipe.Flush`: 2745
  * received 0.5Mb
* `ProxyOutputStream.Ack`: 113
  * received 0.0Mb
* `ProxyOutputStream.EOF`: 2647
  * received 5.0Mb
* `ProxyOutputStream.Unexport`: 3243
  * received 4.2Mb
* `ProxyWriter.EOF`: 30
  * received 0.1Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.fetch3[java.lang.String]`: 3103
  * received 1.8Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResource2[java.lang.String]`: 57
  * received 0.0Mb
* `RPCRequest:hudson.remoting.RemoteClassLoader$IClassLoader.getResources2[java.lang.String]`: 12
  * received 0.0Mb
* `Request.Cancel`: 10
  * received 0.0Mb
* `Response`: 29236
  * received 117.8Mb
* `Unexport`: 73677
  * received 110.6Mb
* `UserRequest:UserRPCRequest:hudson.remoting.JarLoader.notifyJarPresence[long,long]`: 223
  * received 1.6Mb
* `UserRequest:hudson.remoting.PingThread$Ping`: 1144
  * received 2.1Mb
* `UserRequest:hudson.util.ProcessTree$DoVetoersExist`: 4
  * received 0.0Mb
* `UserRequest:hudson.util.ProcessTree$ListAll`: 46
  * received 0.1Mb

# Responses received
* `UserRequest:UserRPCRequest:hudson.Launcher$RemoteProcess.getIOtriplet[]`: 533
  * waited 1.4 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.addCredentials[java.lang.String,com.cloudbees.plugins.credentials.common.StandardCredentials]`: 80
  * waited 2.6 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.hasGitRepo[]`: 80
  * waited 1.5 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.isCommitInRepo[org.eclipse.jgit.lib.ObjectId]`: 30
  * waited 0.29 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setProxy[hudson.ProxyConfiguration]`: 80
  * waited 0.17 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.setRemoteUrl[java.lang.String,java.lang.String]`: 80
  * waited 0.84 sec
* `UserRequest:UserRPCRequest:org.jenkinsci.plugins.gitclient.GitClient.withRepository[org.jenkinsci.plugins.gitclient.RepositoryCallback]`: 80
  * waited 11 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogFetcher`: 96
  * waited 0.14 sec
* `UserRequest:com.cloudbees.jenkins.support.SupportPlugin$LogInitializer`: 4
  * waited 2.5 sec
* `UserRequest:com.cloudbees.jenkins.support.api.CommandOutputContent$CommandLauncher`: 576
  * waited 22 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetJavaInfo`: 96
  * waited 4.4 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveDigest`: 96
  * waited 1 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.AboutJenkins$GetSlaveVersion`: 96
  * waited 0.36 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.EnvironmentVariables$GetEnvironmentVariables`: 96
  * waited 0.2 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.FileDescriptorLimit$GetUlimit`: 96
  * waited 0.72 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.NetworkInterfaces$GetNetworkInterfaces`: 96
  * waited 0.23 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.RootCAs$GetRootCA`: 95
  * waited 0.55 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SmartLogFetcher$LogFileHashSlurper`: 191
  * waited 1.7 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemConfiguration$GetDmiInfo`: 192
  * waited 0.8 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.SystemProperties$GetSystemProperties`: 95
  * waited 0.2 sec
* `UserRequest:com.cloudbees.jenkins.support.impl.ThreadDumps$GetThreadDump`: 96
  * waited 2.3 sec
* `UserRequest:com.cloudbees.jenkins.support.util.SystemPlatform$GetCurrentPlatform`: 384
  * waited 0.62 sec
* `UserRequest:hudson.EnvVars$GetEnvVars`: 7
  * waited 0.76 sec
* `UserRequest:hudson.FilePath$2`: 2
  * waited 31 ms
* `UserRequest:hudson.FilePath$CallableWith`: 214
  * waited 1.5 sec
* `UserRequest:hudson.FilePath$Chmod`: 611
  * waited 1.1 sec
* `UserRequest:hudson.FilePath$CopyRecursiveRemoteToLocal`: 59
  * waited 0.75 sec
* `UserRequest:hudson.FilePath$CopyTo`: 2292
  * waited 4.6 sec
* `UserRequest:hudson.FilePath$DeleteRecursive`: 553
  * waited 1.3 sec
* `UserRequest:hudson.FilePath$Exists`: 1001
  * waited 1.5 sec
* `UserRequest:hudson.FilePath$IsDirectory`: 2218
  * waited 4.7 sec
* `UserRequest:hudson.FilePath$LastModified`: 2546
  * waited 3.6 sec
* `UserRequest:hudson.FilePath$Length`: 132
  * waited 0.19 sec
* `UserRequest:hudson.FilePath$ListGlob`: 75
  * waited 1.2 sec
* `UserRequest:hudson.FilePath$Mkdirs`: 1465
  * waited 3.6 sec
* `UserRequest:hudson.FilePath$Read`: 294
  * waited 0.63 sec
* `UserRequest:hudson.FilePath$RenameTo`: 23
  * waited 49 ms
* `UserRequest:hudson.FilePath$Touch`: 78
  * waited 0.5 sec
* `UserRequest:hudson.FilePath$Write`: 533
  * waited 3 sec
* `UserRequest:hudson.FilePath$WritePipe`: 78
  * waited 0.14 sec
* `UserRequest:hudson.Launcher$RemoteLaunchCallable`: 533
  * waited 3.2 sec
* `UserRequest:hudson.Launcher$RemoteLauncher$KillTask`: 48
  * waited 1.8 sec
* `UserRequest:hudson.model.Slave$GetClockDifference1`: 107
  * waited 0.66 sec
* `UserRequest:hudson.node_monitors.ArchitectureMonitor$GetArchTask`: 107
  * waited 0.26 sec
* `UserRequest:hudson.node_monitors.ResponseTimeMonitor$Step1`: 107
  * waited 0.73 sec
* `UserRequest:hudson.node_monitors.SwapSpaceMonitor$MonitorTask`: 107
  * waited 1 sec
* `UserRequest:hudson.plugin.versioncolumn.JVMVersionMonitor$JavaVersion`: 107
  * waited 0.86 sec
* `UserRequest:hudson.plugin.versioncolumn.VersionMonitor$SlaveVersion`: 107
  * waited 0.64 sec
* `UserRequest:hudson.remoting.PingThread$Ping`: 1144
  * waited 2 sec
* `UserRequest:hudson.slaves.ChannelPinger$SetUpRemotePing`: 4
  * waited 0.13 sec
* `UserRequest:hudson.slaves.SlaveComputer$SlaveLogFetcher`: 96
  * waited 0.21 sec
* `UserRequest:hudson.tasks.Shell$DescriptorImpl$Shellinterpreter`: 245
  * waited 0.8 sec
* `UserRequest:hudson.tasks.junit.JUnitParser$ParseResultCallable`: 39
  * waited 1.1 sec
* `UserRequest:jenkins.slaves.StandardOutputSwapper$ChannelSwapper`: 4
  * waited 1.2 sec
* `UserRequest:jenkins.slaves.restarter.JnlpSlaveRestarterInstaller$FindEffectiveRestarters`: 4
  * waited 0.8 sec
* `UserRequest:net.bull.javamelody.RemoteCallHelper$DelegatingTask`: 5729
  * waited 3 min 46 sec
* `UserRequest:org.jenkinsci.modules.launchd_slave_installer.SlaveInstallerFactoryImpl$Predicate`: 4
  * waited 0.1 sec
* `UserRequest:org.jenkinsci.modules.slave_installer.impl.InstallerGui`: 4
  * waited 1.9 sec
* `UserRequest:org.jenkinsci.modules.systemd_slave_installer.SlaveInstallerFactoryImpl$HasSystemd`: 4
  * waited 0.28 sec
* `UserRequest:org.jenkinsci.modules.upstart_slave_installer.SlaveInstallerFactoryImpl$HasUpstart`: 4
  * waited 0.1 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.BourneShellScript$getOsType`: 533
  * waited 1.1 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$StatusCheck`: 1924
  * waited 3.2 sec
* `UserRequest:org.jenkinsci.plugins.durabletask.FileMonitoringTask$FileMonitoringController$WriteLog`: 2454
  * waited 4.4 sec
* `UserRequest:org.jenkinsci.plugins.envinject.EnvInjectComputerListener$2`: 4
  * waited 0.36 sec
* `UserRequest:org.jenkinsci.plugins.envinject.service.EnvInjectMasterEnvVarsSetter`: 4
  * waited 50 ms
* `UserRequest:org.jenkinsci.plugins.gitclient.Git$1`: 80
  * waited 9.6 sec
* `UserRequest:org.jenkinsci.plugins.gitclient.RemoteGitImpl$CommandInvocationHandler$1`: 221
  * waited 40 sec
* `UserRequest:org.jenkinsci.plugins.pipeline.utility.steps.zip.ZipStepExecution$ZipItFileCallable`: 59
  * waited 1.8 sec
* `UserRequest:org.jvnet.hudson.plugins.platformlabeler.PlatformDetailsTask`: 4
  * waited 0.33 sec

# JARs sent
* `jna-4.2.1.jar`: 1137285b
* `libpam4j-1.8.jar`: 19925b
* `support-core.jar`: 284176b
* `launchd-slave-installer-1.2.jar`: 22663b
* `slave-installer-1.6.jar`: 27374b
* `systemd-slave-installer-1.1.jar`: 11541b
* `upstart-slave-installer-1.1.jar`: 10798b
* `commons-io-2.4.jar`: 185140b
* `commons-compress-1.10.jar`: 409475b
* `ant-1.9.2.jar`: 2000557b
* `commons-fileupload-1.3.1-jenkins-2.jar`: 68803b
* `envinject.jar`: 153357b
* `envinject-lib-1.29.jar`: 20599b
* `platformlabeler.jar`: 10838b
* `monitoring.jar`: 41563b
* `itext-2.1.7.jar`: 1130070b
* `spring-context-2.5.6.SEC03.jar`: 476894b
* `versioncolumn.jar`: 24498b
* `git-client.jar`: 212094b
* `org.eclipse.jgit-4.5.4.201711221230-r.jar`: 2384093b
* `xpp3-1.1.4c.jar`: 120069b
* `icon-set-1.0.5.jar`: 17567b
* `slf4j-jdk14-1.7.25.jar`: 8460b
* `git.jar`: 638384b
* `json-lib-2.4-jenkins-2.jar`: 141207b
* `durable-task.jar`: 48525b
* `pipeline-utility-steps.jar`: 458150b
* `workflow-step-api.jar`: 75707b
* `junit.jar`: 441990b
* `dom4j-1.6.1-jenkins-4.jar`: 254359b
* `commons-codec-1.9.jar`: 263965b
* `jcl-over-slf4j-1.7.25.jar`: 16515b
* `commons-lang-2.6.jar`: 284220b
* `task-reactor-1.5.jar`: 22114b
* `commons-jelly-1.1-jenkins-20120928.jar`: 170642b
* `antlr-2.7.6.jar`: 443432b
* `stapler-jelly-1.254.jar`: 87292b

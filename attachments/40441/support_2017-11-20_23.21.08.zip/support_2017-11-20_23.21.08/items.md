Item statistics
===============

  * `com.cloudbees.hudson.plugins.folder.Folder`
    - Number of items: 170
    - Number of items per container: 5.635294117647059 [n=170, s=40.0]
  * `hudson.model.FreeStyleProject`
    - Number of items: 1
    - Number of builds per job: 0 [n=1]
  * `org.jenkinsci.plugins.workflow.job.WorkflowJob`
    - Number of items: 2368
    - Number of builds per job: 3.896114864864865 [n=2368, s=3.50522841159777]
  * `org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject`
    - Number of items: 1012
    - Number of items per container: 2.0543478260869565 [n=1012, s=3.416086178218872]

Total job statistics
======================

  * Number of jobs: 2369
  * Number of builds per job: 3.8944702406078515 [n=2369, s=3.5054022955208084]

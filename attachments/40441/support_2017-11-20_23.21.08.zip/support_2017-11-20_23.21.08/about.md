Jenkins
=======

Version details
---------------

  * Version: `2.73.2`
  * Mode:    WAR
  * Url:     https://build.gauntlet.corp.adobe.com/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.8.0_31
      - Maximum memory:   7.11 GB (7635730432)
      - Allocated memory: 6.06 GB (6505365504)
      - Free memory:      3.09 GB (3321526320)
      - In-use memory:    2.97 GB (3183839184)
      - GC strategy:      ParallelGC
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 25.31-b07
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      3.10.0-229.el7.x86_64
  * Process ID: 3252 (0xcb4)
  * Process started: 2017-11-20 07:00:25.866+0000
  * Process uptime: 16 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.31-2.b13.el7.x86_64/jre/classes`
      - Classpath: `/usr/lib/jenkins/jenkins.war:/usr/local/bin/newrelic-java/newrelic.jar`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcom.sun.net.ssl.enableECC=false`
      - arg[1]: `-javaagent:/usr/local/bin/newrelic-java/newrelic.jar`
      - arg[2]: `-Dnewrelic.config.file=/etc/jenkins/newrelic.yml`
      - arg[3]: `-Xmx8192m`
      - arg[4]: `-Djava.io.tmpdir=/var/lib/jenkins/tmp`

Important configuration
---------------

  * Security realm: `org.jenkinsci.plugins.GithubSecurityRealm`
  * Authorization strategy: `hudson.security.ProjectMatrixAuthorizationStrategy`
  * CSRF Protection: false
  * Initialization Milestone: Completed initialization

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * analysis-collector:1.52 'Static Analysis Collector Plug-in'
  * analysis-core:1.92 'Static Analysis Utilities'
  * ansicolor:0.5.2 'AnsiColor'
  * ant:1.7 'Ant Plugin'
  * antisamy-markup-formatter:1.5 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.3-2.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * authentication-tokens:1.3 'Authentication Tokens API Plugin'
  * bast-code-signing-jenkins-plugin:5.1.0-SNAPSHOT (private-09/13/2017 06:44-jenkins) 'Bast Jenkins Plugin'
  * blueocean:1.3.1 *(update available)* 'Blue Ocean'
  * blueocean-autofavorite:1.0.0 *(update available)* 'Autofavorite for Blue Ocean'
  * blueocean-bitbucket-pipeline:1.3.1 *(update available)* 'Bitbucket Pipeline for Blue Ocean'
  * blueocean-commons:1.3.1 *(update available)* 'Common API for Blue Ocean'
  * blueocean-config:1.3.1 *(update available)* 'Config API for Blue Ocean'
  * blueocean-dashboard:1.3.1 *(update available)* 'Dashboard for Blue Ocean'
  * blueocean-display-url:2.1.1 'Display URL for Blue Ocean'
  * blueocean-events:1.3.1 *(update available)* 'Events API for Blue Ocean'
  * blueocean-git-pipeline:1.3.1 *(update available)* 'Git Pipeline for Blue Ocean'
  * blueocean-github-pipeline:1.3.1 *(update available)* 'GitHub Pipeline for Blue Ocean'
  * blueocean-i18n:1.3.1 *(update available)* 'i18n for Blue Ocean'
  * blueocean-jira:1.3.1 *(update available)* 'JIRA Integration for Blue Ocean'
  * blueocean-jwt:1.3.1 *(update available)* 'JWT for Blue Ocean'
  * blueocean-personalization:1.3.1 *(update available)* 'Personalization for Blue Ocean'
  * blueocean-pipeline-api-impl:1.3.1 *(update available)* 'Pipeline implementation for Blue Ocean'
  * blueocean-pipeline-editor:1.3.1 *(update available)* 'Blue Ocean Pipeline Editor'
  * blueocean-pipeline-scm-api:1.3.1 *(update available)* 'Pipeline SCM API for Blue Ocean'
  * blueocean-rest:1.3.1 *(update available)* 'REST API for Blue Ocean'
  * blueocean-rest-impl:1.3.1 *(update available)* 'REST Implementation for Blue Ocean'
  * blueocean-web:1.3.1 *(update available)* 'Web for Blue Ocean'
  * bouncycastle-api:2.16.2 'bouncycastle API Plugin'
  * branch-api:2.0.15 'Branch API Plugin'
  * build-timeout:1.19 'Build Timeout'
  * checkstyle:3.49 'Checkstyle Plug-in'
  * cloudbees-bitbucket-branch-source:2.2.5 *(update available)* 'Bitbucket Branch Source Plugin'
  * cloudbees-folder:6.1.2 *(update available)* 'Folders Plugin'
  * cobertura:1.11 *(update available)* 'Jenkins Cobertura Plugin'
  * config-file-provider:2.16.4 'Config File Provider Plugin'
  * credentials:2.1.16 'Credentials Plugin'
  * credentials-binding:1.13 'Credentials Binding Plugin'
  * cvs:2.13 'Jenkins CVS Plug-in'
  * disable-github-multibranch-status:1.1 'Disable GitHub Multibranch Status Plugin'
  * display-url-api:2.1.0 'Display URL API'
  * docker-commons:1.9 'Docker Commons Plugin'
  * docker-workflow:1.14 'Docker Pipeline'
  * durable-task:1.15 *(update available)* 'Durable Task Plugin'
  * email-ext:2.61 'Email Extension Plugin'
  * embeddable-build-status:1.9 'embeddable-build-status'
  * envinject:2.1.5 'Environment Injector Plugin'
  * envinject-api:1.4 'EnvInject API Plugin'
  * external-monitor-job:1.7 'External Monitor Job Type Plugin'
  * favorite:2.3.1 'Favorite'
  * findbugs:4.71 'FindBugs Plug-in'
  * gauntlet:1.4.0.228 'Gauntlet'
  * gauntlet-to-github:0.2.0.15 'Gauntlet to Github'
  * gauntlet-to-rebuild:1.0.2 'Gauntlet To Rebuild'
  * git:3.6.4 'Jenkins Git plugin'
  * git-client:2.6.0 'Jenkins Git client plugin'
  * git-server:1.7 'Jenkins GIT server Plugin'
  * github:1.28.1 'GitHub plugin'
  * github-api:1.86 *(update available)* 'GitHub API Plugin'
  * github-branch-source:2.2.6 *(update available)* 'GitHub Branch Source Plugin'
  * github-oauth:0.28.1 'GitHub Authentication plugin'
  * github-organization-folder:1.6 'GitHub Organization Folder Plugin'
  * github-pr-checks:1.2.0.22 'GitHub PR Checks'
  * github-pr-comment-build:2.0 'GitHub PR Comment Build Plugin'
  * handlebars:1.1.1 'JavaScript GUI Lib: Handlebars bundle plugin'
  * hashicorp-vault-plugin:2.1.0 'HashiCorp Vault Plugin'
  * htmlpublisher:1.14 'HTML Publisher plugin'
  * icon-shim:2.0.3 'Icon Shim Plugin'
  * jackson2-api:2.7.3 *(update available)* 'Jackson 2 API Plugin'
  * javadoc:1.4 'Javadoc Plugin'
  * jira:2.4.2 *(update available)* 'Jenkins JIRA plugin'
  * job-dsl:1.61 *(update available)* 'Job DSL'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jsch:0.1.54.1 'Jenkins JSch dependency plugin'
  * junit:1.21 *(update available)* 'JUnit Plugin'
  * ldap:1.17 *(update available)* 'LDAP Plugin'
  * load-script-pipeline:1.0-SNAPSHOT (private-14931bcc-saville) 'Load Script Pipeline Plugin'
  * lockable-resources:2.0 *(update available)* 'Lockable Resources plugin'
  * mailer:1.20 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-auth:1.7 *(update available)* 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.12 'Matrix Project Plugin'
  * maven-plugin:3.0 'Maven Integration plugin'
  * mercurial:2.2 'Jenkins Mercurial plugin'
  * metrics:3.1.2.10 'Metrics Plugin'
  * momentjs:1.1.1 'JavaScript GUI Lib: Moment.js bundle plugin'
  * next-build-number:1.5 'Next Build Number Plugin'
  * pam-auth:1.3 'PAM Authentication plugin'
  * perforce:1.3.36 'Perforce Plugin'
  * pipeline-build-step:2.5.1 'Pipeline: Build Step'
  * pipeline-github-lib:1.0 'Pipeline: GitHub Groovy Libraries'
  * pipeline-graph-analysis:1.5 'Pipeline Graph Analysis Plugin'
  * pipeline-input-step:2.8 'Pipeline: Input Step'
  * pipeline-milestone-step:1.3.1 'Pipeline: Milestone Step'
  * pipeline-model-api:1.2.3 *(update available)* 'Pipeline: Model API'
  * pipeline-model-declarative-agent:1.1.1 'Pipeline: Declarative Agent API'
  * pipeline-model-definition:1.2.3 *(update available)* 'Pipeline: Declarative'
  * pipeline-model-extensions:1.2.3 *(update available)* 'Pipeline: Declarative Extension Points API'
  * pipeline-rest-api:2.9 'Pipeline: REST API Plugin'
  * pipeline-stage-step:2.3 'Pipeline: Stage Step'
  * pipeline-stage-tags-metadata:1.2.3 *(update available)* 'Pipeline: Stage Tags Metadata'
  * pipeline-stage-view:2.9 'Pipeline: Stage View Plugin'
  * pipeline-utility-steps:1.5.1 'Pipeline Utility Steps'
  * plain-credentials:1.4 'Plain Credentials Plugin'
  * pubsub-light:1.12 'Jenkins Pub-Sub "light" Bus'
  * rebuild:1.27 'Rebuilder'
  * scm-api:2.2.5 'SCM API Plugin'
  * script-security:1.35 'Script Security Plugin'
  * simple-theme-plugin:0.3 'Simple Theme Plugin'
  * sse-gateway:1.15 'Server Sent Events (SSE) Gateway Plugin'
  * ssh-credentials:1.13 'SSH Credentials Plugin'
  * ssh-slaves:1.22 'Jenkins SSH Slaves plugin'
  * structs:1.10 'Structs Plugin'
  * subversion:2.9 'Jenkins Subversion Plug-in'
  * support-core:2.43 'Support Core Plugin'
  * timestamper:1.8.8 'Timestamper'
  * token-macro:2.3 'Token Macro Plugin'
  * translation:1.15 'Jenkins Translation Assistance plugin'
  * update-sites-manager:2.0.0 'UpdateSites Manager plugin'
  * variant:1.1 'Variant Plugin'
  * windows-slaves:1.3.1 'Windows Slaves Plugin'
  * workflow-aggregator:2.5 'Pipeline'
  * workflow-api:2.23.1 'Pipeline: API'
  * workflow-basic-steps:2.6 'Pipeline: Basic Steps'
  * workflow-cps:2.41 'Pipeline: Groovy'
  * workflow-cps-global-lib:2.9 'Pipeline: Shared Groovy Libraries'
  * workflow-durable-task-step:2.16 *(update available)* 'Pipeline: Nodes and Processes'
  * workflow-job:2.11.2 *(update available)* 'Pipeline: Job'
  * workflow-multibranch:2.16 'Pipeline: Multibranch'
  * workflow-scm-step:2.5 *(update available)* 'Pipeline: SCM Step'
  * workflow-step-api:2.13 'Pipeline: Step API'
  * workflow-support:2.14 *(update available)* 'Pipeline: Supporting APIs'

Support Bundle Manifest
=======================

Generated on 2017-11-20 23:21:08.704+0000

Requested components:

  * Garbage Collection Logs

  * About browser

      - `browser.md`

  * About Jenkins

      - `about.md`

      - `docker/Dockerfile`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `nodes/slave/server10.local/checksums.md5`

      - `nodes/slave/server11.local/checksums.md5`

      - `nodes/slave/server5.local/checksums.md5`

      - `nodes/slave/server6.local/checksums.md5`

      - `nodes/slave/server7.local/checksums.md5`

      - `nodes/slave/server8.local/checksums.md5`

      - `nodes/slave/server9.local/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`

  * About user (basic authentication details only)

      - `user.md`

  * Administrative monitors

      - `admin-monitors.md`

  * Build queue

      - `buildqueue.md`

  * Dump agent export tables (could reveal some memory leaks)

      - `nodes/slave/server10.local/exportTable.txt`

      - `nodes/slave/server11.local/exportTable.txt`

      - `nodes/slave/server5.local/exportTable.txt`

      - `nodes/slave/server6.local/exportTable.txt`

      - `nodes/slave/server7.local/exportTable.txt`

      - `nodes/slave/server8.local/exportTable.txt`

      - `nodes/slave/server9.local/exportTable.txt`

  * Environment variables

      - `nodes/master/environment.txt`

      - `nodes/slave/server10.local/environment.txt`

      - `nodes/slave/server11.local/environment.txt`

      - `nodes/slave/server5.local/environment.txt`

      - `nodes/slave/server6.local/environment.txt`

      - `nodes/slave/server7.local/environment.txt`

      - `nodes/slave/server8.local/environment.txt`

      - `nodes/slave/server9.local/environment.txt`

  * File descriptors (Unix only)

      - `nodes/master/file-descriptors.txt`

      - `nodes/slave/server10.local/file-descriptors.txt`

      - `nodes/slave/server11.local/file-descriptors.txt`

      - `nodes/slave/server5.local/file-descriptors.txt`

      - `nodes/slave/server6.local/file-descriptors.txt`

      - `nodes/slave/server7.local/file-descriptors.txt`

      - `nodes/slave/server8.local/file-descriptors.txt`

      - `nodes/slave/server9.local/file-descriptors.txt`

  * Master Heap Histogram

      - `nodes/master/heap-histogram.txt`

  * JVM process system metrics (Linux only)

      - `nodes/master/proc/meminfo.txt`

      - `nodes/master/proc/self/cmdline`

      - `nodes/master/proc/self/environ`

      - `nodes/master/proc/self/limits.txt`

      - `nodes/master/proc/self/mountstats.txt`

      - `nodes/master/proc/self/status.txt`

      - `nodes/slave/server10.local/proc/meminfo.txt`

      - `nodes/slave/server10.local/proc/self/cmdline`

      - `nodes/slave/server10.local/proc/self/environ`

      - `nodes/slave/server10.local/proc/self/limits.txt`

      - `nodes/slave/server10.local/proc/self/mountstats.txt`

      - `nodes/slave/server10.local/proc/self/status.txt`

      - `nodes/slave/server11.local/proc/meminfo.txt`

      - `nodes/slave/server11.local/proc/self/cmdline`

      - `nodes/slave/server11.local/proc/self/environ`

      - `nodes/slave/server11.local/proc/self/limits.txt`

      - `nodes/slave/server11.local/proc/self/mountstats.txt`

      - `nodes/slave/server11.local/proc/self/status.txt`

      - `nodes/slave/server5.local/proc/meminfo.txt`

      - `nodes/slave/server5.local/proc/self/cmdline`

      - `nodes/slave/server5.local/proc/self/environ`

      - `nodes/slave/server5.local/proc/self/limits.txt`

      - `nodes/slave/server5.local/proc/self/mountstats.txt`

      - `nodes/slave/server5.local/proc/self/status.txt`

      - `nodes/slave/server6.local/proc/meminfo.txt`

      - `nodes/slave/server6.local/proc/self/cmdline`

      - `nodes/slave/server6.local/proc/self/environ`

      - `nodes/slave/server6.local/proc/self/limits.txt`

      - `nodes/slave/server6.local/proc/self/mountstats.txt`

      - `nodes/slave/server6.local/proc/self/status.txt`

      - `nodes/slave/server7.local/proc/meminfo.txt`

      - `nodes/slave/server7.local/proc/self/cmdline`

      - `nodes/slave/server7.local/proc/self/environ`

      - `nodes/slave/server7.local/proc/self/limits.txt`

      - `nodes/slave/server7.local/proc/self/mountstats.txt`

      - `nodes/slave/server7.local/proc/self/status.txt`

      - `nodes/slave/server8.local/proc/meminfo.txt`

      - `nodes/slave/server8.local/proc/self/cmdline`

      - `nodes/slave/server8.local/proc/self/environ`

      - `nodes/slave/server8.local/proc/self/limits.txt`

      - `nodes/slave/server8.local/proc/self/mountstats.txt`

      - `nodes/slave/server8.local/proc/self/status.txt`

      - `nodes/slave/server9.local/proc/meminfo.txt`

      - `nodes/slave/server9.local/proc/self/cmdline`

      - `nodes/slave/server9.local/proc/self/environ`

      - `nodes/slave/server9.local/proc/self/limits.txt`

      - `nodes/slave/server9.local/proc/self/mountstats.txt`

      - `nodes/slave/server9.local/proc/self/status.txt`

  * Load Statistics

      - `load-stats/label/docker/gnuplot`

      - `load-stats/label/docker/hour.csv`

      - `load-stats/label/docker/min.csv`

      - `load-stats/label/docker/sec10.csv`

      - `load-stats/label/job-dsl/gnuplot`

      - `load-stats/label/job-dsl/hour.csv`

      - `load-stats/label/job-dsl/min.csv`

      - `load-stats/label/job-dsl/sec10.csv`

      - `load-stats/label/master/gnuplot`

      - `load-stats/label/master/hour.csv`

      - `load-stats/label/master/min.csv`

      - `load-stats/label/master/sec10.csv`

      - `load-stats/label/server10.local/gnuplot`

      - `load-stats/label/server10.local/hour.csv`

      - `load-stats/label/server10.local/min.csv`

      - `load-stats/label/server10.local/sec10.csv`

      - `load-stats/label/server11.local/gnuplot`

      - `load-stats/label/server11.local/hour.csv`

      - `load-stats/label/server11.local/min.csv`

      - `load-stats/label/server11.local/sec10.csv`

      - `load-stats/label/server5.local/gnuplot`

      - `load-stats/label/server5.local/hour.csv`

      - `load-stats/label/server5.local/min.csv`

      - `load-stats/label/server5.local/sec10.csv`

      - `load-stats/label/server6.local/gnuplot`

      - `load-stats/label/server6.local/hour.csv`

      - `load-stats/label/server6.local/min.csv`

      - `load-stats/label/server6.local/sec10.csv`

      - `load-stats/label/server7.local/gnuplot`

      - `load-stats/label/server7.local/hour.csv`

      - `load-stats/label/server7.local/min.csv`

      - `load-stats/label/server7.local/sec10.csv`

      - `load-stats/label/server8.local/gnuplot`

      - `load-stats/label/server8.local/hour.csv`

      - `load-stats/label/server8.local/min.csv`

      - `load-stats/label/server8.local/sec10.csv`

      - `load-stats/label/server9.local/gnuplot`

      - `load-stats/label/server9.local/hour.csv`

      - `load-stats/label/server9.local/min.csv`

      - `load-stats/label/server9.local/sec10.csv`

      - `load-stats/no-label/gnuplot`

      - `load-stats/no-label/hour.csv`

      - `load-stats/no-label/min.csv`

      - `load-stats/no-label/sec10.csv`

      - `load-stats/overall/gnuplot`

      - `load-stats/overall/hour.csv`

      - `load-stats/overall/min.csv`

      - `load-stats/overall/sec10.csv`

  * All loggers currently enabled.

      - `loggers.md`

  * Metrics

      - `nodes/master/metrics.json`

      - `nodes/slave/server10.local/metrics.json`

      - `nodes/slave/server11.local/metrics.json`

      - `nodes/slave/server5.local/metrics.json`

      - `nodes/slave/server6.local/metrics.json`

      - `nodes/slave/server7.local/metrics.json`

      - `nodes/slave/server8.local/metrics.json`

      - `nodes/slave/server9.local/metrics.json`

  * Networking Interface

      - `nodes/master/networkInterface.md`

      - `nodes/slave/server10.local/networkInterface.md`

      - `nodes/slave/server11.local/networkInterface.md`

      - `nodes/slave/server5.local/networkInterface.md`

      - `nodes/slave/server6.local/networkInterface.md`

      - `nodes/slave/server7.local/networkInterface.md`

      - `nodes/slave/server8.local/networkInterface.md`

      - `nodes/slave/server9.local/networkInterface.md`

  * Node monitors

      - `node-monitors.md`

  * System configuration (Linux only)

      - `nodes/master/dmesg.txt`

      - `nodes/master/dmi.txt`

      - `nodes/master/proc/cpuinfo.txt`

      - `nodes/master/proc/mounts.txt`

      - `nodes/master/proc/net/rpc/nfs.txt`

      - `nodes/master/proc/net/rpc/nfsd.txt`

      - `nodes/master/proc/swaps.txt`

      - `nodes/master/proc/system-uptime.txt`

      - `nodes/master/sysctl.txt`

      - `nodes/master/userid.txt`

      - `nodes/slave/server10.local/dmesg.txt`

      - `nodes/slave/server10.local/dmi.txt`

      - `nodes/slave/server10.local/proc/cpuinfo.txt`

      - `nodes/slave/server10.local/proc/mounts.txt`

      - `nodes/slave/server10.local/proc/net/rpc/nfs.txt`

      - `nodes/slave/server10.local/proc/net/rpc/nfsd.txt`

      - `nodes/slave/server10.local/proc/swaps.txt`

      - `nodes/slave/server10.local/proc/system-uptime.txt`

      - `nodes/slave/server10.local/sysctl.txt`

      - `nodes/slave/server10.local/userid.txt`

      - `nodes/slave/server11.local/dmesg.txt`

      - `nodes/slave/server11.local/dmi.txt`

      - `nodes/slave/server11.local/proc/cpuinfo.txt`

      - `nodes/slave/server11.local/proc/mounts.txt`

      - `nodes/slave/server11.local/proc/net/rpc/nfs.txt`

      - `nodes/slave/server11.local/proc/net/rpc/nfsd.txt`

      - `nodes/slave/server11.local/proc/swaps.txt`

      - `nodes/slave/server11.local/proc/system-uptime.txt`

      - `nodes/slave/server11.local/sysctl.txt`

      - `nodes/slave/server11.local/userid.txt`

      - `nodes/slave/server5.local/dmesg.txt`

      - `nodes/slave/server5.local/dmi.txt`

      - `nodes/slave/server5.local/proc/cpuinfo.txt`

      - `nodes/slave/server5.local/proc/mounts.txt`

      - `nodes/slave/server5.local/proc/net/rpc/nfs.txt`

      - `nodes/slave/server5.local/proc/net/rpc/nfsd.txt`

      - `nodes/slave/server5.local/proc/swaps.txt`

      - `nodes/slave/server5.local/proc/system-uptime.txt`

      - `nodes/slave/server5.local/sysctl.txt`

      - `nodes/slave/server5.local/userid.txt`

      - `nodes/slave/server6.local/dmesg.txt`

      - `nodes/slave/server6.local/dmi.txt`

      - `nodes/slave/server6.local/proc/cpuinfo.txt`

      - `nodes/slave/server6.local/proc/mounts.txt`

      - `nodes/slave/server6.local/proc/net/rpc/nfs.txt`

      - `nodes/slave/server6.local/proc/net/rpc/nfsd.txt`

      - `nodes/slave/server6.local/proc/swaps.txt`

      - `nodes/slave/server6.local/proc/system-uptime.txt`

      - `nodes/slave/server6.local/sysctl.txt`

      - `nodes/slave/server6.local/userid.txt`

      - `nodes/slave/server7.local/dmesg.txt`

      - `nodes/slave/server7.local/dmi.txt`

      - `nodes/slave/server7.local/proc/cpuinfo.txt`

      - `nodes/slave/server7.local/proc/mounts.txt`

      - `nodes/slave/server7.local/proc/net/rpc/nfs.txt`

      - `nodes/slave/server7.local/proc/net/rpc/nfsd.txt`

      - `nodes/slave/server7.local/proc/swaps.txt`

      - `nodes/slave/server7.local/proc/system-uptime.txt`

      - `nodes/slave/server7.local/sysctl.txt`

      - `nodes/slave/server7.local/userid.txt`

      - `nodes/slave/server8.local/dmesg.txt`

      - `nodes/slave/server8.local/dmi.txt`

      - `nodes/slave/server8.local/proc/cpuinfo.txt`

      - `nodes/slave/server8.local/proc/mounts.txt`

      - `nodes/slave/server8.local/proc/net/rpc/nfs.txt`

      - `nodes/slave/server8.local/proc/net/rpc/nfsd.txt`

      - `nodes/slave/server8.local/proc/swaps.txt`

      - `nodes/slave/server8.local/proc/system-uptime.txt`

      - `nodes/slave/server8.local/sysctl.txt`

      - `nodes/slave/server8.local/userid.txt`

      - `nodes/slave/server9.local/dmesg.txt`

      - `nodes/slave/server9.local/dmi.txt`

      - `nodes/slave/server9.local/proc/cpuinfo.txt`

      - `nodes/slave/server9.local/proc/mounts.txt`

      - `nodes/slave/server9.local/proc/net/rpc/nfs.txt`

      - `nodes/slave/server9.local/proc/net/rpc/nfsd.txt`

      - `nodes/slave/server9.local/proc/swaps.txt`

      - `nodes/slave/server9.local/proc/system-uptime.txt`

      - `nodes/slave/server9.local/sysctl.txt`

      - `nodes/slave/server9.local/userid.txt`

  * System properties

      - `nodes/master/system.properties`

      - `nodes/slave/server10.local/system.properties`

      - `nodes/slave/server11.local/system.properties`

      - `nodes/slave/server5.local/system.properties`

      - `nodes/slave/server6.local/system.properties`

      - `nodes/slave/server7.local/system.properties`

      - `nodes/slave/server8.local/system.properties`

      - `nodes/slave/server9.local/system.properties`

  * Update Center

      - `update-center.md`

  * Slow Request Records

  * Deadlock Records

  * Thread dumps

      - `nodes/master/thread-dump.txt`

      - `nodes/slave/server10.local/thread-dump.txt`

      - `nodes/slave/server11.local/thread-dump.txt`

      - `nodes/slave/server5.local/thread-dump.txt`

      - `nodes/slave/server6.local/thread-dump.txt`

      - `nodes/slave/server7.local/thread-dump.txt`

      - `nodes/slave/server8.local/thread-dump.txt`

      - `nodes/slave/server9.local/thread-dump.txt`


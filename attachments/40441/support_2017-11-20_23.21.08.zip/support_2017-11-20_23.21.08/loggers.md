Loggers currently enabled
=========================
org.apache.sshd - WARNING
hudson.plugins.jira.JiraRestService - ALL
winstone - INFO

User
====

Authentication
--------------

  * Authenticated: true
  * Name: saville
  * Authorities 
      - `authenticated`
  * Raw: `org.jenkinsci.plugins.GithubAuthenticationToken@52260943: Username: admin; Password: [PROTECTED]; Authenticated: true; Details: null; Granted Authorities: authenticated`


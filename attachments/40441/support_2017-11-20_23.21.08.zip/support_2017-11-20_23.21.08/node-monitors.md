Node monitors
=============
Architecture
----
 - Is Ignored: false
 - Computers:
   * master: Linux (amd64)
   * server10.local: Linux (amd64)
   * server11.local: Linux (amd64)
   * server5.local: Linux (amd64)
   * server6.local: Linux (amd64)
   * server7.local: Linux (amd64)
   * server8.local: Linux (amd64)
   * server9.local: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * master: In sync
   * server10.local: In sync
   * server11.local: In sync
   * server5.local: In sync
   * server6.local: In sync
   * server7.local: In sync
   * server8.local: In sync
   * server9.local: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 137.242GB left on /raid/jenkins.
   * server10.local: Disk space is too low. Only 62.158GB left on /home/slaveuser/jenkins.
   * server11.local: Disk space is too low. Only 91.118GB left on /home/slaveuser/jenkins.
   * server5.local: Disk space is too low. Only 67.878GB left on /home/slaveuser/jenkins.
   * server6.local: Disk space is too low. Only 87.242GB left on /home/slaveuser/jenkins.
   * server7.local: Disk space is too low. Only 53.790GB left on /home/slaveuser/jenkins.
   * server8.local: Disk space is too low. Only 45.555GB left on /home/slaveuser/jenkins.
   * server9.local: Disk space is too low. Only 74.128GB left on /home/slaveuser/jenkins.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * master: Memory:1435/32012MB  Swap:3511/4095MB
   * server10.local: Memory:7602/23948MB  Swap:3728/4095MB
   * server11.local: Memory:12605/23948MB  Swap:3702/4095MB
   * server5.local: Memory:3274/23947MB  Swap:3945/4095MB
   * server6.local: Memory:9038/23948MB  Swap:2754/4095MB
   * server7.local: Memory:13281/23948MB  Swap:4054/4095MB
   * server8.local: Memory:8285/23948MB  Swap:3866/4095MB
   * server9.local: Memory:11757/23948MB  Swap:3592/4095MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * master: Disk space is too low. Only 2.687GB left on /var/lib/jenkins/tmp.
   * server10.local: Disk space is too low. Only 62.158GB left on /tmp.
   * server11.local: Disk space is too low. Only 91.118GB left on /tmp.
   * server5.local: Disk space is too low. Only 67.878GB left on /tmp.
   * server6.local: Disk space is too low. Only 87.242GB left on /tmp.
   * server7.local: Disk space is too low. Only 53.790GB left on /tmp.
   * server8.local: Disk space is too low. Only 45.555GB left on /tmp.
   * server9.local: Disk space is too low. Only 74.128GB left on /tmp.
Response Time
----
 - Is Ignored: false
 - Computers:
   * master: 0ms
   * server10.local: 5ms
   * server11.local: 5ms
   * server5.local: 7ms
   * server6.local: 5ms
   * server7.local: 6ms
   * server8.local: 5ms
   * server9.local: 3ms

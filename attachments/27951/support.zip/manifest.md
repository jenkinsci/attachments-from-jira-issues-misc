Support Bundle Manifest
=======================

Generated on 2014-11-06 05:02:34 +0000

Requested components:

  * About Jenkins

      - `about.md`

      - `items.md`

      - `nodes.md`

      - `nodes/master/checksums.md5`

      - `plugins/active.txt`

      - `plugins/disabled.txt`

      - `plugins/failed.txt`


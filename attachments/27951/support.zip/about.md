Jenkins
=======

Version details
---------------

  * Version: `1.573`
  * Mode:    WAR
  * Servlet container
      - Specification: 3.0
      - Name:          `jetty/8.y.z-SNAPSHOT`
  * Java
      - Home:           `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65.x86_64/jre`
      - Vendor:           Oracle Corporation
      - Version:          1.7.0_65
      - Maximum memory:   1.27 GB (1364721664)
      - Allocated memory: 544.00 MB (570425344)
      - Free memory:      213.18 MB (223538688)
      - In-use memory:    330.82 MB (346886656)
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.7
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Oracle Corporation
      - Version: 24.65-b04
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      2.6.32-431.29.2.el6.x86_64
      - Distribution: "CentOS release 6.5 (Final)"
      - LSB Modules:  `:base-4.0-amd64:base-4.0-noarch:core-4.0-amd64:core-4.0-noarch:graphics-4.0-amd64:graphics-4.0-noarch:printing-4.0-amd64:printing-4.0-noarch`
  * Process ID: 831 (0x33f)
  * Process started: 2014-11-06 17:01:34.828+0000
  * Process uptime: 59 sec
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65.x86_64/jre/lib/rhino.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.7.0-openjdk-1.7.0.65.x86_64/jre/classes`
      - Classpath: `/opt/jenkins/jenkins.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-DJENKINS_HOME=/opt/jenkins`

Important configuration
---------------

  * Security realm: `hudson.security.LDAPSecurityRealm`
  * Authorization strategy: `hudson.security.GlobalMatrixAuthorizationStrategy`

Active Plugins
--------------

  * analysis-collector:1.41 'Static Analysis Collector Plug-in'
  * analysis-core:1.62 *(update available)* 'Static Analysis Utilities'
  * ant:1.2 'Ant Plugin'
  * antisamy-markup-formatter:1.1 *(update available)* 'OWASP Markup Formatter Plugin'
  * any-buildstep:0.1 'Any Build Step Plugin'
  * build-flow-plugin:0.12 *(update available)* 'CloudBees Build Flow plugin'
  * build-timeout:1.14 'Jenkins build timeout plugin'
  * conditional-buildstep:1.3.3 'conditional-buildstep'
  * copyartifact:1.31 *(update available)* 'Copy Artifact Plugin'
  * credentials:1.15 *(update available)* 'Credentials Plugin'
  * cvs:2.11 *(update available)* 'Jenkins CVS Plug-in'
  * dashboard-view:2.9.4 'Dashboard View'
  * docker-plugin:0.6.2 *(update available)* 'Docker plugin'
  * external-monitor-job:1.2 'External Monitor Job Type Plugin'
  * findbugs:4.57 'FindBugs Plug-in'
  * flexible-publish:0.12 'Flexible Publish Plugin'
  * greenballs:1.14 'Green Balls'
  * jacoco:1.0.16 'Jenkins JaCoCo plugin'
  * javadoc:1.1 *(update available)* 'Javadoc Plugin'
  * jclouds-jenkins:2.8 'Jenkins JClouds plugin'
  * jquery:1.7.2-1 'Jenkins jQuery plugin'
  * ldap:1.10.2 *(update available)* 'LDAP Plugin'
  * mailer:1.8 *(update available)* 'Jenkins Mailer Plugin'
  * matrix-auth:1.1 *(update available)* 'Matrix Authorization Strategy Plugin'
  * matrix-project:1.2 *(update available)* 'Matrix Project Plugin'
  * maven-plugin:2.5 *(update available)* 'Maven Integration plugin'
  * metrics:3.0.7 'Metrics Plugin'
  * pam-auth:1.1 *(update available)* 'PAM Authentication plugin'
  * parameterized-trigger:2.25 'Jenkins Parameterized Trigger plugin'
  * postbuild-task:1.8 'Hudson Post build task'
  * rad-builder:1.1.4 'RAD Builder Plugin'
  * run-condition:1.0 'Run Condition Plugin'
  * ssh-credentials:1.7.1 *(update available)* 'SSH Credentials Plugin'
  * ssh-slaves:1.6 *(update available)* 'Jenkins SSH Slaves plugin'
  * subversion:1.54 *(update available)* 'Jenkins Subversion Plug-in'
  * support-core:2.18 'Support Core Plugin'
  * teamconcert:1.1.8 *(update available)* 'Team Concert Plugin'
  * token-macro:1.10 'Token Macro Plugin'
  * translation:1.10 *(update available)* 'Jenkins Translation Assistance plugin'
  * warnings:4.42 *(update available)* 'Warnings Plug-in'
  * windows-slaves:1.0 'Windows Slaves Plugin'

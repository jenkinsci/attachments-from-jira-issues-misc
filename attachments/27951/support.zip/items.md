Item statistics
===============

  * `hudson.model.FreeStyleProject`
    - Number of items: 15
    - Number of builds per job: 51.13333333333333 [n=15, s=90.0]

Total job statistics
======================

  * Number of jobs: 15
  * Number of builds per job: 51.13333333333333 [n=15, s=90.0]

package sample.integration.test;

import junit.framework.TestCase;
import sample.Adder;

public class AdderIntegrationTest extends TestCase
{
	public void testAdd()
	{
		Adder add = new Adder();

		int x = 5;
		int y = 7;
		int expected = 12;

		assertEquals("Add didn't work!", add.add(x, y), expected);
	}
}

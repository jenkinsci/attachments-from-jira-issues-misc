package sample;

public class Adder
{
	public int add(int x, int y)
	{
		return x + y;
	}
}

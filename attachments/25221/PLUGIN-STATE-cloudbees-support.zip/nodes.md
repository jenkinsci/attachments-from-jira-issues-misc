Build Nodes
===========

  * master (Jenkins)
      - Description:    `the master Jenkins node`
      - Executors:      1
      - Remote FS root: `E:\Jenkins`
      - Labels:         (none)
      - Usage:          Leave this machine for tied jobs only
      - Java
          + Home:           `E:\Java\jdk1.7.0_40\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_40
          + Maximum memory:   380.50 MB (398983168)
          + Allocated memory: 380.50 MB (398983168)
          + Free memory:      157.14 MB (164778160)
          + In-use memory:    223.36 MB (234205008)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.0-b56
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 3280 (0xcd0)
      - Process started: 2014-01-28 15:08:50.512-0500
      - Process uptime: 1 day 18 hr
      - JVM startup parameters:
          + Boot classpath: `E:\Java\jdk1.7.0_40\jre\lib\resources.jar;E:\Java\jdk1.7.0_40\jre\lib\rt.jar;E:\Java\jdk1.7.0_40\jre\lib\sunrsasign.jar;E:\Java\jdk1.7.0_40\jre\lib\jsse.jar;E:\Java\jdk1.7.0_40\jre\lib\jce.jar;E:\Java\jdk1.7.0_40\jre\lib\charsets.jar;E:\Java\jdk1.7.0_40\jre\lib\jfr.jar;E:\Java\jdk1.7.0_40\jre\classes;E:\introscope9550A\wily\Agent.jar`
          + Classpath: `E:\Jenkins\jenkins.war;E:/introscope9550A/wily/Agent.jar`
          + Library path: `E:\Java\jdk1.7.0_40\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\Java\jdk1.7.0_40\bin;E:\AccuRev\601\bin;.`
          + arg[0]: `-javaagent:E:/introscope9550A/wily/Agent.jar`
          + arg[1]: `-Dintroscope.agent.customProcessName=Jenkins`
          + arg[2]: `-Dintroscope.agent.agentName=Jenkins`
          + arg[3]: `-Dcom.wily.introscope.agentProfile=E:/introscope9550A/wily/core/config/IntroscopeAgent-FULL-TEST.profile`
          + arg[4]: `-Xrs`
          + arg[5]: `-Xms384m`
          + arg[6]: `-Xmx386m`
          + arg[7]: `-XX:MaxPermSize=128m`
          + arg[8]: `-XX:+HeapDumpOnOutOfMemoryError`
          + arg[9]: `-Xloggc:E:\Jenkins/verbosegc.log`
          + arg[10]: `-XX:+UseGCLogFileRotation`
          + arg[11]: `-XX:NumberOfGCLogFiles=3`
          + arg[12]: `-XX:GCLogFileSize=5M`
          + arg[13]: `-XX:+PrintGCDetails`
          + arg[14]: `-XX:+PrintGCDateStamps`
          + arg[15]: `-XX:-TraceClassUnloading`
          + arg[16]: `-Dhudson.DNSMultiCast.disabled=true`
          + arg[17]: `-Dhudson.model.DownloadService.never=true`
          + arg[18]: `-Dhudson.model.UpdateCenter.never=true`
          + arg[19]: `-Dhudson.security.ExtendedReadPermission=true`
          + arg[20]: `-Dhudson.Util.noSymLink=true`
          + arg[21]: `-Djava.io.tmpdir=E:\TEMP`
          + arg[22]: `-Dhudson.lifecycle=hudson.lifecycle.WindowsServiceLifecycle`

  * Java-002 (Dumb Slave)
      - Description:    `JEE Build Slave`
      - Executors:      2
      - Remote FS root: `E:\Jenkins`
      - Labels:         Java Broker Coverity
      - Usage:          Utilize this slave as much as possible
      - Launch method:  Launch slave agents via Java Web Start
      - Availability:   Keep this slave on-line as much as possible
      - Status:         on-line
      - Version:        2.32
      - Java
          + Home:           `E:\Java\jdk1.7.0_40\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_40
          + Maximum memory:   910.50 MB (954728448)
          + Allocated memory: 59.00 MB (61865984)
          + Free memory:      42.12 MB (44161000)
          + In-use memory:    16.88 MB (17704984)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.0-b56
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 5076 (0x13d4)
      - Process started: 2014-01-29 00:06:07.415-0500
      - Process uptime: 1 day 9 hr
      - JVM startup parameters:
          + Boot classpath: `E:\Java\jdk1.7.0_40\jre\lib\resources.jar;E:\Java\jdk1.7.0_40\jre\lib\rt.jar;E:\Java\jdk1.7.0_40\jre\lib\sunrsasign.jar;E:\Java\jdk1.7.0_40\jre\lib\jsse.jar;E:\Java\jdk1.7.0_40\jre\lib\jce.jar;E:\Java\jdk1.7.0_40\jre\lib\charsets.jar;E:\Java\jdk1.7.0_40\jre\lib\jfr.jar;E:\Java\jdk1.7.0_40\jre\classes`
          + Classpath: `E:\Jenkins\slave.jar`
          + Library path: `E:\Java\jdk1.7.0_40\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\Java\jdk1.7.0_40\bin;E:\Accurev\601\bin;.`
          + arg[0]: `-Xrs`
          + arg[1]: `-Djava.io.tmpdir=E:\TEMP`

  * dotNET-005 (Dumb Slave)
      - Description:    `.NET Build Slave`
      - Executors:      2
      - Remote FS root: `E:\Jenkins`
      - Labels:         .NET
      - Usage:          Utilize this slave as much as possible
      - Launch method:  Launch slave agents via Java Web Start
      - Availability:   Keep this slave on-line as much as possible
      - Status:         on-line
      - Version:        2.32
      - Java
          + Home:           `E:\Java\jdk1.7.0_40\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_40
          + Maximum memory:   494.94 MB (518979584)
          + Allocated memory: 31.06 MB (32571392)
          + Free memory:      24.68 MB (25882248)
          + In-use memory:    6.38 MB (6689144)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.0-b56
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 1572 (0x624)
      - Process started: 2014-01-22 20:08:15.759-0500
      - Process uptime: 7 days 13 hr
      - JVM startup parameters:
          + Boot classpath: `E:\Java\jdk1.7.0_40\jre\lib\resources.jar;E:\Java\jdk1.7.0_40\jre\lib\rt.jar;E:\Java\jdk1.7.0_40\jre\lib\sunrsasign.jar;E:\Java\jdk1.7.0_40\jre\lib\jsse.jar;E:\Java\jdk1.7.0_40\jre\lib\jce.jar;E:\Java\jdk1.7.0_40\jre\lib\charsets.jar;E:\Java\jdk1.7.0_40\jre\lib\jfr.jar;E:\Java\jdk1.7.0_40\jre\classes`
          + Classpath: `E:\Jenkins\slave.jar`
          + Library path: `E:\Java\jdk1.7.0_40\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\Java\jdk1.7.0_40\bin;E:\AccuRev\601\bin;C:\Program Files (x86)\Microsoft SQL Server\110\Tools\Binn\ManagementStudio\;C:\Program Files (x86)\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files\Microsoft SQL Server\110\Tools\Binn\;C:\Program Files (x86)\Microsoft Visual Studio 10.0\Common7\IDE\PrivateAssemblies\;C:\Program Files (x86)\Microsoft SQL Server\110\DTS\Binn\;.`
          + arg[0]: `-Xrs`
          + arg[1]: `-Djava.io.tmpdir=E:\TEMP`

  * Deploy-101 (Dumb Slave)
      - Description:    `WIA Deploy Server`
      - Executors:      2
      - Remote FS root: `E:\Jenkins`
      - Labels:         WIA
      - Usage:          Utilize this slave as much as possible
      - Launch method:  Launch slave agents via Java Web Start
      - Availability:   Keep this slave on-line as much as possible
      - Status:         on-line
      - Version:        2.32
      - Java
          + Home:           `E:\Java\jdk1.7.0_40\jre`
          + Vendor:           Oracle Corporation
          + Version:          1.7.0_40
          + Maximum memory:   455.00 MB (477102080)
          + Allocated memory: 29.00 MB (30408704)
          + Free memory:      19.52 MB (20471648)
          + In-use memory:    9.48 MB (9937056)
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.7
      - JVM Implementation
          + Name:    Java HotSpot(TM) 64-Bit Server VM
          + Vendor:  Oracle Corporation
          + Version: 24.0-b56
      - Operating system
          + Name:         Windows Server 2008 R2
          + Architecture: amd64
          + Version:      6.1
      - Process ID: 3112 (0xc28)
      - Process started: 2014-01-22 00:00:48.117-0500
      - Process uptime: 8 days 9 hr
      - JVM startup parameters:
          + Boot classpath: `E:\Java\jdk1.7.0_40\jre\lib\resources.jar;E:\Java\jdk1.7.0_40\jre\lib\rt.jar;E:\Java\jdk1.7.0_40\jre\lib\sunrsasign.jar;E:\Java\jdk1.7.0_40\jre\lib\jsse.jar;E:\Java\jdk1.7.0_40\jre\lib\jce.jar;E:\Java\jdk1.7.0_40\jre\lib\charsets.jar;E:\Java\jdk1.7.0_40\jre\lib\jfr.jar;E:\Java\jdk1.7.0_40\jre\classes`
          + Classpath: `E:\Jenkins\slave.jar`
          + Library path: `E:\Java\jdk1.7.0_40\bin;C:\Windows\Sun\Java\bin;C:\Windows\system32;C:\Windows;C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem;C:\Windows\System32\WindowsPowerShell\v1.0\;E:\Java\jdk1.7.0_40\bin;E:\AccuRev\601\bin;.`
          + arg[0]: `-Xrs`
          + arg[1]: `-Djava.io.tmpdir=E:\TEMP`


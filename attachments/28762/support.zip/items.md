Item statistics
===============

  * `hudson.matrix.MatrixConfiguration`
    - Number of items: 2
    - Number of builds per job: 4.0 [n=2, s=0.0]
  * `hudson.matrix.MatrixProject`
    - Number of items: 1
    - Number of builds per job: 4 [n=1]
    - Number of items per container: 2 [n=1]
  * `hudson.model.FreeStyleProject`
    - Number of items: 79
    - Number of builds per job: 0.8481012658227848 [n=79, s=1.0]

Total job statistics
======================

  * Number of jobs: 82
  * Number of builds per job: 0.9634146341463414 [n=82, s=1.0]

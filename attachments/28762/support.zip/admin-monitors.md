Monitors
========

`OldData`
--------------
  * Problematic object: `hudson.model.FreeStyleProject@5725272[tests-thefactory-currentBuildParams_trigger_B]`
    - MissingFieldException: No field 'ignoreDirPropChanges' found in class 'hudson.scm.SubversionSCM', MissingFieldException: No field 'filterChangelog' found in class 'hudson.scm.SubversionSCM'
  * Problematic object: `hudson.model.FreeStyleProject@4cdd4cfc[tests-thefactory-bugzilla_link]`
    - MissingFieldException: No field 'ignoreDirPropChanges' found in class 'hudson.scm.SubversionSCM', MissingFieldException: No field 'filterChangelog' found in class 'hudson.scm.SubversionSCM'
  * Problematic object: `hudson.model.FreeStyleProject@43144be7[tests-thefactory-svn_trigger_B]`
    - MissingFieldException: No field 'ignoreDirPropChanges' found in class 'hudson.scm.SubversionSCM', MissingFieldException: No field 'filterChangelog' found in class 'hudson.scm.SubversionSCM'
  * Problematic object: `hudson.model.FreeStyleProject@b88381d[tests-thefactory-predefined_trigger_B_unstable]`
    - MissingFieldException: No field 'ignoreDirPropChanges' found in class 'hudson.scm.SubversionSCM', MissingFieldException: No field 'filterChangelog' found in class 'hudson.scm.SubversionSCM'
  * Problematic object: `hudson.model.FreeStyleProject@73517ae8[tests-thefactory-keep_build_forever]`
    - DuplicateFieldException: logRotator
---- Debugging information ----
duplicate-field     : logRotator
-------------------------------
  * Problematic object: `hudson.model.FreeStyleProject@7f4c17f7[tests-thefactory-predefined_trigger_B]`
    - MissingFieldException: No field 'ignoreDirPropChanges' found in class 'hudson.scm.SubversionSCM', MissingFieldException: No field 'filterChangelog' found in class 'hudson.scm.SubversionSCM'
  * Problematic object: `hudson.model.FreeStyleProject@430a9005[tests-thefactory-currentBuildParams_trigger_B_unstable]`
    - MissingFieldException: No field 'ignoreDirPropChanges' found in class 'hudson.scm.SubversionSCM', MissingFieldException: No field 'filterChangelog' found in class 'hudson.scm.SubversionSCM'
  * Problematic object: `hudson.model.FreeStyleProject@60df2ae0[tests-thefactory-svn_trigger_A]`
    - MissingFieldException: No field 'ignoreDirPropChanges' found in class 'hudson.scm.SubversionSCM', MissingFieldException: No field 'filterChangelog' found in class 'hudson.scm.SubversionSCM'

`jenkins.diagnostics.PinningIsBlockingBundledPluginMonitor`
--------------
(active and enabled)

`jenkins.diagnostics.SecurityIsOffMonitor`
--------------
(active and enabled)

`jenkins.model.DownloadSettings$Warning`
--------------
(active and enabled)

Browser
=======

  * Screen size: 1440x900
  * User Agent
      - Type:     Browser
      - Name:     Firefox
      - Family:   FIREFOX
      - Producer: Mozilla Foundation
      - Version:  36.0
      - Raw:      `Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:36.0) Gecko/20100101 Firefox/36.0`
  * Operating System
      - Name:     OS X
      - Family:   OS_X
      - Producer: Apple Computer, Inc.
      - Version:  10.10


JENKINS_HOME=/home/jgarcia/SECOs/SECO-4569/latestOSS/jenkins-home  java \
-Djavax.net.ssl.trustStore=trustStore.jks -Djavax.net.ssl.trustStorePassword=JENKINS-75676 -Djavax.net.debug=ssl \
-Xms256m -jar ./jenkins.war --httpPort=8090 --httpListenAddress=127.0.0.1
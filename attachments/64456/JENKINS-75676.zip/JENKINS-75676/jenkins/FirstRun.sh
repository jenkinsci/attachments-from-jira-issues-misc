JENKINS_HOME=./jenkins-home  java \
-Xms256m -jar ./jenkins.war --httpPort=8090 --httpListenAddress=127.0.0.1